@echo off
setlocal
title Network Snapshot
set "LOGDIR=%~dp0..\Logs"
if not exist "%LOGDIR%" mkdir "%LOGDIR%"
set "LOG=%LOGDIR%\%COMPUTERNAME%_Network_%RANDOM%.txt"
echo Collecting network information...
(
echo NETWORK SNAPSHOT - %COMPUTERNAME% - %DATE% %TIME%
echo.
echo ===== IPCONFIG /ALL =====
ipconfig /all
echo.
echo ===== ROUTE PRINT =====
route print
echo.
echo ===== ARP TABLE =====
arp -a
echo.
echo ===== ACTIVE CONNECTIONS =====
netstat -ano
echo.
echo ===== DNS CACHE =====
ipconfig /displaydns
) > "%LOG%" 2>&1
echo.

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\00_Common\Convert-TextReport.ps1" -TextPath "%LOG%" -Title "%~n0"


echo Saved to: %LOG%
if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)
endlocal

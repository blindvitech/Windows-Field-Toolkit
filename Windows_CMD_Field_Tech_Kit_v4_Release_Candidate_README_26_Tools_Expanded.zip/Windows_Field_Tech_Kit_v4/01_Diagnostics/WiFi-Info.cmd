@echo off
setlocal
title Wi-Fi Information
set "LOGDIR=%~dp0..\Logs"
if not exist "%LOGDIR%" mkdir "%LOGDIR%"
set "LOG=%LOGDIR%\%COMPUTERNAME%_WiFi_%RANDOM%.txt"
echo Collecting Wi-Fi information...
(
echo WI-FI INFORMATION - %COMPUTERNAME% - %DATE% %TIME%
echo.
echo ===== WLAN INTERFACES =====
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\00_Common\Invoke-Native-Bridge.ps1" -FilePath "netsh.exe" -Label "WLAN Interfaces" wlan show interfaces
echo.
echo ===== WLAN DRIVERS =====
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\00_Common\Invoke-Native-Bridge.ps1" -FilePath "netsh.exe" -Label "WLAN Drivers" wlan show drivers
echo.
echo ===== SAVED PROFILE NAMES - NO PASSWORDS EXPORTED =====
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\00_Common\Invoke-Native-Bridge.ps1" -FilePath "netsh.exe" -Label "WLAN Profile Names" wlan show profiles
) > "%LOG%" 2>&1
echo.

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\00_Common\Convert-TextReport.ps1" -TextPath "%LOG%" -Title "%~n0"


echo Saved to: %LOG%
if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)
endlocal

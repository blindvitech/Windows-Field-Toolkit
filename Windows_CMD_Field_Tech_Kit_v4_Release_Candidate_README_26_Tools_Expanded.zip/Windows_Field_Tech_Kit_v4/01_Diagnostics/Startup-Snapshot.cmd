@echo off
setlocal
title Startup Snapshot
set "LOGDIR=%~dp0..\Logs"
if not exist "%LOGDIR%" mkdir "%LOGDIR%"
set "LOG=%LOGDIR%\%COMPUTERNAME%_Startup_%RANDOM%.txt"
(
echo STARTUP SNAPSHOT
echo Computer: %COMPUTERNAME%
echo Date: %DATE% %TIME%
echo.
echo ===== CURRENT USER RUN =====
reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\Run"
echo.
echo ===== LOCAL MACHINE RUN =====
reg query "HKLM\Software\Microsoft\Windows\CurrentVersion\Run"
echo.
echo ===== 32-BIT LOCAL MACHINE RUN =====
reg query "HKLM\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Run"
echo.
echo ===== SCHEDULED TASKS =====
schtasks /query /fo LIST /v
) > "%LOG%" 2>&1

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\00_Common\Convert-TextReport.ps1" -TextPath "%LOG%" -Title "%~n0"


echo Saved to:
echo %LOG%
if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)
endlocal

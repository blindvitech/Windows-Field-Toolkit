@echo off
setlocal
title Quick Windows Health Snapshot
set "LOGDIR=%~dp0..\Logs"
if not exist "%LOGDIR%" mkdir "%LOGDIR%"
set "LOG=%LOGDIR%\%COMPUTERNAME%_QuickHealth_%RANDOM%.txt"
(
echo ============================================================
echo QUICK WINDOWS HEALTH SNAPSHOT
echo Computer: %COMPUTERNAME%
echo User: %USERNAME%
echo Date: %DATE% %TIME%
echo ============================================================
echo.
echo ===== WINDOWS VERSION =====
ver
systeminfo | findstr /B /C:"OS Name" /C:"OS Version" /C:"System Model" /C:"System Type" /C:"Total Physical Memory"
echo.
echo ===== BOOT TIME =====
systeminfo | findstr /C:"System Boot Time"
echo.
echo ===== DISK SPACE =====
wmic logicaldisk get caption,freespace,size 2>nul
echo.
echo ===== NETWORK =====
ipconfig
echo.
echo ===== BITLOCKER =====
manage-bde -status 2>nul
echo.
echo ===== ACTIVATION =====
cscript //nologo %windir%\system32\slmgr.vbs /xpr
) > "%LOG%" 2>&1

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\00_Common\Convert-TextReport.ps1" -TextPath "%LOG%" -Title "%~n0"


echo Saved to:
echo %LOG%
if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)
endlocal

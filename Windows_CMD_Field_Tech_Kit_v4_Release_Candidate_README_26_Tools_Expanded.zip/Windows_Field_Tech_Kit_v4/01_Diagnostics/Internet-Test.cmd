@echo off
title Internet and DNS Test
echo [1/5] Local TCP/IP stack...
ping -n 2 127.0.0.1
echo.
echo [2/5] Cloudflare IPv4 reachability...
ping -n 4 1.1.1.1
echo.
echo [3/5] Google DNS IPv4 reachability...
ping -n 4 8.8.8.8
echo.
echo [4/5] DNS lookup...
nslookup www.microsoft.com
echo.
echo [5/5] Name-based ping...
ping -n 4 www.microsoft.com
echo.
if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

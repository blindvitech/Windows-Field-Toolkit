@echo off
setlocal
title System Snapshot
set "LOGDIR=%~dp0..\Logs"
if not exist "%LOGDIR%" mkdir "%LOGDIR%"
set "LOG=%LOGDIR%\%COMPUTERNAME%_System_%RANDOM%.txt"
echo Collecting system information...
(
echo SYSTEM SNAPSHOT - %COMPUTERNAME% - %DATE% %TIME%
echo.
echo ===== SYSTEMINFO =====
systeminfo
echo.
echo ===== DRIVERQUERY =====
driverquery /v
echo.
echo ===== RUNNING TASKS =====
tasklist
echo.
echo ===== STORAGE =====
fsutil fsinfo drives
echo.
echo ===== WINDOWS LICENSE STATUS =====
cscript //nologo %windir%\system32\slmgr.vbs /dli
) > "%LOG%" 2>&1
echo.

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\00_Common\Convert-TextReport.ps1" -TextPath "%LOG%" -Title "%~n0"


echo Saved to: %LOG%
if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)
endlocal

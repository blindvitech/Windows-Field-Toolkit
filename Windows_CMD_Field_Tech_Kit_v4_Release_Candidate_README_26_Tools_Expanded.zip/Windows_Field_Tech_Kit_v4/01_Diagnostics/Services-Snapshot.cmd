@echo off
setlocal
title Services Snapshot
set "LOGDIR=%~dp0..\Logs"
if not exist "%LOGDIR%" mkdir "%LOGDIR%"
set "LOG=%LOGDIR%\%COMPUTERNAME%_Services_%RANDOM%.txt"
(
echo SERVICES SNAPSHOT
echo Computer: %COMPUTERNAME%
echo Date: %DATE% %TIME%
echo.
sc query type= service state= all
) > "%LOG%" 2>&1

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\00_Common\Convert-TextReport.ps1" -TextPath "%LOG%" -Title "%~n0"


echo Saved to:
echo %LOG%
if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)
endlocal

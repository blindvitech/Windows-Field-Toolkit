@echo off
setlocal EnableExtensions
title Crash Correlation and Reliability Investigator
echo Crash Correlation / Reliability Investigator
echo.
echo Correlates crashes, WHEA, power, storage, graphics, application failures,
echo reliability records, and dump presence. Correlation does not prove cause.
echo.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Crash-Reliability-Report.ps1"
set "RC=%errorlevel%"
echo.
if "%SRMODE%"=="1" (
  if "%RC%"=="0" (echo Crash correlation completed successfully.) else (echo Crash correlation returned error code %RC%.)
  echo Press any key to continue.
  pause >nul
) else (
  pause
)
exit /b %RC%

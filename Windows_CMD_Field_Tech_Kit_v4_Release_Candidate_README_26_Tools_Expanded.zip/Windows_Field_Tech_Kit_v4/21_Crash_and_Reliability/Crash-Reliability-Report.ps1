$screenReaderCommon = Join-Path (Split-Path $PSScriptRoot -Parent) "00_Common\ScreenReader-Common.ps1"
if (Test-Path -LiteralPath $screenReaderCommon -PathType Leaf) { . $screenReaderCommon }

$ErrorActionPreference = "SilentlyContinue"
$ProgressPreference = "SilentlyContinue"

$toolkitRoot=Split-Path $PSScriptRoot -Parent
$diagnosticEvidence=Join-Path $toolkitRoot "00_Common\Diagnostic-Evidence.ps1"
if(Test-Path -LiteralPath $diagnosticEvidence -PathType Leaf){. $diagnosticEvidence}
$logs=Join-Path $toolkitRoot "Logs"
if(-not(Test-Path -LiteralPath $logs)){New-Item -ItemType Directory -Path $logs -Force|Out-Null}
$writer=Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"

Write-Host "CRASH CORRELATION / RELIABILITY INVESTIGATOR"
Write-Host "1. 24 hours"
Write-Host "2. 7 days"
Write-Host "3. 14 days"
Write-Host "4. 30 days"
$choice=Read-ToolkitPrompt "Select 1 through 4"
$days=7
switch($choice){"1"{$days=1};"2"{$days=7};"3"{$days=14};"4"{$days=30};default{$days=7}}
$start=(Get-Date).AddDays(-$days)
$basePath=Join-Path $logs ($env:COMPUTERNAME+"_Crash_Correlation_"+$days+"days_"+(Get-Date -Format "yyyyMMdd_HHmmss"))
$csvPath=$basePath+".csv"

$rows=New-Object System.Collections.Generic.List[object]
$capabilityRows=New-Object System.Collections.Generic.List[object]
$seenKeys=@{}

function Add-Row {
    param(
        [datetime]$Time,
        [string]$Class,
        [string]$Source,
        [string]$Id,
        [string]$Severity,
        [string]$Summary,
        [bool]$IsAnchor=$false,
        [string]$IncidentKey="",
        [string]$DeviceContext="",
        [string]$Confidence="Context",
        [datetime]$ArtifactTimestamp=[datetime]::MinValue
    )
    if(-not $Time -or $Time -lt $start){return}
    $clean=($Summary -replace "[\r\n]+"," " -replace "\s{2,}"," ").Trim()
    if($clean.Length -gt 900){$clean=$clean.Substring(0,900)+"..."}
    if($IncidentKey -and $seenKeys.ContainsKey($IncidentKey)){return}
    if($IncidentKey){$seenKeys[$IncidentKey]=$true}
    $evidenceId=Get-ToolkitEvidenceId -Category "WindowsEvent" -Source $Source -EventId $Id -Timestamp $Time `
        -Device $DeviceContext -Evidence $clean
    $rows.Add([pscustomobject]@{
        EvidenceId=$evidenceId
        Timestamp=$Time
        ArtifactTimestamp=$(if($ArtifactTimestamp -ne [datetime]::MinValue){$ArtifactTimestamp}else{$null})
        ObservedAt=(Get-Date)
        Class=$Class
        Confidence=(Get-ToolkitConfidenceLabel -Level $Confidence)
        Source=$Source
        EventId=$Id
        Severity=$Severity
        IsAnchor=$IsAnchor
        DeviceContext=$DeviceContext
        Summary=$clean
    })
}

Write-Host ("Collecting high-signal crash evidence from the last "+$days+" day(s)...")

$diskMap=@{}
try{
    Get-Disk -ErrorAction Stop|ForEach-Object{$diskMap[[int]$_.Number]=$_}
}catch{}

# System evidence is classified by the shared diagnostic engine.
try {
    Get-WinEvent -FilterHashtable @{LogName="System";StartTime=$start} -MaxEvents 2500 -ErrorAction Stop | ForEach-Object {
        $provider=[string]$_.ProviderName
        $id=[int]$_.Id
        $level=[int]$_.Level
        $message=[string]$_.Message
        $classification=Get-ToolkitSystemEventClassification -ProviderName $provider -EventId $id -Level $level `
            -Message $message -DiskMap $diskMap
        if($classification.Class){
            $key="SYS|"+$provider+"|"+$id+"|"+$_.RecordId
            Add-Row $_.TimeCreated $classification.Class $provider ([string]$id) $_.LevelDisplayName $message `
                ([bool]$classification.IsAnchor) $key $classification.DeviceContext $classification.Confidence
        }
    }
    $capabilityRows.Add((New-ToolkitCapabilityStatus -Capability "System Event Log query" -Available $true -Status "Available" -Detail "System event query completed." -SourceTool "ADV-007"))
} catch {
    $cf=Get-ToolkitCapabilityFailureClassification -ExceptionMessage $_.Exception.Message -Context "System Event Log query"
    $capabilityRows.Add((New-ToolkitCapabilityStatus -Capability "System Event Log query" -Available $false -Status $cf.Label -Detail $cf.Detail -SourceTool "ADV-007"))
}

# Application Error / Hang / WER. WER is classified by Event Name instead of treating all Event 1001 rows as crashes.
try {
    Get-WinEvent -FilterHashtable @{LogName="Application";StartTime=$start} -MaxEvents 2500 -ErrorAction Stop |
    Where-Object { $_.Id -in 1000,1001,1002 -or $_.ProviderName -match '(?i)Application Error|Windows Error Reporting|Application Hang' } |
    ForEach-Object {
        $provider=[string]$_.ProviderName
        $message=[string]$_.Message
        $id=[int]$_.Id

        if($provider -match '(?i)Application Hang' -or $id -eq 1002){
            $exe=""
            if($message -match '(?i)program\s+([^\s]+\.exe)'){$exe=$matches[1].ToLowerInvariant()}
            $key="HANG|"+$exe+"|"+$_.TimeCreated.ToString("yyyyMMddHHmmss")
            Add-Row $_.TimeCreated "Application hang" $provider ([string]$id) $_.LevelDisplayName $message $true $key $exe "Confirmed"
            return
        }

        if($provider -match '(?i)Application Error' -and $id -eq 1000){
            $exe=""
            if($message -match '(?i)Faulting application name:\s*([^,\s]+)'){$exe=$matches[1].ToLowerInvariant()}
            $key="APPCRASH|"+$exe+"|"+$_.TimeCreated.ToString("yyyyMMddHHmmss")
            Add-Row $_.TimeCreated "Application crash" $provider ([string]$id) $_.LevelDisplayName $message $true $key $exe "Confirmed"
            return
        }

        if($provider -match '(?i)Windows Error Reporting'){
            $wc=Get-ToolkitWerClassification -Message $message -EventTime $_.TimeCreated -LookbackStart $start `
                -FallbackId ([string]$_.RecordId)
            $deviceContext=""
            if($wc.DumpName){$deviceContext="Referenced dump: "+$wc.DumpName}
            Add-Row $_.TimeCreated $wc.Class $provider ([string]$id) $_.LevelDisplayName $message `
                ([bool]$wc.IsAnchor) $wc.IncidentKey $deviceContext $wc.Confidence `
                $(if($wc.ArtifactTimestamp){[datetime]$wc.ArtifactTimestamp}else{[datetime]::MinValue})
        }
    }
    $capabilityRows.Add((New-ToolkitCapabilityStatus -Capability "Application/WER Event Log query" -Available $true -Status "Available" -Detail "Application Error/Hang/WER query completed." -SourceTool "ADV-007"))
} catch {
    $cf=Get-ToolkitCapabilityFailureClassification -ExceptionMessage $_.Exception.Message -Context "Application/WER Event Log query"
    $capabilityRows.Add((New-ToolkitCapabilityStatus -Capability "Application/WER Event Log query" -Available $false -Status $cf.Label -Detail $cf.Detail -SourceTool "ADV-007"))
}

# Reliability records are supplemental. Suppress obvious duplicates when an application crash/hang already exists at the same time.
try {
    Get-CimInstance Win32_ReliabilityRecords -ErrorAction Stop |
    Where-Object { $_.TimeGenerated -ge $start -and ($_.SourceName -match '(?i)Windows Error Reporting|Application|Hardware|BlueScreen' -or $_.Message -match '(?i)stopped working|hardware error|blue screen|crash') } |
    Select-Object -First 500 | ForEach-Object {
        $time=[datetime]$_.TimeGenerated
        $product=[string]$_.ProductName
        $duplicate=@($rows.ToArray()|Where-Object{
            $_.Class -in @("Application crash","Application hang","LiveKernelEvent","Bugcheck") -and
            [math]::Abs(($_.Timestamp-$time).TotalSeconds) -le 5 -and
            (($product -and $_.Summary -match [regex]::Escape($product)) -or -not $product)
        }).Count -gt 0
        if(-not $duplicate){
            Add-Row $time "Reliability context" $_.SourceName ([string]$_.EventIdentifier) "Reliability" ($product+" | "+$_.Message) $false ("REL|"+$_.EventIdentifier+"|"+$time.Ticks+"|"+$product) $product "Context"
        }
    }
    $capabilityRows.Add((New-ToolkitCapabilityStatus -Capability "Reliability Monitor query" -Available $true -Status "Available" -Detail "Win32_ReliabilityRecords query completed." -SourceTool "ADV-007"))
} catch {
    $cf=Get-ToolkitCapabilityFailureClassification -ExceptionMessage $_.Exception.Message -Context "Win32_ReliabilityRecords"
    $capabilityRows.Add((New-ToolkitCapabilityStatus -Capability "Reliability Monitor query" -Available $false -Status $cf.Label -Detail $cf.Detail -SourceTool "ADV-007"))
}

$sorted=@($rows.ToArray()|Sort-Object Timestamp)
if($sorted.Count -gt 0){$sorted|Export-Csv -LiteralPath $csvPath -NoTypeInformation -Encoding UTF8}
else{"EvidenceId,Timestamp,ArtifactTimestamp,ObservedAt,Class,Confidence,Source,EventId,Severity,IsAnchor,DeviceContext,Summary"|Set-Content -LiteralPath $csvPath -Encoding UTF8}

$anchors=@($sorted|Where-Object{$_.IsAnchor -eq $true}|Sort-Object Timestamp)
$incidents=New-Object System.Collections.Generic.List[object]

if($anchors.Count -gt 0){
    $current=@()
    $previous=$null

    function Add-IncidentFromAnchors {
        param([object[]]$AnchorSet,[object[]]$AllRows,[System.Collections.Generic.List[object]]$Target)
        if(-not $AnchorSet -or $AnchorSet.Count -eq 0){return}
        $startTime=($AnchorSet|Sort-Object Timestamp|Select-Object -First 1).Timestamp
        $endTime=($AnchorSet|Sort-Object Timestamp -Descending|Select-Object -First 1).Timestamp
        $context=@($AllRows|Where-Object{$_.Timestamp -ge $startTime.AddMinutes(-10) -and $_.Timestamp -le $endTime.AddMinutes(10) -and $_.IsAnchor -eq $false})
        $classes=@($AnchorSet|Select-Object -ExpandProperty Class -Unique)
        $sources=@($AnchorSet|Select-Object -ExpandProperty Source -Unique)
        $devices=@($AnchorSet|Where-Object{$_.DeviceContext}|Select-Object -ExpandProperty DeviceContext -Unique)
        $summary="High-signal anchors: "+($classes -join ", ")
        if($devices.Count -gt 0){$summary+=" | Devices: "+($devices -join "; ")}
        if($context.Count -gt 0){$summary+=" | Context rows within +/-10 min: "+$context.Count}
        $Target.Add([pscustomobject]@{
            IncidentStart=$startTime
            IncidentEnd=$endTime
            AnchorCount=$AnchorSet.Count
            AnchorClasses=($classes -join ", ")
            AnchorSources=($sources -join ", ")
            ContextRows=$context.Count
            Summary=$summary
        })
    }

    foreach($a in $anchors){
        if($null -eq $previous -or ($a.Timestamp-$previous.Timestamp).TotalMinutes -le 10){
            $current+=,$a
        }else{
            Add-IncidentFromAnchors $current $sorted $incidents
            $current=@($a)
        }
        $previous=$a
    }
    Add-IncidentFromAnchors $current $sorted $incidents
}

$counts=@($sorted|Group-Object Class|Sort-Object Count -Descending|Select-Object Name,Count)
$historicalWer=@($sorted|Where-Object{$_.Class -eq "Historical WER replay"})
$highSignal=@($sorted|Where-Object{$_.IsAnchor -eq $true})
$contextRows=@($sorted|Where-Object{$_.IsAnchor -eq $false})

$minidumps=@(Get-ChildItem "$env:SystemRoot\Minidump\*.dmp" -ErrorAction SilentlyContinue|
    Where-Object{$_.LastWriteTime -ge $start}|Select-Object Name,Length,LastWriteTime)
$liveKernelDumps=@()
try{$liveKernelDumps=@(Get-ChildItem "$env:SystemRoot\LiveKernelReports" -Filter *.dmp -Recurse -ErrorAction Stop|
    Where-Object{$_.LastWriteTime -ge $start}|Select-Object FullName,Length,LastWriteTime)}catch{}
$memoryDump=Get-Item "$env:SystemRoot\MEMORY.DMP" -ErrorAction SilentlyContinue|Select-Object Name,Length,LastWriteTime

$lines=New-Object System.Collections.Generic.List[string]
function Add-Section([string]$Title,$Data,[string]$Note=""){
    $lines.Add("");$lines.Add(("="*78));$lines.Add($Title);$lines.Add(("="*78))
    if($Note){$lines.Add("NOTE: "+$Note)}
    $x=($Data|Out-String -Width 280).TrimEnd()
    if($x){$lines.Add($x)}else{$lines.Add("(No data returned / no matching evidence.)")}
}

$lines.Add("CRASH CORRELATION / RELIABILITY INVESTIGATOR")
$lines.Add("Computer: "+$env:COMPUTERNAME)
$lines.Add("Generated: "+(Get-Date))
$lines.Add("Lookback: "+$days+" day(s)")
$lines.Add("Raw relevant rows: "+$sorted.Count)
$lines.Add("High-signal anchors: "+$highSignal.Count)
$lines.Add("Correlated incidents: "+$incidents.Count)
$lines.Add("")
$lines.Add("Correlation means events occurred near one another in time. It does NOT prove causation.")
$lines.Add("Only high-signal crash/hardware/storage/graphics/power-loss evidence creates incidents. Informational resume, WER replay, update-failure, and other context rows cannot create an incident by themselves.")
$lines.Add("Historical WER replay means Windows reported an old dump during the selected lookback; the WER event time is not treated as the original crash time.")

Add-Section "CAPABILITY / QUERY STATUS" $(if($capabilityRows.Count -gt 0){$capabilityRows.ToArray()}else{$null}) "Unavailable queries are classified as Not Supported, Driver/API Did Not Expose, Requires Elevation, Not Applicable, Query/API Failed, or Unknown/Indeterminate."
Add-Section "EVENT COUNTS BY CLASS" $counts
Add-Section "CORRELATED INCIDENTS" $(if($incidents.Count -gt 0){$incidents.ToArray()}else{$null}) "An incident groups high-signal anchors no more than 10 minutes apart, then counts surrounding context within +/-10 minutes."
Add-Section "HIGH-SIGNAL TIMELINE" $highSignal
Add-Section "HISTORICAL / RE-REPORTED WER" $historicalWer "Repeated references to the same historical watchdog dump are deduplicated by dump filename."
Add-Section "SUPPORTING CONTEXT TIMELINE - MAX 200" @($contextRows|Select-Object -First 200)
Add-Section "MINIDUMPS CREATED IN LOOKBACK" $minidumps
Add-Section "LIVEKERNEL DUMPS CREATED IN LOOKBACK" $liveKernelDumps
Add-Section "MEMORY.DMP" $memoryDump

& $writer -BasePath $basePath -Title "Crash Correlation / Reliability Investigator" -Body ($lines -join [Environment]::NewLine) -ToolId "ADV-007"
Write-ToolkitDiagnosticSidecar -BasePath $basePath -ToolkitRoot $toolkitRoot -ToolId "ADV-007" `
    -Title "Crash Correlation / Reliability Investigator" -Findings @() -Evidence $sorted `
    -Capabilities $(if($capabilityRows.Count -gt 0){$capabilityRows.ToArray()}else{@()})
$html=$basePath+".html"
Write-Host("Relevant rows: "+$sorted.Count)
Write-Host("High-signal anchors: "+$highSignal.Count)
Write-Host("Correlated incidents: "+$incidents.Count)
Write-Host("Report: "+$html)
Write-Host("CSV: "+$csvPath)
try{Start-Process -FilePath $html}catch{}
exit 0

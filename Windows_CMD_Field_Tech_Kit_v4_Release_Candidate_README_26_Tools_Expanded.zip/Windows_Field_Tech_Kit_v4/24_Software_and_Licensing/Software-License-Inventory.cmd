@echo off
setlocal EnableExtensions
title Software Activation and Licensing Deep Dive

echo Software / Activation / Licensing Deep Dive
echo.
echo Collecting Windows activation/channel/KMS details, product-key sources, Office licensing,
echo installed applications, and WinGet information.
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Software-License-Inventory.ps1"
set "RC=%errorlevel%"

if "%SRMODE%"=="1" (
    echo.
    if "%RC%"=="0" (
        echo Software / Activation / Licensing Deep Dive completed successfully.
    ) else (
        echo Software / Activation / Licensing Deep Dive returned error code %RC%.
    )
    echo Press any key to continue.
    pause >nul
) else (
    echo.
    pause
)

exit /b %RC%

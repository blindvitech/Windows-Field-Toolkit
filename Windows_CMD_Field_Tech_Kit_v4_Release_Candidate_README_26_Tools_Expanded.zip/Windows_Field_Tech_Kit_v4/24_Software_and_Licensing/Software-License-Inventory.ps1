$ErrorActionPreference = "SilentlyContinue"
$ProgressPreference = "SilentlyContinue"

$toolkitRoot = Split-Path $PSScriptRoot -Parent
$logs = Join-Path $toolkitRoot "Logs"
if (-not (Test-Path -LiteralPath $logs)) {
    New-Item -ItemType Directory -Path $logs -Force | Out-Null
}

$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$basePath = Join-Path $logs ($env:COMPUTERNAME + "_Software_and_Licensing_Inventory_" + $stamp)
$writer = Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"

function Add-Section {
    param(
        [System.Collections.Generic.List[string]]$Lines,
        [string]$Title,
        $Data,
        [string]$Note = ""
    )

    $Lines.Add("")
    $Lines.Add(("=" * 78))
    $Lines.Add($Title)
    $Lines.Add(("=" * 78))

    if (-not [string]::IsNullOrWhiteSpace($Note)) {
        $Lines.Add("NOTE: " + $Note)
    }

    if ($null -eq $Data) {
        $Lines.Add("(No data returned / not applicable)")
        return
    }

    $formatted = ($Data | Out-String -Width 240).TrimEnd()
    if ([string]::IsNullOrWhiteSpace($formatted)) {
        $Lines.Add("(No data returned / not applicable)")
    }
    else {
        $Lines.Add($formatted)
    }
}

function Test-FullProductKeyFormat {
    param([string]$Key)
    if ([string]::IsNullOrWhiteSpace($Key)) { return $false }
    return ($Key -match '^[A-Z0-9]{5}(?:-[A-Z0-9]{5}){4}$')
}

function Get-DecodedDigitalProductIdKey {
    try {
        $reg = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion" -ErrorAction Stop
        [byte[]]$digitalProductId = $reg.DigitalProductId

        if (-not $digitalProductId -or $digitalProductId.Length -lt 67) {
            return $null
        }

        $keyOffset = 52
        $chars = "BCDFGHJKMPQRTVWXY2346789"
        $isWin8 = (($digitalProductId[66] / 6) -band 1)
        $digitalProductId[66] = ($digitalProductId[66] -band 0xF7) -bor (($isWin8 -band 2) * 4)

        $key = ""
        $last = 0

        for ($i = 24; $i -ge 0; $i--) {
            $current = 0
            for ($j = 14; $j -ge 0; $j--) {
                $current = ($current * 256) + $digitalProductId[$j + $keyOffset]
                $digitalProductId[$j + $keyOffset] = [math]::Floor($current / 24)
                $current = $current % 24
            }
            $key = $chars[$current] + $key
            $last = $current
        }

        if ($isWin8 -eq 1) {
            if ($last -eq 0) {
                $key = "N" + $key.Substring(1)
            }
            else {
                $key = $key.Substring(1, $last) + "N" + $key.Substring($last + 1)
            }
        }

        $groups = New-Object System.Collections.Generic.List[string]
        for ($i = 0; $i -lt 25; $i += 5) {
            $groups.Add($key.Substring($i, 5))
        }

        return ($groups -join "-")
    }
    catch {
        return $null
    }
}

function Get-LicenseStatusText {
    param([int]$Status)
    switch ($Status) {
        0 { return "Unlicensed" }
        1 { return "Licensed" }
        2 { return "OOB Grace" }
        3 { return "OOT Grace" }
        4 { return "Non-Genuine Grace" }
        5 { return "Notification" }
        6 { return "Extended Grace" }
        default { return "Unknown (" + $Status + ")" }
    }
}

Write-Host "Collecting Windows, licensing, Office, and installed-software inventory..."

$lines = New-Object System.Collections.Generic.List[string]
$lines.Add("SOFTWARE / ACTIVATION / LICENSING DEEP DIVE")
$lines.Add("Computer: " + $env:COMPUTERNAME)
$lines.Add("Generated: " + (Get-Date))
$lines.Add("User: " + $env:USERDOMAIN + "\" + $env:USERNAME)

Write-Host " - Windows edition and build"
$cv = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion" -ErrorAction SilentlyContinue
$os = Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue

$displayProductName = $os.Caption
if ([string]::IsNullOrWhiteSpace($displayProductName)) {
    $displayProductName = $cv.ProductName
}

$windowsInfo = [pscustomobject]@{
    ProductName = $displayProductName
    LegacyRegistryProductName = $cv.ProductName
    DisplayVersion = $cv.DisplayVersion
    EditionID = $cv.EditionID
    InstallationType = $cv.InstallationType
    Version = $os.Version
    Build = $os.BuildNumber
    UBR = $cv.UBR
    Architecture = $os.OSArchitecture
    InstallDate = $os.InstallDate
}
Add-Section $lines "WINDOWS" $windowsInfo

Write-Host " - Windows activation state"
$activation = @(Get-CimInstance SoftwareLicensingProduct -ErrorAction SilentlyContinue |
    Where-Object { $_.PartialProductKey -and $_.Name -like "Windows*" } |
    Select-Object Name,Description,LicenseStatus,PartialProductKey)

$activationDisplay = @($activation | ForEach-Object {
    [pscustomobject]@{
        Name = $_.Name
        Description = $_.Description
        LicenseStatus = $_.LicenseStatus
        LicenseStatusText = Get-LicenseStatusText $_.LicenseStatus
        PartialProductKey = $_.PartialProductKey
    }
})
Add-Section $lines "WINDOWS ACTIVATION" $activationDisplay

Write-Host " - Windows activation / licensing deep dive"
$activationDeep = @(Get-CimInstance SoftwareLicensingProduct -ErrorAction SilentlyContinue |
    Where-Object { $_.PartialProductKey -and $_.Name -like "Windows*" } |
    ForEach-Object {
        $channel = "Unknown"
        if ([string]$_.Description -match '(?i),\s*([^,]+?)\s+channel') {
            $channel = $matches[1].Trim()
        }
        [pscustomobject]@{
            Name = $_.Name
            Description = $_.Description
            Channel = $channel
            LicenseStatus = $_.LicenseStatus
            LicenseStatusText = Get-LicenseStatusText $_.LicenseStatus
            LicenseStatusReason = ("0x{0:X8}" -f ([uint32]$_.LicenseStatusReason))
            GracePeriodMinutes = $_.GracePeriodRemaining
            EvaluationEndDate = $_.EvaluationEndDate
            PartialProductKey = $_.PartialProductKey
            ProductId = $_.ID
            ApplicationId = $_.ApplicationID
        }
    })
Add-Section $lines "WINDOWS ACTIVATION / CHANNEL DEEP DIVE" $activationDeep `
    "Channel is inferred from Windows licensing-product Description when Windows exposes it (for example RETAIL, OEM_DM, VOLUME_MAK, or VOLUME_KMSCLIENT)."

$licensingService = $null
try {
    $svc = Get-CimInstance SoftwareLicensingService -ErrorAction Stop
    $licensingService = [pscustomobject]@{
        Version = $svc.Version
        RemainingWindowsReArmCount = $svc.RemainingWindowsReArmCount
        OA3xOriginalProductKeyDescription = $svc.OA3xOriginalProductKeyDescription
        KeyManagementServiceListeningPort = $svc.KeyManagementServiceListeningPort
        KeyManagementServiceLookupDomain = $svc.KeyManagementServiceLookupDomain
        KeyManagementServiceHostCaching = $svc.KeyManagementServiceHostCaching
    }
}
catch {}
Add-Section $lines "SOFTWARE LICENSING SERVICE" $licensingService `
    "No passwords, credential secrets, or BitLocker recovery material are collected."

$slmgrXpr = ""
$slmgrDlv = ""
try { $slmgrXpr = (& cscript.exe //nologo "$env:windir\system32\slmgr.vbs" /xpr 2>&1 | Out-String -Width 240).TrimEnd() } catch {}
try { $slmgrDlv = (& cscript.exe //nologo "$env:windir\system32\slmgr.vbs" /dlv 2>&1 | Out-String -Width 240).TrimEnd() } catch {}
Add-Section $lines "SLMGR ACTIVATION EXPIRATION" $slmgrXpr
Add-Section $lines "SLMGR DETAILED LICENSE VIEW" $slmgrDlv `
    "Useful for digital-license, Retail/OEM, MAK, and KMS troubleshooting. KMS infrastructure names may appear when configured."

$activeWindows = $activation | Where-Object LicenseStatus -eq 1 | Select-Object -First 1
if (-not $activeWindows) {
    $activeWindows = $activation | Select-Object -First 1
}
$activePartial = ""
if ($activeWindows -and $activeWindows.PartialProductKey) {
    $activePartial = [string]$activeWindows.PartialProductKey
}

Write-Host " - Recoverable Windows product-key sources"
$oemKey = ""
try {
    $oemKey = [string](Get-CimInstance SoftwareLicensingService -ErrorAction Stop).OA3xOriginalProductKey
}
catch {
    $oemKey = ""
}

$backupKey = ""
try {
    $backupKey = [string](Get-ItemPropertyValue `
        -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\SoftwareProtectionPlatform" `
        -Name "BackupProductKeyDefault" `
        -ErrorAction Stop)
}
catch {
    $backupKey = ""
}

$decodedKey = Get-DecodedDigitalProductIdKey

$keyRows = New-Object System.Collections.Generic.List[object]

if (Test-FullProductKeyFormat $oemKey) {
    $keyRows.Add([pscustomobject]@{
        Source = "Firmware / OEM"
        ProductKey = $oemKey
        Status = "Authoritative OEM firmware key"
        Notes = "Read from OA3xOriginalProductKey."
    })
}

if (Test-FullProductKeyFormat $backupKey) {
    $backupValid = $false
    $backupStatus = ""
    $backupNotes = ""

    if (Test-FullProductKeyFormat $oemKey) {
        if ($backupKey -eq $oemKey) {
            $backupValid = $true
            $backupStatus = "Matches firmware key"
            $backupNotes = "BackupProductKeyDefault exactly matches the authoritative OEM key."
        }
        else {
            $backupStatus = "Suppressed - does not match firmware key"
            $backupNotes = "An OEM firmware key is present; this registry value was hidden because it differs."
        }
    }
    elseif ($activePartial -and $backupKey.EndsWith($activePartial, [System.StringComparison]::OrdinalIgnoreCase)) {
        $backupValid = $true
        $backupStatus = "Validated against active partial key"
        $backupNotes = "No firmware key was present; the registry key matches the active Windows partial product key."
    }
    else {
        $backupStatus = "Suppressed - validation failed"
        $backupNotes = "Registry value did not validate against the active Windows partial product key."
    }

    $keyRows.Add([pscustomobject]@{
        Source = "Registry / BackupProductKeyDefault"
        ProductKey = $(if ($backupValid) { $backupKey } else { "(value suppressed)" })
        Status = $backupStatus
        Notes = $backupNotes
    })
}

if (Test-FullProductKeyFormat $decodedKey) {
    $decodedValid = $false
    $decodedStatus = ""
    $decodedNotes = ""

    if (Test-FullProductKeyFormat $oemKey) {
        if ($decodedKey -eq $oemKey) {
            $decodedValid = $true
            $decodedStatus = "Matches firmware key"
            $decodedNotes = "Decoded DigitalProductId exactly matches the authoritative OEM key."
        }
        else {
            $decodedStatus = "Suppressed - does not match firmware key"
            $decodedNotes = "Firmware/OEM key is present, so a differing decoded value is not shown."
        }
    }
    elseif ($activePartial -and $decodedKey.EndsWith($activePartial, [System.StringComparison]::OrdinalIgnoreCase)) {
        $decodedValid = $true
        $decodedStatus = "Validated against active partial key"
        $decodedNotes = "No firmware key was present; decoded key matches the active Windows partial product key."
    }
    else {
        $decodedStatus = "Suppressed - validation failed"
        $decodedNotes = "Decoded value did not validate against the active Windows partial product key."
    }

    $keyRows.Add([pscustomobject]@{
        Source = "Installed Windows / DigitalProductId"
        ProductKey = $(if ($decodedValid) { $decodedKey } else { "(decoded value suppressed)" })
        Status = $decodedStatus
        Notes = $decodedNotes
    })
}

if ($keyRows.Count -eq 0) {
    $keyRows.Add([pscustomobject]@{
        Source = "Windows licensing"
        ProductKey = "(No recoverable full key exposed)"
        Status = "No full key available"
        Notes = "Digital-license activation can be valid without a recoverable 25-character product key."
    })
}

Add-Section $lines "WINDOWS PRODUCT KEY SOURCES" $keyRows `
    "Firmware/OEM is authoritative when present. Non-OEM registry/decoded values must validate against the active partial key before the full value is shown."

Write-Host " - Office licensing"
$officeProducts = @(Get-CimInstance SoftwareLicensingProduct -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -match "Office" -and ($_.PartialProductKey -or $_.LicenseStatus -ne 0) } |
    Select-Object Name,Description,LicenseStatus,PartialProductKey)

$officeDisplay = @($officeProducts | ForEach-Object {
    [pscustomobject]@{
        Name = $_.Name
        Description = $_.Description
        LicenseStatus = $_.LicenseStatus
        LicenseStatusText = Get-LicenseStatusText $_.LicenseStatus
        PartialProductKey = $_.PartialProductKey
    }
})
Add-Section $lines "OFFICE LICENSING PRODUCTS" $officeDisplay

Write-Host " - Office Click-to-Run configuration"
$officeCtr = $null
try {
    $ctr = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Office\ClickToRun\Configuration" -ErrorAction Stop
    $officeCtr = [pscustomobject]@{
        ProductReleaseIds = $ctr.ProductReleaseIds
        ClientVersionToReport = $ctr.ClientVersionToReport
        Platform = $ctr.Platform
        UpdateChannel = $ctr.UpdateChannel
        CDNBaseUrl = $ctr.CDNBaseUrl
        AudienceId = $ctr.AudienceId
        UpdatesEnabled = $ctr.UpdatesEnabled
    }
}
catch {
    $officeCtr = $null
}
Add-Section $lines "OFFICE CLICK-TO-RUN CONFIGURATION" $officeCtr

Write-Host " - Installed applications"
$uninstallPaths = @(
    "HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*",
    "HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*",
    "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*"
)

$apps = @(Get-ItemProperty $uninstallPaths -ErrorAction SilentlyContinue |
    Where-Object DisplayName |
    Select-Object DisplayName,DisplayVersion,Publisher,InstallDate |
    Sort-Object DisplayName,DisplayVersion -Unique)
Add-Section $lines "INSTALLED APPLICATIONS" $apps

Write-Host " - WinGet status"
$wingetData = New-Object System.Collections.Generic.List[string]
$winget = Get-Command winget.exe -ErrorAction SilentlyContinue
if ($winget) {
    $wingetData.Add("Executable: " + $winget.Source)
    try {
        $version = (& winget.exe --version 2>&1 | Out-String).Trim()
        $wingetData.Add("Version: " + $version)
    }
    catch {
        $wingetData.Add("Version query failed.")
    }

    $wingetData.Add("")
    $wingetData.Add("Installed package listing:")
    try {
        $listOutput = & winget.exe list --accept-source-agreements --disable-interactivity 2>&1 | Out-String -Width 240
        if ([string]::IsNullOrWhiteSpace($listOutput)) {
            $wingetData.Add("(WinGet returned no package-list output.)")
        }
        else {
            $wingetData.Add($listOutput.TrimEnd())
        }
    }
    catch {
        $wingetData.Add("WinGet list failed: " + $_.Exception.Message)
    }
}
else {
    $wingetData.Add("WinGet is not available in this user/session.")
}
Add-Section $lines "WINGET" $wingetData

$body = $lines -join [Environment]::NewLine

if (-not (Test-Path -LiteralPath $writer)) {
    Write-Host "Report writer not found:"
    Write-Host $writer
    exit 3
}

& $writer -BasePath $basePath -Title "Software / Activation / Licensing Deep Dive" -Body $body
$writerRc = $LASTEXITCODE

$html = $basePath + ".html"
$txt = $basePath + ".txt"
$md = $basePath + ".md"

if (-not (Test-Path -LiteralPath $html) -or -not (Test-Path -LiteralPath $txt) -or -not (Test-Path -LiteralPath $md)) {
    Write-Host ""
    Write-Host "The inventory ran, but one or more report files were not created."
    exit 4
}

Write-Host ""
Write-Host "Software / activation / licensing deep dive complete."
Write-Host ("HTML: " + $html)
Write-Host ("Text: " + $txt)
Write-Host ("Markdown: " + $md)

try {
    Start-Process -FilePath $html
}
catch {
    Write-Host "The HTML report was created but could not be opened automatically."
}

exit 0

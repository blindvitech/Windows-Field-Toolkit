@echo off
setlocal EnableExtensions
title Printer Snapshot

echo Printer Snapshot
echo.
echo Running dedicated PowerShell collector...
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Printer-Snapshot.ps1"
set "RC=%errorlevel%"

echo.
if "%RC%"=="0" (
    echo Printer Snapshot completed.
) else (
    echo Printer Snapshot returned error code %RC%.
)

if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

exit /b %RC%

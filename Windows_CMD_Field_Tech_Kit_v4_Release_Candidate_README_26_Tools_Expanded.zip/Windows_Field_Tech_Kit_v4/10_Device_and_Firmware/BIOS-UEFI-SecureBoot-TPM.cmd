@echo off
setlocal EnableExtensions
title BIOS UEFI Secure Boot TPM Snapshot
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0BIOS-UEFI-SecureBoot-TPM.ps1"
set "RC=%errorlevel%"
echo.
if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)
exit /b %RC%

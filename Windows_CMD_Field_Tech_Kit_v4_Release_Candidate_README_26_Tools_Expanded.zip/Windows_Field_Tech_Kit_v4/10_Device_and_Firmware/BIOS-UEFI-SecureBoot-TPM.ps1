$ErrorActionPreference = "SilentlyContinue"
$toolkitRoot = Split-Path $PSScriptRoot -Parent
$logs = Join-Path $toolkitRoot "Logs"
if (-not (Test-Path -LiteralPath $logs)) { New-Item -ItemType Directory -Path $logs -Force | Out-Null }
$writer = Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"
$basePath = Join-Path $logs ($env:COMPUTERNAME + "_FirmwareSecurity_" + (Get-Date -Format "yyyyMMdd_HHmmss"))

$lines = New-Object System.Collections.Generic.List[string]
$lines.Add("BIOS / UEFI / SECURE BOOT / TPM")
$lines.Add("Computer: " + $env:COMPUTERNAME)
$lines.Add("Generated: " + (Get-Date))

$lines.Add("")
$lines.Add("BIOS")
try {
    $bios = Get-CimInstance Win32_BIOS -ErrorAction Stop |
        Select-Object Manufacturer,SMBIOSBIOSVersion,ReleaseDate,SerialNumber
    $lines.Add(($bios | Format-List | Out-String -Width 220).TrimEnd())
}
catch { $lines.Add("Unavailable: " + $_.Exception.Message) }

$lines.Add("")
$lines.Add("SYSTEM")
try {
    $cs = Get-CimInstance Win32_ComputerSystem -ErrorAction Stop |
        Select-Object Manufacturer,Model,SystemType
    $lines.Add(($cs | Format-List | Out-String -Width 220).TrimEnd())
}
catch { $lines.Add("Unavailable: " + $_.Exception.Message) }

$lines.Add("")
$lines.Add("SECURE BOOT")
try {
    $sb = Confirm-SecureBootUEFI -ErrorAction Stop
    $lines.Add("Secure Boot enabled: " + $sb)
}
catch {
    $lines.Add("Unavailable / not UEFI / access restricted: " + $_.Exception.Message)
}

$lines.Add("")
$lines.Add("TPM")
try {
    if (-not (Get-Command Get-Tpm -ErrorAction SilentlyContinue)) { throw "Get-Tpm cmdlet is unavailable." }
    $tpm = Get-Tpm -ErrorAction Stop
    $lines.Add(($tpm | Format-List * | Out-String -Width 220).TrimEnd())
}
catch { $lines.Add("Unavailable: " + $_.Exception.Message) }

& $writer -BasePath $basePath -Title "BIOS UEFI Secure Boot TPM Snapshot" -Body ($lines -join [Environment]::NewLine)
Write-Host ("Report: " + $basePath + ".html")
try { Start-Process -FilePath ($basePath + ".html") } catch {}
exit 0

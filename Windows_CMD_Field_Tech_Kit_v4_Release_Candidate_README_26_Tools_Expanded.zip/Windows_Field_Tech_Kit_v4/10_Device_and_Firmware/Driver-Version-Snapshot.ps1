$ErrorActionPreference = "SilentlyContinue"
$ProgressPreference = "SilentlyContinue"
$toolkitRoot = Split-Path $PSScriptRoot -Parent
$logs = Join-Path $toolkitRoot "Logs"
if (-not (Test-Path -LiteralPath $logs)) { New-Item -ItemType Directory -Path $logs -Force | Out-Null }
$writer = Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"
$stamp = Get-Date -Format "yyyyMMdd_HHmmss"

$csv = Join-Path $logs ($env:COMPUTERNAME + "_Drivers_" + $stamp + ".csv")
Get-CimInstance Win32_PnPSignedDriver -ErrorAction SilentlyContinue |
    Select-Object DeviceName,Manufacturer,DriverVersion,DriverDate,InfName |
    Sort-Object DeviceName |
    Export-Csv -LiteralPath $csv -NoTypeInformation -Encoding UTF8
Write-Host ("Saved CSV: " + $csv)
exit 0

$ErrorActionPreference = "SilentlyContinue"
$ProgressPreference = "SilentlyContinue"
$toolkitRoot = Split-Path $PSScriptRoot -Parent
$logs = Join-Path $toolkitRoot "Logs"
if (-not (Test-Path -LiteralPath $logs)) { New-Item -ItemType Directory -Path $logs -Force | Out-Null }
$writer = Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"
$stamp = Get-Date -Format "yyyyMMdd_HHmmss"

$reportBase = Join-Path $logs ($env:COMPUTERNAME + "_Printers_" + $stamp)
$data = Get-Printer -ErrorAction SilentlyContinue |
    Select-Object Name,DriverName,PortName,Shared,Published,PrinterStatus
$body = if ($data) { ($data | Format-Table -AutoSize | Out-String -Width 260).TrimEnd() } else { "(No printers returned.)" }
& $writer -BasePath $reportBase -Title "Printer Snapshot" -Body $body
Write-Host ("Report: " + $reportBase + ".html")
try { Start-Process -FilePath ($reportBase + ".html") } catch {}
exit 0

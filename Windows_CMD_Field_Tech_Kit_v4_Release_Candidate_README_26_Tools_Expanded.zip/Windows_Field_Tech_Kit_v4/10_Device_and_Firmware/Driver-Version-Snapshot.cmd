@echo off
setlocal EnableExtensions
title Driver Version Snapshot

echo Driver Version Snapshot
echo.
echo Running dedicated PowerShell collector...
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Driver-Version-Snapshot.ps1"
set "RC=%errorlevel%"

echo.
if "%RC%"=="0" (
    echo Driver Version Snapshot completed.
) else (
    echo Driver Version Snapshot returned error code %RC%.
)

if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

exit /b %RC%

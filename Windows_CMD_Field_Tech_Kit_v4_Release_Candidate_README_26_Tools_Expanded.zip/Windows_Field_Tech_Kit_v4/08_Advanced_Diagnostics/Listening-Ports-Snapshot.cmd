@echo off
setlocal
title Listening Ports Snapshot
set "LOGDIR=%~dp0..\Logs"
if not exist "%LOGDIR%" mkdir "%LOGDIR%"
set "LOG=%LOGDIR%\%COMPUTERNAME%_ListeningPorts_%RANDOM%.txt"

(
echo ============================================================
echo LISTENING PORTS / CONNECTIONS
echo Computer: %COMPUTERNAME%
echo Date: %DATE% %TIME%
echo ============================================================
echo.
echo ===== NETSTAT WITH PIDS =====
netstat -abno
echo.
echo ===== PROCESS LIST =====
tasklist /svc
) > "%LOG%" 2>&1


powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\00_Common\Convert-TextReport.ps1" -TextPath "%LOG%" -Title "%~n0"


echo Saved to:
echo %LOG%
if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)
endlocal


@echo off
setlocal EnableExtensions
title Problem Devices

echo Problem Devices
echo.
echo Running dedicated PowerShell collector...
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Problem-Devices.ps1"
set "RC=%errorlevel%"

echo.
if "%RC%"=="0" (
    echo Problem Devices completed.
) else (
    echo Problem Devices returned error code %RC%.
)

if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

exit /b %RC%

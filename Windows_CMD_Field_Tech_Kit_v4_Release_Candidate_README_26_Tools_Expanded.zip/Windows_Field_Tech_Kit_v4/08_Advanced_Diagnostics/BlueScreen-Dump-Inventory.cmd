@echo off
setlocal
title Blue Screen Dump Inventory
set "LOGDIR=%~dp0..\Logs"
if not exist "%LOGDIR%" mkdir "%LOGDIR%"
set "LOG=%LOGDIR%\%COMPUTERNAME%_CrashDumps_%RANDOM%.txt"

(
echo ============================================================
echo CRASH DUMP INVENTORY
echo Computer: %COMPUTERNAME%
echo Date: %DATE% %TIME%
echo ============================================================
echo.
echo ===== MINIDUMPS =====
dir "%SystemRoot%\Minidump\*.dmp" /a:-d /o:-d 2>nul
echo.
echo ===== MEMORY.DMP =====
dir "%SystemRoot%\MEMORY.DMP" /a:-d 2>nul
) > "%LOG%" 2>&1


powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\00_Common\Convert-TextReport.ps1" -TextPath "%LOG%" -Title "%~n0"


echo Saved to:
echo %LOG%
if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)
endlocal


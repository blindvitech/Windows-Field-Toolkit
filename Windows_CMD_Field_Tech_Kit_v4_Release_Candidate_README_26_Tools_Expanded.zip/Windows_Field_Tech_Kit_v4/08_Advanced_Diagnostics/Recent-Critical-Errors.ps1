$ErrorActionPreference = "SilentlyContinue"
$ProgressPreference = "SilentlyContinue"
$toolkitRoot = Split-Path $PSScriptRoot -Parent
$logs = Join-Path $toolkitRoot "Logs"
if (-not (Test-Path -LiteralPath $logs)) { New-Item -ItemType Directory -Path $logs -Force | Out-Null }
$writer = Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"
$stamp = Get-Date -Format "yyyyMMdd_HHmmss"

$reportBase = Join-Path $logs ($env:COMPUTERNAME + "_RecentErrors_" + $stamp)
$start = (Get-Date).AddDays(-7)
$data = Get-WinEvent -FilterHashtable @{LogName="System"; StartTime=$start; Level=1,2} -ErrorAction SilentlyContinue |
    Select-Object TimeCreated,Id,ProviderName,LevelDisplayName,Message
$body = if ($data) { ($data | Format-List | Out-String -Width 260).TrimEnd() } else { "(No matching critical/error System events returned in the last 7 days.)" }
& $writer -BasePath $reportBase -Title "Recent Critical and Error Events" -Body $body
Write-Host ("Report: " + $reportBase + ".html")
try { Start-Process -FilePath ($reportBase + ".html") } catch {}
exit 0

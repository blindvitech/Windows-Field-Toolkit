$ErrorActionPreference = "SilentlyContinue"
$ProgressPreference = "SilentlyContinue"
$toolkitRoot = Split-Path $PSScriptRoot -Parent
$logs = Join-Path $toolkitRoot "Logs"
if (-not (Test-Path -LiteralPath $logs)) { New-Item -ItemType Directory -Path $logs -Force | Out-Null }
$writer = Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"
$stamp = Get-Date -Format "yyyyMMdd_HHmmss"

$reportBase = Join-Path $logs ($env:COMPUTERNAME + "_UpdateHistory_" + $stamp)
$data = @()
try {
    $session = New-Object -ComObject Microsoft.Update.Session
    $searcher = $session.CreateUpdateSearcher()
    $count = $searcher.GetTotalHistoryCount()
    if ($count -gt 0) {
        $data = $searcher.QueryHistory(0,[Math]::Min($count,100)) |
            Select-Object Date,Title,ResultCode,HResult
    }
}
catch {}
$body = if ($data) { ($data | Format-Table -Wrap | Out-String -Width 260).TrimEnd() } else { "(No Windows Update history returned.)" }
& $writer -BasePath $reportBase -Title "Windows Update History" -Body $body
Write-Host ("Report: " + $reportBase + ".html")
try { Start-Process -FilePath ($reportBase + ".html") } catch {}
exit 0

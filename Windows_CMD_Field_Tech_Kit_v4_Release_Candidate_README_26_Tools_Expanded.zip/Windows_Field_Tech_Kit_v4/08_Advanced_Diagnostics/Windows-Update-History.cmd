@echo off
setlocal EnableExtensions
title Windows Update History

echo Windows Update History
echo.
echo Running dedicated PowerShell collector...
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Windows-Update-History.ps1"
set "RC=%errorlevel%"

echo.
if "%RC%"=="0" (
    echo Windows Update History completed.
) else (
    echo Windows Update History returned error code %RC%.
)

if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

exit /b %RC%

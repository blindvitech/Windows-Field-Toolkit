$ErrorActionPreference = "SilentlyContinue"
$ProgressPreference = "SilentlyContinue"
$toolkitRoot = Split-Path $PSScriptRoot -Parent
$logs = Join-Path $toolkitRoot "Logs"
if (-not (Test-Path -LiteralPath $logs)) { New-Item -ItemType Directory -Path $logs -Force | Out-Null }
$writer = Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"
$stamp = Get-Date -Format "yyyyMMdd_HHmmss"

$reportBase = Join-Path $logs ($env:COMPUTERNAME + "_ProblemDevices_" + $stamp)
$data = Get-PnpDevice -PresentOnly -ErrorAction SilentlyContinue |
    Where-Object Status -ne "OK" |
    Sort-Object Class,FriendlyName |
    Select-Object Status,Class,FriendlyName,InstanceId
$body = if ($data) { ($data | Format-Table -AutoSize | Out-String -Width 260).TrimEnd() } else { "(No problem devices returned.)" }
& $writer -BasePath $reportBase -Title "Problem Devices" -Body $body
Write-Host ("Report: " + $reportBase + ".html")
try { Start-Process -FilePath ($reportBase + ".html") } catch {}
exit 0

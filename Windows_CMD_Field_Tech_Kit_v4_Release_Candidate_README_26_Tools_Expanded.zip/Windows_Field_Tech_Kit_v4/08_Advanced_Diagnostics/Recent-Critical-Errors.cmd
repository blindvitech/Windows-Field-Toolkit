@echo off
setlocal EnableExtensions
title Recent Critical and Error Events

echo Recent Critical and Error Events
echo.
echo Running dedicated PowerShell collector...
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Recent-Critical-Errors.ps1"
set "RC=%errorlevel%"

echo.
if "%RC%"=="0" (
    echo Recent Critical and Error Events completed.
) else (
    echo Recent Critical and Error Events returned error code %RC%.
)

if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

exit /b %RC%

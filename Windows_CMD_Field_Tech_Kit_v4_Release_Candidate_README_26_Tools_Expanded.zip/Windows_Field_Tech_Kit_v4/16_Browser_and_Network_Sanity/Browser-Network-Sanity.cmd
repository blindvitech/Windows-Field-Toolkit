@echo off
setlocal EnableExtensions
title Browser and Network Sanity

echo Browser and Network Sanity
echo.
echo Collecting report data. This may take a moment.
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Browser-Network-Sanity.ps1"
set "RC=%errorlevel%"

if "%SRMODE%"=="1" (
    echo.
    if "%RC%"=="0" (
        echo Browser and Network Sanity completed successfully.
    ) else (
        echo Browser and Network Sanity returned error code %RC%.
    )
    echo Press any key to continue.
    pause >nul
) else (
    echo.
    pause
)

exit /b %RC%

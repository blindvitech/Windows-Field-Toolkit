$ErrorActionPreference = "SilentlyContinue"
$ProgressPreference = "SilentlyContinue"

$toolkitRoot = Split-Path $PSScriptRoot -Parent
$foundation = Join-Path $toolkitRoot "00_Common\Foundation-Common.ps1"
if (Test-Path -LiteralPath $foundation -PathType Leaf) { . $foundation }
$logs = Join-Path $toolkitRoot "Logs"
if (-not (Test-Path -LiteralPath $logs)) {
    New-Item -ItemType Directory -Path $logs -Force | Out-Null
}

$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$basePath = Join-Path $logs ($env:COMPUTERNAME + "_Browser_and_Network_Sanity_" + $stamp)
$writer = Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"

Write-Host "Collecting Browser and Network Sanity..."

$body = & {
Write-Output "===== WINHTTP PROXY ====="
$proxyNative = Invoke-ToolkitNativeCommand -FilePath "netsh.exe" -Arguments @("winhttp","show","proxy") -Label "Browser Sanity WinHTTP Proxy" -Action "Browser and Network Sanity" -Quiet
$proxyNative.Output
Write-Output "`n===== USER INTERNET SETTINGS ====="
Get-ItemProperty "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings" -ErrorAction SilentlyContinue |
    Select-Object ProxyEnable,ProxyServer,AutoConfigURL
Write-Output "`n===== NETWORK ADAPTER SANITY ====="
$adapterRows = @(Get-NetAdapter -ErrorAction SilentlyContinue |
    Select-Object Name,InterfaceDescription,Status,LinkSpeed,MacAddress,DriverInformation,DriverFileName,DriverVersion)
$adapterRows
Write-Output "`nAdapter statistics:"
Get-NetAdapterStatistics -ErrorAction SilentlyContinue |
    Select-Object Name,ReceivedBytes,SentBytes,ReceivedDiscardedPackets,OutboundDiscardedPackets,ReceivedPacketErrors,OutboundPacketErrors
Write-Output "`nSigned network drivers:"
Get-CimInstance Win32_PnPSignedDriver -ErrorAction SilentlyContinue |
    Where-Object { $_.DeviceClass -eq "NET" } |
    Select-Object DeviceName,DriverProviderName,DriverVersion,DriverDate,InfName,IsSigned
Write-Output "`nPower management:"
foreach ($adapter in $adapterRows) {
    try {
        Get-NetAdapterPowerManagement -Name $adapter.Name -ErrorAction Stop |
            Select-Object Name,AllowComputerToTurnOffDevice,WakeOnMagicPacket,WakeOnPattern
    } catch {}
}

Write-Output "`n===== DNS SUFFIX / SEARCH LIST ====="
Get-DnsClient -ErrorAction SilentlyContinue |
    Select-Object InterfaceAlias,ConnectionSpecificSuffix,RegisterThisConnectionsAddress,UseSuffixWhenRegistering
Get-DnsClientGlobalSetting -ErrorAction SilentlyContinue
Write-Output "`n===== TLS / SCHANNEL PROTOCOL KEYS ====="
Get-ChildItem "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols" -Recurse -ErrorAction SilentlyContinue |
    Select-Object PSPath
Write-Output "`n===== ROOT CERTIFICATE COUNT ====="
Get-ChildItem Cert:\LocalMachine\Root -ErrorAction SilentlyContinue | Measure-Object | Select-Object Count
Write-Output "`n===== HOSTS FILE ====="
Get-Content "$env:SystemRoot\System32\drivers\etc\hosts" -ErrorAction SilentlyContinue
} | Out-String -Width 240

if (-not (Test-Path -LiteralPath $writer)) {
    Write-Host "Report writer not found:"
    Write-Host $writer
    exit 3
}

& $writer -BasePath $basePath -Title "Browser and Network Sanity" -Body $body

$html = $basePath + ".html"
$txt = $basePath + ".txt"
$md = $basePath + ".md"

if (-not (Test-Path -LiteralPath $html) -or -not (Test-Path -LiteralPath $txt) -or -not (Test-Path -LiteralPath $md)) {
    Write-Host ""
    Write-Host "Collection finished, but one or more report files were not created."
    exit 4
}

Write-Host ""
Write-Host "Browser and Network Sanity complete."
Write-Host ("HTML: " + $html)
Write-Host ("Text: " + $txt)
Write-Host ("Markdown: " + $md)
exit 0

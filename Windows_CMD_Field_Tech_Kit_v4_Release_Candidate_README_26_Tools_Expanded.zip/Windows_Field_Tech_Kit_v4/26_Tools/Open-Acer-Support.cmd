@echo off

start "" "https://www.acer.com/us-en/support"
exit /b 0

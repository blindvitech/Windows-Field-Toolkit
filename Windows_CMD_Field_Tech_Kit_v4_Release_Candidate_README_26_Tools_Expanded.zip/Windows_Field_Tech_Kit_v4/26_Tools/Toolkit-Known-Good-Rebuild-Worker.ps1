param(
    [Parameter(Mandatory=$true)][string]$ToolkitRoot,
    [Parameter(Mandatory=$true)][string]$StageRoot,
    [Parameter(Mandatory=$true)][string]$ManifestPath
)

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

function Get-SHA256 {
    param([Parameter(Mandatory=$true)][string]$Path)
    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256 -ErrorAction Stop).Hash.ToUpperInvariant()
}

$manifest = (Get-Content -LiteralPath $ManifestPath -Raw -ErrorAction Stop) | ConvertFrom-Json -ErrorAction Stop
$logs = Join-Path $ToolkitRoot "Logs"
if (-not (Test-Path -LiteralPath $logs)) {
    New-Item -ItemType Directory -Path $logs -Force | Out-Null
}

$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$backupRoot = Join-Path $logs ("TOOLKIT_REBUILD_BACKUP_" + $stamp)
$journal = Join-Path $logs ("TOOLKIT_REBUILD_JOURNAL_" + $stamp + ".txt")
New-Item -ItemType Directory -Path $backupRoot -Force | Out-Null

$journalLines = New-Object System.Collections.Generic.List[string]
$journalLines.Add("TOOLKIT KNOWN-GOOD REBUILD JOURNAL")
$journalLines.Add("Started: " + (Get-Date))
$journalLines.Add("Toolkit root: " + $ToolkitRoot)
$journalLines.Add("Backup root: " + $backupRoot)
$journalLines.Add("Manifest generated: " + $manifest.Generated)
$journalLines.Add("")

$restore = New-Object System.Collections.Generic.List[object]
foreach ($entry in $manifest.Files) {
    $relative = [string]$entry.Path
    $live = Join-Path $ToolkitRoot ($relative -replace '/', [IO.Path]::DirectorySeparatorChar)
    $stage = Join-Path $StageRoot ($relative -replace '/', [IO.Path]::DirectorySeparatorChar)

    if (-not (Test-Path -LiteralPath $stage -PathType Leaf)) {
        throw "Verified stage unexpectedly lost file: $relative"
    }

    if (-not (Test-Path -LiteralPath $live -PathType Leaf)) {
        $restore.Add([pscustomobject]@{Status="MISSING";Path=$relative;Live=$live;Stage=$stage})
        continue
    }

    $liveHash = ""
    try { $liveHash = Get-SHA256 $live } catch {}
    if ($liveHash -ne ([string]$entry.SHA256).ToUpperInvariant()) {
        $restore.Add([pscustomobject]@{Status="MODIFIED";Path=$relative;Live=$live;Stage=$stage})
    }
}

if ($restore.Count -eq 0) {
    $journalLines.Add("No files required restoration.")
    $journalLines | Set-Content -LiteralPath $journal -Encoding UTF8
    Write-Host "No known toolkit files require restoration."
    exit 0
}

$journalLines.Add("Files requiring restoration: " + $restore.Count)
$journalLines.Add("")

$copyFailures = New-Object System.Collections.Generic.List[string]
foreach ($item in $restore) {
    try {
        if (Test-Path -LiteralPath $item.Live -PathType Leaf) {
            $backup = Join-Path $backupRoot ($item.Path -replace '/', [IO.Path]::DirectorySeparatorChar)
            $backupDir = Split-Path $backup -Parent
            if (-not (Test-Path -LiteralPath $backupDir)) {
                New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
            }
            Copy-Item -LiteralPath $item.Live -Destination $backup -Force -ErrorAction Stop
            $journalLines.Add("BACKUP  " + $item.Path)
        }
        else {
            $journalLines.Add("MISSING " + $item.Path + " - no prior file to back up")
        }

        $destDir = Split-Path $item.Live -Parent
        if (-not (Test-Path -LiteralPath $destDir)) {
            New-Item -ItemType Directory -Path $destDir -Force | Out-Null
        }

        Copy-Item -LiteralPath $item.Stage -Destination $item.Live -Force -ErrorAction Stop
        $journalLines.Add("RESTORE " + $item.Path)
    }
    catch {
        $message = $item.Path + " - " + $_.Exception.Message
        $copyFailures.Add($message)
        $journalLines.Add("FAILED  " + $message)
    }
}

$journalLines.Add("")
$journalLines.Add("POST-RESTORE HASH VERIFICATION")
$postFailures = New-Object System.Collections.Generic.List[string]
foreach ($entry in $manifest.Files) {
    $relative = [string]$entry.Path
    $live = Join-Path $ToolkitRoot ($relative -replace '/', [IO.Path]::DirectorySeparatorChar)
    if (-not (Test-Path -LiteralPath $live -PathType Leaf)) {
        $postFailures.Add("Missing after rebuild: " + $relative)
        continue
    }
    try {
        $hash = Get-SHA256 $live
        if ($hash -ne ([string]$entry.SHA256).ToUpperInvariant()) {
            $postFailures.Add("Hash mismatch after rebuild: " + $relative)
        }
    }
    catch {
        $postFailures.Add("Unreadable after rebuild: " + $relative)
    }
}

if ($postFailures.Count -eq 0) {
    $journalLines.Add("PASS - all known core files match the known-good manifest.")
}
else {
    foreach ($failure in $postFailures) { $journalLines.Add("FAIL - " + $failure) }
}

$journalLines.Add("")
$journalLines.Add("TOOLKIT SELF-TEST")
$selfTest = Join-Path $ToolkitRoot "26_Tools\Toolkit-Self-Test.ps1"
$selfTestRC = 999
if (Test-Path -LiteralPath $selfTest -PathType Leaf) {
    try {
        & powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File $selfTest -ToolkitRoot $ToolkitRoot
        $selfTestRC = $LASTEXITCODE
    }
    catch {
        $journalLines.Add("Self-test launch error: " + $_.Exception.Message)
    }
}
else {
    $journalLines.Add("Self-test script missing after rebuild.")
}
$journalLines.Add("Self-test return code: " + $selfTestRC)
$journalLines.Add("")
$journalLines.Add("Finished: " + (Get-Date))

$journalLines | Set-Content -LiteralPath $journal -Encoding UTF8

Write-Host ""
Write-Host ("Backup: " + $backupRoot)
Write-Host ("Journal: " + $journal)
Write-Host ("Files restored: " + ($restore.Count - $copyFailures.Count))
Write-Host ("Copy failures: " + $copyFailures.Count)
Write-Host ("Post-restore hash failures: " + $postFailures.Count)
Write-Host ("Self-test return code: " + $selfTestRC)

if ($copyFailures.Count -gt 0 -or $postFailures.Count -gt 0 -or $selfTestRC -ne 0) {
    Write-Host "Toolkit rebuild completed with verification failures. Review the journal."
    exit 5
}

Write-Host "Toolkit rebuild and verification: PASS"
exit 0

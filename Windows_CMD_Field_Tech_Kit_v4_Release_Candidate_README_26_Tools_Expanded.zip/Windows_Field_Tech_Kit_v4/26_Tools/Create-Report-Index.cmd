@echo off
setlocal EnableExtensions
title Create Report / Export Index

echo Create Report / Export Index
echo.
echo Scanning the Logs folder and creating a browsable local index.
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Create-Report-Index.ps1"
set "RC=%errorlevel%"

if "%SRMODE%"=="1" (
    echo.
    if "%RC%"=="0" (
        echo Create Report / Export Index completed successfully.
    ) else (
        echo Create Report / Export Index returned error code %RC%.
    )
    echo Press any key to continue.
    pause >nul
) else (
    echo.
    pause
)

exit /b %RC%

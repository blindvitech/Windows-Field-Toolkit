@echo off
title PKTMON Start Capture - ADMIN
net session >nul 2>&1
if not "%errorlevel%"=="0" (
    echo Administrator privileges required.
    if "%SRMODE%"=="1" (
        echo Press any key to continue.
        pause >nul
    ) else (
        pause
    )
    exit /b 1
)
set "LOGDIR=%~dp0..\Logs"
if not exist "%LOGDIR%" mkdir "%LOGDIR%"
set "ETL=%LOGDIR%\%COMPUTERNAME%_pktmon_capture.etl"

echo Starting packet capture...
pktmon filter remove >nul 2>&1
pktmon start --etw -p 0 -c --file-name "%ETL%"
echo.
echo Capture started.
echo ETL: %ETL%
echo Use the Stop/Convert option from Tools when finished.
if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)


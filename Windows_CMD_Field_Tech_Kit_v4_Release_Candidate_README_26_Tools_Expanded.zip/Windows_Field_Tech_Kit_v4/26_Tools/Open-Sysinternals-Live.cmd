@echo off

start "" "https://live.sysinternals.com/"
exit /b 0

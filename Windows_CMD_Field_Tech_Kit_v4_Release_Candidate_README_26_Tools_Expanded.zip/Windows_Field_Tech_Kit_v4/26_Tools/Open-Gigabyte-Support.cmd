@echo off

start "" "https://www.gigabyte.com/Support"
exit /b 0

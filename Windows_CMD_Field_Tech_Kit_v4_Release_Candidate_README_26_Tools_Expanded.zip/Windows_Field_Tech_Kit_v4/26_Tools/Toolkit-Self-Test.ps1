param(
    [string]$ToolkitRoot = (Split-Path $PSScriptRoot -Parent),
    [ValidateSet("Quick","Full","NoSimulation","DiagnosticLogic")][string]$Level = "Full"
)

try {
    $ToolkitRoot = (Resolve-Path -LiteralPath $ToolkitRoot -ErrorAction Stop).Path.TrimEnd([char[]]@(92,47))
}
catch {
    $ToolkitRoot = [IO.Path]::GetFullPath($ToolkitRoot).TrimEnd([char[]]@(92,47))
}

$screenReaderCommon = Join-Path (Split-Path $PSScriptRoot -Parent) "00_Common\ScreenReader-Common.ps1"
if (Test-Path -LiteralPath $screenReaderCommon -PathType Leaf) {
    . $screenReaderCommon
}

$ErrorActionPreference = "SilentlyContinue"

$results = New-Object System.Collections.Generic.List[object]

function Add-Test {
    param(
        [string]$Test,
        [bool]$Passed,
        [string]$Details
    )
    $results.Add([pscustomobject]@{
        Test = $Test
        Status = $(if ($Passed) { "PASS" } else { "FAIL" })
        Details = $Details
    })
}

function Get-ToolkitRelativePath {
    param([Parameter(Mandatory=$true)][string]$FullPath)

    try {
        $resolved = (Resolve-Path -LiteralPath $FullPath -ErrorAction Stop).Path
    }
    catch {
        $resolved = [IO.Path]::GetFullPath($FullPath)
    }

    $prefix = $ToolkitRoot + [IO.Path]::DirectorySeparatorChar
    if ($resolved.StartsWith($prefix,[System.StringComparison]::OrdinalIgnoreCase)) {
        return $resolved.Substring($prefix.Length)
    }
    if ($resolved -ieq $ToolkitRoot) {
        return ""
    }
    return $resolved
}

if ($Level -eq "DiagnosticLogic") {
    $diagnosticHelper = Join-Path $ToolkitRoot "00_Common\Diagnostic-Evidence.ps1"
    $diagnosticFixtures = Join-Path $ToolkitRoot "00_Common\Diagnostic-Fixtures.json"
    $versionFile = Join-Path $ToolkitRoot "00_Common\Toolkit-Version.json"

    Add-Test "Diagnostic evidence helper exists" (Test-Path -LiteralPath $diagnosticHelper -PathType Leaf) $diagnosticHelper
    Add-Test "Diagnostic fixtures exist" (Test-Path -LiteralPath $diagnosticFixtures -PathType Leaf) $diagnosticFixtures
    Add-Test "Toolkit v4 metadata exists" (Test-Path -LiteralPath $versionFile -PathType Leaf) $versionFile

    if ((Test-Path -LiteralPath $diagnosticHelper -PathType Leaf) -and (Test-Path -LiteralPath $diagnosticFixtures -PathType Leaf)) {
        try {
            . $diagnosticHelper
            $fixtureResults = @(Test-ToolkitDiagnosticFixtures -FixturePath $diagnosticFixtures)
            foreach($fixture in $fixtureResults) {
                Add-Test $fixture.Test ([bool]$fixture.Passed) ("Expected=" + $fixture.Expected + "; Actual=" + $fixture.Actual)
            }
            Add-Test "Diagnostic schema version" ((Get-ToolkitDiagnosticSchemaVersion) -eq "1.0") ("Schema=" + (Get-ToolkitDiagnosticSchemaVersion))
            Add-Test "Diagnostic classifier version" ((Get-ToolkitDiagnosticClassifierVersion) -eq "4.1.0") ("Classifier=" + (Get-ToolkitDiagnosticClassifierVersion))

            $corrTemp=Join-Path $env:TEMP ("FieldTechEvidenceCorrelation_"+[guid]::NewGuid().ToString("N"))
            try{
                New-Item -ItemType Directory -Path $corrTemp -Force|Out-Null
                $sharedId=Get-ToolkitEvidenceId -Category "WindowsEvent" -Source "disk" -EventId "11" -Timestamp ([datetime]"2026-09-11T20:00:00") -Device "Disk 3 Generic Reader" -Evidence "controller error"
                foreach($n in 1,2){
                    $payload=[pscustomobject]@{
                        Report=[pscustomobject]@{ToolId=$(if($n -eq 1){"ADV-006"}else{"ADV-007"});Title=("Fixture "+$n);GeneratedAt=(Get-Date)}
                        Findings=@()
                        Evidence=@([pscustomobject]@{EvidenceId=$sharedId;Class="Storage";DeviceContext="Disk 3 Generic Reader";Timestamp="2026-09-11T20:00:00";Source="disk";EventId="11"})
                    }
                    $payload|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $corrTemp ("fixture"+$n+".evidence.json")) -Encoding UTF8
                }
                $corr=Update-ToolkitEvidenceCorrelationIndex -LogRoot $corrTemp
                Add-Test "Evidence correlation fixture" ($corr.CorrelatedEvidenceCount -eq 1 -and $corr.CorrelatedEvidence[0].ReportCount -eq 2) ("CorrelatedEvidence="+$corr.CorrelatedEvidenceCount+"; Reports="+$corr.CorrelatedEvidence[0].ReportCount)

                $healthCurrent=Get-ToolkitEvidenceCorrelationHealth -LogRoot $corrTemp
                Add-Test "Evidence correlation health current" ($healthCurrent.Status -eq "CURRENT" -and $healthCurrent.Healthy) ("Status="+$healthCurrent.Status)
                Start-Sleep -Milliseconds 25
                Add-Content -LiteralPath (Join-Path $corrTemp "fixture1.evidence.json") -Value " " -Encoding UTF8
                $healthStale=Get-ToolkitEvidenceCorrelationHealth -LogRoot $corrTemp
                Add-Test "Evidence correlation health stale detection" ($healthStale.Status -eq "STALE" -and -not $healthStale.Healthy) ("Status="+$healthStale.Status)
            }catch{
                Add-Test "Evidence correlation fixture" $false $_.Exception.Message
            }finally{
                Remove-Item -LiteralPath $corrTemp -Recurse -Force -ErrorAction SilentlyContinue
            }
        }
        catch {
            Add-Test "Diagnostic fixture execution" $false $_.Exception.Message
        }
    }

    $failedDiagnostic = @($results | Where-Object Status -eq "FAIL")
    Write-Host ""
    Write-Host "WINDOWS FIELD TECH TOOLKIT SELF-TEST - DIAGNOSTIC LOGIC"
    $results | Format-Table -AutoSize -Wrap
    Write-Host ""
    Write-Host $(if ($failedDiagnostic.Count -eq 0) { "Diagnostic logic self-test: PASS" } else { "Diagnostic logic self-test: FAIL" })
    exit $(if ($failedDiagnostic.Count -eq 0) { 0 } else { 1 })
}

if ($Level -eq "Quick") {
    $quickLauncher = Join-Path $ToolkitRoot "RUN-WINDOWS-FIELD-TECH.cmd"
    $quickCatalog = Join-Path $ToolkitRoot "00_Common\ToolCatalog.json"
    $quickFoundation = Join-Path $ToolkitRoot "00_Common\Foundation-Common.ps1"
    $quickKnownGood = Join-Path $ToolkitRoot "26_Tools\KnownGood\Toolkit-Core-Manifest.json"
    $quickDiagnostic = Join-Path $ToolkitRoot "00_Common\Diagnostic-Evidence.ps1"
    $quickFixtures = Join-Path $ToolkitRoot "00_Common\Diagnostic-Fixtures.json"
    $quickVersion = Join-Path $ToolkitRoot "00_Common\Toolkit-Version.json"
    $quickSectioned = Join-Path $ToolkitRoot "00_Common\Sectioned-Html-Report.ps1"
    $quickAssessmentConfidence = Join-Path $ToolkitRoot "00_Common\Assessment-Confidence.ps1"
    Add-Test "Root launcher exists" (Test-Path -LiteralPath $quickLauncher -PathType Leaf) $quickLauncher
    Add-Test "Foundation exists" (Test-Path -LiteralPath $quickFoundation -PathType Leaf) $quickFoundation
    Add-Test "Tool catalog exists" (Test-Path -LiteralPath $quickCatalog -PathType Leaf) $quickCatalog
    Add-Test "Known-Good manifest exists" (Test-Path -LiteralPath $quickKnownGood -PathType Leaf) $quickKnownGood
    Add-Test "Toolkit v4 diagnostic engine exists" (Test-Path -LiteralPath $quickDiagnostic -PathType Leaf) $quickDiagnostic
    Add-Test "Toolkit v4 diagnostic fixtures exist" (Test-Path -LiteralPath $quickFixtures -PathType Leaf) $quickFixtures
    Add-Test "Toolkit v4 metadata exists" (Test-Path -LiteralPath $quickVersion -PathType Leaf) $quickVersion
    Add-Test "Sectioned long-report renderer exists" (Test-Path -LiteralPath $quickSectioned -PathType Leaf) $quickSectioned
    Add-Test "Shared assessment confidence helper exists" (Test-Path -LiteralPath $quickAssessmentConfidence -PathType Leaf) $quickAssessmentConfidence

    $catalogCount = 0
    try {
        $cat = Get-Content -LiteralPath $quickCatalog -Raw | ConvertFrom-Json
        $catalogCount = @($cat.Tools).Count
    } catch {}
    Add-Test "Tool catalog count" ($catalogCount -eq 158) ("Catalog tools: " + $catalogCount)

    $logs = Join-Path $ToolkitRoot "Logs"
    $writable = $false
    try {
        if (-not (Test-Path -LiteralPath $logs)) { New-Item -ItemType Directory -Path $logs -Force | Out-Null }
        $probe = Join-Path $logs (".quick_selftest_" + [guid]::NewGuid().ToString("N") + ".tmp")
        "probe" | Set-Content -LiteralPath $probe -Encoding ASCII -ErrorAction Stop
        Remove-Item -LiteralPath $probe -Force -ErrorAction Stop
        $writable = $true
    } catch {}
    Add-Test "Logs writable" $writable $logs
    Add-Test "PowerShell available" ($PSVersionTable.PSVersion.Major -ge 5) ("PowerShell " + $PSVersionTable.PSVersion)

    $failedQuick = @($results | Where-Object Status -eq "FAIL")
    Write-Host ""
    Write-Host "WINDOWS FIELD TECH TOOLKIT SELF-TEST - QUICK"
    $results | Format-Table -AutoSize -Wrap
    Write-Host ""
    Write-Host $(if ($failedQuick.Count -eq 0) { "Quick self-test: PASS" } else { "Quick self-test: FAIL" })
    exit $(if ($failedQuick.Count -eq 0) { 0 } else { 1 })
}

$launcher = Join-Path $ToolkitRoot "RUN-WINDOWS-FIELD-TECH.cmd"
Add-Test "Root launcher exists" (Test-Path -LiteralPath $launcher) $launcher

$rootCmds = @(Get-ChildItem -LiteralPath $ToolkitRoot -Filter "*.cmd" -File -ErrorAction SilentlyContinue)
Add-Test "One root CMD launcher" ($rootCmds.Count -eq 1 -and $rootCmds[0].Name -ieq "RUN-WINDOWS-FIELD-TECH.cmd") ("Root CMD count: " + $rootCmds.Count)

$legacyRootStaticDocs = @(
    "ACCESSIBILITY-AUDIT.txt",
    "RELEASE-MANIFEST-v4.txt",
    "REPAIR-CONFIRMATION-AUDIT.txt",
    "SCRIPT-AUDIT.txt",
    "STATE-CHANGE-CONFIRMATION-AUDIT.txt"
)
$legacyRootStaticDocsPresent = @(
    $legacyRootStaticDocs | Where-Object {
        Test-Path -LiteralPath (Join-Path $ToolkitRoot $_) -PathType Leaf
    }
)
Add-Test "Static documentation root cleanup" `
    ($legacyRootStaticDocsPresent.Count -eq 0) `
    ("Legacy root documentation files present: " + ($legacyRootStaticDocsPresent -join ", "))


$essential = @(
    "00_Common\Convert-TextReport.ps1",
    "00_Common\Write-TriReport.ps1",
    "00_Common\Sectioned-Html-Report.ps1",
    "00_Common\Assessment-Confidence.ps1",
    "00_Common\Show-Basic-Next-Step.ps1",
    "00_Common\Diagnostic-Evidence.ps1",
    "00_Common\Diagnostic-Fixtures.json",
    "00_Common\Toolkit-Version.json",
    "VERSION.txt",
    "Documentation\ACCESSIBILITY-AUDIT.txt",
    "Documentation\RELEASE-MANIFEST-v4.txt",
    "Documentation\REPAIR-CONFIRMATION-AUDIT.txt",
    "Documentation\SCRIPT-AUDIT.txt",
    "Documentation\STATE-CHANGE-CONFIRMATION-AUDIT.txt",
    "FIELD-VALIDATION-STATUS.txt",
    "00_Common\Invoke-Elevated-Self.ps1",
    "00_Common\Foundation-Common.ps1",
    "00_Common\Get-Toolkit-SessionId.ps1",
    "00_Common\Initialize-Toolkit-Runtime.ps1",
    "00_Common\First-Run-Validation.ps1",
    "00_Common\Refresh-Menu-Capabilities.ps1",
    "00_Common\Invoke-Native-Bridge.ps1",
    "00_Common\Invoke-Toolkit-MenuTool.ps1",
    "00_Common\Capture-Active-Case-Artifacts.ps1",
    "00_Common\FOUNDATION-ARCHITECTURE.txt",
    "00_Common\ToolCatalog.json",
    "00_Common\Compatibility-Matrix.json",
    "00_Common\Retention-Maintenance.ps1",
    "00_Common\Close-Toolkit-Session.ps1",
    "26_Tools\Toolkit-Foundation-Health.cmd",
    "26_Tools\Toolkit-Foundation-Health.ps1",
    "26_Tools\Menu-Search.cmd",
    "26_Tools\Menu-Search.ps1",
    "05_Security_and_Accounts\Defender-Status.ps1",
    "06_Hardware\Storage-Health-Snapshot.ps1",
    "07_Convenience\Open-Admin-CMD.ps1",
    "09_Security_Network_State\Firewall-Status-Snapshot.ps1",
    "09_Security_Network_State\SMB-Shares-and-Mapped-Drives.ps1",
    "10_Device_and_Firmware\BIOS-UEFI-SecureBoot-TPM.ps1",
    "13_Network_Triage\NETWORK-TRIAGE.ps1",
    "13_Network_Triage\Port-Test.ps1",
    "00_Full_Machine_Report\RUN-FULL-MACHINE-REPORT.cmd",
    "00_Full_Machine_Report\Full-Machine-Report.ps1",
    "12_Field_Intake\Machine-Intake-Summary.cmd",
    "12_Field_Intake\Machine-Intake-Summary.ps1",
    "27_Support_Bundle\CREATE-SUPPORT-BUNDLE.cmd",
    "27_Support_Bundle\Create-Share-Safe-Report.cmd",
    "28_Repair\Repair-Common.ps1",
    "28_Repair\DISM-Service-Center-ADMIN.cmd",
    "28_Repair\DISM-Service-Center.ps1",
    "28_Repair\BitLocker-Protection-Control-ADMIN.cmd",
    "28_Repair\BitLocker-Protection-Control.ps1",
    "29_Advanced_Audit\Recent-Changes-Timeline.cmd",
    "29_Advanced_Audit\Recent-Changes-Timeline.ps1",
    "29_Advanced_Audit\Defender-Security-Audit.cmd",
    "29_Advanced_Audit\Defender-Security-Audit.ps1",
    "29_Advanced_Audit\WiFi-Adapter-Capability.cmd",
    "29_Advanced_Audit\WiFi-Adapter-Capability.ps1",
    "29_Advanced_Audit\Why-Did-This-PC-Reboot.cmd",
    "29_Advanced_Audit\Why-Did-This-PC-Reboot.ps1",
    "29_Advanced_Audit\Network-Before-After-Compare.cmd",
    "29_Advanced_Audit\Network-Before-After-Compare.ps1",
    "26_Tools\Create-Report-Index.cmd",
    "26_Tools\Create-Report-Index.ps1",
    "30_Assessment_Case\Profile-Health-Audit.cmd",
    "30_Assessment_Case\Profile-Health-Audit.ps1",
    "30_Assessment_Case\Application-Crash-Investigator.cmd",
    "30_Assessment_Case\Application-Crash-Investigator.ps1",
    "30_Assessment_Case\Local-Security-Baseline-Compare.cmd",
    "30_Assessment_Case\Local-Security-Baseline-Compare.ps1",
    "30_Assessment_Case\Event-Viewer-What-Matters.cmd",
    "30_Assessment_Case\Event-Viewer-What-Matters.ps1",
    "30_Assessment_Case\Certificate-TLS-Audit.cmd",
    "30_Assessment_Case\Certificate-TLS-Audit.ps1",
    "30_Assessment_Case\Collect-Case-Mode.cmd",
    "30_Assessment_Case\Collect-Case-Mode.ps1",
    "30_Assessment_Case\Full-Machine-Before-After-Compare.cmd",
    "30_Assessment_Case\Full-Machine-Before-After-Compare.ps1",
    "30_Assessment_Case\Boot-Startup-Performance-Audit.cmd",
    "30_Assessment_Case\Boot-Startup-Performance-Audit.ps1",
    "30_Assessment_Case\Browser-Health-Audit.cmd",
    "30_Assessment_Case\Browser-Health-Audit.ps1",
    "30_Assessment_Case\Windows-Update-Failure-Investigator.cmd",
    "30_Assessment_Case\Windows-Update-Failure-Investigator.ps1",
    "30_Assessment_Case\Authentication-Logon-Investigator.cmd",
    "30_Assessment_Case\Authentication-Logon-Investigator.ps1",
    "30_Assessment_Case\USB-Removable-Device-History.cmd",
    "30_Assessment_Case\USB-Removable-Device-History.ps1",
    "30_Assessment_Case\Power-Sleep-Wake-Investigator.cmd",
    "30_Assessment_Case\Power-Sleep-Wake-Investigator.ps1",
    "30_Assessment_Case\Printer-Failure-Investigator.cmd",
    "30_Assessment_Case\Printer-Failure-Investigator.ps1",
    "30_Assessment_Case\Network-Path-Investigator.cmd",
    "30_Assessment_Case\Network-Path-Investigator.ps1",
    "30_Assessment_Case\DNS-Resolution-Chain-Investigator.cmd",
    "30_Assessment_Case\DNS-Resolution-Chain-Investigator.ps1",
    "30_Assessment_Case\DHCP-Lease-State-Deep-Dive.cmd",
    "30_Assessment_Case\DHCP-Lease-State-Deep-Dive.ps1",
    "30_Assessment_Case\Network-Driver-Event-Correlation.cmd",
    "30_Assessment_Case\Network-Driver-Event-Correlation.ps1",
    "30_Assessment_Case\SMB-Connectivity-Troubleshooting-Investigator.cmd",
    "30_Assessment_Case\SMB-Connectivity-Troubleshooting-Investigator.ps1",
    "30_Assessment_Case\Hardware-Error-Investigator.cmd",
    "30_Assessment_Case\Hardware-Error-Investigator.ps1",
    "30_Assessment_Case\Scheduled-Task-Investigator.cmd",
    "30_Assessment_Case\Scheduled-Task-Investigator.ps1",
    "30_Assessment_Case\Service-Failure-Investigator.cmd",
    "30_Assessment_Case\Service-Failure-Investigator.ps1",
    "31_Hardware_Acceptance\Hardware-Acceptance-Test.cmd",
    "31_Hardware_Acceptance\Hardware-Acceptance-Test.ps1",
    "30_Assessment_Case\Change-Comparison-Dashboard.cmd",
    "30_Assessment_Case\Change-Comparison-Dashboard.ps1",
    "30_Assessment_Case\Case-Technician-Notes.cmd",
    "30_Assessment_Case\Case-Technician-Notes.ps1",
    "30_Assessment_Case\Case-Closeout-Report.cmd",
    "30_Assessment_Case\Case-Closeout-Report.ps1",
    "26_Tools\Toolkit-Known-Good-Rebuild.cmd",
    "26_Tools\Toolkit-Known-Good-Rebuild.ps1",
    "26_Tools\Toolkit-Known-Good-Rebuild-Worker.ps1",
    "26_Tools\KnownGood\Toolkit-Core-KnownGood.zip",
    "26_Tools\KnownGood\Toolkit-Core-Manifest.json",
    "26_Tools\KnownGood\Toolkit-Core-KnownGood.sha256",
    "26_Tools\KnownGood\Toolkit-Core-Manifest.sha256"
)
foreach ($rel in $essential) {
    $path = Join-Path $ToolkitRoot $rel
    Add-Test ("Essential file: " + $rel) (Test-Path -LiteralPath $path) $path
}

$readmePath=Join-Path $ToolkitRoot "README.txt"
$scriptAuditPath=Join-Path $ToolkitRoot "Documentation\SCRIPT-AUDIT.txt"
$accessAuditPath=Join-Path $ToolkitRoot "Documentation\ACCESSIBILITY-AUDIT.txt"
$versionTextPath=Join-Path $ToolkitRoot "VERSION.txt"
$versionJsonPath=Join-Path $ToolkitRoot "00_Common\Toolkit-Version.json"
$readmeText=$(if(Test-Path -LiteralPath $readmePath -PathType Leaf){Get-Content -LiteralPath $readmePath -Raw -ErrorAction SilentlyContinue}else{""})
$scriptAuditText=$(if(Test-Path -LiteralPath $scriptAuditPath -PathType Leaf){Get-Content -LiteralPath $scriptAuditPath -Raw -ErrorAction SilentlyContinue}else{""})
$accessAuditText=$(if(Test-Path -LiteralPath $accessAuditPath -PathType Leaf){Get-Content -LiteralPath $accessAuditPath -Raw -ErrorAction SilentlyContinue}else{""})
$versionText=$(if(Test-Path -LiteralPath $versionTextPath -PathType Leaf){Get-Content -LiteralPath $versionTextPath -Raw -ErrorAction SilentlyContinue}else{""})
$versionJsonText=$(if(Test-Path -LiteralPath $versionJsonPath -PathType Leaf){Get-Content -LiteralPath $versionJsonPath -Raw -ErrorAction SilentlyContinue}else{""})

$documentationCurrentStatePass=(
    $readmeText.IndexOf('CURRENT BUILD SNAPSHOT',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $readmeText.IndexOf('CONTENTS / DOCUMENT MAP',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $readmeText.IndexOf('WINPE / WINRE OFFLINE COMPANION',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $readmeText.IndexOf('COLLECT CASE - LIVE ARTIFACT CAPTURE',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    ([regex]::Matches($readmeText,'(?im)^END\r?$')).Count -eq 1 -and
    $readmeText.LastIndexOf('END',[System.StringComparison]::OrdinalIgnoreCase) -gt $readmeText.IndexOf('COLLECT CASE - LIVE ARTIFACT CAPTURE',[System.StringComparison]::OrdinalIgnoreCase) -and
    $scriptAuditText.IndexOf('CURRENT AUDIT STATUS',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $scriptAuditText.IndexOf('HISTORICAL AUDIT CHRONOLOGY',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $accessAuditText.IndexOf('CURRENT ACCESSIBILITY STATUS',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $accessAuditText.IndexOf('HISTORICAL AUDIT CHRONOLOGY',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $accessAuditText.IndexOf('Basic: 25',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $accessAuditText.IndexOf('Advanced: 76',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $accessAuditText.IndexOf('Tools: 43',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $accessAuditText.IndexOf('Repair: 14',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $accessAuditText.IndexOf('does not add synthetic "Prompt" or "Input" labels',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $versionText.IndexOf('Release-line baseline date:',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $versionJsonText.IndexOf('"ReleaseDateMeaning"',[System.StringComparison]::OrdinalIgnoreCase) -ge 0
)
Add-Test "Documentation current-state front matter" $documentationCurrentStatePass `
    $(if($documentationCurrentStatePass){"README navigation/current snapshot, audit current-state headers/history labels, and release-date semantics present"}else{"Documentation current-state front matter or date semantics incomplete"})

$launcherText = ""
if (Test-Path -LiteralPath $launcher) {
    $launcherText = Get-Content -LiteralPath $launcher -Raw
}

# WinPE / WinRE Offline Companion regression.
$winpeCompanionRoot = Join-Path $ToolkitRoot "90_WinPE_Offline_Companion"
$winpeRequiredFiles = @(
    "RUN-WINPE-OFFLINE-TECH.cmd",
    "README-WINPE.txt",
    "WINPE-COMPANION-VERSION.txt",
    "WINPE-MEDIA-BUILD-GUIDE.txt",
    "00_Common\WinPE-Common.cmd",
    "01_Detect_Offline_Windows\Detect-Offline-Windows.cmd",
    "02_Disk_Layout\Disk-Layout.cmd",
    "03_Offline_SFC\Offline-SFC.cmd",
    "04_Offline_DISM\Offline-DISM.cmd",
    "05_Boot_EFI\Boot-EFI-Repair.cmd",
    "06_BitLocker\BitLocker-Offline.cmd",
    "07_Offline_Registry\Offline-Registry-Audit.cmd",
    "08_Data_Rescue\Data-Rescue.cmd",
    "09_Log_Harvester\Log-Harvester.cmd",
    "10_Driver_Network\Driver-Network.cmd",
    "11_Pending_Actions\Pending-Actions.cmd"
)
$winpeMissingFiles = @($winpeRequiredFiles | Where-Object {
    -not (Test-Path -LiteralPath (Join-Path $winpeCompanionRoot $_) -PathType Leaf)
})
Add-Test "WinPE Offline Companion file set" ($winpeMissingFiles.Count -eq 0) `
    $(if($winpeMissingFiles.Count -eq 0){"Companion launcher/common/docs and 11 offline workflows present"}else{"Missing: "+($winpeMissingFiles -join "; ")})

$miniNtIndex = $launcherText.IndexOf('reg query HKLM\SYSTEM\CurrentControlSet\Control\MiniNT',[System.StringComparison]::OrdinalIgnoreCase)
$winpeRouteIndex = $launcherText.IndexOf('90_WinPE_Offline_Companion\RUN-WINPE-OFFLINE-TECH.cmd',[System.StringComparison]::OrdinalIgnoreCase)
$firstPowerShellIndex = $launcherText.IndexOf('powershell.exe',[System.StringComparison]::OrdinalIgnoreCase)
$winpeRoutePass = (
    $miniNtIndex -ge 0 -and
    $winpeRouteIndex -ge 0 -and
    $firstPowerShellIndex -ge 0 -and
    $miniNtIndex -lt $firstPowerShellIndex -and
    $winpeRouteIndex -lt $firstPowerShellIndex
)
Add-Test "WinPE handoff occurs before PowerShell dependency" $winpeRoutePass `
    ("MiniNT index="+$miniNtIndex+"; route index="+$winpeRouteIndex+"; first PowerShell index="+$firstPowerShellIndex)

$winpeCmdFiles = @(Get-ChildItem -LiteralPath $winpeCompanionRoot -Filter "*.cmd" -File -Recurse -ErrorAction SilentlyContinue)
$winpeCmdText = (($winpeCmdFiles | ForEach-Object {
    Get-Content -LiteralPath $_.FullName -Raw -ErrorAction SilentlyContinue
}) -join "`n")
$winpePowerShellCalls = @($winpeCmdFiles | Where-Object {
    (Get-Content -LiteralPath $_.FullName -Raw -ErrorAction SilentlyContinue) -match '(?im)^\s*powershell(?:\.exe)?\b'
})
Add-Test "WinPE Companion has no PowerShell runtime dependency" ($winpePowerShellCalls.Count -eq 0) `
    ("Companion CMD files="+$winpeCmdFiles.Count+"; PowerShell-call files="+$winpePowerShellCalls.Count)

$winpeSafetyPass = (
    $winpeCmdText.IndexOf('Type SFC OFFLINE exactly',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $winpeCmdText.IndexOf('Type DISM RESTORE exactly',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $winpeCmdText.IndexOf('Type BCDBOOT exactly',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $winpeCmdText.IndexOf('Type COPY DATA exactly',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $winpeCmdText.IndexOf('Type LOAD DRIVER exactly',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $winpeCmdText.IndexOf('Type REVERT PENDING ACTIONS exactly',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $winpeCmdText.IndexOf('manage-bde -unlock %DRV% -password',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $winpeCmdText -notmatch '(?im)^\s*manage-bde\b.*\s-recoverypassword\b' -and
    $winpeCmdText -notmatch '(?im)^\s*robocopy\b.*(?:\s/MIR\b|\s/PURGE\b|\s/MOVE\b)'
)
Add-Test "WinPE Companion state-change and privacy contract" $winpeSafetyPass `
    $(if($winpeSafetyPass){"Typed repair gates present; no recovery-password wrapper or destructive Robocopy modes"}else{"WinPE safety contract missing or regressed"})

Add-Test "Advanced menu total 76" ($launcherText -match 'There are 76 numbered advanced tools\.') "Expected Advanced total: 76"
Add-Test "Advanced deep investigator range" ($launcherText -match 'Tools 58 through 76\.') "Expected screen-reader category 58 through 76"
$choicePromptCount = ([regex]::Matches($launcherText, '(?im)^set /p choice=Select an option:')).Count
$choiceClearPromptCount = ([regex]::Matches($launcherText, '(?im)^set "choice="\r?\nset /p choice=Select an option:')).Count
Add-Test "Menu prompts clear stale choice" `
    ($choicePromptCount -gt 0 -and $choiceClearPromptCount -eq $choicePromptCount) `
    ("choice prompts=" + $choicePromptCount + "; cleared prompts=" + $choiceClearPromptCount)

Add-Test "Basic routing isolated from batch control flow" `
    (($launcherText -match 'Show-Basic-Next-Step\.ps1') -and
     ($launcherText -notmatch '(?m)^:BASIC_NEXT_STEP\s*$')) `
    "Expected external PowerShell routing helper and no BASIC_NEXT_STEP batch label"

Add-Test "Tools menu total 43" ($launcherText -match 'There are 43 numbered tools\.') "Expected Tools total: 43"
Add-Test "Case workflow menu entries" (($launcherText -match 'Change Comparison Dashboard') -and ($launcherText -match 'Case Notes / Technician Notes') -and ($launcherText -match 'Case Closeout Report')) "Expected Tools 39 through 41"
Add-Test "Known-good rebuild menu entry" ($launcherText -match 'Toolkit Known-Good Integrity / Rebuild') "Expected Tools 42"
Add-Test "Foundation health menu entry" (($launcherText -match '43\. Toolkit Foundation Health') -and ($launcherText -match 'Toolkit-Foundation-Health\.cmd')) "Expected Tools 43"
Add-Test "Repair DISM Service Center menu entry" (($launcherText -match '13\. DISM Service Center') -and ($launcherText -match 'DISM-Service-Center-ADMIN\.cmd')) "Expected Repair item 13"
Add-Test "Hardware Acceptance menu entry" (($launcherText -match '70\. Hardware Acceptance Test') -and ($launcherText -match 'Hardware-Acceptance-Test\.cmd')) "Expected Advanced item 70"
Add-Test "Network investigator menu entries" `
    (($launcherText -match '71\. DNS Resolution Chain Investigator') -and
     ($launcherText -match '72\. DHCP Lease / State Deep Dive') -and
     ($launcherText -match '73\. Network Driver / Event Correlation') -and
     ($launcherText -match 'DNS-Resolution-Chain-Investigator\.cmd') -and
     ($launcherText -match 'DHCP-Lease-State-Deep-Dive\.cmd') -and
     ($launcherText -match 'Network-Driver-Event-Correlation\.cmd')) `
    "Expected Advanced items 71 through 73"
Add-Test "SMB investigator menu entry" `
    (($launcherText -match '74\. SMB Connectivity / Troubleshooting Investigator') -and
     ($launcherText -match 'SMB-Connectivity-Troubleshooting-Investigator\.cmd')) `
    "Expected Advanced item 74"


Add-Test "Windows servicing health report menu entry" `
    (($launcherText -match '75\. Windows Servicing / Update Health Report') -and
     ($launcherText -match 'Windows-Servicing-Update-Health-Report\.cmd')) `
    "Expected Advanced item 75"

Add-Test "Domain trust AD health investigator menu entry" `
    (($launcherText -match '76\. Domain Trust / AD Health Investigator') -and
     ($launcherText -match 'Domain-Trust-AD-Health-Investigator\.cmd')) `
    "Expected Advanced item 76"

$catalogPath = Join-Path $ToolkitRoot "00_Common\ToolCatalog.json"
$catalogPass = $false
$catalogDetails = "Catalog missing"
$menuCountMismatches = @("Catalog unavailable")
try {
    $catalog = Get-Content -LiteralPath $catalogPath -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
    $catalogTools = @($catalog.Tools)
    $ids = @($catalogTools | ForEach-Object { [string]$_.ToolId })

    $expectedMenuCounts = [ordered]@{
        BASIC = 25
        ADVANCED = 76
        TOOLS = 43
        REPAIR = 14
    }
    $menuCountMismatches = @(
        foreach($menuName in $expectedMenuCounts.Keys) {
            $expectedCount = [int]$expectedMenuCounts[$menuName]
            $summaryProperty = $catalog.Menus.PSObject.Properties[$menuName]
            $summaryCount = $(if($summaryProperty){[int]$summaryProperty.Value}else{-1})
            $actualCount = @($catalogTools | Where-Object { [string]$_.Menu -eq $menuName }).Count

            if($summaryCount -ne $expectedCount -or $actualCount -ne $expectedCount) {
                [pscustomobject]@{
                    Menu = $menuName
                    Expected = $expectedCount
                    Summary = $summaryCount
                    Actual = $actualCount
                }
            }
        }
    )

    $catalogPass = (
        [int]$catalog.SchemaVersion -eq 1 -and
        $catalogTools.Count -eq 158 -and
        (@($ids | Sort-Object -Unique).Count -eq 158) -and
        $menuCountMismatches.Count -eq 0 -and
        (@($catalogTools | Where-Object {
            -not $_.RelativePath -or
            -not $_.OperationClass -or
            -not $_.ToolId -or
            -not $_.PSObject.Properties["RequiredDependencies"] -or
            -not $_.PSObject.Properties["AdvisoryDependencies"]
        }).Count -eq 0)
    )
    $catalogDetails = "Tools=" + $catalogTools.Count +
        "; unique IDs=" + @($ids | Sort-Object -Unique).Count +
        "; expected menu counts BASIC/ADVANCED/TOOLS/REPAIR=25/76/43/14" +
        $(if($menuCountMismatches.Count -gt 0){
            "; mismatches=" + (($menuCountMismatches | ForEach-Object {
                $_.Menu + ": expected=" + $_.Expected + ", summary=" + $_.Summary + ", actual=" + $_.Actual
            }) -join " | ")
        }else{""})
}
catch { $catalogDetails = $_.Exception.Message }
Add-Test "Machine-readable Tool Catalog" $catalogPass $catalogDetails
Add-Test "Tool Catalog per-menu count contract" ($menuCountMismatches.Count -eq 0) `
    $(if($menuCountMismatches.Count -eq 0){"Summary and actual counts are BASIC 25 / ADVANCED 76 / TOOLS 43 / REPAIR 14"}else{$catalogDetails})

$networkInvestigatorContracts=@(
    [pscustomobject]@{Name="DNS Resolution Chain Investigator";Path="30_Assessment_Case\DNS-Resolution-Chain-Investigator.ps1";Tokens=@("Resolve-DnsName","Get-DnsClientNrptPolicy","HOSTS FILE MATCHES","PUBLIC COMPARISON RESOLVERS","Write-ToolkitDiagnosticSidecar")},
    [pscustomobject]@{Name="DHCP Lease / State Deep Dive";Path="30_Assessment_Case\DHCP-Lease-State-Deep-Dive.ps1";Tokens=@("Win32_NetworkAdapterConfiguration","DHCPLeaseExpires","APIPA","Microsoft-Windows-Dhcp-Client","Write-ToolkitDiagnosticSidecar")},
    [pscustomobject]@{Name="Network Driver / Event Correlation";Path="30_Assessment_Case\Network-Driver-Event-Correlation.ps1";Tokens=@("Win32_PnPSignedDriver","Get-NetAdapterPowerManagement","WLAN-AutoConfig","ADAPTER / EVENT CORRELATION SUMMARY","Write-ToolkitDiagnosticSidecar")}
)
foreach($contract in $networkInvestigatorContracts){
    $contractPath=Join-Path $ToolkitRoot $contract.Path
    $contractText=$(if(Test-Path -LiteralPath $contractPath -PathType Leaf){Get-Content -LiteralPath $contractPath -Raw -ErrorAction SilentlyContinue}else{""})
    $contractMissing=@($contract.Tokens|Where-Object{$contractText.IndexOf($_,[System.StringComparison]::OrdinalIgnoreCase) -lt 0})
    Add-Test ("Network investigator contract: "+$contract.Name) `
        ((Test-Path -LiteralPath $contractPath -PathType Leaf) -and $contractMissing.Count -eq 0) `
        $(if($contractMissing.Count -eq 0){"Read-only diagnostic/report/evidence contract present"}else{"Missing: "+($contractMissing -join "; ")})
}

$smbInvestigatorPath=Join-Path $ToolkitRoot "30_Assessment_Case\SMB-Connectivity-Troubleshooting-Investigator.ps1"
$smbInvestigatorText=$(if(Test-Path -LiteralPath $smbInvestigatorPath -PathType Leaf){Get-Content -LiteralPath $smbInvestigatorPath -Raw -ErrorAction SilentlyContinue}else{""})
$smbTokens=@(
    "Local SMB Client Health",
    "Troubleshoot Server / Host",
    "Troubleshoot UNC Share",
    "SMB Event Investigator",
    "Credentialed SMB Share Access Test",
    "Get-Credential",
    "Invoke-NativeWindowsCredentialPrompt",
    "CredUIPromptForWindowsCredentials",
    "CredUnPackAuthenticationBuffer",
    "CREDENTIAL_DIALOG_FAILED",
    "WNetAddConnection2",
    "WNetCancelConnection2",
    "IPC$",
    "IPC_AUTH_VALIDATION_UNAVAILABLE",
    "IPC_AUTH_SESSION_CLEANUP_FAILED",
    "CREDENTIALS_REJECTED",
    "NETWORK_PATH_NOT_FOUND",
    "SHARE_NOT_FOUND",
    "EXISTING_SESSION_CONFLICT",
    "Type AUTH TEST exactly",
    "Remove-PSDrive",
    "Write-SanitizedCredentialTestReport",
    "Target identifier logged: NO",
    "Credential username logged: NO",
    "Raw authentication error logged: NO",
    "EXISTING_SESSION_PRESENT_TEST_NOT_ATTEMPTED",
    "AUTHENTICATION_TIMEOUT",
    "Authentication still in progress",
    "Maximum wait:",
    "Write-ToolkitStatus",
    "UNC path to test, for example \\server\share",
    "Write-SanitizedCredentialTestReport",
    "Write-ToolkitDiagnosticSidecar"
)
$smbMissing=@($smbTokens|Where-Object{$smbInvestigatorText.IndexOf($_,[System.StringComparison]::OrdinalIgnoreCase) -lt 0})
$smbPrivacyPass=(
    $smbMissing.Count -eq 0 -and
    $smbInvestigatorText.IndexOf('\\server\\share',[System.StringComparison]::OrdinalIgnoreCase) -lt 0 -and
    $smbInvestigatorText -notmatch '(?im)^\s*cmdkey(?:\.exe)?\b' -and
    $smbInvestigatorText -notmatch '(?i)ConvertFrom-SecureString' -and
    $smbInvestigatorText -notmatch '(?i)\$cred\.UserName'
)
Add-Test "SMB investigator privacy / credential-test contract" $smbPrivacyPass `
    $(if($smbPrivacyPass){"Modes 1-4 passive; mode 5 confirmed one-shot auth with sanitized persistent output"}else{"Missing tokens: "+($smbMissing -join "; ")})

$smbTimeoutPass=(
    $smbInvestigatorText.IndexOf('$authTimeoutSeconds=45',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $smbInvestigatorText.IndexOf('CredUIPromptForWindowsCredentials',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $smbInvestigatorText.IndexOf('CREDENTIAL_DIALOG_FAILED',[System.StringComparison]::OrdinalIgnoreCase) -ge 0
)
Add-Test "SMB native credential UI + 45-second auth timeout" $smbTimeoutPass `
    $(if($smbTimeoutPass){"Native Windows CredUI prompt; SMB auth worker=45s"}else{"Expected native CredUI and 45-second SMB auth timeout"})

$smbNativeBackendPass=(
    $smbInvestigatorText.IndexOf('WNetAddConnection2',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $smbInvestigatorText.IndexOf('WNetCancelConnection2',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $smbInvestigatorText.IndexOf('1326',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $smbInvestigatorText.IndexOf('1219',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $smbInvestigatorText.IndexOf('NETWORK_PATH_NOT_FOUND',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $smbInvestigatorText.IndexOf('SHARE_NOT_FOUND',[System.StringComparison]::OrdinalIgnoreCase) -ge 0
)
Add-Test "SMB credential backend uses native Windows return codes" $smbNativeBackendPass `
    $(if($smbNativeBackendPass){"WNetAddConnection2/WNetCancelConnection2 with explicit auth/path/share/session classifications"}else{"Native SMB connection return-code contract missing"})

$smbIpcStagePass=(
    $smbInvestigatorText.IndexOf('IPC$',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $smbInvestigatorText.IndexOf('IPC_AUTH',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $smbInvestigatorText.IndexOf('SHARE_CONNECT',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $smbInvestigatorText.IndexOf('IPC_AUTH_SESSION_CLEANUP_FAILED',[System.StringComparison]::OrdinalIgnoreCase) -ge 0
)
Add-Test "SMB credential workflow separates auth from share access" $smbIpcStagePass `
    $(if($smbIpcStagePass){"IPC$ credential validation precedes requested-share test; cleanup gate present"}else{"Two-stage SMB auth/share contract missing"})

$smbCredentialMemoryPass=(
    $smbInvestigatorText.IndexOf('EntryPoint = "WNetAddConnection2W"',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $smbInvestigatorText.IndexOf('IntPtr lpPassword',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $smbInvestigatorText.IndexOf('SecureStringToGlobalAllocUnicode',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $smbInvestigatorText.IndexOf('ZeroFreeGlobalAllocUnicode',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $smbInvestigatorText.IndexOf('WNetAddConnection2([ref]$ipcNr,$passwordPtr,$username,0)',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $smbInvestigatorText.IndexOf('WNetAddConnection2([ref]$shareNr,$passwordPtr,$username,0)',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $smbInvestigatorText.IndexOf('PtrToStringUni',[System.StringComparison]::OrdinalIgnoreCase) -lt 0 -and
    $smbInvestigatorText.IndexOf('Convert-ToolkitCredentialToTransientPlaintext',[System.StringComparison]::OrdinalIgnoreCase) -lt 0
)
Add-Test "SMB credential password avoids immutable managed String copy" $smbCredentialMemoryPass `
    $(if($smbCredentialMemoryPass){"SecureString unmanaged Unicode buffer passes directly to WNetAddConnection2W as IntPtr and is zero-freed"}else{"Managed-string password hardening contract missing or regressed"})

$launcherMap = New-Object System.Collections.Generic.List[object]
$currentCatalogMenu = ""
foreach ($line in ($launcherText -split "`r?`n")) {
    if ($line -match '^:(BASIC|ADVANCED|TOOLS|REPAIR)$') {
        $currentCatalogMenu = $matches[1]
        continue
    }
    $m = [regex]::Match($line,'^if "%choice%"=="(?<n>\d+)" call :RUN_TOOL "(?<label>[^"]+)" "%~dp0(?<path>[^"]+)" "(?<access>[^"]*)"')
    if ($m.Success -and $currentCatalogMenu) {
        $launcherMap.Add([pscustomobject]@{
            Menu=$currentCatalogMenu
            Order=[int]$m.Groups["n"].Value
            Label=$m.Groups["label"].Value
            RelativePath=($m.Groups["path"].Value -replace '\\','/')
        })
    }
}
$mappingProblems = New-Object System.Collections.Generic.List[string]
if ($catalogTools) {
    foreach ($tool in $catalogTools) {
        $match = @($launcherMap | Where-Object {
            $_.Menu -eq [string]$tool.Menu -and
            $_.Order -eq [int]$tool.Order -and
            $_.Label -eq [string]$tool.Label -and
            $_.RelativePath -eq [string]$tool.RelativePath
        })
        if ($match.Count -ne 1) { $mappingProblems.Add([string]$tool.ToolId) }
    }
}
Add-Test "Tool Catalog matches launcher mappings" `
    ($launcherMap.Count -eq 158 -and $mappingProblems.Count -eq 0) `
    ("Launcher mappings=" + $launcherMap.Count + "; catalog mismatches=" + $mappingProblems.Count)

$matches = [regex]::Matches($launcherText, '"%~dp0([^"]+\.cmd)"', [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
$refs = @($matches | ForEach-Object { $_.Groups[1].Value } | Sort-Object -Unique)
$missing = New-Object System.Collections.Generic.List[string]

foreach ($rel in $refs) {
    $path = Join-Path $ToolkitRoot ($rel -replace '\\', [IO.Path]::DirectorySeparatorChar)
    if (-not (Test-Path -LiteralPath $path)) {
        $missing.Add($rel)
    }
}

Add-Test "Launcher CMD targets resolve" ($missing.Count -eq 0) ("Referenced CMD targets: " + $refs.Count + "; missing: " + $missing.Count)

$missingPs1 = New-Object System.Collections.Generic.List[string]
$ps1RefCount = 0
$cmdFiles = @(Get-ChildItem -LiteralPath $ToolkitRoot -Filter "*.cmd" -File -Recurse -ErrorAction SilentlyContinue)
foreach ($cmd in $cmdFiles) {
    $cmdText = Get-Content -LiteralPath $cmd.FullName -Raw -ErrorAction SilentlyContinue
    $psMatches = [regex]::Matches($cmdText, '%~dp0([^"]+\.ps1)', [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
    foreach ($m in $psMatches) {
        $ps1RefCount++
        $relPs = $m.Groups[1].Value -replace '\\', [IO.Path]::DirectorySeparatorChar
        $psPath = Join-Path $cmd.DirectoryName $relPs
        if (-not (Test-Path -LiteralPath $psPath)) {
            $missingPs1.Add(($cmd.FullName + " -> " + $m.Groups[1].Value))
        }
    }
}
Add-Test "CMD PowerShell targets resolve" ($missingPs1.Count -eq 0) ("Referenced PowerShell targets: " + $ps1RefCount + "; missing: " + $missingPs1.Count)

$caretPowerShell = New-Object System.Collections.Generic.List[string]
foreach ($cmd in $cmdFiles) {
    $cmdText = Get-Content -LiteralPath $cmd.FullName -Raw -ErrorAction SilentlyContinue
    if ($cmdText -match '(?im)^\s*powershell(?:\.exe)?\b[^\r\n]*-Command\s*\^\s*$') {
        $caretPowerShell.Add($cmd.FullName)
    }
}
Add-Test "No caret-continued PowerShell -Command wrappers" ($caretPowerShell.Count -eq 0) ("Found: " + $caretPowerShell.Count)

$inlinePowerShellCommand = New-Object System.Collections.Generic.List[string]
foreach ($cmd in $cmdFiles) {
    $cmdText = Get-Content -LiteralPath $cmd.FullName -Raw -ErrorAction SilentlyContinue
    if ($cmdText -match '(?im)^\s*powershell(?:\.exe)?\b[^\r\n]*\s-Command\b') {
        $inlinePowerShellCommand.Add($cmd.FullName)
    }
}
Add-Test "No inline PowerShell -Command wrappers" ($inlinePowerShellCommand.Count -eq 0) ("Found: " + $inlinePowerShellCommand.Count)

# Native Windows PowerShell parser validation. ParseFile builds an AST and
# returns syntax errors without executing any toolkit script.
$nativeParseErrors = New-Object System.Collections.Generic.List[object]
$psFilesForParse = @(Get-ChildItem -LiteralPath $ToolkitRoot -Filter "*.ps1" -File -Recurse -ErrorAction SilentlyContinue)
foreach ($psFile in $psFilesForParse) {
    try {
        $tokens = $null
        $parseErrors = $null
        [void][System.Management.Automation.Language.Parser]::ParseFile(
            $psFile.FullName,
            [ref]$tokens,
            [ref]$parseErrors
        )
        foreach ($parseError in @($parseErrors)) {
            $nativeParseErrors.Add([pscustomobject]@{
                File = Get-ToolkitRelativePath -FullPath $psFile.FullName
                Line = $parseError.Extent.StartLineNumber
                Column = $parseError.Extent.StartColumnNumber
                ErrorId = $parseError.ErrorId
                Message = $parseError.Message
            })
        }
    }
    catch {
        $nativeParseErrors.Add([pscustomobject]@{
            File = Get-ToolkitRelativePath -FullPath $psFile.FullName
            Line = 0
            Column = 0
            ErrorId = "ParseFileException"
            Message = $_.Exception.Message
        })
    }
}
Add-Test "Native PowerShell AST parse - all PS1 files" ($nativeParseErrors.Count -eq 0) `
    ("PowerShell files parsed: " + $psFilesForParse.Count + "; parser errors: " + $nativeParseErrors.Count)


$knownGoodDir = Join-Path $ToolkitRoot "26_Tools\KnownGood"
$knownGoodZip = Join-Path $knownGoodDir "Toolkit-Core-KnownGood.zip"
$knownGoodManifest = Join-Path $knownGoodDir "Toolkit-Core-Manifest.json"
$knownGoodHashFile = Join-Path $knownGoodDir "Toolkit-Core-KnownGood.sha256"
$knownGoodManifestHashFile = Join-Path $knownGoodDir "Toolkit-Core-Manifest.sha256"
$knownGoodAssets = (Test-Path -LiteralPath $knownGoodZip -PathType Leaf) -and
                   (Test-Path -LiteralPath $knownGoodManifest -PathType Leaf) -and
                   (Test-Path -LiteralPath $knownGoodHashFile -PathType Leaf) -and
                   (Test-Path -LiteralPath $knownGoodManifestHashFile -PathType Leaf)
Add-Test "Known-good rebuild trust-source files exist" $knownGoodAssets $knownGoodDir

$knownGoodHashPass = $false
$knownGoodHashDetails = "Trust-source files missing"
if ($knownGoodAssets) {
    try {
        $expectedKnownGoodHash = (Get-Content -LiteralPath $knownGoodHashFile -Raw -ErrorAction Stop).Trim().ToUpperInvariant()
        $actualKnownGoodHash = (Get-FileHash -LiteralPath $knownGoodZip -Algorithm SHA256 -ErrorAction Stop).Hash.ToUpperInvariant()
        $knownGoodHashPass = ($expectedKnownGoodHash -match '^[0-9A-F]{64}$') -and ($actualKnownGoodHash -eq $expectedKnownGoodHash)
        $knownGoodHashDetails = "Expected: " + $expectedKnownGoodHash + "; actual: " + $actualKnownGoodHash
    }
    catch {
        $knownGoodHashDetails = $_.Exception.Message
    }
}
Add-Test "Known-good archive SHA256 matches recorded checksum" $knownGoodHashPass $knownGoodHashDetails

$knownGoodManifestHashPass = $false
$knownGoodManifestHashDetails = "Trust-source files missing"
if ($knownGoodAssets) {
    try {
        $expectedManifestHash = (Get-Content -LiteralPath $knownGoodManifestHashFile -Raw -ErrorAction Stop).Trim().ToUpperInvariant()
        $actualManifestHash = (Get-FileHash -LiteralPath $knownGoodManifest -Algorithm SHA256 -ErrorAction Stop).Hash.ToUpperInvariant()
        $knownGoodManifestHashPass = ($expectedManifestHash -match '^[0-9A-F]{64}$') -and ($actualManifestHash -eq $expectedManifestHash)
        $knownGoodManifestHashDetails = "Expected: " + $expectedManifestHash + "; actual: " + $actualManifestHash
    }
    catch {
        $knownGoodManifestHashDetails = $_.Exception.Message
    }
}
Add-Test "Known-good manifest SHA256 matches recorded checksum" $knownGoodManifestHashPass $knownGoodManifestHashDetails

$rebuildScript = Join-Path $ToolkitRoot "26_Tools\Toolkit-Known-Good-Rebuild.ps1"
$rebuildSafetyPass = $false
$rebuildSafetyDetails = "Rebuild script missing"
if (Test-Path -LiteralPath $rebuildScript -PathType Leaf) {
    $rebuildText = Get-Content -LiteralPath $rebuildScript -Raw -ErrorAction SilentlyContinue
    $confirm = [regex]::Match($rebuildText, '(?im)^\s*\$answer\s*=\s*Read-ToolkitPrompt\s+"Type REBUILD exactly to continue"\s+-SpellExactPhrase\s+"REBUILD"')
    $cancel = $rebuildText -match 'Canceled\. No toolkit files were changed\.'
    $stageVerify = $rebuildText -match 'Staged known-good payload verification failed\. Live toolkit was not changed\.'
    $workerLaunch = [regex]::Match($rebuildText, '(?im)^\s*&\s+powershell\.exe\b.*-File\s+\$worker')
    $rebuildSafetyPass = $confirm.Success -and $cancel -and $stageVerify -and $workerLaunch.Success -and ($confirm.Index -lt $workerLaunch.Index)
    $rebuildSafetyDetails = $(if ($rebuildSafetyPass) {
        "Typed REBUILD precedes staged worker; clean cancel/staging-failure text present"
    } else {
        "Known-good rebuild confirmation/staging safety check failed"
    })
}
Add-Test "Toolkit known-good rebuild safety gate" $rebuildSafetyPass $rebuildSafetyDetails

# Safety check for Basic / Advanced tools that intentionally change Windows state.
# Each listed tool must explain/cancel cleanly, contain an explicit confirmation,
# and place that confirmation before its first state-changing command.
$stateChangeRules = @(
    # Change patterns are anchored to the beginning of a CMD line so explanatory
    # ECHO text such as "This will run SFC /SCANNOW" cannot be mistaken for the
    # actual state-changing command.
    [pscustomobject]@{Path="02_Network\Flush-DNS.cmd"; Confirm='(?im)^\s*choice\s+/C\s+YN\b'; Change='(?im)^\s*ipconfig\s+/flushdns\b'},
    [pscustomobject]@{Path="02_Network\Renew-DHCP-ADMIN.cmd"; Confirm='(?im)^\s*choice\s+/C\s+YN\b'; Change='(?im)^\s*ipconfig\s+/release\b'},
    [pscustomobject]@{Path="03_Windows_Repair\SFC-Scan-ADMIN.cmd"; Confirm='(?im)^\s*choice\s+/C\s+YN\b'; Change='(?im)^\s*powershell\.exe\b.*Invoke-Native-Bridge\.ps1.*-FilePath\s+"sfc\.exe".*-Mutation\s+/scannow\b'},
    [pscustomobject]@{Path="03_Windows_Repair\DISM-RestoreHealth-ADMIN.cmd"; Confirm='(?im)^\s*choice\s+/C\s+YN\b'; Change='(?im)^\s*powershell\.exe\b.*Invoke-Native-Bridge\.ps1.*-FilePath\s+"dism\.exe".*-Mutation\s+/Online\s+/Cleanup-Image\s+/RestoreHealth\b'},
    [pscustomobject]@{Path="03_Windows_Repair\Print-Spooler-Cleanup-ADMIN.cmd"; Confirm='(?im)^\s*choice\s+/C\s+YN\b'; Change='(?im)^\s*net\s+stop\s+spooler\b'},
    [pscustomobject]@{Path="02_Network\Time-Sync-ADMIN.cmd"; Confirm='(?im)^\s*choice\s+/C\s+YN\b'; Change='(?im)^\s*powershell\.exe\b.*Invoke-Native-Bridge\.ps1.*-FilePath\s+"w32tm\.exe".*-Mutation\s+/resync\b'},
    [pscustomobject]@{Path="03_Windows_Repair\Windows-Update-Repair-ADMIN.cmd"; Confirm='(?im)^\s*choice\s+/C\s+YN\b'; Change='(?im)^\s*net\s+stop\s+wuauserv\b'},
    [pscustomobject]@{Path="02_Network\Reset-Winsock-IP-ADMIN.cmd"; Confirm='(?im)^\s*set\s+/p\s+"CONFIRM=.*RESET'; Change='(?im)^\s*powershell\.exe\b.*Invoke-Native-Bridge\.ps1.*-FilePath\s+"netsh\.exe".*-Mutation\s+winsock\s+reset\b'}
)

foreach ($rule in $stateChangeRules) {
    $statePath = Join-Path $ToolkitRoot $rule.Path
    $stateText = ""
    if (Test-Path -LiteralPath $statePath) {
        $stateText = Get-Content -LiteralPath $statePath -Raw -ErrorAction SilentlyContinue
    }

    $confirmMatch = [regex]::Match($stateText, $rule.Confirm)
    $changeMatch = [regex]::Match($stateText, $rule.Change)
    $cancelText = $stateText -match 'Canceled\.\s+No changes were made\.'
    $ordered = $confirmMatch.Success -and $changeMatch.Success -and ($confirmMatch.Index -lt $changeMatch.Index)
    $passed = (Test-Path -LiteralPath $statePath) -and $cancelText -and $ordered

    if ($passed) {
        $details = "Confirmation precedes actual change command; cancel path present"
    }
    else {
        $parts = New-Object System.Collections.Generic.List[string]
        if (-not (Test-Path -LiteralPath $statePath)) { $parts.Add("file missing") }
        if (-not $confirmMatch.Success) { $parts.Add("confirmation prompt not matched") }
        if (-not $changeMatch.Success) { $parts.Add("actual change command not matched") }
        if ($confirmMatch.Success -and $changeMatch.Success -and -not $ordered) { $parts.Add("change command appears before confirmation") }
        if (-not $cancelText) { $parts.Add("clean cancel text not matched") }
        $details = ($parts -join "; ")
    }

    Add-Test ("State-change confirmation: " + $rule.Path) $passed $details
}


# Native-command convergence check.
# These tools should route through the shared foundation runner/bridge rather
# than invoking the targeted Windows utilities directly from CMD.
$bridgePath = Join-Path $ToolkitRoot "00_Common\Invoke-Native-Bridge.ps1"
$bridgeText = ""
if (Test-Path -LiteralPath $bridgePath) {
    $bridgeText = Get-Content -LiteralPath $bridgePath -Raw -ErrorAction SilentlyContinue
}
$bridgeTokens = @(
    'Foundation-Common.ps1',
    'Invoke-ToolkitNativeCommand',
    'ValueFromRemainingArguments',
    '-Mutation:$Mutation'
)
$bridgeMissing = @($bridgeTokens | Where-Object {
    $bridgeText.IndexOf($_,[System.StringComparison]::OrdinalIgnoreCase) -lt 0
})
Add-Test "Native command bridge" `
    ((Test-Path -LiteralPath $bridgePath) -and $bridgeMissing.Count -eq 0) `
    $(if ($bridgeMissing.Count -eq 0) { "CMD-to-foundation native bridge present" } else { "Missing: " + ($bridgeMissing -join "; ") })

$foundationStatusPath=Join-Path $ToolkitRoot "00_Common\Foundation-Common.ps1"
$foundationStatusText=$(if(Test-Path -LiteralPath $foundationStatusPath -PathType Leaf){Get-Content -LiteralPath $foundationStatusPath -Raw -ErrorAction SilentlyContinue}else{""})
$foundationStatusTokens=@(
    "function Write-ToolkitStatus",
    "statusAfterSeconds = 5",
    "statusIntervalSeconds = 10",
    "is still running. Elapsed:",
    "reached the toolkit timeout",
    "completed after"
)
$foundationStatusMissing=@($foundationStatusTokens|Where-Object{$foundationStatusText.IndexOf($_,[System.StringComparison]::OrdinalIgnoreCase) -lt 0})
Add-Test "Kit-wide native operation heartbeat" `
    ($foundationStatusMissing.Count -eq 0) `
    $(if($foundationStatusMissing.Count -eq 0){"Native commands gain delayed progress + timeout/completion status"}else{"Missing: "+($foundationStatusMissing -join "; ")})

$menuRunnerStatusPath=Join-Path $ToolkitRoot "00_Common\Invoke-Toolkit-MenuTool.ps1"
$menuRunnerStatusText=$(if(Test-Path -LiteralPath $menuRunnerStatusPath -PathType Leaf){Get-Content -LiteralPath $menuRunnerStatusPath -Raw -ErrorAction SilentlyContinue}else{""})
$menuRunnerStatusPass=(
    $menuRunnerStatusText.IndexOf('STATUS: Starting tool:',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $menuRunnerStatusText.IndexOf('STATUS: Tool finished:',[System.StringComparison]::OrdinalIgnoreCase) -ge 0
)
Add-Test "Kit-wide tool lifecycle status" $menuRunnerStatusPass `
    $(if($menuRunnerStatusPass){"Launcher/Search runner announces start and finish for every numbered tool"}else{"Shared runner lifecycle STATUS lines missing"})

$directNativeCmd = New-Object System.Collections.Generic.List[string]
$directNativePattern = '(?im)^\s*(dism|sfc|chkdsk|reagentc|pnputil|bcdedit|netsh|w32tm|powercfg)(?:\.exe)?\b'
foreach ($cmdFile in Get-ChildItem -LiteralPath $ToolkitRoot -Recurse -File -Filter *.cmd -ErrorAction SilentlyContinue) {
    $cmdText = Get-Content -LiteralPath $cmdFile.FullName -Raw -ErrorAction SilentlyContinue
    if ([string]::IsNullOrWhiteSpace($cmdText)) { continue }
    if ([regex]::IsMatch($cmdText,$directNativePattern)) {
        $relativeCmd = Get-ToolkitRelativePath -FullPath $cmdFile.FullName
        $directNativeCmd.Add($relativeCmd)
    }
}
Add-Test "CMD native execution converges on shared runner" `
    ($directNativeCmd.Count -eq 0) `
    $(if ($directNativeCmd.Count -eq 0) { "No direct DISM/SFC/CHKDSK/REAgentC/PnPUtil/BCDEdit/netsh/w32tm/powercfg commands remain in CMD wrappers" } else { "Direct native commands: " + ($directNativeCmd -join ", ") })

$directNativePs = New-Object System.Collections.Generic.List[string]
$nativePsExclude = @(
    '00_Common\Foundation-Common.ps1',
    '00_Common\Invoke-Native-Bridge.ps1',
    '26_Tools\Toolkit-Self-Test.ps1'
)
$directNativePsPattern = '(?i)(?:^|[=\{\(]\s*)(?:&\s*)?(dism|sfc|chkdsk|reagentc|pnputil|bcdedit|netsh|w32tm|powercfg)(?:\.exe)?(?:\s|/)'
foreach ($psFile in Get-ChildItem -LiteralPath $ToolkitRoot -Recurse -File -Filter *.ps1 -ErrorAction SilentlyContinue) {
    $relativePs = Get-ToolkitRelativePath -FullPath $psFile.FullName
    if ($nativePsExclude -contains $relativePs) { continue }

    $lineNumber = 0
    foreach ($line in Get-Content -LiteralPath $psFile.FullName -ErrorAction SilentlyContinue) {
        $lineNumber++
        $trimmed = $line.TrimStart()
        if ($trimmed.StartsWith('#')) { continue }
        if ($line.IndexOf('Invoke-ToolkitNativeCommand',[System.StringComparison]::OrdinalIgnoreCase) -ge 0) { continue }
        if ([regex]::IsMatch($line,$directNativePsPattern)) {
            $directNativePs.Add($relativePs + ":" + $lineNumber)
        }
    }
}
Add-Test "PowerShell native execution converges on shared runner" `
    ($directNativePs.Count -eq 0) `
    $(if ($directNativePs.Count -eq 0) { "No direct targeted Windows native-command invocations remain outside the shared foundation/bridge" } else { "Direct native commands: " + ($directNativePs -join ", ") })

$relativePathSamples = @(
    [pscustomobject]@{Path=(Join-Path $ToolkitRoot "00_Common\Foundation-Common.ps1"); Expected="00_Common\Foundation-Common.ps1"},
    [pscustomobject]@{Path=(Join-Path $ToolkitRoot "00_Common\ScreenReader-Common.ps1"); Expected="00_Common\ScreenReader-Common.ps1"},
    [pscustomobject]@{Path=(Join-Path $ToolkitRoot "28_Repair\WinRE-Repair.ps1"); Expected="28_Repair\WinRE-Repair.ps1"},
    [pscustomobject]@{Path=$MyInvocation.MyCommand.Path; Expected="26_Tools\Toolkit-Self-Test.ps1"}
)
$relativePathProblems = New-Object System.Collections.Generic.List[string]
foreach ($sample in $relativePathSamples) {
    $actualRelative = Get-ToolkitRelativePath -FullPath $sample.Path
    if ($actualRelative -ine $sample.Expected) {
        $relativePathProblems.Add($sample.Expected + " -> " + $actualRelative)
    }
}
Add-Test "Self-Test canonical relative-path handling" `
    ($relativePathProblems.Count -eq 0) `
    $(if ($relativePathProblems.Count -eq 0) { "Canonical root normalization preserves complete relative paths and exclusions" } else { "Path mismatches: " + ($relativePathProblems -join "; ") })

# Windows PowerShell 5.1 has a runtime binder edge case where wrapping a
# System.Collections.Generic.List<T> directly in the array-subexpression
# operator can throw "Argument types do not match". Require ToArray() or
# pipeline materialization instead.
$genericListArrayHazards = New-Object System.Collections.Generic.List[string]
$genericListDecl = '\$(?<name>[A-Za-z_][A-Za-z0-9_]*)\s*=\s*New-Object\s+System\.Collections\.Generic\.List'
foreach ($psFile in Get-ChildItem -LiteralPath $ToolkitRoot -Recurse -File -Filter *.ps1 -ErrorAction SilentlyContinue) {
    $relativePs = Get-ToolkitRelativePath -FullPath $psFile.FullName
    $psText = Get-Content -LiteralPath $psFile.FullName -Raw -ErrorAction SilentlyContinue
    if ([string]::IsNullOrWhiteSpace($psText)) { continue }

    $listNames = New-Object System.Collections.Generic.HashSet[string]([System.StringComparer]::OrdinalIgnoreCase)
    foreach ($match in [regex]::Matches($psText,$genericListDecl,[System.Text.RegularExpressions.RegexOptions]::IgnoreCase)) {
        [void]$listNames.Add($match.Groups['name'].Value)
    }

    $lineNumber = 0
    foreach ($line in ($psText -split "`r?`n")) {
        $lineNumber++
        foreach ($name in $listNames) {
            $hazardPattern = '@\(\$' + [regex]::Escape($name) + '\)'
            if ([regex]::IsMatch($line,$hazardPattern)) {
                $genericListArrayHazards.Add($relativePs + ":" + $lineNumber + " -> " + $name)
            }
        }
    }
}
Add-Test "Windows PowerShell 5.1 generic-list array compatibility" `
    ($genericListArrayHazards.Count -eq 0) `
    $(if ($genericListArrayHazards.Count -eq 0) { "No direct @(`$genericList) binder hazards; list materialization uses ToArray/pipeline" } else { "Hazards: " + ($genericListArrayHazards -join ", ") })


# Repair-menu safety-gate checks. These are intentionally focused on the
# confirmation mechanisms that guard system-state changes.
$repairSafety = @(
    [pscustomobject]@{Path="28_Repair\Defender-Offline-Scan.ps1"; Required=@('Confirm-RepairPhrase','"REBOOT"','Start-MpWDOScan')},
    [pscustomobject]@{Path="28_Repair\Create-Restore-Point-and-Safety-Backup.ps1"; Required=@('Confirm-RepairAction','[switch]$Confirmed','Checkpoint-Computer')},
    [pscustomobject]@{Path="28_Repair\Microsoft-Store-Repair.ps1"; Required=@('Confirm-RepairAction','Start-Process -FilePath "wsreset.exe"','Reset-AppxPackage')},
    [pscustomobject]@{Path="28_Repair\Print-System-Repair.ps1"; Required=@('Confirm-RepairAction','Stop-Service -Name Spooler','Remove-Item -LiteralPath $file.FullName -Force')},
    [pscustomobject]@{Path="28_Repair\Safe-Free-Space-Recovery.ps1"; Required=@('Confirm-RepairAction "Delete temp content older than 48 hours?"','Confirm-RepairAction "Clear the Windows Update download cache?"','Confirm-RepairAction "Delete crash dumps?','Confirm-RepairAction "Empty the Recycle Bin?')},
    [pscustomobject]@{Path="28_Repair\Disk-FileSystem-Health-Repair.ps1"; Required=@('Confirm-RepairPhrase','"FIX"','Invoke-ToolkitNativeCommand','CHKDSK Repair')},
    [pscustomobject]@{Path="28_Repair\Deep-Windows-Update-Reset.ps1"; Required=@('Confirm-RepairPhrase','"RESET"','Stop-Service -Name $name')},
    [pscustomobject]@{Path="28_Repair\Windows-Repair-Chain.ps1"; Required=@('Confirm-RepairPhrase','"REPAIR"','Run-Step -Name "DISM RestoreHealth"','Invoke-ToolkitNativeCommand','-Confirmed')},
    [pscustomobject]@{Path="28_Repair\Driver-Recovery.ps1"; Required=@('Confirm-RepairAction "Run the Plug and Play device rescan?"','Confirm-RepairAction "Restart this device?','Confirm-RepairAction "Add these driver packages','type the exact package name')},
    [pscustomobject]@{Path="28_Repair\WinRE-Repair.ps1"; Required=@('Confirm-RepairAction "Run reagentc /enable','Confirm-RepairPhrase','"WINRE"','Invoke-ReagentcChecked','"/setreimage"','Invoke-BitLockerBootRiskPreflight','BITLOCKER_GUARD_BLOCKED')},
    [pscustomobject]@{Path="28_Repair\Service-Recovery.ps1"; Required=@('Start service ','Restart service ','Stop service ','type its exact service name','Apply these failure actions')},
    [pscustomobject]@{Path="28_Repair\DISM-Service-Center.ps1"; Required=@('Confirm-RepairAction','Confirm-RepairPhrase','"I UNDERSTAND"','-SpellExactPhrase "I UNDERSTAND"','RESETBASE_CANCELED_ACK','RESETBASE_ACKNOWLEDGED','"RESETBASE"','All letters are uppercase','There are no spaces, hyphens, or other punctuation','ResetBase-Confirm','Capital R, capital B, hyphen, capital C. No spaces.','Final ResetBase confirmation','Any other entry, including 0 or pressing Enter','Requires three exact typed confirmations','Resolve-DismMenuChoice','Q / QUIT / EXIT / X','B / BACK / RETURN','ScreenReaderMode','env:SRMODE','Write-DismAccessibilityAnnouncement','Write-DismMenuNavigationHelp','Screen Reader Mode: Enabled. Inherited from the main toolkit context.','"REMOVE"','"REVERT"','"MOUNT"','"COMMIT"','"DISCARD"','Invoke-DismOperation')},
    [pscustomobject]@{Path="28_Repair\BitLocker-Protection-Control.ps1"; Required=@('ValidateRange(1,3)','Confirm-RepairPhrase','"SUSPEND"','Suspend-BitLocker','Confirm-RepairAction','Resume-BitLocker','Recovery passwords are not displayed or logged','Write-RepairVerification')}
)

foreach ($rule in $repairSafety) {
    $repairPath = Join-Path $ToolkitRoot $rule.Path
    $repairText = ""
    if (Test-Path -LiteralPath $repairPath) {
        $repairText = Get-Content -LiteralPath $repairPath -Raw -ErrorAction SilentlyContinue
    }

    $missingTokens = @($rule.Required | Where-Object { $repairText.IndexOf($_, [System.StringComparison]::OrdinalIgnoreCase) -lt 0 })
    $passed = (Test-Path -LiteralPath $repairPath) -and ($missingTokens.Count -eq 0)
    Add-Test ("Repair safety gate: " + $rule.Path) $passed `
        $(if ($passed) { "Required confirmation guards present" } else { "Missing: " + ($missingTokens -join "; ") })
}

$dismGatePath=Join-Path $ToolkitRoot "28_Repair\DISM-Service-Center.ps1"
$dismGateText=$(if(Test-Path -LiteralPath $dismGatePath -PathType Leaf){Get-Content -LiteralPath $dismGatePath -Raw -ErrorAction SilentlyContinue}else{""})
$ackIndex=$dismGateText.IndexOf('Initial ResetBase acknowledgement',[System.StringComparison]::OrdinalIgnoreCase)
$resetbaseIndex=$dismGateText.IndexOf('First confirmation requires the exact word RESETBASE',[System.StringComparison]::OrdinalIgnoreCase)
$finalIndex=$dismGateText.IndexOf('Final ResetBase confirmation',[System.StringComparison]::OrdinalIgnoreCase)
$dismThreeGatePass=($ackIndex -ge 0 -and $resetbaseIndex -gt $ackIndex -and $finalIndex -gt $resetbaseIndex)
Add-Test "DISM ResetBase three typed gates preserve existing order" $dismThreeGatePass `
    $(if($dismThreeGatePass){"I UNDERSTAND gate precedes unchanged RESETBASE and ResetBase-Confirm gates"}else{"Expected acknowledgement -> RESETBASE -> ResetBase-Confirm ordering"})


# Shared toolkit foundation regression.
$foundationPath = Join-Path $ToolkitRoot "00_Common\Foundation-Common.ps1"
$foundationText = ""
if (Test-Path -LiteralPath $foundationPath) {
    $foundationText = Get-Content -LiteralPath $foundationPath -Raw -ErrorAction SilentlyContinue
}
$foundationTokens = @(
    'function Get-ToolkitRuntimeContext',
    'function Get-ToolkitBuildIdentity',
    'function Set-ToolkitAtomicText',
    'File.Replace',
    '.fttmp_',
    '.ftbak_',
    'Substring(0,12)',
    'Atomic write verification failed',
    'function Set-ToolkitAtomicJson',
    'function Add-ToolkitJsonLine',
    'function Get-ToolkitToolCatalog',
    'function Get-ToolkitToolDefinition',
    'function Test-ToolkitToolDependencies',
    'function Get-ToolkitCompatibilityAssessment',
    'function Recover-ToolkitStaleSessions',
    'INTERRUPTED_SESSIONS.jsonl',
    'LauncherProcessId',
    'function Initialize-ToolkitSessionState',
    'function Close-ToolkitSessionState',
    'function Get-ToolkitFieldValidationStatus',
    'function Set-ToolkitFieldValidationStatus',
    'AUTO-VERIFIED',
    'AutoVerifiedAt',
    'AutoVerificationResult',
    'function Sync-ToolkitFieldValidationStatus',
    'function Invoke-ToolkitPowerShellOperation',
    'TIMED_OUT',
    'TimeoutSeconds',
    'function Test-ToolkitCapability',
    'function Get-ToolkitFeatureCapabilities',
    'function Get-ToolkitCapabilityForLabel',
    'WLAN ADAPTER PRESENT',
    'NO WLAN ADAPTER DETECTED',
    'AVAILABLE / DISABLED',
    'CPU / FIRMWARE LIMIT',
    'function Invoke-ToolkitNativeCommand',
    'function New-ToolkitResult',
    '"SUCCESS"',
    '"FAILED"',
    '"UNSUPPORTED"',
    '"CANCELED"',
    '"PARTIAL"',
    '"REBOOT_REQUIRED"',
    'function Write-ToolkitOperationLedger',
    'OPERATION_LEDGER.jsonl',
    'function Write-ToolkitMutationLedger',
    'MUTATION_LEDGER.jsonl',
    'ReadToEndAsync',
    'function Get-ToolkitInterruptedOperations',
    '_ACTIVE_REPAIR_PROCESSES',
    'function Initialize-ToolkitRepairProcess',
    'MarkerNonce',
    'ProcessName',
    'ProcessPath',
    'ProcessSessionId',
    'function Get-ToolkitCaseContext',
    'FIELDTECH_SESSION_ID'
)
$foundationMissing = @($foundationTokens | Where-Object {
    $foundationText.IndexOf($_,[System.StringComparison]::OrdinalIgnoreCase) -lt 0
})
Add-Test "Shared foundation architecture" `
    ((Test-Path -LiteralPath $foundationPath) -and $foundationMissing.Count -eq 0) `
    $(if ($foundationMissing.Count -eq 0) { "Runtime context, capability layer, native runner, result contract, mutation ledger, interruption detection, case/session context present" } else { "Missing: " + ($foundationMissing -join "; ") })

# Runtime regression for replacing an existing file through the shared atomic writer.
$atomicReplacePass=$false
$atomicReplaceDetails="Not run"
$atomicTemp=Join-Path $env:TEMP ("FieldTechAtomicReplace_"+[guid]::NewGuid().ToString("N")+".txt")
try{
    . $foundationPath
    [void](Set-ToolkitAtomicText -Path $atomicTemp -Content "FIRST")
    [void](Set-ToolkitAtomicText -Path $atomicTemp -Content "SECOND")
    $atomicRead=[IO.File]::ReadAllText($atomicTemp,(New-Object Text.UTF8Encoding($false)))
    $atomicReplacePass=($atomicRead -ceq "SECOND")
    $atomicReplaceDetails="Second write persisted: "+$atomicRead
}catch{
    $atomicReplaceDetails=$_.Exception.GetType().FullName+": "+$_.Exception.Message
}finally{
    Remove-Item -LiteralPath $atomicTemp -Force -ErrorAction SilentlyContinue
    Get-ChildItem -LiteralPath $env:TEMP -Filter ".fttmp_*" -ErrorAction SilentlyContinue|Remove-Item -Force -ErrorAction SilentlyContinue
    Get-ChildItem -LiteralPath $env:TEMP -Filter ".ftbak_*" -ErrorAction SilentlyContinue|Remove-Item -Force -ErrorAction SilentlyContinue
}
Add-Test "Atomic writer replaces existing file and verifies content" $atomicReplacePass $atomicReplaceDetails

# Regression for the launcher/session-state failure class observed when a
# descriptive ZIP was extracted into an equally descriptive outer folder.
# The destination remains below legacy MAX_PATH, while the old
# "$Path.tmp.<32-char-guid>" staging scheme would exceed it.
$atomicLongPathPass=$false
$atomicLongPathDetails="Not run"
$atomicLongRoot=Join-Path $env:TEMP ("FTPathBudget_"+[guid]::NewGuid().ToString("N").Substring(0,8))
try{
    $atomicLongDir=$atomicLongRoot
    $atomicLongLeaf="SESSION_STATE_"+[guid]::NewGuid().ToString("N")+".json"
    New-Item -ItemType Directory -Path $atomicLongDir -Force|Out-Null
    while((Join-Path $atomicLongDir $atomicLongLeaf).Length -lt 225){
        $atomicLongDir=Join-Path $atomicLongDir "segment_1234567890"
        New-Item -ItemType Directory -Path $atomicLongDir -Force|Out-Null
    }
    $atomicLongTarget=Join-Path $atomicLongDir $atomicLongLeaf
    $legacyStagedLength=($atomicLongTarget+".tmp."+("0"*32)).Length
    [void](Set-ToolkitAtomicText -Path $atomicLongTarget -Content "PATH-BUDGET-FIRST")
    [void](Set-ToolkitAtomicText -Path $atomicLongTarget -Content "PATH-BUDGET-SECOND")
    $atomicLongRead=[IO.File]::ReadAllText($atomicLongTarget,(New-Object Text.UTF8Encoding($false)))
    $atomicLongPathPass=(
        $atomicLongTarget.Length -lt 260 -and
        $legacyStagedLength -ge 260 -and
        $atomicLongRead -ceq "PATH-BUDGET-SECOND"
    )
    $atomicLongPathDetails="TargetLength="+$atomicLongTarget.Length+
        "; legacyStagedLength="+$legacyStagedLength+
        "; content="+$atomicLongRead
}catch{
    $atomicLongPathDetails=$_.Exception.GetType().FullName+": "+$_.Exception.Message
}finally{
    Remove-Item -LiteralPath $atomicLongRoot -Recurse -Force -ErrorAction SilentlyContinue
}
Add-Test "Atomic writer long-path staging budget" $atomicLongPathPass $atomicLongPathDetails

$staleRecoveryPass=$false
$staleRecoveryDetails="Not run"
$staleTemp=Join-Path $env:TEMP ("FieldTechStaleSession_"+[guid]::NewGuid().ToString("N"))
try{
    New-Item -ItemType Directory -Path $staleTemp -Force|Out-Null
    $fakeSession="fixture-"+[guid]::NewGuid().ToString("N")
    $fakePath=Join-Path $staleTemp ("SESSION_STATE_"+$fakeSession+".json")
    $fake=[ordered]@{
        SchemaVersion=2
        SessionId=$fakeSession
        Computer=$env:COMPUTERNAME
        User=($env:USERDOMAIN+"\"+$env:USERNAME)
        LauncherProcessId=2147483000
        Status="ACTIVE"
        Started=(Get-Date).AddMinutes(-10).ToString("o")
        Updated=(Get-Date).AddMinutes(-10).ToString("o")
        Ended=$null
    }
    [void](Set-ToolkitAtomicJson -Path $fakePath -Object $fake)
    $recovered=@(Recover-ToolkitStaleSessions -LogRoot $staleTemp -CurrentSessionId "current-fixture")
    $after=Get-Content -LiteralPath $fakePath -Raw|ConvertFrom-Json
    $staleRecoveryPass=($recovered.Count -eq 1 -and [string]$after.Status -eq "INTERRUPTED" -and -not [string]::IsNullOrWhiteSpace([string]$after.InterruptedAt))
    $staleRecoveryDetails="Recovered="+$recovered.Count+"; Status="+$after.Status
}catch{
    $staleRecoveryDetails=$_.Exception.GetType().FullName+": "+$_.Exception.Message
}finally{
    Remove-Item -LiteralPath $staleTemp -Recurse -Force -ErrorAction SilentlyContinue
}
Add-Test "Stale ACTIVE session becomes INTERRUPTED" $staleRecoveryPass $staleRecoveryDetails

$closeoutScriptPath=Join-Path $ToolkitRoot "00_Common\Close-Toolkit-Session.ps1"
$closeoutScriptText=""
if(Test-Path -LiteralPath $closeoutScriptPath -PathType Leaf){
    $closeoutScriptText=Get-Content -LiteralPath $closeoutScriptPath -Raw -ErrorAction SilentlyContinue
}
$closeoutTokens=@(
    "LAST_EXIT_STATUS.json",
    "LAST_EXIT_STATUS.txt",
    "EXIT_ERRORS.jsonl",
    "CloseoutStatus",
    "Closeout verification failed"
)
$closeoutMissing=@($closeoutTokens|Where-Object{$closeoutScriptText.IndexOf($_,[System.StringComparison]::OrdinalIgnoreCase) -lt 0})
Add-Test "Closeout persistent failure telemetry" ($closeoutMissing.Count -eq 0) `
    $(if($closeoutMissing.Count -eq 0){"LAST_EXIT_STATUS + EXIT_ERRORS contracts present"}else{"Missing: "+($closeoutMissing -join "; ")})

$launcherCloseoutTokens=@(
    "CLOSEOUT_RC",
    "Toolkit closeout encountered an error",
    "EXIT_ERRORS.jsonl"
)
$launcherCloseoutMissing=@($launcherCloseoutTokens|Where-Object{$launcherText.IndexOf($_,[System.StringComparison]::OrdinalIgnoreCase) -lt 0})
Add-Test "Launcher pauses on closeout failure" ($launcherCloseoutMissing.Count -eq 0) `
    $(if($launcherCloseoutMissing.Count -eq 0){"Closeout return code captured and failure pause present"}else{"Missing: "+($launcherCloseoutMissing -join "; ")})

$retentionPath=Join-Path $ToolkitRoot "00_Common\Retention-Maintenance.ps1"
$retentionText=Get-Content -LiteralPath $retentionPath -Raw -ErrorAction SilentlyContinue
$retentionTokens=@(
    "Invoke-ExitErrorRetention",
    "EXIT_ERRORS.jsonl",
    "Type PURGE exactly",
    "ExitErrors_OlderThan",
    "LAST_EXIT_STATUS"
)
$retentionMissing=@($retentionTokens|Where-Object{$retentionText.IndexOf($_,[System.StringComparison]::OrdinalIgnoreCase) -lt 0})
Add-Test "Exit-log retention and latest-status hygiene contract" ($retentionMissing.Count -eq 0) `
    $(if($retentionMissing.Count -eq 0){"EXIT_ERRORS entry retention + LAST_EXIT_STATUS exclusions present"}else{"Missing: "+($retentionMissing -join "; ")})

$fieldStatusPath=Join-Path $ToolkitRoot "FIELD-VALIDATION-STATUS.txt"
$fieldStatusText=$(if(Test-Path -LiteralPath $fieldStatusPath -PathType Leaf){Get-Content -LiteralPath $fieldStatusPath -Raw -ErrorAction SilentlyContinue}else{""})
$fieldStatusValue=""
if($fieldStatusText -match '(?im)^\s*Status\s*:\s*(UNVALIDATED|AUTO-VERIFIED|VALIDATED)\s*$'){$fieldStatusValue=$matches[1]}
Add-Test "Field-validation status marker exists" `
    ((Test-Path -LiteralPath $fieldStatusPath -PathType Leaf) -and
     -not [string]::IsNullOrWhiteSpace($fieldStatusValue) -and
     $fieldStatusText.IndexOf("BuildId:",[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
     $fieldStatusText.IndexOf("AutoVerifiedAt:",[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
     $fieldStatusText.IndexOf("AutoVerificationResult:",[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
     $fieldStatusText.IndexOf("ValidatedAt:",[System.StringComparison]::OrdinalIgnoreCase) -ge 0) `
    ("Status=" + $fieldStatusValue + "; " + $fieldStatusPath)

$launcherFoundationTokens = @(
    'FIELDTECH_SESSION_ID',
    'Get-Toolkit-SessionId.ps1',
    'Initialize-Toolkit-Runtime.ps1',
    'First-Run-Validation.ps1',
    'Refresh-Menu-Capabilities.ps1',
    'CAP_BITLOCKER',
    'Toolkit Menu Search'
)
$launcherFoundationMissing = @($launcherFoundationTokens | Where-Object {
    $launcherText.IndexOf($_,[System.StringComparison]::OrdinalIgnoreCase) -lt 0
})
Add-Test "Launcher shared session/runtime context" `
    ($launcherFoundationMissing.Count -eq 0) `
    $(if ($launcherFoundationMissing.Count -eq 0) { "One inherited session ID plus persisted runtime initialization present" } else { "Missing: " + ($launcherFoundationMissing -join "; ") })

$firstRunPath = Join-Path $ToolkitRoot "00_Common\First-Run-Validation.ps1"
$firstRunText = ""
if (Test-Path -LiteralPath $firstRunPath) {
    $firstRunText = Get-Content -LiteralPath $firstRunPath -Raw -ErrorAction SilentlyContinue
}
$firstRunTokens = @(
    'FIRST_RUN_VALIDATED_',
    'Known-Good archive checksum',
    'Known-Good manifest checksum',
    'Logging writable',
    'PowerShell 5+',
    'Invoke-Toolkit-MenuTool.ps1',
    'CriticalFailureCount',
    'WarningCount',
    'AUTO-VERIFIED',
    'AutoVerificationResult',
    'Full field validation has not been completed',
    'exit 3',
    'one-time acknowledgement'
)
$firstRunMissing = @($firstRunTokens | Where-Object {
    $firstRunText.IndexOf($_,[System.StringComparison]::OrdinalIgnoreCase) -lt 0
})
$firstRunAttentionAck = (
    $launcherText.IndexOf('if "%FIRST_RUN_RC%"=="2"',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $launcherText.IndexOf('acknowledge the first-run warnings',[System.StringComparison]::OrdinalIgnoreCase) -ge 0
)
$firstRunPassHold = (
    $launcherText.IndexOf('if "%FIRST_RUN_RC%"=="3"',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $launcherText.IndexOf('Automatic first-run verification: PASS',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $launcherText.IndexOf('Starting toolkit in 3 seconds',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $launcherText.IndexOf('timeout /t 3 /nobreak',[System.StringComparison]::OrdinalIgnoreCase) -ge 0
)
Add-Test "First-run validation contract" `
    ((Test-Path -LiteralPath $firstRunPath) -and $firstRunMissing.Count -eq 0 -and $firstRunAttentionAck -and $firstRunPassHold) `
    $(if ($firstRunMissing.Count -eq 0 -and $firstRunAttentionAck -and $firstRunPassHold) { "Build-keyed lightweight AUTO-VERIFIED validation, one-time ATTENTION acknowledgement, and fresh-PASS three-second hold present" } else { "First-run validation, warning acknowledgement, or PASS hold incomplete" })


$fullMachineReportPath = Join-Path $ToolkitRoot "00_Full_Machine_Report\Full-Machine-Report.ps1"
$fullMachineReportText = ""
if (Test-Path -LiteralPath $fullMachineReportPath -PathType Leaf) {
    $fullMachineReportText = Get-Content -LiteralPath $fullMachineReportPath -Raw -ErrorAction SilentlyContinue
}
$fullMachineStatusTokens = @(
    'ScreenReader-Common.ps1',
    'function Write-FullMachineProgress',
    'Test-ToolkitScreenReaderMode',
    '[Console]::IsOutputRedirected',
    'Write-Host ("`r" + $padded) -NoNewline',
    'Write-FullMachineProgress "Full Machine Report [1/11]',
    'Write-FullMachineProgress "Full Machine Report [5/11]',
    'Write-FullMachineProgress "Full Machine Report [10/11]',
    'Write-FullMachineProgress "Full Machine Report [11/11]',
    'Write-FullMachineProgress "Full Machine Report complete.',
    '-Complete'
)
$fullMachineStatusMissing = @($fullMachineStatusTokens | Where-Object {
    $fullMachineReportText.IndexOf($_,[System.StringComparison]::OrdinalIgnoreCase) -lt 0
})
Add-Test "Full Machine Report progress/status contract" `
    ((Test-Path -LiteralPath $fullMachineReportPath -PathType Leaf) -and $fullMachineStatusMissing.Count -eq 0) `
    $(if($fullMachineStatusMissing.Count -eq 0){"Single-line visual progress with line-oriented screen-reader/redirected fallback covers collection through report writing"}else{"Missing: "+($fullMachineStatusMissing -join "; ")})

$retentionPath = Join-Path $ToolkitRoot "00_Common\Retention-Maintenance.ps1"
$retentionText = ""
if (Test-Path -LiteralPath $retentionPath) { $retentionText = Get-Content -LiteralPath $retentionPath -Raw -ErrorAction SilentlyContinue }
$retentionTokens = @(
    'AgeDays = 90',
    'more than " + $AgeDays + " days old',
    'archive these items to a ZIP',
    'purge these items without archiving',
    'DRY RUN - old',
    'Type PURGE exactly to continue',
    'Cases_OlderThan90Days',
    'Reports_OlderThan90Days'
)
$retentionMissing = @($retentionTokens | Where-Object { $retentionText.IndexOf($_,[StringComparison]::OrdinalIgnoreCase) -lt 0 })
$launcherRetention = $launcherText.IndexOf('Retention-Maintenance.ps1" -AgeDays 90',[StringComparison]::OrdinalIgnoreCase) -ge 0
Add-Test "90-day case/report retention prompt" `
    ((Test-Path -LiteralPath $retentionPath) -and $retentionMissing.Count -eq 0 -and $launcherRetention) `
    $(if ($retentionMissing.Count -eq 0 -and $launcherRetention) { "Archive / typed PURGE / skip workflow present for >90-day cases and reports" } else { "Retention contract incomplete" })

$closeSessionPath = Join-Path $ToolkitRoot "00_Common\Close-Toolkit-Session.ps1"
$sessionClosePresent = (
    (Test-Path -LiteralPath $closeSessionPath) -and
    $launcherText.IndexOf(':TOOLKIT_EXIT',[StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $launcherText.IndexOf('Close-Toolkit-Session.ps1',[StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    ([regex]::Matches($launcherText,'if "%choice%"=="0" goto TOOLKIT_EXIT')).Count -ge 1
)
Add-Test "Session closeout on toolkit exit" $sessionClosePresent "Session state and closeout summary are written before launcher exit"

$compatPath = Join-Path $ToolkitRoot "00_Common\Compatibility-Matrix.json"
$compatPass = $false
try {
    $compat = Get-Content -LiteralPath $compatPath -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
    $compatPass = @($compat.Profiles).Count -ge 6 -and [int]$compat.PowerShell.MinimumCompatibleMajor -eq 5
} catch {}
Add-Test "Runtime compatibility matrix" $compatPass $compatPath

$capRefreshPath = Join-Path $ToolkitRoot "00_Common\Refresh-Menu-Capabilities.ps1"
$capRefreshText = ""
if (Test-Path -LiteralPath $capRefreshPath) {
    $capRefreshText = Get-Content -LiteralPath $capRefreshPath -Raw -ErrorAction SilentlyContinue
}
$capTokens = @(
    'Get-ToolkitFeatureCapabilities',
    'CAP_DISM',
    'CAP_BITLOCKER',
    'CAP_DEFENDER',
    'CAP_WINRE',
    'CAP_PNPUTIL',
    'CAP_BATTERY',
    'CAP_WLAN',
    'CAP_HYPERV'
)
$capMissing = @($capTokens | Where-Object {
    $capRefreshText.IndexOf($_,[System.StringComparison]::OrdinalIgnoreCase) -lt 0
})
$launcherCapPresent = (
    $launcherText.IndexOf(':REFRESH_CAPS',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $launcherText.IndexOf('%CAP_BITLOCKER%',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $launcherText.IndexOf('%CAP_DISM%',[System.StringComparison]::OrdinalIgnoreCase) -ge 0
)
Add-Test "Capability-aware menu layer" `
    ((Test-Path -LiteralPath $capRefreshPath) -and $capMissing.Count -eq 0 -and $launcherCapPresent) `
    $(if ($capMissing.Count -eq 0 -and $launcherCapPresent) { "Capability cache and menu annotations present" } else { "Capability menu plumbing incomplete" })

$menuSearchPath = Join-Path $ToolkitRoot "26_Tools\Menu-Search.ps1"
$menuSearchText = ""
if (Test-Path -LiteralPath $menuSearchPath) {
    $menuSearchText = Get-Content -LiteralPath $menuSearchPath -Raw -ErrorAction SilentlyContinue
}
$menuSearchTokens = @(
    'TOOLKIT MENU SEARCH',
    'Get-ToolkitCapabilityForLabel',
    'Get-ToolkitFeatureCapabilities',
    'Read-ToolkitPrompt',
    'Get-ToolkitToolCatalog',
    'Invoke-Toolkit-MenuTool.ps1',
    'Capability status refreshed after the tool returned',
    'Searches Basic, Advanced, Tools, and Repair',
    'function Test-MenuSearchExitChoice',
    '"0","99","B","BACK","RETURN","Q","QUIT","EXIT","X"',
    '0. Return to the previous toolkit menu',
    'S. Search again'
)
$menuSearchMissing = @($menuSearchTokens | Where-Object {
    $menuSearchText.IndexOf($_,[System.StringComparison]::OrdinalIgnoreCase) -lt 0
})
$searchCatalogCount = $(if ($catalogTools) { $catalogTools.Count } else { 0 })
$searchHotkeyCount = ([regex]::Matches($launcherText,'(?im)^if /I "%choice%"=="S" call :RUN_TOOL "Toolkit Menu Search"')).Count
Add-Test "Menu Search indexes all numbered tools" `
    ((Test-Path -LiteralPath $menuSearchPath) -and $menuSearchMissing.Count -eq 0 -and $searchCatalogCount -eq 158 -and $mappingProblems.Count -eq 0 -and $searchHotkeyCount -ge 4) `
    ("Catalog tools=" + $searchCatalogCount + "; catalog/launcher mismatches=" + $mappingProblems.Count + "; search hotkeys=" + $searchHotkeyCount + "; missing tokens=" + ($menuSearchMissing -join ","))

$menuRunnerPath = Join-Path $ToolkitRoot "00_Common\Invoke-Toolkit-MenuTool.ps1"
$menuRunnerText = ""
if (Test-Path -LiteralPath $menuRunnerPath) {
    $menuRunnerText = Get-Content -LiteralPath $menuRunnerPath -Raw -ErrorAction SilentlyContinue
}
$menuRunnerTokens = @(
    'ToolId',
    'Get-BridgeCatalogTool',
    'Write-BridgeLifecycle',
    'FIELDTECH_TOOL_ID',
    'FIELDTECH_TOOL_TIMEOUT_SECONDS',
    'ToolName',
    'ToolPath',
    'EnforceAccess',
    'Capture-Active-Case-Artifacts.ps1',
    '$toolStartedAt',
    '-Since $toolStartedAt.ToString("o")',
    'Launch source:',
    'Tool finished:',
    'Return code:'
)
$menuRunnerMissing = @($menuRunnerTokens | Where-Object {
    $menuRunnerText.IndexOf($_,[System.StringComparison]::OrdinalIgnoreCase) -lt 0
})
$launcherUsesSharedRunner = (
    $launcherText.IndexOf('Invoke-Toolkit-MenuTool.ps1',[System.StringComparison]::OrdinalIgnoreCase) -ge 0
)
Add-Test "Shared launcher/search tool runner" `
    ((Test-Path -LiteralPath $menuRunnerPath) -and $menuRunnerMissing.Count -eq 0 -and $launcherUsesSharedRunner) `
    $(if ($menuRunnerMissing.Count -eq 0 -and $launcherUsesSharedRunner) { "Launcher and Search share lifecycle/admin/return-code runner" } else { "Shared runner integration incomplete" })

$minimalBridgePass = (
    -not [regex]::IsMatch($menuRunnerText,'(?im)^\s*\.\s+\$?foundation\b') -and
    -not [regex]::IsMatch($menuRunnerText,'(?im)^\s*(Test-ToolkitToolDependencies|Get-ToolkitFeatureCapabilities|Get-ToolkitRuntimeContext|Write-ToolkitOperationLedger)\b')
)
Add-Test "Minimal Foundation-independent launch bridge" `
    $minimalBridgePass `
    $(if ($minimalBridgePass) { "Pre-launch path does not load Foundation or capability/runtime dependency stacks" } else { "Shared launch bridge has regained a heavy pre-launch Foundation dependency" })

$caseCapturePath = Join-Path $ToolkitRoot "00_Common\Capture-Active-Case-Artifacts.ps1"
$caseCaptureText = ""
if(Test-Path -LiteralPath $caseCapturePath -PathType Leaf){
    $caseCaptureText=Get-Content -LiteralPath $caseCapturePath -Raw -ErrorAction SilentlyContinue
}
$caseCaptureTokens=@(
    'ACTIVE_CASE.json',
    'ACTIVE_CASE.txt',
    'CASE_STATE.json',
    'Status -and [string]$caseState.Status -ine "ACTIVE"',
    'Artifacts\LogsMirror',
    'Activity',
    'CASE_ARTIFACTS.jsonl',
    'CASE_OPERATION_LEDGER.jsonl',
    'CASE_MUTATION_LEDGER.jsonl',
    'CASE_REPAIR_SESSION_JOURNAL.txt',
    'CASE_TOOL_RUNS.jsonl',
    'SourceRelativePath',
    'CapturedRelativePath',
    'FinalSweep',
    'OPERATION_LEDGER.jsonl',
    'MUTATION_LEDGER.jsonl',
    'REPAIR_SESSION_JOURNAL.txt'
)
$caseCaptureMissing=@($caseCaptureTokens|Where-Object{
    $caseCaptureText.IndexOf($_,[System.StringComparison]::OrdinalIgnoreCase) -lt 0
})
$caseCaptureInactiveGuard=(
    $caseCaptureText.IndexOf('if($null -eq $case){return}',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $caseCaptureText.IndexOf('Shared/global files can contain material from other cases/sessions',[System.StringComparison]::OrdinalIgnoreCase) -ge 0
)
Add-Test "Active-case-only artifact capture contract" `
    ((Test-Path -LiteralPath $caseCapturePath -PathType Leaf) -and $caseCaptureMissing.Count -eq 0 -and $caseCaptureInactiveGuard) `
    $(if($caseCaptureMissing.Count -eq 0 -and $caseCaptureInactiveGuard){"No active case = no-op; active case mirrors Logs artifacts and case-filtered activity evidence"}else{"Missing: "+($caseCaptureMissing -join "; ")})

$collectCasePath=Join-Path $ToolkitRoot "30_Assessment_Case\Collect-Case-Mode.ps1"
$collectCaseText=$(if(Test-Path -LiteralPath $collectCasePath -PathType Leaf){Get-Content -LiteralPath $collectCasePath -Raw -ErrorAction SilentlyContinue}else{""})
$closeoutCasePath=Join-Path $ToolkitRoot "30_Assessment_Case\Case-Closeout-Report.ps1"
$closeoutCaseText=$(if(Test-Path -LiteralPath $closeoutCasePath -PathType Leaf){Get-Content -LiteralPath $closeoutCasePath -Raw -ErrorAction SilentlyContinue}else{""})
$caseWorkflowCapturePass=(
    $collectCaseText.IndexOf('ArtifactCaptureMode="ACTIVE_CASE_ONLY"',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $collectCaseText.IndexOf('CASE_CAPTURE_POLICY.txt',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $closeoutCaseText.IndexOf('Case Closeout Final Sweep',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $closeoutCaseText.IndexOf('Captured Toolkit Artifacts',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $closeoutCaseText.IndexOf('CapturedArtifactCount',[System.StringComparison]::OrdinalIgnoreCase) -ge 0
)
Add-Test "Collect Case live-capture / closeout integration" $caseWorkflowCapturePass `
    $(if($caseWorkflowCapturePass){"Collect Case enables ACTIVE_CASE_ONLY capture; Closeout final-sweeps and inventories captured evidence"}else{"Case live-capture/closeout integration incomplete"})

$nativeRunnerRules = @(
    [pscustomobject]@{Path="28_Repair\Windows-Repair-Chain.ps1"; Tokens=@('Invoke-ToolkitNativeCommand','DISM RestoreHealth','SFC Scannow')},
    [pscustomobject]@{Path="28_Repair\DISM-Service-Center.ps1"; Tokens=@('Invoke-ToolkitNativeCommand','Invoke-DismOperation','SFC VerifyOnly')},
    [pscustomobject]@{Path="28_Repair\WinRE-Repair.ps1"; Tokens=@('Invoke-ToolkitNativeCommand','REAgentC','BCD Export Before WinRE Change')},
    [pscustomobject]@{Path="28_Repair\Driver-Recovery.ps1"; Tokens=@('Invoke-ToolkitNativeCommand','PnPUtil Scan Devices','PnPUtil Remove')},
    [pscustomobject]@{Path="28_Repair\Disk-FileSystem-Health-Repair.ps1"; Tokens=@('Invoke-ToolkitNativeCommand','CHKDSK Repair')},
    [pscustomobject]@{Path="28_Repair\Create-Restore-Point-and-Safety-Backup.ps1"; Tokens=@('Invoke-ToolkitNativeCommand','BCD Safety Export','Firewall Policy Export')}
)
foreach ($rule in $nativeRunnerRules) {
    $path = Join-Path $ToolkitRoot $rule.Path
    $text = ""
    if (Test-Path -LiteralPath $path) {
        $text = Get-Content -LiteralPath $path -Raw -ErrorAction SilentlyContinue
    }
    $missing = @($rule.Tokens | Where-Object { $text.IndexOf($_,[System.StringComparison]::OrdinalIgnoreCase) -lt 0 })
    Add-Test ("Shared native runner: " + $rule.Path) `
        ((Test-Path -LiteralPath $path) -and $missing.Count -eq 0) `
        $(if ($missing.Count -eq 0) { "Native command execution routes through shared runner" } else { "Missing: " + ($missing -join "; ") })
}

$featureChecks = @(
    [pscustomobject]@{Name="Toolkit v4 diagnostic evidence engine";Path="00_Common\Diagnostic-Evidence.ps1";Tokens=@("Get-ToolkitEvidenceId","New-ToolkitDiagnosticFinding","Get-ToolkitDiskContext","Get-ToolkitSystemEventClassification","Get-ToolkitWerClassification","Get-ToolkitCapabilityFailureClassification","Update-ToolkitEvidenceCorrelationIndex","Get-ToolkitEvidenceCorrelationHealth","Test-ToolkitDiagnosticFixtures")},
    [pscustomobject]@{Name="Toolkit v4 report metadata sidecar";Path="00_Common\Write-TriReport.ps1";Tokens=@("Toolkit-Version.json","ReportSchemaVersion","ToolkitBuildId",".meta.json")},
    [pscustomobject]@{Name="Sectioned long-report HTML renderer";Path="00_Common\Sectioned-Html-Report.ps1";Tokens=@("New-ToolkitSectionedReport","Add-ToolkitSectionedReportSection","Write-ToolkitSectionedHtmlReport","Expand all","Collapse all","Back to top","<details")},
    [pscustomobject]@{Name="Long-report auto sectioning in shared tri-report writer";Path="00_Common\Write-TriReport.ps1";Tokens=@("Sectioned-Html-Report.ps1","$Body.Length -ge 5000","$sectionMatches.Count -ge 4","Write-ToolkitSectionedHtmlReport")},
    [pscustomobject]@{Name="Full Machine Report shared sectioned HTML";Path="00_Full_Machine_Report\Full-Machine-Report.ps1";Tokens=@("Sectioned-Html-Report.ps1","New-ToolkitSectionedReport","Write-ToolkitSectionedHtmlReport")},
    [pscustomobject]@{Name="Full Machine Compare shared sectioned HTML";Path="30_Assessment_Case\Full-Machine-Before-After-Compare.ps1";Tokens=@("Sectioned-Html-Report.ps1","New-ToolkitSectionedReport","Write-ToolkitSectionedHtmlReport")},
    [pscustomobject]@{Name="Case Closeout shared sectioned HTML";Path="30_Assessment_Case\Case-Closeout-Report.ps1";Tokens=@("Sectioned-Html-Report.ps1","New-ToolkitSectionedReport","Write-ToolkitSectionedHtmlReport")},
    [pscustomobject]@{Name="Windows Servicing / Update Health Report";Path="30_Assessment_Case\Windows-Servicing-Update-Health-Report.ps1";Tokens=@("Read-only umbrella assessment","/CheckHealth","/AnalyzeComponentStore","Get-WindowsPackage","Microsoft.Update.Session","WindowsUpdateClient/Operational","CBS Log - Filtered Recent Evidence","Recommended Next Actions","Write-ToolkitSectionedHtmlReport","No cleanup, ResetBase, RestoreHealth")},
    [pscustomobject]@{Name="Shared assessment confidence convention";Path="00_Common\Assessment-Confidence.ps1";Tokens=@("CONFIRMED","STRONG_EVIDENCE","POSSIBLE","INDETERMINATE","NOT_TESTED","ConvertTo-ToolkitAssessmentConfidence","New-ToolkitAssessment")},
    [pscustomobject]@{Name="Windows Servicing shared confidence usage";Path="30_Assessment_Case\Windows-Servicing-Update-Health-Report.ps1";Tokens=@("Assessment-Confidence.ps1","Assessment Confidence Vocabulary","AssessmentConfidenceVocabulary","STRONG_EVIDENCE","NOT_TESTED")},
    [pscustomobject]@{Name="Domain Trust / AD Health Investigator";Path="30_Assessment_Case\Domain-Trust-AD-Health-Investigator.ps1";Tokens=@("Test-ComputerSecureChannel","/dsgetdc:","/sc_query:","_ldap._tcp.dc._msdcs.","Test-NetConnection","w32tm.exe","Likely Cause Matrix","AssessmentConfidenceVocabulary","Write-ToolkitSectionedHtmlReport")},
    [pscustomobject]@{Name="Basic follow-up routing helper";Path="00_Common\Show-Basic-Next-Step.ps1";Tokens=@("NEXT STEP:","Advanced 71","Advanced 72","Advanced 73","Advanced 74","Advanced 75","Advanced 76","cannot alter launcher labels")},
    [pscustomobject]@{Name="Launcher menu-choice hardening";Path="RUN-WINDOWS-FIELD-TECH.cmd";Tokens=@("Show-Basic-Next-Step.ps1","Completed Basic tools may suggest a deeper Advanced follow-up","set \"TOOL_RC=\"")},
    [pscustomobject]@{Name="Windows Update Readiness deep assessment";Path="19_Update_Readiness\Windows-Update-Readiness.ps1";Tokens=@("Overall readiness:","RECENT WINDOWS UPDATE EVENTS - 14 DAYS","WINDOWS UPDATE POLICY","DISM CHECKHEALTH")},
    [pscustomobject]@{Name="SMART / Drive Deep Dive";Path="20_Storage_Deep_Dive\Storage-Deep-Dive.ps1";Tokens=@("Get-StorageReliabilityCounter","MSStorageDriver_FailurePredictStatus","STORAGE EVENT SUMMARY - 30 DAYS","REMOVABLE / NO-MEDIA STORAGE CONTEXT","Overall interpretation:")},
    [pscustomobject]@{Name="Crash correlation investigator";Path="21_Crash_and_Reliability\Crash-Reliability-Report.ps1";Tokens=@("CORRELATED INCIDENTS","High-signal anchors:","Historical WER replay","Repeated references to the same historical watchdog dump are deduplicated","Removable storage context")},
    [pscustomobject]@{Name="Activation / licensing deep dive";Path="24_Software_and_Licensing\Software-License-Inventory.ps1";Tokens=@("WINDOWS ACTIVATION / CHANNEL DEEP DIVE","SOFTWARE LICENSING SERVICE","SLMGR DETAILED LICENSE VIEW","OA3xOriginalProductKey")},
    [pscustomobject]@{Name="What Changed analyzer";Path="29_Advanced_Audit\Recent-Changes-Timeline.ps1";Tokens=@("WHAT CHANGED? - RECENT CHANGES ANALYZER","Service start-type change","Scheduled task change","CHANGE COUNTS BY CATEGORY")},
    [pscustomobject]@{Name="Network adapter sanity - Advanced Browser/Network";Path="16_Browser_and_Network_Sanity\Browser-Network-Sanity.ps1";Tokens=@("NETWORK ADAPTER SANITY","Get-NetAdapterStatistics","Get-NetAdapterPowerManagement","Win32_PnPSignedDriver")},
    [pscustomobject]@{Name="Network adapter sanity - Full Network Triage";Path="13_Network_Triage\NETWORK-TRIAGE.ps1";Tokens=@("NETWORK ADAPTER SANITY","Get-NetAdapterStatistics","Power-management state","RECENT NETWORK ADAPTER / DRIVER EVENTS - 14 DAYS")},
    [pscustomobject]@{Name="Hardware Acceptance Test";Path="31_Hardware_Acceptance\Hardware-Acceptance-Test.ps1";Tokens=@("HARDWARE ACCEPTANCE TEST","Get-StorageReliabilityCounter","Zero-size/no-filesystem volume objects","Unavailable / indeterminate","WHEA WARNING/ERROR EVENTS - 7 DAYS")}
)
foreach ($feature in $featureChecks) {
    $featurePath = Join-Path $ToolkitRoot $feature.Path
    $featureText = ""
    if (Test-Path -LiteralPath $featurePath -PathType Leaf) {
        $featureText = Get-Content -LiteralPath $featurePath -Raw -ErrorAction SilentlyContinue
    }
    $missingFeatureTokens = @($feature.Tokens | Where-Object { $featureText.IndexOf($_,[System.StringComparison]::OrdinalIgnoreCase) -lt 0 })
    Add-Test ("Feature integration: " + $feature.Name) `
        ((Test-Path -LiteralPath $featurePath -PathType Leaf) -and $missingFeatureTokens.Count -eq 0) `
        $(if ($missingFeatureTokens.Count -eq 0) { "Requested diagnostic capability present" } else { "Missing: " + ($missingFeatureTokens -join "; ") })
}

# Field-report refinement regressions.
$hardwareAcceptanceText = Get-Content -LiteralPath (Join-Path $ToolkitRoot "31_Hardware_Acceptance\Hardware-Acceptance-Test.ps1") -Raw -ErrorAction SilentlyContinue
Add-Test "Hardware Acceptance ignores zero-size phantom volumes for free-space scoring" `
    ($hardwareAcceptanceText.IndexOf('$v.FileSystem -and',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
     $hardwareAcceptanceText.IndexOf('$v.SizeGB -gt 0',[System.StringComparison]::OrdinalIgnoreCase) -ge 0) `
    "Free-space findings require a real filesystem and positive volume size"

$storageDeepDiveText = Get-Content -LiteralPath (Join-Path $ToolkitRoot "20_Storage_Deep_Dive\Storage-Deep-Dive.ps1") -Raw -ErrorAction SilentlyContinue
Add-Test "Storage Deep Dive maps event Harddisk numbers before scoring" `
    ($storageDeepDiveText.IndexOf('Get-Disk -ErrorAction SilentlyContinue',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
     $storageDeepDiveText.IndexOf('REMOVABLE / NO-MEDIA',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
     $storageDeepDiveText.IndexOf('INTERNAL / FIXED',[System.StringComparison]::OrdinalIgnoreCase) -ge 0) `
    "Storage Event Log scoring distinguishes internal/fixed from removable/no-media devices"

$crashCorrelationText = Get-Content -LiteralPath (Join-Path $ToolkitRoot "21_Crash_and_Reliability\Crash-Reliability-Report.ps1") -Raw -ErrorAction SilentlyContinue
Add-Test "Crash Correlation uses high-signal anchors and WER replay deduplication" `
    ($crashCorrelationText.IndexOf('IsAnchor',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
     $crashCorrelationText.IndexOf('Historical WER replay',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
     $crashCorrelationText.IndexOf('LIVEKERNEL|',[System.StringComparison]::OrdinalIgnoreCase) -ge 0) `
    "Informational context does not create incidents and historical LiveKernelEvent dumps are deduplicated"

$repairCommonPath = Join-Path $ToolkitRoot "28_Repair\Repair-Common.ps1"
$repairCommonText = ""
if (Test-Path -LiteralPath $repairCommonPath) {
    $repairCommonText = Get-Content -LiteralPath $repairCommonPath -Raw -ErrorAction SilentlyContinue
}
$repairFoundationTokens = @(
    'Foundation-Common.ps1',
    'Initialize-ToolkitRuntimeContext',
    'Initialize-ToolkitRepairProcess',
    'Get-RepairOperationId',
    'Write-ToolkitOperationLedger',
    'Write-ToolkitMutationLedger',
    'New-ToolkitResult',
    'Write-ToolkitResult'
)
$repairFoundationMissing = @($repairFoundationTokens | Where-Object {
    $repairCommonText.IndexOf($_,[System.StringComparison]::OrdinalIgnoreCase) -lt 0
})
Add-Test "Repair foundation integration" `
    ($repairFoundationMissing.Count -eq 0) `
    $(if ($repairFoundationMissing.Count -eq 0) { "Repair journal uses session/operation IDs, ledger, runtime context, interruption marker, and unified result states" } else { "Missing: " + ($repairFoundationMissing -join "; ") })


# Support-bundle BitLocker privacy guard.
$supportBundlePath = Join-Path $ToolkitRoot "27_Support_Bundle\Create-Support-Bundle.ps1"
$supportBundleText = ""
if (Test-Path -LiteralPath $supportBundlePath) {
    $supportBundleText = Get-Content -LiteralPath $supportBundlePath -Raw -ErrorAction SilentlyContinue
}
$supportBundleBitLockerSafe = (
    $supportBundleText.IndexOf('ProtectorTypes',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $supportBundleText.IndexOf('.RecoveryPassword',[System.StringComparison]::OrdinalIgnoreCase) -lt 0
)
$supportManifestPresent = (
    $supportBundleText.IndexOf('SUPPORT_BUNDLE_MANIFEST.json',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $supportBundleText.IndexOf('ToolkitManifestSHA256',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $supportBundleText.IndexOf('BundleSensitivity',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $supportBundleText.IndexOf('Get-FileHash',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $supportBundleText.IndexOf('VERIFY-SUPPORT-BUNDLE.ps1',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $supportBundleText.IndexOf('DigitalSignatureStatus = "NOT SIGNED"',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $supportBundleText.IndexOf('ZIP SHA256',[System.StringComparison]::OrdinalIgnoreCase) -ge 0
)
Add-Test "Support bundle BitLocker privacy" `
    ((Test-Path -LiteralPath $supportBundlePath) -and $supportBundleBitLockerSafe) `
    $(if ($supportBundleBitLockerSafe) { "Status/protector types only; no RecoveryPassword property access" } else { "Support bundle BitLocker privacy guard missing or unsafe" })
Add-Test "Support bundle manifest and hashes" `
    ((Test-Path -LiteralPath $supportBundlePath) -and $supportManifestPresent) `
    $(if ($supportManifestPresent) { "Manifest, offline verifier, explicit NOT SIGNED status, per-file hashes, and ZIP hash evidence present" } else { "Support bundle manifest/hash/verifier contract missing" })


# BitLocker boot-risk guard regression. The shared helper must retain the
# bounded 1-3 reboot suspension, typed SUSPEND gate, post-state verification,
# and no-secret policy.
$bitLockerGuardPath = Join-Path $ToolkitRoot "28_Repair\Repair-Common.ps1"
$bitLockerGuardText = ""
if (Test-Path -LiteralPath $bitLockerGuardPath) {
    $bitLockerGuardText = Get-Content -LiteralPath $bitLockerGuardPath -Raw -ErrorAction SilentlyContinue
}
$bitLockerGuardTokens = @(
    'function Invoke-BitLockerBootRiskPreflight',
    '^[1-3]$',
    '"SUSPEND"',
    'Suspend-BitLocker',
    'Write-RepairVerification',
    'This check never displays or logs BitLocker recovery passwords.'
)
$bitLockerGuardMissing = @($bitLockerGuardTokens | Where-Object {
    $bitLockerGuardText.IndexOf($_,[System.StringComparison]::OrdinalIgnoreCase) -lt 0
})
Add-Test "BitLocker boot-risk preflight helper" `
    ((Test-Path -LiteralPath $bitLockerGuardPath) -and $bitLockerGuardMissing.Count -eq 0) `
    $(if ($bitLockerGuardMissing.Count -eq 0) { "Bounded suspension, confirmation, verification, and no-secret controls present" } else { "Missing: " + ($bitLockerGuardMissing -join "; ") })

# Scan current CMD/PowerShell code for direct boot/recovery/security-state
# mutation primitives. Any file that contains one must also invoke the shared
# BitLocker boot-risk preflight. This protects future additions from silently
# bypassing the guard.
$bootRiskFiles = New-Object System.Collections.Generic.List[string]
$unguardedBootRiskFiles = New-Object System.Collections.Generic.List[string]

$scanFiles = @(
    Get-ChildItem -LiteralPath $ToolkitRoot -Recurse -File -ErrorAction SilentlyContinue |
        Where-Object {
            $_.Extension -in @(".ps1",".cmd") -and
            $_.FullName -ne $MyInvocation.MyCommand.Path
        }
)

foreach ($scanFile in $scanFiles) {
    $scanText = Get-Content -LiteralPath $scanFile.FullName -Raw -ErrorAction SilentlyContinue
    if ([string]::IsNullOrWhiteSpace($scanText)) { continue }

    $directBootMutation = (
        $scanText -match '(?i)\bbcdedit(?:\.exe)?\s+/(set|delete|deletevalue|create|copy|import|createstore|displayorder|bootsequence|default|timeout)\b' -or
        $scanText -match '(?i)\b(bootrec|bcdboot|bootsect)(?:\.exe)?\b' -or
        $scanText -match '(?i)\b(Resize-Partition|New-Partition|Remove-Partition|Set-Partition)\b' -or
        $scanText -match '(?i)\b(Clear-Tpm|Initialize-Tpm|Set-SecureBootUEFI)\b' -or
        (
            $scanText -match '(?i)\breagentc(?:\.exe)?\b' -and
            $scanText -match '(?i)/(enable|disable|setreimage)\b'
        )
    )

    if (-not $directBootMutation) { continue }

    $relativeRiskPath = Get-ToolkitRelativePath -FullPath $scanFile.FullName
    $bootRiskFiles.Add($relativeRiskPath)

    if ($scanText.IndexOf('Invoke-BitLockerBootRiskPreflight',[System.StringComparison]::OrdinalIgnoreCase) -lt 0) {
        $unguardedBootRiskFiles.Add($relativeRiskPath)
    }
}

Add-Test "BitLocker guard coverage for boot-sensitive mutations" `
    ($unguardedBootRiskFiles.Count -eq 0) `
    $(if ($unguardedBootRiskFiles.Count -eq 0) {
        "Guarded boot-risk files: " + $(if ($bootRiskFiles.Count -gt 0) { $bootRiskFiles -join ", " } else { "(none detected)" })
    } else {
        "Unguarded: " + ($unguardedBootRiskFiles -join ", ")
    })


# Verification-contract check for repair tools that can change Windows state.
# A repair must explicitly record a post-action verification status rather than
# treating a successful command launch/exit code as sufficient proof by itself.
$repairVerificationRules = @(
    "28_Repair\Defender-Offline-Scan.ps1",
    "28_Repair\Create-Restore-Point-and-Safety-Backup.ps1",
    "28_Repair\Microsoft-Store-Repair.ps1",
    "28_Repair\Print-System-Repair.ps1",
    "28_Repair\Safe-Free-Space-Recovery.ps1",
    "28_Repair\Disk-FileSystem-Health-Repair.ps1",
    "28_Repair\Deep-Windows-Update-Reset.ps1",
    "28_Repair\Windows-Repair-Chain.ps1",
    "28_Repair\Driver-Recovery.ps1",
    "28_Repair\WinRE-Repair.ps1",
    "28_Repair\Service-Recovery.ps1",
    "28_Repair\DISM-Service-Center.ps1",
    "28_Repair\BitLocker-Protection-Control.ps1"
)
foreach ($rel in $repairVerificationRules) {
    $verificationPath = Join-Path $ToolkitRoot $rel
    $verificationText = ""
    if (Test-Path -LiteralPath $verificationPath) {
        $verificationText = Get-Content -LiteralPath $verificationPath -Raw -ErrorAction SilentlyContinue
    }
    $hasContract = $verificationText -match '(?i)Write-RepairVerification'
    Add-Test ("Repair verification contract: " + $rel) `
        ((Test-Path -LiteralPath $verificationPath) -and $hasContract) `
        $(if ($hasContract) { "Post-action verification status recorded" } else { "Write-RepairVerification not found" })
}

# Process Investigation is deliberately the Repair menu's read-only tool.
$processInvestigationPath = Join-Path $ToolkitRoot "28_Repair\Safe-Process-Investigation.ps1"
$processInvestigationText = ""
if (Test-Path -LiteralPath $processInvestigationPath) {
    $processInvestigationText = Get-Content -LiteralPath $processInvestigationPath -Raw -ErrorAction SilentlyContinue
}
$processMutationPattern = '(?im)^\s*(Stop-Process|Remove-Item|Set-Service|Start-Service|Stop-Service|Restart-Service|pnputil\.exe\s+/(delete-driver|restart-device|add-driver)|reagentc\.exe\s+/(enable|disable|setreimage))'
Add-Test "Repair read-only invariant: Safe Process Investigation" `
    (-not [regex]::IsMatch($processInvestigationText, $processMutationPattern)) `
    "No known system-state mutation command detected."


# Global Screen Reader Mode dependency audit.
# Every interactive PowerShell prompt must use Read-ToolkitPrompt, which is
# supplied either directly by ScreenReader-Common.ps1 or through Repair-Common.
$srCommonPath = Join-Path $ToolkitRoot "00_Common\ScreenReader-Common.ps1"
$srCommonText = ""
if (Test-Path -LiteralPath $srCommonPath) {
    $srCommonText = Get-Content -LiteralPath $srCommonPath -Raw -ErrorAction SilentlyContinue
}

$srCommonTokens = @(
    'function Test-ToolkitScreenReaderMode',
    'env:SRMODE',
    'env:FIELDTECH_SCREEN_READER',
    'function Write-SRAnnouncement',
    'function Write-ToolkitStatus',
    'function Read-ToolkitPrompt'
)
$srCommonMissing = @($srCommonTokens | Where-Object {
    $srCommonText.IndexOf($_,[System.StringComparison]::OrdinalIgnoreCase) -lt 0
})
Add-Test "Screen Reader shared context helper" `
    ((Test-Path -LiteralPath $srCommonPath) -and $srCommonMissing.Count -eq 0) `
    $(if ($srCommonMissing.Count -eq 0) { "Shared SRMODE context, announcement, and prompt helpers present" } else { "Missing: " + ($srCommonMissing -join "; ") })

$legacyPromptLabel='Write-Host ("Prompt: " + $Prompt)'
$legacyInputCall=("Read"+"-Host ""Input""")
$sharedInputCall=("return Read"+"-Host")
$srPromptContextPass=(
    $srCommonText.IndexOf($legacyPromptLabel,[System.StringComparison]::OrdinalIgnoreCase) -lt 0 -and
    $srCommonText.IndexOf($legacyInputCall,[System.StringComparison]::OrdinalIgnoreCase) -lt 0 -and
    $srCommonText.IndexOf($sharedInputCall,[System.StringComparison]::OrdinalIgnoreCase) -ge 0
)
Add-Test "Screen Reader prompt context is single-announcement" `
    $srPromptContextPass `
    $(if($srPromptContextPass){"No synthetic Prompt/Input labels; prompt is announced once before input"}else{"Legacy duplicate Prompt/Input labeling detected"})

$srSpellingTokens=@(
    'function ConvertTo-ToolkitSpokenExactPhrase',
    'SpellExactPhrase',
    'space'
)
$srSpellingMissing=@($srSpellingTokens|Where-Object{$srCommonText.IndexOf($_,[System.StringComparison]::OrdinalIgnoreCase) -lt 0})
Add-Test "Screen Reader exact confirmation spelling helper" `
    ($srSpellingMissing.Count -eq 0) `
    $(if($srSpellingMissing.Count -eq 0){"SR-only exact phrase spelling helper present"}else{"Missing: "+($srSpellingMissing -join "; ")})

$srExactPhraseContracts=@(
    [pscustomobject]@{Path="30_Assessment_Case\SMB-Connectivity-Troubleshooting-Investigator.ps1";Phrase="AUTH TEST"},
    [pscustomobject]@{Path="00_Common\Retention-Maintenance.ps1";Phrase="PURGE"},
    [pscustomobject]@{Path="26_Tools\Toolkit-Known-Good-Rebuild.ps1";Phrase="REBUILD"},
    [pscustomobject]@{Path="28_Repair\DISM-Service-Center.ps1";Phrase="REMOVE"},
    [pscustomobject]@{Path="29_Advanced_Audit\Network-Before-After-Compare.ps1";Phrase="YES"},
    [pscustomobject]@{Path="29_Advanced_Audit\Network-Before-After-Compare.ps1";Phrase="DELETE"}
)
$srExactMissing=New-Object System.Collections.Generic.List[string]
foreach($contract in $srExactPhraseContracts){
    $contractPath=Join-Path $ToolkitRoot $contract.Path
    $contractText=$(if(Test-Path -LiteralPath $contractPath -PathType Leaf){Get-Content -LiteralPath $contractPath -Raw -ErrorAction SilentlyContinue}else{""})
    $token='-SpellExactPhrase "'+$contract.Phrase+'"'
    if($contractText.IndexOf($token,[System.StringComparison]::OrdinalIgnoreCase) -lt 0){
        $srExactMissing.Add(($contract.Path+" -> "+$contract.Phrase))
    }
}
Add-Test "Exact typed safety phrases have SR-only spelling" `
    ($srExactMissing.Count -eq 0) `
    $(if($srExactMissing.Count -eq 0){"AUTH TEST / PURGE / REBUILD / REMOVE / YES / DELETE use SR-only spelling"}else{"Missing: "+($srExactMissing -join "; ")})

$srSelfSourcePass = $true
if ($srCommonText) {
    $srSelfSourcePass = -not (
        $srCommonText.IndexOf('00_Common\ScreenReader-Common.ps1',[System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
        $srCommonText -match '(?im)^\s*\.\s*\$screenReaderCommon\s*$'
    )
}
Add-Test "Screen Reader helper does not self-source" `
    $srSelfSourcePass `
    $(if ($srSelfSourcePass) { "No recursive self-dot-source detected in ScreenReader-Common.ps1" } else { "Recursive self-dot-source detected; this can cause CallDepthOverflow" })

$interactivePs = New-Object System.Collections.Generic.List[string]
$missingSrDependency = New-Object System.Collections.Generic.List[string]
$rawReadHost = New-Object System.Collections.Generic.List[string]
$readHostName = "Read" + "-Host"

foreach ($psFile in Get-ChildItem -LiteralPath $ToolkitRoot -Recurse -File -Filter *.ps1 -ErrorAction SilentlyContinue) {
    if ($psFile.FullName -eq $srCommonPath) { continue }

    $psText = Get-Content -LiteralPath $psFile.FullName -Raw -ErrorAction SilentlyContinue
    if ([string]::IsNullOrWhiteSpace($psText)) { continue }

    $relativePs = Get-ToolkitRelativePath -FullPath $psFile.FullName
    $usesSharedPrompt = $psText.IndexOf('Read-ToolkitPrompt',[System.StringComparison]::OrdinalIgnoreCase) -ge 0

    # Detect unqualified legacy host-input commands without embedding the command name
    # name literally in this script's source.
    $rawPattern = '(?im)(?<![\\\w-])' + [regex]::Escape($readHostName) + '(?![\w-])'
    $hasRawReadHost = [regex]::IsMatch($psText,$rawPattern)

    if ($usesSharedPrompt -or $hasRawReadHost) {
        $interactivePs.Add($relativePs)
    }

    if ($hasRawReadHost) {
        $rawReadHost.Add($relativePs)
    }

    if ($usesSharedPrompt) {
        $hasDirectSr = $psText.IndexOf('ScreenReader-Common.ps1',[System.StringComparison]::OrdinalIgnoreCase) -ge 0
        $hasRepairSr = $psText.IndexOf('Repair-Common.ps1',[System.StringComparison]::OrdinalIgnoreCase) -ge 0
        $isRepairCommon = $relativePs -ieq '28_Repair\Repair-Common.ps1'

        if (-not ($hasDirectSr -or $hasRepairSr -or $isRepairCommon)) {
            $missingSrDependency.Add($relativePs)
        }
    }
}

Add-Test "Interactive PowerShell uses shared screen-reader prompt layer" `
    ($rawReadHost.Count -eq 0) `
    $(if ($rawReadHost.Count -eq 0) { "No unqualified legacy " + $readHostName + " calls outside the shared helper" } else { "Legacy prompt calls: " + ($rawReadHost -join ", ") })

Add-Test "Interactive PowerShell has SRMODE dependency" `
    ($missingSrDependency.Count -eq 0) `
    $(if ($missingSrDependency.Count -eq 0) { "Interactive scripts with shared prompt layer: " + $interactivePs.Count } else { "Missing SR dependency: " + ($missingSrDependency -join ", ") })

# Interactive CMD wrappers must also preserve the inherited SRMODE context.
$interactiveCmdMissingSr = New-Object System.Collections.Generic.List[string]
foreach ($cmdFile in Get-ChildItem -LiteralPath $ToolkitRoot -Recurse -File -Filter *.cmd -ErrorAction SilentlyContinue) {
    $cmdText = Get-Content -LiteralPath $cmdFile.FullName -Raw -ErrorAction SilentlyContinue
    if ([string]::IsNullOrWhiteSpace($cmdText)) { continue }

    $isInteractiveCmd = (
        $cmdText -match '(?im)^\s*pause(?:\s|$)' -or
        $cmdText -match '(?im)^\s*set\s+/p\b' -or
        $cmdText -match '(?im)^\s*choice\b'
    )
    if (-not $isInteractiveCmd) { continue }

    if ($cmdText.IndexOf('SRMODE',[System.StringComparison]::OrdinalIgnoreCase) -lt 0) {
        $relativeCmd = Get-ToolkitRelativePath -FullPath $cmdFile.FullName
        $interactiveCmdMissingSr.Add($relativeCmd)
    }
}

Add-Test "Interactive CMD wrappers preserve SRMODE" `
    ($interactiveCmdMissingSr.Count -eq 0) `
    $(if ($interactiveCmdMissingSr.Count -eq 0) { "All interactive CMD wrappers reference SRMODE" } else { "Missing SRMODE: " + ($interactiveCmdMissingSr -join ", ") })


$logs = Join-Path $ToolkitRoot "Logs"
$writeOk = $false
$writeDetails = ""
try {
    if (-not (Test-Path -LiteralPath $logs)) {
        New-Item -ItemType Directory -Path $logs -Force | Out-Null
    }
    $probe = Join-Path $logs (".toolkit_write_test_" + [guid]::NewGuid().ToString("N") + ".tmp")
    "write test" | Set-Content -LiteralPath $probe -Encoding ASCII -ErrorAction Stop
    Remove-Item -LiteralPath $probe -Force -ErrorAction Stop
    $writeOk = $true
    $writeDetails = $logs
}
catch {
    $writeDetails = $_.Exception.Message
}
Add-Test "Logs folder writable" $writeOk $writeDetails

$psMajor = $PSVersionTable.PSVersion.Major
Add-Test "PowerShell available" ($psMajor -ge 5) ("PowerShell " + $PSVersionTable.PSVersion.ToString())

$isAdmin = $false
try {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($id)
    $isAdmin = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}
catch {
    $isAdmin = $false
}
Add-Test "Elevation check" $true $(if ($isAdmin) { "Running as Administrator" } else { "Running as standard user" })

$cmdCount = @(Get-ChildItem -LiteralPath $ToolkitRoot -Filter "*.cmd" -File -Recurse).Count
$ps1Count = @(Get-ChildItem -LiteralPath $ToolkitRoot -Filter "*.ps1" -File -Recurse).Count
Add-Test "Script inventory" $true ("CMD: " + $cmdCount + "; PowerShell: " + $ps1Count)

$diagnosticHelperPath = Join-Path $ToolkitRoot "00_Common\Diagnostic-Evidence.ps1"
$diagnosticFixturePath = Join-Path $ToolkitRoot "00_Common\Diagnostic-Fixtures.json"
$diagnosticFixturePass = $false
$diagnosticFixtureDetails = "Not run"
try {
    if (Test-Path -LiteralPath $diagnosticHelperPath -PathType Leaf) {
        . $diagnosticHelperPath
        $fixtureResultsFull = @(Test-ToolkitDiagnosticFixtures -FixturePath $diagnosticFixturePath)
        $fixtureFailuresFull = @($fixtureResultsFull | Where-Object { -not $_.Passed })
        $diagnosticFixturePass = ($fixtureResultsFull.Count -gt 0 -and $fixtureFailuresFull.Count -eq 0)
        $diagnosticFixtureDetails = "Fixtures=" + $fixtureResultsFull.Count + "; failures=" + $fixtureFailuresFull.Count
    }
}
catch {
    $diagnosticFixtureDetails = $_.Exception.Message
}
Add-Test "Shared diagnostic classifier fixtures" $diagnosticFixturePass $diagnosticFixtureDetails

$correlationPass=$false
$correlationDetails="Not run"
$corrTempFull=Join-Path $env:TEMP ("FieldTechEvidenceCorrelationFull_"+[guid]::NewGuid().ToString("N"))
try{
    if(Get-Command Update-ToolkitEvidenceCorrelationIndex -ErrorAction SilentlyContinue){
        New-Item -ItemType Directory -Path $corrTempFull -Force|Out-Null
        $sharedIdFull=Get-ToolkitEvidenceId -Category "WindowsEvent" -Source "disk" -EventId "11" -Timestamp ([datetime]"2026-09-11T20:00:00") -Device "Disk 3 Generic Reader" -Evidence "controller error"
        foreach($n in 1,2){
            $payload=[pscustomobject]@{
                Report=[pscustomobject]@{ToolId=$(if($n -eq 1){"ADV-006"}else{"ADV-007"});Title=("Full Fixture "+$n);GeneratedAt=(Get-Date)}
                Findings=@()
                Evidence=@([pscustomobject]@{EvidenceId=$sharedIdFull;Class="Storage";DeviceContext="Disk 3 Generic Reader";Timestamp="2026-09-11T20:00:00";Source="disk";EventId="11"})
            }
            $payload|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $corrTempFull ("fixture"+$n+".evidence.json")) -Encoding UTF8
        }
        $corrFull=Update-ToolkitEvidenceCorrelationIndex -LogRoot $corrTempFull
        $correlationPass=($corrFull.CorrelatedEvidenceCount -eq 1 -and $corrFull.CorrelatedEvidence[0].ReportCount -eq 2)
        $correlationDetails="CorrelatedEvidence="+$corrFull.CorrelatedEvidenceCount+"; Reports="+$corrFull.CorrelatedEvidence[0].ReportCount
    }
}catch{
    $correlationDetails=$_.Exception.Message
}finally{
    Remove-Item -LiteralPath $corrTempFull -Recurse -Force -ErrorAction SilentlyContinue
}
Add-Test "Evidence correlation index simulation" $correlationPass $correlationDetails

$selfTestCmdPath = Join-Path $ToolkitRoot "26_Tools\Toolkit-Self-Test.cmd"
$selfTestCmdText = Get-Content -LiteralPath $selfTestCmdPath -Raw -ErrorAction SilentlyContinue
$selfTestLevelsPass = (
    $selfTestCmdText.IndexOf('LEVEL=Quick',[StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $selfTestCmdText.IndexOf('LEVEL=Full',[StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $selfTestCmdText.IndexOf('LEVEL=NoSimulation',[StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $selfTestCmdText.IndexOf('LEVEL=DiagnosticLogic',[StringComparison]::OrdinalIgnoreCase) -ge 0 -and
    $MyInvocation.MyCommand.Path -and
    $Level -in @("Quick","Full","NoSimulation","DiagnosticLogic")
)
Add-Test "Self-Test level contract" $selfTestLevelsPass ("Current level=" + $Level)

if ($Level -eq "Full") {
    $simulationPass = $false
    $simulationDetails = "Not run"
    $temp = Join-Path $env:TEMP ("FieldTechSelfTest_" + [guid]::NewGuid().ToString("N"))
    try {
        New-Item -ItemType Directory -Path $temp -Force | Out-Null
        $kgZip = Join-Path $ToolkitRoot "26_Tools\KnownGood\Toolkit-Core-KnownGood.zip"
        Expand-Archive -LiteralPath $kgZip -DestinationPath $temp -Force
        $sample = Get-ChildItem -LiteralPath $temp -File -Recurse -ErrorAction Stop | Select-Object -First 1
        $simulationPass = $null -ne $sample
        $simulationDetails = "Disposable Known-Good extraction succeeded; live toolkit unchanged."
    }
    catch { $simulationDetails = $_.Exception.Message }
    finally { Remove-Item -LiteralPath $temp -Recurse -Force -ErrorAction SilentlyContinue }
    Add-Test "Disposable Known-Good extraction simulation" $simulationPass $simulationDetails
}
else {
    Add-Test "Simulation policy" $true "NoSimulation level selected; disposable extraction simulation skipped."
}

$failed = @($results | Where-Object { $_.Status -eq "FAIL" })

Write-Host ""
Write-Host "WINDOWS FIELD TECH TOOLKIT SELF-TEST"
Write-Host ("Level: " + $Level)
Write-Host ("Toolkit root: " + $ToolkitRoot)
Write-Host ""
$results | Format-Table -AutoSize -Wrap

if ($missing.Count -gt 0) {
    Write-Host ""
    Write-Host "Missing launcher targets:"
    $missing | ForEach-Object { Write-Host (" - " + $_) }
}

if ($nativeParseErrors.Count -gt 0) {
    Write-Host ""
    Write-Host "Native PowerShell parser errors:"
    foreach ($parseError in $nativeParseErrors) {
        Write-Host (" - " + $parseError.File + ":" + $parseError.Line + ":" + $parseError.Column + " [" + $parseError.ErrorId + "] " + $parseError.Message)
    }
}

Write-Host ""
if ($failed.Count -eq 0) {
    Write-Host "Toolkit integrity: PASS"
}
else {
    Write-Host ("Toolkit integrity: FAIL - " + $failed.Count + " test(s) failed.")
    Write-Host "No automatic repair was performed."
    Write-Host "For toolkit-file integrity problems, run Tools 42 - Toolkit Known-Good Integrity / Rebuild."
}

try {
    if (-not (Test-Path -LiteralPath $logs)) {
        New-Item -ItemType Directory -Path $logs -Force | Out-Null
    }
    $stamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $report = Join-Path $logs ("TOOLKIT_SELF_TEST_" + $stamp + ".txt")
    $reportLines = New-Object System.Collections.Generic.List[string]
    $reportLines.Add("WINDOWS FIELD TECH TOOLKIT SELF-TEST")
    $reportLines.Add("Generated: " + (Get-Date))
    $reportLines.Add("Level: " + $Level)
    $reportLines.Add("Toolkit root: " + $ToolkitRoot)
    $reportLines.Add("")
    foreach ($r in $results) {
        $reportLines.Add(("{0}: {1} - {2}" -f $r.Status, $r.Test, $r.Details))
    }
    if ($missing.Count -gt 0) {
        $reportLines.Add("")
        $reportLines.Add("Missing launcher targets:")
        foreach ($item in $missing) {
            $reportLines.Add(" - " + $item)
        }
    }
    if ($missingPs1.Count -gt 0) {
        $reportLines.Add("")
        $reportLines.Add("Missing CMD PowerShell targets:")
        foreach ($item in $missingPs1) {
            $reportLines.Add(" - " + $item)
        }
    }
    if ($nativeParseErrors.Count -gt 0) {
        $reportLines.Add("")
        $reportLines.Add("Native PowerShell parser errors:")
        foreach ($parseError in $nativeParseErrors) {
            $reportLines.Add((" - {0}:{1}:{2} [{3}] {4}" -f $parseError.File,$parseError.Line,$parseError.Column,$parseError.ErrorId,$parseError.Message))
        }
    }
    $reportLines.Add("")
    $reportLines.Add($(if ($failed.Count -eq 0) { "Toolkit integrity: PASS" } else { "Toolkit integrity: FAIL" }))
    if ($failed.Count -gt 0) {
        $reportLines.Add("No automatic repair was performed.")
        $reportLines.Add("For toolkit-file integrity problems, run Tools 42 - Toolkit Known-Good Integrity / Rebuild.")
    }
    $reportLines | Set-Content -LiteralPath $report -Encoding UTF8
    Write-Host ("Saved self-test report: " + $report)
}
catch {
    Write-Host "Self-test completed, but the text report could not be saved."
}

if ($failed.Count -eq 0) {
    if($Level -eq "Full"){
        try{
            if(-not (Get-Command Get-ToolkitBuildIdentity -ErrorAction SilentlyContinue)){
                . (Join-Path $ToolkitRoot "00_Common\Foundation-Common.ps1")
            }
            $build=Get-ToolkitBuildIdentity
            $candidate=[ordered]@{
                SchemaVersion=1
                Status="FULL_SELF_TEST_PASS"
                BuildId=[string]$build.BuildId
                BuildManifestSHA256=[string]$build.ManifestSHA256
                Timestamp=(Get-Date).ToString("o")
                Computer=$env:COMPUTERNAME
                User=($env:USERDOMAIN+"\"+$env:USERNAME)
                SelfTestLevel=$Level
                ReportPath=$(if($report){$report}else{""})
            }
            $candidatePath=Join-Path $logs ("FIELD_VALIDATION_CANDIDATE_"+$build.BuildId+".json")
            [void](Set-ToolkitAtomicJson -Path $candidatePath -Object $candidate)
            Write-Host ("Field-validation candidate recorded: " + $candidatePath)
        }catch{
            Write-Host ("WARNING: Full Self-Test passed, but validation candidate could not be recorded: " + $_.Exception.Message)
        }
    }
    exit 0
}
exit 1

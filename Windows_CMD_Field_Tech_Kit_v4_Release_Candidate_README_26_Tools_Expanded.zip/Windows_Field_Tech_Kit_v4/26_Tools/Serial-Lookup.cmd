@echo off
setlocal EnableExtensions
title Machine Serial Lookup

echo Machine Serial Lookup
echo.
echo Running dedicated PowerShell collector...
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Serial-Lookup.ps1"
set "RC=%errorlevel%"

echo.
if "%RC%"=="0" (
    echo Machine Serial Lookup completed.
) else (
    echo Machine Serial Lookup returned error code %RC%.
)

if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

exit /b %RC%

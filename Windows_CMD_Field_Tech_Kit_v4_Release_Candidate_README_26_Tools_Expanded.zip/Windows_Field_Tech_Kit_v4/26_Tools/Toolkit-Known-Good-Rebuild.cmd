@echo off
setlocal EnableExtensions
title Toolkit Known-Good Integrity / Rebuild

echo TOOLKIT KNOWN-GOOD INTEGRITY / REBUILD
echo.
echo This maintenance tool verifies or repairs the TOOLKIT ITSELF.
echo It does not repair or modify Windows configuration.
echo.
echo Verify mode is read-only.
echo Rebuild mode backs up affected toolkit files before replacement,
echo preserves Logs and technician-generated case/report data, stages and
echo verifies the known-good payload first, and requires typing REBUILD.
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Toolkit-Known-Good-Rebuild.ps1"
set "RC=%errorlevel%"

echo.
if "%RC%"=="0" (
    echo Toolkit integrity / rebuild workflow completed.
) else (
    echo Toolkit integrity / rebuild workflow returned error code %RC%.
)

if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

exit /b %RC%

$ErrorActionPreference = "SilentlyContinue"
$ProgressPreference = "SilentlyContinue"

$toolkitRoot = Split-Path $PSScriptRoot -Parent
$logs = Join-Path $toolkitRoot "Logs"
if (-not (Test-Path -LiteralPath $logs)) {
    New-Item -ItemType Directory -Path $logs -Force | Out-Null
}

$indexHtml = Join-Path $logs "REPORT_INDEX_CURRENT.html"
$indexCsv = Join-Path $logs "REPORT_INDEX_CURRENT.csv"
$indexTxt = Join-Path $logs "REPORT_INDEX_CURRENT.txt"

Write-Host "Building an index of files in the Logs folder..."

$files = @(Get-ChildItem -LiteralPath $logs -File -Recurse -ErrorAction SilentlyContinue |
    Where-Object {
        $_.FullName -ne $indexHtml -and
        $_.FullName -ne $indexCsv -and
        $_.FullName -ne $indexTxt
    } |
    Sort-Object LastWriteTime -Descending)

$rows = New-Object System.Collections.Generic.List[object]

foreach ($file in $files) {
    $relative = $file.FullName.Substring($logs.Length).TrimStart("\")
    $toolkitVersion=""
    $toolId=""
    $reportSchema=""

    if($file.Name -like "*.meta.json"){
        try{
            $meta=Get-Content -LiteralPath $file.FullName -Raw -ErrorAction Stop|ConvertFrom-Json -ErrorAction Stop
            $toolkitVersion=[string]$meta.ToolkitVersion
            $toolId=[string]$meta.ToolId
            $reportSchema=[string]$meta.ReportSchemaVersion
        }catch{}
    }else{
        $metaCandidate=[IO.Path]::Combine($file.DirectoryName,([IO.Path]::GetFileNameWithoutExtension($file.Name)+".meta.json"))
        if(Test-Path -LiteralPath $metaCandidate -PathType Leaf){
            try{
                $meta=Get-Content -LiteralPath $metaCandidate -Raw -ErrorAction Stop|ConvertFrom-Json -ErrorAction Stop
                $toolkitVersion=[string]$meta.ToolkitVersion
                $toolId=[string]$meta.ToolId
                $reportSchema=[string]$meta.ReportSchemaVersion
            }catch{}
        }
    }

    $rows.Add([pscustomobject]@{
        Modified = $file.LastWriteTime
        SizeKB = [math]::Round($file.Length / 1KB, 1)
        Extension = $file.Extension.ToLowerInvariant()
        ToolkitVersion = $toolkitVersion
        ToolId = $toolId
        ReportSchema = $reportSchema
        RelativePath = $relative
    })
}

$rows | Export-Csv -LiteralPath $indexCsv -NoTypeInformation -Encoding UTF8

$textLines = New-Object System.Collections.Generic.List[string]
$textLines.Add("FIELD TECH TOOLKIT REPORT / EXPORT INDEX")
$textLines.Add("Generated: " + (Get-Date))
$textLines.Add("Logs folder: " + $logs)
$textLines.Add("Indexed files: " + $rows.Count)
$textLines.Add("")
$textLines.Add(($rows | Format-Table Modified,SizeKB,Extension,ToolkitVersion,ToolId,ReportSchema,RelativePath -AutoSize | Out-String -Width 260).TrimEnd())
$textLines | Set-Content -LiteralPath $indexTxt -Encoding UTF8

$html = New-Object System.Text.StringBuilder
[void]$html.AppendLine("<!doctype html>")
[void]$html.AppendLine('<html><head><meta charset="utf-8"><title>Field Tech Toolkit Report Index</title>')
[void]$html.AppendLine("<style>body{font-family:Segoe UI,Arial,sans-serif;margin:24px;background:#f5f7fa;color:#18212f}table{border-collapse:collapse;width:100%;background:white}th,td{border:1px solid #d7dde5;padding:7px;text-align:left;vertical-align:top}th{background:#eef2f6}tr:nth-child(even){background:#fafbfc}a{word-break:break-word}.meta{color:#5c6675;margin-bottom:18px}</style>")
[void]$html.AppendLine("</head><body>")
[void]$html.AppendLine("<h1>Field Tech Toolkit Report / Export Index</h1>")
[void]$html.AppendLine('<div class="meta">Generated: ' + [System.Net.WebUtility]::HtmlEncode([string](Get-Date)) + ' | Files indexed: ' + $rows.Count + '</div>')
[void]$html.AppendLine("<p>This index links to files currently stored under the toolkit Logs folder. It does not copy or redact report contents.</p>")
[void]$html.AppendLine("<table><thead><tr><th>Modified</th><th>Size KB</th><th>Type</th><th>Toolkit</th><th>Tool ID</th><th>Schema</th><th>File</th></tr></thead><tbody>")

foreach ($row in $rows) {
    $display = [System.Net.WebUtility]::HtmlEncode($row.RelativePath)
    $href = ($row.RelativePath -split '\\' | ForEach-Object { [uri]::EscapeDataString($_) }) -join "/"
    [void]$html.AppendLine(
        "<tr><td>" + [System.Net.WebUtility]::HtmlEncode([string]$row.Modified) +
        "</td><td>" + [System.Net.WebUtility]::HtmlEncode([string]$row.SizeKB) +
        "</td><td>" + [System.Net.WebUtility]::HtmlEncode([string]$row.Extension) +
        "</td><td>" + [System.Net.WebUtility]::HtmlEncode([string]$row.ToolkitVersion) +
        "</td><td>" + [System.Net.WebUtility]::HtmlEncode([string]$row.ToolId) +
        "</td><td>" + [System.Net.WebUtility]::HtmlEncode([string]$row.ReportSchema) +
        "</td><td><a href=""" + $href + """>" + $display + "</a></td></tr>"
    )
}

[void]$html.AppendLine("</tbody></table>")
[void]$html.AppendLine("</body></html>")
$html.ToString() | Set-Content -LiteralPath $indexHtml -Encoding UTF8

Write-Host ""
Write-Host "Report index complete."
Write-Host ("Indexed files: " + $rows.Count)
Write-Host ("HTML index: " + $indexHtml)
Write-Host ("CSV index: " + $indexCsv)
Write-Host ("Text index: " + $indexTxt)

try { Start-Process -FilePath $indexHtml } catch {}
exit 0

@echo off

start "" "https://www.asus.com/support/"
exit /b 0

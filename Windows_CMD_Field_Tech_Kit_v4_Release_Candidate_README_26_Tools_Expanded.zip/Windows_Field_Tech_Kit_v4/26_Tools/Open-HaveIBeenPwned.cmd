@echo off
start "" "https://haveibeenpwned.com/"
exit /b 0

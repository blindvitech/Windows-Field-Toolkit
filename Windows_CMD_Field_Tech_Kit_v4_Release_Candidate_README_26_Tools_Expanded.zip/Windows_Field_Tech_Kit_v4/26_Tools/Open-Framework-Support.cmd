@echo off

start "" "https://knowledgebase.frame.work/"
exit /b 0

@echo off
start "" "https://www.virustotal.com/gui/home/upload"
exit /b 0

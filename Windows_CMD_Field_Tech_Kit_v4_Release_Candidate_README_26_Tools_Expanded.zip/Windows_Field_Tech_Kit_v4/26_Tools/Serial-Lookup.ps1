$ErrorActionPreference="SilentlyContinue"
$cs=Get-CimInstance Win32_ComputerSystem -ErrorAction SilentlyContinue
$bios=Get-CimInstance Win32_BIOS -ErrorAction SilentlyContinue
$os=Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
$cv=Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion" -ErrorAction SilentlyContinue
[pscustomobject]@{
    Computer=$env:COMPUTERNAME
    Manufacturer=$cs.Manufacturer
    Model=$cs.Model
    Serial=$bios.SerialNumber
    BIOS=$bios.SMBIOSBIOSVersion
    Windows=$(if($os.Caption){$os.Caption}else{$cv.ProductName})
    DisplayVersion=$cv.DisplayVersion
    Build=$os.BuildNumber
}|Format-List
exit 0

@echo off
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Open-Support-Page-For-This-PC.ps1"
exit /b %errorlevel%

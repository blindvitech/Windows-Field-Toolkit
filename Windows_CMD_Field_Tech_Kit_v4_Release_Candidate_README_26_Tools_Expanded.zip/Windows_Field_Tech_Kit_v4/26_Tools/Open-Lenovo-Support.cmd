@echo off

start "" "https://support.lenovo.com/us/en"
exit /b 0

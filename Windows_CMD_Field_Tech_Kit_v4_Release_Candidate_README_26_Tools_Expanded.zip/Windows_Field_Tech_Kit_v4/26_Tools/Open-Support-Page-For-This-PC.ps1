$ErrorActionPreference = "Stop"

try {
    $cs   = Get-CimInstance Win32_ComputerSystem
    $bios = Get-CimInstance Win32_BIOS

    $manufacturer = [string]$cs.Manufacturer
    $model        = [string]$cs.Model
    $serial       = [string]$bios.SerialNumber

    $m = $manufacturer.ToLowerInvariant()
    $oem = $manufacturer
    $url = $null

    if ($m -match 'dell') {
        $oem = 'Dell'
        $url = 'https://www.dell.com/support/home/en-us'
    }
    elseif ($m -match 'hewlett|(^|\s)hp(\s|$)|hp inc') {
        $oem = 'HP'
        $url = 'https://support.hp.com/us-en'
    }
    elseif ($m -match 'lenovo') {
        $oem = 'Lenovo'
        $url = 'https://support.lenovo.com/us/en'
    }
    elseif ($m -match 'asus|asustek') {
        $oem = 'ASUS'
        $url = 'https://www.asus.com/support/'
    }
    elseif ($m -match 'acer') {
        $oem = 'Acer'
        $url = 'https://www.acer.com/us-en/support'
    }
    elseif ($m -match 'micro-star|msi') {
        $oem = 'MSI'
        $url = 'https://www.msi.com/support'
    }
    elseif ($m -match 'microsoft') {
        $oem = 'Microsoft Surface'
        $url = 'https://support.microsoft.com/surface'
    }
    elseif ($m -match 'samsung') {
        $oem = 'Samsung'
        $url = 'https://www.samsung.com/us/support/'
    }
    elseif ($m -match 'gigabyte') {
        $oem = 'Gigabyte'
        $url = 'https://www.gigabyte.com/Support'
    }
    elseif ($m -match 'framework') {
        $oem = 'Framework'
        $url = 'https://knowledgebase.frame.work/'
    }
    else {
        $oem = 'Unknown OEM'
        $query = [uri]::EscapeDataString("$manufacturer $model support")
        $url = "https://www.google.com/search?q=$query"
    }

    # Copy serial/service tag when one is available.
    if (-not [string]::IsNullOrWhiteSpace($serial)) {
        try {
            Set-Clipboard -Value $serial
        }
        catch {
            $serial | clip.exe
        }
    }

    Write-Host ""
    Write-Host "Detected OEM:        $oem"
    Write-Host "Manufacturer:        $manufacturer"
    Write-Host "Model:               $model"
    Write-Host "Serial / Service Tag: $serial"
    Write-Host ""
    Write-Host "Opening support page:"
    Write-Host $url
    Write-Host ""

    Start-Process -FilePath $url

    exit 0
}
catch {
    Write-Host ""
    Write-Host "Unable to open the OEM support page." -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Press any key to return to the toolkit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    exit 1
}

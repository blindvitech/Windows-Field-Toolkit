@echo off
setlocal EnableExtensions
title Toolkit Menu Search

if "%SRMODE%"=="1" (
  echo Toolkit Menu Search.
  echo Search Basic, Advanced, Tools, and Repair by name or keyword.
  echo.
)

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Menu-Search.ps1"
set "RC=%errorlevel%"

if "%SRMODE%"=="1" (
  echo Menu Search finished with return code %RC%.
)
exit /b %RC%

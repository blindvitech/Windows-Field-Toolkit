@echo off

start "" "https://learn.microsoft.com/en-us/windows/release-health/"
exit /b 0

@echo off

start "" "https://support.microsoft.com/surface"
exit /b 0

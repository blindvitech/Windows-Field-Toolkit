@echo off

start "" "https://www.catalog.update.microsoft.com/"
exit /b 0

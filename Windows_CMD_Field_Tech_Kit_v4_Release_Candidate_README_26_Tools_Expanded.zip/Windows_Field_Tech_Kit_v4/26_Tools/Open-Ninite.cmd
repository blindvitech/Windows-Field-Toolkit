@echo off

start "" "https://ninite.com/"
exit /b 0

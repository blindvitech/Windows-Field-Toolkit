@echo off
title PKTMON Stop and Convert - ADMIN
net session >nul 2>&1
if not "%errorlevel%"=="0" (
    echo Administrator privileges required.
    if "%SRMODE%"=="1" (
        echo Press any key to continue.
        pause >nul
    ) else (
        pause
    )
    exit /b 1
)
set "LOGDIR=%~dp0..\Logs"
set "ETL=%LOGDIR%\%COMPUTERNAME%_pktmon_capture.etl"
set "PCAP=%LOGDIR%\%COMPUTERNAME%_pktmon_capture.pcapng"

pktmon stop
if exist "%ETL%" (
    pktmon etl2pcap "%ETL%" --out "%PCAP%"
    echo.
    echo Converted capture:
    echo %PCAP%
) else (
    echo No expected ETL file found:
    echo %ETL%
)
if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)


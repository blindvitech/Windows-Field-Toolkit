$ErrorActionPreference="SilentlyContinue"
$cs=Get-CimInstance Win32_ComputerSystem -ErrorAction SilentlyContinue
$bios=Get-CimInstance Win32_BIOS -ErrorAction SilentlyContinue
$os=Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
$cv=Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion" -ErrorAction SilentlyContinue
$windows=if($os.Caption){$os.Caption}else{$cv.ProductName}
$text=@(
    "Computer: "+$env:COMPUTERNAME,
    "Manufacturer: "+$cs.Manufacturer,
    "Model: "+$cs.Model,
    "Serial/Service Tag: "+$bios.SerialNumber,
    "Windows: "+$windows+" "+$cv.DisplayVersion+" (Build "+$os.BuildNumber+")"
)-join [Environment]::NewLine
try{Set-Clipboard -Value $text -ErrorAction Stop;$copied=$true}catch{$copied=$false}
Write-Host $text
Write-Host ""
if($copied){Write-Host "Machine ID copied to clipboard."}else{Write-Host "Machine ID displayed, but clipboard copy was unavailable."}
exit 0

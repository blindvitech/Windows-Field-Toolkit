param(
    [ValidateSet("Menu","Verify","Rebuild")]
    [string]$Mode = "Menu"
)

$screenReaderCommon = Join-Path (Split-Path $PSScriptRoot -Parent) "00_Common\ScreenReader-Common.ps1"
if (Test-Path -LiteralPath $screenReaderCommon -PathType Leaf) {
    . $screenReaderCommon
}

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

$toolkitRoot = Split-Path $PSScriptRoot -Parent
$logs = Join-Path $toolkitRoot "Logs"
$knownGoodDir = Join-Path $PSScriptRoot "KnownGood"
$archive = Join-Path $knownGoodDir "Toolkit-Core-KnownGood.zip"
$manifestPath = Join-Path $knownGoodDir "Toolkit-Core-Manifest.json"
$archiveHashPath = Join-Path $knownGoodDir "Toolkit-Core-KnownGood.sha256"
$manifestHashPath = Join-Path $knownGoodDir "Toolkit-Core-Manifest.sha256"
$workerRelative = "26_Tools\Toolkit-Known-Good-Rebuild-Worker.ps1"

function Write-Section {
    param([string]$Text)
    Write-Host ""
    Write-Host ("=" * 72)
    Write-Host $Text
    Write-Host ("=" * 72)
}

function Get-SHA256 {
    param([Parameter(Mandatory=$true)][string]$Path)
    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256 -ErrorAction Stop).Hash.ToUpperInvariant()
}

function Load-Manifest {
    if (-not (Test-Path -LiteralPath $manifestPath)) {
        throw "Known-good manifest is missing: $manifestPath"
    }
    $raw = Get-Content -LiteralPath $manifestPath -Raw -ErrorAction Stop
    $manifest = $raw | ConvertFrom-Json -ErrorAction Stop
    if (-not $manifest.Files) {
        throw "Known-good manifest contains no file entries."
    }
    return $manifest
}

function Test-TrustSource {
    $issues = New-Object System.Collections.Generic.List[string]
    foreach ($path in @($archive,$manifestPath,$archiveHashPath,$manifestHashPath)) {
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
            $issues.Add("Missing trust-source file: " + $path)
        }
    }
    if ($issues.Count -gt 0) {
        return [pscustomobject]@{Passed=$false;Issues=$issues;Expected=$null;Actual=$null}
    }

    $expected = (Get-Content -LiteralPath $archiveHashPath -Raw -ErrorAction Stop).Trim().ToUpperInvariant()
    $expectedManifest = (Get-Content -LiteralPath $manifestHashPath -Raw -ErrorAction Stop).Trim().ToUpperInvariant()
    if ($expected -notmatch '^[0-9A-F]{64}$') {
        $issues.Add("Known-good archive checksum file is invalid.")
    }
    if ($expectedManifest -notmatch '^[0-9A-F]{64}$') {
        $issues.Add("Known-good manifest checksum file is invalid.")
    }

    $actual = Get-SHA256 $archive
    $actualManifest = Get-SHA256 $manifestPath
    if ($expected -match '^[0-9A-F]{64}$' -and $actual -ne $expected) {
        $issues.Add("Known-good archive SHA256 does not match its recorded checksum.")
    }
    if ($expectedManifest -match '^[0-9A-F]{64}$' -and $actualManifest -ne $expectedManifest) {
        $issues.Add("Known-good manifest SHA256 does not match its recorded checksum.")
    }

    return [pscustomobject]@{
        Passed = ($issues.Count -eq 0)
        Issues = $issues
        Expected = $expected
        Actual = $actual
        ExpectedManifest = $expectedManifest
        ActualManifest = $actualManifest
    }
}

function Get-LiveIntegrity {
    param($Manifest)

    $rows = New-Object System.Collections.Generic.List[object]
    $known = @{}

    foreach ($entry in $Manifest.Files) {
        $relative = [string]$entry.Path
        $known[$relative.ToLowerInvariant()] = $true
        $livePath = Join-Path $toolkitRoot ($relative -replace '/', [IO.Path]::DirectorySeparatorChar)
        if (-not (Test-Path -LiteralPath $livePath -PathType Leaf)) {
            $rows.Add([pscustomobject]@{
                Status="MISSING";Path=$relative;ExpectedSHA256=$entry.SHA256;ActualSHA256="";Size=$entry.Size
            })
            continue
        }

        try {
            $actual = Get-SHA256 $livePath
            $status = if ($actual -eq ([string]$entry.SHA256).ToUpperInvariant()) { "OK" } else { "MODIFIED" }
            $rows.Add([pscustomobject]@{
                Status=$status;Path=$relative;ExpectedSHA256=$entry.SHA256;ActualSHA256=$actual;Size=(Get-Item -LiteralPath $livePath).Length
            })
        }
        catch {
            $rows.Add([pscustomobject]@{
                Status="UNREADABLE";Path=$relative;ExpectedSHA256=$entry.SHA256;ActualSHA256="";Size=""
            })
        }
    }

    $unexpected = New-Object System.Collections.Generic.List[string]
    $files = Get-ChildItem -LiteralPath $toolkitRoot -File -Recurse -Force -ErrorAction SilentlyContinue
    foreach ($file in $files) {
        $relative = $file.FullName.Substring($toolkitRoot.Length).TrimStart('\') -replace '\\','/'
        if ($relative -like "Logs/*") { continue }
        if ($relative -like "26_Tools/KnownGood/*") { continue }
        if (-not $known.ContainsKey($relative.ToLowerInvariant())) {
            $unexpected.Add($relative)
        }
    }

    return [pscustomobject]@{Rows=$rows;Unexpected=$unexpected}
}

function Save-VerificationReport {
    param($Trust,$Integrity,$Manifest)

    if (-not (Test-Path -LiteralPath $logs)) {
        New-Item -ItemType Directory -Path $logs -Force | Out-Null
    }
    $stamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $path = Join-Path $logs ("TOOLKIT_KNOWN_GOOD_VERIFY_" + $stamp + ".txt")
    $lines = New-Object System.Collections.Generic.List[string]
    $lines.Add("TOOLKIT KNOWN-GOOD INTEGRITY VERIFICATION")
    $lines.Add("Generated: " + (Get-Date))
    $lines.Add("Toolkit root: " + $toolkitRoot)
    $lines.Add("Manifest generated: " + $Manifest.Generated)
    $lines.Add("Known-good archive SHA256 expected: " + $Trust.Expected)
    $lines.Add("Known-good archive SHA256 actual:   " + $Trust.Actual)
    $lines.Add("Known-good manifest SHA256 expected: " + $Trust.ExpectedManifest)
    $lines.Add("Known-good manifest SHA256 actual:   " + $Trust.ActualManifest)
    $lines.Add("Trust source: " + $(if($Trust.Passed){"PASS"}else{"FAIL"}))
    $lines.Add("")
    foreach ($issue in $Trust.Issues) { $lines.Add("TRUST ISSUE: " + $issue) }

    $groups = $Integrity.Rows | Group-Object Status | Sort-Object Name
    foreach ($g in $groups) {
        $lines.Add("")
        $lines.Add($g.Name + ": " + $g.Count)
        foreach ($item in $g.Group) {
            $lines.Add(" - " + $item.Path)
        }
    }

    $lines.Add("")
    $lines.Add("UNEXPECTED FILES: " + $Integrity.Unexpected.Count)
    foreach ($item in $Integrity.Unexpected) { $lines.Add(" - " + $item) }
    $lines.Add("")
    $lines.Add("Unexpected files are reported for awareness only. Rebuild does not delete them.")
    $lines | Set-Content -LiteralPath $path -Encoding UTF8
    return $path
}

function Show-Integrity {
    param($Trust,$Integrity)

    $ok = @($Integrity.Rows | Where-Object Status -eq "OK").Count
    $missing = @($Integrity.Rows | Where-Object Status -eq "MISSING").Count
    $modified = @($Integrity.Rows | Where-Object Status -eq "MODIFIED").Count
    $unreadable = @($Integrity.Rows | Where-Object Status -eq "UNREADABLE").Count

    Write-Section "KNOWN-GOOD VERIFICATION RESULTS"
    Write-Host ("Trust source: " + $(if($Trust.Passed){"PASS"}else{"FAIL"}))
    Write-Host ("Known files OK:       " + $ok)
    Write-Host ("Known files MISSING:  " + $missing)
    Write-Host ("Known files MODIFIED: " + $modified)
    Write-Host ("Known files UNREADABLE: " + $unreadable)
    Write-Host ("Unexpected files:     " + $Integrity.Unexpected.Count)
    Write-Host ""

    foreach ($status in @("MISSING","MODIFIED","UNREADABLE")) {
        $items = @($Integrity.Rows | Where-Object Status -eq $status)
        if ($items.Count -gt 0) {
            Write-Host ($status + ":")
            foreach ($item in $items) { Write-Host ("  " + $item.Path) }
            Write-Host ""
        }
    }

    if ($Integrity.Unexpected.Count -gt 0) {
        Write-Host "UNEXPECTED FILES (preserved; not deleted):"
        foreach ($item in $Integrity.Unexpected) { Write-Host ("  " + $item) }
        Write-Host ""
    }
}

function Invoke-Verify {
    $trust = Test-TrustSource
    if (-not $trust.Passed) {
        Write-Section "KNOWN-GOOD TRUST SOURCE FAILED"
        foreach ($issue in $trust.Issues) { Write-Host $issue }
        Write-Host ""
        Write-Host "Rebuild is disabled until the known-good archive/checksum are restored."
        return 3
    }

    $manifest = Load-Manifest
    $integrity = Get-LiveIntegrity $manifest
    Show-Integrity $trust $integrity
    $report = Save-VerificationReport $trust $integrity $manifest
    Write-Host ("Verification report: " + $report)

    $bad = @($integrity.Rows | Where-Object Status -ne "OK").Count
    if ($bad -eq 0) {
        Write-Host ""
        Write-Host "Known-good core integrity: PASS"
        return 0
    }
    Write-Host ""
    Write-Host ("Known-good core integrity: REVIEW - " + $bad + " known file(s) need restoration.")
    return 1
}

function Invoke-Rebuild {
    $trust = Test-TrustSource
    if (-not $trust.Passed) {
        Write-Section "REBUILD BLOCKED"
        foreach ($issue in $trust.Issues) { Write-Host $issue }
        Write-Host "No toolkit files were changed."
        return 3
    }

    $manifest = Load-Manifest
    $integrity = Get-LiveIntegrity $manifest
    Show-Integrity $trust $integrity
    $affected = @($integrity.Rows | Where-Object Status -ne "OK")

    if ($affected.Count -eq 0) {
        Write-Host "No known toolkit files need restoration. Nothing was changed."
        return 0
    }

    Write-Section "REBUILD IMPACT"
    Write-Host ("Known files to restore: " + $affected.Count)
    Write-Host "Existing affected files will be backed up under Logs before replacement."
    Write-Host "Missing files will be restored from the staged known-good payload."
    Write-Host "Logs, cases, reports, captures, baselines, technician notes, and unexpected files are preserved."
    Write-Host "The staged payload is fully hash-verified before any live file is replaced."
    Write-Host ""
    $answer = Read-ToolkitPrompt "Type REBUILD exactly to continue" -SpellExactPhrase "REBUILD"
    if ($answer -cne "REBUILD") {
        Write-Host "Canceled. No toolkit files were changed."
        return 2
    }

    if (-not (Test-Path -LiteralPath $logs)) {
        New-Item -ItemType Directory -Path $logs -Force | Out-Null
    }

    $tempRoot = Join-Path $env:TEMP ("FieldTechToolkitRebuild_" + [guid]::NewGuid().ToString("N"))
    $stage = Join-Path $tempRoot "Stage"
    New-Item -ItemType Directory -Path $stage -Force | Out-Null

    try {
        Write-Host ""
        Write-Host "Copying trust-source files to temporary staging..."
        $tempArchive = Join-Path $tempRoot "Toolkit-Core-KnownGood.zip"
        $tempManifest = Join-Path $tempRoot "Toolkit-Core-Manifest.json"
        Copy-Item -LiteralPath $archive -Destination $tempArchive -Force
        Copy-Item -LiteralPath $manifestPath -Destination $tempManifest -Force

        if ((Get-SHA256 $tempArchive) -ne $trust.Expected) {
            throw "Temporary copy of known-good archive failed SHA256 verification."
        }

        Write-Host "Extracting known-good core to temporary staging..."
        Expand-Archive -LiteralPath $tempArchive -DestinationPath $stage -Force

        Write-Host "Verifying every staged payload file..."
        $stageFailures = New-Object System.Collections.Generic.List[string]
        foreach ($entry in $manifest.Files) {
            $stagePath = Join-Path $stage (([string]$entry.Path) -replace '/', [IO.Path]::DirectorySeparatorChar)
            if (-not (Test-Path -LiteralPath $stagePath -PathType Leaf)) {
                $stageFailures.Add("Missing staged file: " + $entry.Path)
                continue
            }
            if ((Get-SHA256 $stagePath) -ne ([string]$entry.SHA256).ToUpperInvariant()) {
                $stageFailures.Add("Staged hash mismatch: " + $entry.Path)
            }
        }
        if ($stageFailures.Count -gt 0) {
            foreach ($failure in $stageFailures) { Write-Host $failure }
            throw "Staged known-good payload verification failed. Live toolkit was not changed."
        }

        $worker = Join-Path $stage ($workerRelative -replace '\\', [IO.Path]::DirectorySeparatorChar)
        if (-not (Test-Path -LiteralPath $worker -PathType Leaf)) {
            throw "Staged rebuild worker is missing."
        }

        Write-Host "Staged payload verified. Starting temporary rebuild worker..."
        & powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File $worker `
            -ToolkitRoot $toolkitRoot -StageRoot $stage -ManifestPath $tempManifest
        return $LASTEXITCODE
    }
    catch {
        Write-Host ""
        Write-Host "REBUILD ERROR:"
        Write-Host $_.Exception.Message
        Write-Host "If staging verification failed, no live toolkit files were changed."
        return 4
    }
    finally {
        try { Remove-Item -LiteralPath $tempRoot -Recurse -Force -ErrorAction SilentlyContinue } catch {}
    }
}

if ($Mode -eq "Menu") {
    Write-Section "TOOLKIT KNOWN-GOOD INTEGRITY / REBUILD"
    Write-Host "1. Verify Known-Good State - read-only"
    Write-Host "2. Rebuild From Known-Good - backup, typed confirmation, restore, verify"
    Write-Host "0. Return"
    Write-Host ""
    $choice = Read-ToolkitPrompt "Select an option"
    switch ($choice) {
        "1" { exit (Invoke-Verify) }
        "2" { exit (Invoke-Rebuild) }
        "0" { exit 0 }
        default { Write-Host "Invalid selection."; exit 1 }
    }
}
elseif ($Mode -eq "Verify") {
    exit (Invoke-Verify)
}
else {
    exit (Invoke-Rebuild)
}

@echo off
start "" "https://www.speedtest.net/"
exit /b 0

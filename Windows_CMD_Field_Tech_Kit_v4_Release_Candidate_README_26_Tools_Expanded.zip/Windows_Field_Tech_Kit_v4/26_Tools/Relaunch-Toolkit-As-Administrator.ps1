param(
    [Parameter(Mandatory=$true)]
    [string]$Launcher,

    [string]$ScreenReaderMode = "0"
)

$ErrorActionPreference = "Stop"

try {
    if (-not (Test-Path -LiteralPath $Launcher)) {
        Write-Host "Launcher not found: $Launcher"
        exit 2
    }

    if ($ScreenReaderMode -eq "1") {
        $commandLine = '""' + $Launcher + '" /accessibility"'
    }
    else {
        $commandLine = '""' + $Launcher + '""'
    }

    Start-Process -FilePath $env:ComSpec -ArgumentList @("/d", "/c", $commandLine) -Verb RunAs
    exit 0
}
catch {
    Write-Host "Administrator relaunch was not completed."
    Write-Host $_.Exception.Message
    exit 1
}

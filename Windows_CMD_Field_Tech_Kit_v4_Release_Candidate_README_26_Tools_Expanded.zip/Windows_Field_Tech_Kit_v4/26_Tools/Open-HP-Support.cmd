@echo off

start "" "https://support.hp.com/us-en"
exit /b 0

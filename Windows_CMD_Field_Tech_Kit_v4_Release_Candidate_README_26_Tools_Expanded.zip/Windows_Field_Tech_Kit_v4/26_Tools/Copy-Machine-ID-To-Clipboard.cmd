@echo off
setlocal EnableExtensions
title Copy Machine ID to Clipboard

echo Copy Machine ID to Clipboard
echo.
echo Running dedicated PowerShell collector...
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Copy-Machine-ID-To-Clipboard.ps1"
set "RC=%errorlevel%"

echo.
if "%RC%"=="0" (
    echo Copy Machine ID to Clipboard completed.
) else (
    echo Copy Machine ID to Clipboard returned error code %RC%.
)

if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

exit /b %RC%

@echo off

start "" "https://learn.microsoft.com/en-us/windows/package-manager/winget/"
exit /b 0

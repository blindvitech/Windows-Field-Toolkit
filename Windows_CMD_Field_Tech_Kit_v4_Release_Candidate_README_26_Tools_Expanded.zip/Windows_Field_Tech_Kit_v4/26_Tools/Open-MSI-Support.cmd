@echo off

start "" "https://www.msi.com/support"
exit /b 0

@echo off

start "" "https://www.dell.com/support/home/en-us"
exit /b 0

@echo off
setlocal EnableExtensions
title Toolkit Foundation Health

echo Toolkit Foundation Health
echo.
echo Read-only check of shared runtime context, capabilities, logging, session IDs, and repair markers.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Toolkit-Foundation-Health.ps1"
set "RC=%errorlevel%"

if "%SRMODE%"=="1" (
  echo.
  echo Toolkit Foundation Health finished with return code %RC%.
  echo Press any key to continue.
  pause >nul
) else (
  echo.
  pause
)
exit /b %RC%

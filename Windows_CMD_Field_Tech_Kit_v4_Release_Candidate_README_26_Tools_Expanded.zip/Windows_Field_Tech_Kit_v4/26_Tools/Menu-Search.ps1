$toolkitRoot = Split-Path $PSScriptRoot -Parent

$srCommon = Join-Path $toolkitRoot "00_Common\ScreenReader-Common.ps1"
if (Test-Path -LiteralPath $srCommon -PathType Leaf) { . $srCommon }

$foundation = Join-Path $toolkitRoot "00_Common\Foundation-Common.ps1"
if (Test-Path -LiteralPath $foundation -PathType Leaf) { . $foundation }

function Test-MenuSearchExitChoice {
    param([string]$Value)

    if ($null -eq $Value) { return $true }
    $normalized = $Value.Trim().ToUpperInvariant()
    return $normalized -in @("","0","99","B","BACK","RETURN","Q","QUIT","EXIT","X")
}

$catalog = Get-ToolkitToolCatalog
if (-not $catalog -or -not $catalog.Tools) {
    Write-Host "Tool catalog is missing or invalid."
    exit 2
}

$sharedRunner = Join-Path $toolkitRoot "00_Common\Invoke-Toolkit-MenuTool.ps1"
if (-not (Test-Path -LiteralPath $sharedRunner -PathType Leaf)) {
    Write-Host "Shared toolkit tool runner not found."
    exit 2
}

$entries = @(
    $catalog.Tools |
        Sort-Object Menu,Order |
        ForEach-Object {
            [pscustomobject]@{
                ToolId = [string]$_.ToolId
                Menu = [string]$_.Menu
                Choice = [int]$_.Order
                Label = [string]$_.Label
                RelativePath = ([string]$_.RelativePath -replace '/','\')
                Access = [string]$_.Access
                OperationClass = [string]$_.OperationClass
                Dependencies = @($_.Dependencies)
            }
        }
)

$capabilities = $null
if (Get-Command Get-ToolkitFeatureCapabilities -ErrorAction SilentlyContinue) {
    $capabilities = Get-ToolkitFeatureCapabilities
}

Write-Host "TOOLKIT MENU SEARCH"
Write-Host ("Indexed menu entries: " + $entries.Count)
Write-Host "Searches Basic, Advanced, Tools, and Repair."
Write-Host "Exit / return: 0, 99, B, BACK, RETURN, Q, QUIT, EXIT, X, or Enter."
Write-Host ""

while ($true) {
    $query = (Read-ToolkitPrompt "Search term, or an exit command").Trim()
    if (Test-MenuSearchExitChoice $query) { break }

    $matches = @(
        $entries | Where-Object {
            $_.ToolId -match [regex]::Escape($query) -or
            $_.Label -match [regex]::Escape($query) -or
            $_.Menu -match [regex]::Escape($query) -or
            $_.RelativePath -match [regex]::Escape($query) -or
            (@($_.Dependencies) -join " ") -match [regex]::Escape($query)
        }
    )

    if ($matches.Count -eq 0) {
        Write-Host "No matching toolkit menu entries."
        Write-Host ""
        continue
    }

    if ($matches.Count -gt 30) {
        Write-Host ("Found " + $matches.Count + " matches. Showing the first 30; use a more specific search to narrow the list.")
        $matches = @($matches | Select-Object -First 30)
    }

    if (Get-Command Get-ToolkitFeatureCapabilities -ErrorAction SilentlyContinue) {
        $capabilities = Get-ToolkitFeatureCapabilities
    }

    Write-Host ""
    for ($i=0; $i -lt $matches.Count; $i++) {
        $item = $matches[$i]
        $capText = ""
        if ($capabilities -and (Get-Command Get-ToolkitCapabilityForLabel -ErrorAction SilentlyContinue)) {
            $capText = Get-ToolkitCapabilityForLabel -Label $item.Label -Capabilities $capabilities
        }
        $accessText = $(if ($item.Access) { " [" + $item.Access + "]" } else { "" })
        Write-Host ("{0}. {1} | {2} {3} - {4}{5} {6} [{7}]" -f ($i+1),$item.ToolId,$item.Menu,$item.Choice,$item.Label,$accessText,$capText,$item.OperationClass)
    }
    Write-Host "S. Search again"
    Write-Host "0. Return to the previous toolkit menu"
    Write-Host "99 / B / BACK / RETURN / Q / QUIT / EXIT / X also return."
    Write-Host ""

    $selection = (Read-ToolkitPrompt "Select a result number, S to search again, or 0 to return").Trim()
    if (Test-MenuSearchExitChoice $selection) {
        break
    }
    if ($selection -ieq "S") {
        Write-Host ""
        continue
    }

    $selectedNumber = 0
    if (-not [int]::TryParse($selection,[ref]$selectedNumber) -or $selectedNumber -lt 1 -or $selectedNumber -gt $matches.Count) {
        Write-Host "Invalid selection."
        Write-Host ""
        continue
    }

    $selected = $matches[$selectedNumber-1]
    $cmdPath = Join-Path $toolkitRoot $selected.RelativePath

    & powershell.exe `
        -NoLogo `
        -NoProfile `
        -ExecutionPolicy Bypass `
        -File $sharedRunner `
        -ToolId $selected.ToolId `
        -ToolName $selected.Label `
        -ToolPath $cmdPath `
        -Access $selected.Access `
        -Caller "Search" `
        -EnforceAccess
    $rc = $LASTEXITCODE

    if ($rc -eq 5) {
        Write-Host "Search result was not started because the current toolkit session is not elevated."
    }
    elseif ($rc -ne 0) {
        Write-Host ("Tool returned code " + $rc + ".")
    }

    if (Get-Command Get-ToolkitFeatureCapabilities -ErrorAction SilentlyContinue) {
        $capabilities = Get-ToolkitFeatureCapabilities
        Write-Host "Capability status refreshed after the tool returned."
    }
    Write-Host ""
}

Write-Host "Returning to the previous toolkit menu."
exit 0

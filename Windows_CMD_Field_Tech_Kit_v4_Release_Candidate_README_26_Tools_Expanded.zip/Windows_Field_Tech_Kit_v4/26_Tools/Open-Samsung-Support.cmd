@echo off

start "" "https://www.samsung.com/us/support/"
exit /b 0

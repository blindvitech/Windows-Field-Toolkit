$toolkitRoot = Split-Path $PSScriptRoot -Parent
$foundation = Join-Path $toolkitRoot "00_Common\Foundation-Common.ps1"
if (-not (Test-Path -LiteralPath $foundation -PathType Leaf)) {
    Write-Host "Foundation helper is missing:"
    Write-Host $foundation
    exit 2
}
. $foundation

$toolkitVersion="v4"
$versionPath=Join-Path $toolkitRoot "00_Common\Toolkit-Version.json"
try{$toolkitVersion=[string](Get-Content -LiteralPath $versionPath -Raw -ErrorAction Stop|ConvertFrom-Json -ErrorAction Stop).DisplayVersion}catch{}
$diagnosticHelper=Join-Path $toolkitRoot "00_Common\Diagnostic-Evidence.ps1"
$diagnosticFixtures=Join-Path $toolkitRoot "00_Common\Diagnostic-Fixtures.json"
$diagnosticLogicHealthy=$false
$diagnosticLogicDetails="Not run"
if((Test-Path -LiteralPath $diagnosticHelper -PathType Leaf) -and (Test-Path -LiteralPath $diagnosticFixtures -PathType Leaf)){
    try{
        . $diagnosticHelper
        $fixtureResults=@(Test-ToolkitDiagnosticFixtures -FixturePath $diagnosticFixtures)
        $fixtureFailures=@($fixtureResults|Where-Object{-not $_.Passed})
        $diagnosticLogicHealthy=($fixtureResults.Count -gt 0 -and $fixtureFailures.Count -eq 0)
        $diagnosticLogicDetails=("Fixtures="+$fixtureResults.Count+"; failures="+$fixtureFailures.Count+"; classifier="+(Get-ToolkitDiagnosticClassifierVersion))
    }catch{
        $diagnosticLogicDetails=$_.Exception.Message
    }
}

$context = Initialize-ToolkitRuntimeContext
$interrupted = @(Get-ToolkitInterruptedOperations)

Write-Host "TOOLKIT FOUNDATION HEALTH"
Write-Host ""
Write-Host ("Session ID ............ " + $context.SessionId)
Write-Host ("Toolkit Version ....... " + $toolkitVersion)
Write-Host ("Toolkit Build ......... " + $context.BuildId)
Write-Host ("Computer .............. " + $context.ComputerName)
Write-Host ("Administrator ......... " + $context.Administrator)
Write-Host ("Screen Reader Mode .... " + $context.ScreenReaderMode)
Write-Host ("PowerShell ............ " + $context.PowerShellVersion)
Write-Host ("Architecture .......... " + $context.ProcessArchitecture)
Write-Host ("Windows ............... " + $context.WindowsCaption)
Write-Host ("Build ................. " + $context.WindowsBuild)
Write-Host ("Log Root .............. " + $context.LogRoot)
Write-Host ("Log Fallback Active ... " + $context.LogFallbackActive)
Write-Host ("Pending Reboot ........ " + $context.PendingReboot)
Write-Host ("Active Case ........... " + $(if ($context.CaseId) { $context.CaseId } else { "(none)" }))
if ($context.PendingRebootReasons.Count -gt 0) {
    Write-Host ("Reboot Reasons ........ " + ($context.PendingRebootReasons -join "; "))
}
Write-Host ("WinRE .................. " + $context.WinRE.State)
Write-Host ("BitLocker Volume ...... " + $context.BitLocker.MountPoint)
Write-Host ("BitLocker Status ...... " + $context.BitLocker.VolumeStatus)
Write-Host ("BitLocker Protection .. " + $context.BitLocker.ProtectionStatus)
Write-Host ("Recovery Protector .... " + $(if ($context.BitLocker.RecoveryProtectorPresent -eq $true) { "PRESENT" } elseif ($context.BitLocker.RecoveryProtectorPresent -eq $false) { "NOT DETECTED" } else { "UNKNOWN" }))
Write-Host ("Interrupted Repairs ... " + $interrupted.Count)
$firstRunMarker = Join-Path $context.LogRoot ("FIRST_RUN_VALIDATED_" + $context.BuildId + ".json")
Write-Host ("First-Run Validation .. " + $(if (Test-Path -LiteralPath $firstRunMarker -PathType Leaf) { "RECORDED" } else { "NOT RECORDED" }))
Write-Host ("Compatibility ......... " + $context.Compatibility.Status)
if ($context.Compatibility.Notes.Count -gt 0) {
    Write-Host ("Compatibility Notes ... " + ($context.Compatibility.Notes -join "; "))
}
Write-Host ("Diagnostic Engine ..... " + $(if($diagnosticLogicHealthy){"HEALTHY"}else{"ATTENTION"}))
Write-Host ("Diagnostic Logic ...... " + $diagnosticLogicDetails)
if(Get-Command Get-ToolkitDiagnosticClassifierVersion -ErrorAction SilentlyContinue){
    Write-Host ("Diagnostic Classifier . " + (Get-ToolkitDiagnosticClassifierVersion))
}
$releaseManifestPath=Join-Path $toolkitRoot "Documentation\RELEASE-MANIFEST-v4.txt"
Write-Host ("Release Manifest ...... " + $(if(Test-Path -LiteralPath $releaseManifestPath -PathType Leaf){"PRESENT"}else{"MISSING"}))
$evidenceIndexPath=Join-Path $context.LogRoot "EVIDENCE_CORRELATION_INDEX.json"
$evidenceCorrelationHealth=$null
if(Get-Command Get-ToolkitEvidenceCorrelationHealth -ErrorAction SilentlyContinue){
    try{$evidenceCorrelationHealth=Get-ToolkitEvidenceCorrelationHealth -LogRoot $context.LogRoot}catch{}
}
if($evidenceCorrelationHealth){
    Write-Host ("Evidence Index ........ " + $evidenceCorrelationHealth.Status)
    Write-Host ("Evidence Index Health . " + $(if($evidenceCorrelationHealth.Healthy){"HEALTHY"}else{"ATTENTION"}))
    Write-Host ("Evidence Sidecars ..... " + $evidenceCorrelationHealth.EvidenceSidecarCount)
    if(-not [string]::IsNullOrWhiteSpace([string]$evidenceCorrelationHealth.Detail)){
        Write-Host ("Evidence Index Detail . " + $evidenceCorrelationHealth.Detail)
    }
    if(Test-Path -LiteralPath $evidenceIndexPath -PathType Leaf){
        try{
            $evidenceIndex=Get-Content -LiteralPath $evidenceIndexPath -Raw -ErrorAction Stop|ConvertFrom-Json -ErrorAction Stop
            Write-Host ("Correlated Evidence ... " + $evidenceIndex.CorrelatedEvidenceCount)
        }catch{}
    }
}else{
    Write-Host ("Evidence Index ........ UNKNOWN")
    Write-Host ("Evidence Index Health . ATTENTION")
}

Write-Host ""
Write-Host "CAPABILITIES"
foreach ($capability in $context.Capabilities) {
    Write-Host ("{0,-16} {1,-20} {2}" -f $capability.Type, $capability.Name, $(if ($capability.Available) { "AVAILABLE" } else { "UNAVAILABLE" }))
}

$featureCaps = Get-ToolkitFeatureCapabilities
Write-Host ""
Write-Host "FEATURE / DEVICE STATE"
Write-Host ("WLAN .................. " + $featureCaps.WLAN)
Write-Host ("Battery ............... " + $featureCaps.Battery)
Write-Host ("Defender .............. " + $featureCaps.Defender)
Write-Host ("BitLocker ............. " + $featureCaps.BitLocker)
Write-Host ("WinRE .................. " + $featureCaps.WinRE)
Write-Host ("TPM ................... " + $featureCaps.TPM)
Write-Host ("Secure Boot ........... " + $featureCaps.SecureBoot)
Write-Host ("Hyper-V ............... " + $featureCaps.HyperV)
Write-Host ("Pending Reboot ........ " + $featureCaps.PendingReboot)

$foundationFiles = @(
    "00_Common\Foundation-Common.ps1",
    "00_Common\ScreenReader-Common.ps1",
    "00_Common\Diagnostic-Evidence.ps1",
    "00_Common\Diagnostic-Fixtures.json",
    "00_Common\Toolkit-Version.json",
    "00_Common\Write-TriReport.ps1",
    "Documentation\RELEASE-MANIFEST-v4.txt",
    "FIELD-VALIDATION-STATUS.txt",
    "00_Common\Get-Toolkit-SessionId.ps1",
    "28_Repair\Repair-Common.ps1"
)
Write-Host ""
Write-Host "FOUNDATION FILES"
$missing = 0
foreach ($relative in $foundationFiles) {
    $path = Join-Path $toolkitRoot $relative
    $present = Test-Path -LiteralPath $path -PathType Leaf
    if (-not $present) { $missing++ }
    Write-Host ("{0,-48} {1}" -f $relative, $(if ($present) { "PRESENT" } else { "MISSING" }))
}

$operationLedger = Join-Path $context.LogRoot "OPERATION_LEDGER.jsonl"
$mutationLedger = Join-Path $context.LogRoot "MUTATION_LEDGER.jsonl"
$journal = Join-Path $context.LogRoot "REPAIR_SESSION_JOURNAL.txt"
Write-Host ""
Write-Host ("Repair Journal ......... " + $(if (Test-Path -LiteralPath $journal) { "PRESENT" } else { "Not created yet" }))
Write-Host ("Operation Ledger ....... " + $(if (Test-Path -LiteralPath $operationLedger) { "PRESENT" } else { "Not created yet" }))
Write-Host ("Mutation Ledger ........ " + $(if (Test-Path -LiteralPath $mutationLedger) { "PRESENT" } else { "Not created yet" }))

Write-Host ""

$evidenceHealthOk=$true
if($evidenceCorrelationHealth -and -not $evidenceCorrelationHealth.Healthy){$evidenceHealthOk=$false}
elseif(-not $evidenceCorrelationHealth){$evidenceHealthOk=$false}

if ($missing -eq 0 -and -not $context.LogFallbackActive -and $diagnosticLogicHealthy -and $evidenceHealthOk) {
    Write-Host "Foundation assessment: HEALTHY"

    # Finalize FIELD-VALIDATION-STATUS only when this build has already passed
    # a Full Self-Test on Windows and Foundation Health is healthy.
    try{
        $candidatePath=Join-Path $context.LogRoot ("FIELD_VALIDATION_CANDIDATE_"+$context.BuildId+".json")
        if(Test-Path -LiteralPath $candidatePath -PathType Leaf){
            $candidate=Get-Content -LiteralPath $candidatePath -Raw -ErrorAction Stop|ConvertFrom-Json -ErrorAction Stop
            if([string]$candidate.Status -eq "FULL_SELF_TEST_PASS" -and [string]$candidate.BuildId -eq [string]$context.BuildId){
                $validation=Set-ToolkitFieldValidationStatus -Status "VALIDATED" -BuildId $context.BuildId `
                    -Details "Full Self-Test PASS + Foundation Health HEALTHY on Windows."
                Write-Host ("Field Validation ...... " + $validation.Status + " (" + $validation.BuildId + ")")
            }
        }
    }catch{
        Write-Host ("Field Validation ...... could not update marker: " + $_.Exception.Message)
    }

    exit 0
}
elseif ($missing -eq 0) {
    $reasons=New-Object System.Collections.Generic.List[string]
    if($context.LogFallbackActive){$reasons.Add("log fallback is active")}
    if(-not $diagnosticLogicHealthy){$reasons.Add("diagnostic classifier fixtures did not pass")}
    if(-not $evidenceHealthOk){$reasons.Add("evidence correlation index is stale, missing, unreadable, or health could not be determined")}
    Write-Host ("Foundation assessment: ATTENTION - "+($reasons.ToArray() -join "; ")+".")
    exit 2
}
else {
    Write-Host "Foundation assessment: FAILED - one or more required foundation files are missing."
    exit 1
}

@echo off
setlocal EnableExtensions
title Toolkit Self-Test

echo Toolkit Self-Test
echo.
echo  1. Quick - launcher, foundation, catalog, logging, and basic runtime checks.
echo  2. Full - complete static/native AST/trust checks plus disposable Known-Good extraction simulation.
echo  3. Full, No Simulation - complete checks without the disposable extraction simulation.
echo  4. Diagnostic Logic - sanitized classifier fixtures only; no Windows state changes.
echo  0. Return without running Self-Test.
echo.
set /p "STLEVEL=Select Self-Test level: "
if "%STLEVEL%"=="0" exit /b 0
if "%STLEVEL%"=="1" set "LEVEL=Quick"
if "%STLEVEL%"=="2" set "LEVEL=Full"
if "%STLEVEL%"=="3" set "LEVEL=NoSimulation"
if "%STLEVEL%"=="4" set "LEVEL=DiagnosticLogic"
if not defined LEVEL (
  echo Invalid selection. No test was run.
  exit /b 2
)

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Toolkit-Self-Test.ps1" -ToolkitRoot "%~dp0.." -Level "%LEVEL%"
set "RC=%errorlevel%"

if "%SRMODE%"=="1" (
    echo.
    if "%RC%"=="0" (echo Toolkit self-test passed.) else (echo Toolkit self-test found one or more failures.)
    echo Press any key to continue.
    pause >nul
) else (
    echo.
    pause
)

exit /b %RC%

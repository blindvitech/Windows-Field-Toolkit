$ErrorActionPreference="SilentlyContinue"
$os=Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
$cv=Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion" -ErrorAction SilentlyContinue
[pscustomobject]@{
    Edition=$(if($os.Caption){$os.Caption}else{$cv.ProductName})
    DisplayVersion=$cv.DisplayVersion
    Version=$os.Version
    Build=$os.BuildNumber
    UBR=$cv.UBR
    Architecture=$os.OSArchitecture
    InstallDate=$os.InstallDate
}|Format-List
exit 0

@echo off
setlocal EnableExtensions
title Pending Reboot Check

echo Pending Reboot Check
echo.
echo Running dedicated PowerShell collector...
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Pending-Reboot-Check.ps1"
set "RC=%errorlevel%"

echo.
if "%RC%"=="0" (
    echo Pending Reboot Check completed.
) else (
    echo Pending Reboot Check returned error code %RC%.
)

if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

exit /b %RC%

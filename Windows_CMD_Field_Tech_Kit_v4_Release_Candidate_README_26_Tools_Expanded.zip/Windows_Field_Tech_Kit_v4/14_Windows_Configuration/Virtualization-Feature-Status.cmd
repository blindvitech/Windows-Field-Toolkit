@echo off
setlocal EnableExtensions
title Virtualization and Sandbox Features

echo Virtualization and Sandbox Features
echo.
echo Running dedicated PowerShell collector...
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Virtualization-Feature-Status.ps1"
set "RC=%errorlevel%"

echo.
if "%RC%"=="0" (
    echo Virtualization and Sandbox Features completed.
) else (
    echo Virtualization and Sandbox Features returned error code %RC%.
)

if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

exit /b %RC%

@echo off
setlocal EnableExtensions
title Pagefile Status

echo Pagefile Status
echo.
echo Running dedicated PowerShell collector...
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Pagefile-Status.ps1"
set "RC=%errorlevel%"

echo.
if "%RC%"=="0" (
    echo Pagefile Status completed.
) else (
    echo Pagefile Status returned error code %RC%.
)

if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

exit /b %RC%

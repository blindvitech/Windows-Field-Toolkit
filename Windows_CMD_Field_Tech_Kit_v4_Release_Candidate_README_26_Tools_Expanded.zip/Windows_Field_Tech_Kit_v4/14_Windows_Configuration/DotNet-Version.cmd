@echo off
setlocal EnableExtensions
title .NET Framework Version

echo .NET Framework Version
echo.
echo Running dedicated PowerShell collector...
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0DotNet-Version.ps1"
set "RC=%errorlevel%"

echo.
if "%RC%"=="0" (
    echo .NET Framework Version completed.
) else (
    echo .NET Framework Version returned error code %RC%.
)

if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

exit /b %RC%

$ErrorActionPreference="SilentlyContinue"
$v=Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full" -ErrorAction SilentlyContinue
[pscustomobject]@{Version=$v.Version;Release=$v.Release;Install=$v.Install}|Format-List
exit 0

$ErrorActionPreference="SilentlyContinue"
Get-WindowsOptionalFeature -Online -ErrorAction SilentlyContinue |
    Where-Object FeatureName -match "Hyper-V|VirtualMachinePlatform|Microsoft-Windows-Subsystem-Linux|Containers-DisposableClientVM|WindowsSandbox" |
    Select-Object FeatureName,State |
    Format-Table -AutoSize
exit 0

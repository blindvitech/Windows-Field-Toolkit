@echo off
setlocal EnableExtensions
title Windows Build and Edition

echo Windows Build and Edition
echo.
echo Running dedicated PowerShell collector...
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Windows-Build-Edition.ps1"
set "RC=%errorlevel%"

echo.
if "%RC%"=="0" (
    echo Windows Build and Edition completed.
) else (
    echo Windows Build and Edition returned error code %RC%.
)

if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

exit /b %RC%

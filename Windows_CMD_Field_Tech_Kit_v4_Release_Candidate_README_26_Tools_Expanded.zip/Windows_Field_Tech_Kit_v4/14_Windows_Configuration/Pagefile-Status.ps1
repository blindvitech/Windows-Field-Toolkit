$ErrorActionPreference="SilentlyContinue"
Get-CimInstance Win32_PageFileSetting -ErrorAction SilentlyContinue |
    Format-Table Name,InitialSize,MaximumSize -AutoSize
Write-Host ""
Get-CimInstance Win32_PageFileUsage -ErrorAction SilentlyContinue |
    Format-Table Name,AllocatedBaseSize,CurrentUsage,PeakUsage -AutoSize
exit 0

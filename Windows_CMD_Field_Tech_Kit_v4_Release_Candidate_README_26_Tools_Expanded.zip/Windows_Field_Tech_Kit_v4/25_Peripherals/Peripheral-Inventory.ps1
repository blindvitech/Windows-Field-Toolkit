$ErrorActionPreference = "SilentlyContinue"
$ProgressPreference = "SilentlyContinue"

$toolkitRoot = Split-Path $PSScriptRoot -Parent
$logs = Join-Path $toolkitRoot "Logs"
if (-not (Test-Path -LiteralPath $logs)) {
    New-Item -ItemType Directory -Path $logs -Force | Out-Null
}

$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$basePath = Join-Path $logs ($env:COMPUTERNAME + "_Peripheral_Inventory_" + $stamp)
$writer = Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"

Write-Host "Collecting Peripheral Inventory..."

$body = & {
Write-Output "===== USB DEVICES ====="
Get-PnpDevice -Class USB -ErrorAction SilentlyContinue |
    Select-Object Status,FriendlyName,InstanceId
Write-Output "`n===== MONITORS ====="
Get-CimInstance Win32_DesktopMonitor -ErrorAction SilentlyContinue |
    Select-Object Name,MonitorType,ScreenHeight,ScreenWidth,Status
Write-Output "`n===== AUDIO ====="
Get-PnpDevice -Class AudioEndpoint,MEDIA -ErrorAction SilentlyContinue |
    Select-Object Status,Class,FriendlyName
Write-Output "`n===== BLUETOOTH ====="
Get-PnpDevice -Class Bluetooth -ErrorAction SilentlyContinue |
    Select-Object Status,FriendlyName,InstanceId
Write-Output "`n===== CAMERAS ====="
Get-PnpDevice -Class Camera,Image -ErrorAction SilentlyContinue |
    Select-Object Status,Class,FriendlyName
Write-Output "`n===== COM PORTS ====="
Get-CimInstance Win32_SerialPort -ErrorAction SilentlyContinue |
    Select-Object DeviceID,Name,Description,PNPDeviceID
} | Out-String -Width 240

if (-not (Test-Path -LiteralPath $writer)) {
    Write-Host "Report writer not found:"
    Write-Host $writer
    exit 3
}

& $writer -BasePath $basePath -Title "Peripheral Inventory" -Body $body

$html = $basePath + ".html"
$txt = $basePath + ".txt"
$md = $basePath + ".md"

if (-not (Test-Path -LiteralPath $html) -or -not (Test-Path -LiteralPath $txt) -or -not (Test-Path -LiteralPath $md)) {
    Write-Host ""
    Write-Host "Collection finished, but one or more report files were not created."
    exit 4
}

Write-Host ""
Write-Host "Peripheral Inventory complete."
Write-Host ("HTML: " + $html)
Write-Host ("Text: " + $txt)
Write-Host ("Markdown: " + $md)
exit 0

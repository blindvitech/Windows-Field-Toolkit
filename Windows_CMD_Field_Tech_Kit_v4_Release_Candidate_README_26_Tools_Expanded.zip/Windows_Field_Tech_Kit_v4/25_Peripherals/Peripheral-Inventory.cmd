@echo off
setlocal EnableExtensions
title Peripheral Inventory

echo Peripheral Inventory
echo.
echo Collecting report data. This may take a moment.
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Peripheral-Inventory.ps1"
set "RC=%errorlevel%"

if "%SRMODE%"=="1" (
    echo.
    if "%RC%"=="0" (
        echo Peripheral Inventory completed successfully.
    ) else (
        echo Peripheral Inventory returned error code %RC%.
    )
    echo Press any key to continue.
    pause >nul
) else (
    echo.
    pause
)

exit /b %RC%

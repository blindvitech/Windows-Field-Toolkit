@echo off
setlocal EnableDelayedExpansion
title Installed Apps Snapshot
set "LOGDIR=%~dp0..\Logs"
if not exist "%LOGDIR%" mkdir "%LOGDIR%"
set "LOG=%LOGDIR%\%COMPUTERNAME%_InstalledApps_%RANDOM%.txt"
echo Collecting installed applications...
where winget >nul 2>&1
set "HASWINGET=!errorlevel!"
(
echo INSTALLED APPLICATIONS - %COMPUTERNAME% - %DATE% %TIME%
echo.
if "!HASWINGET!"=="0" (
 echo ===== WINGET LIST =====
 winget list --accept-source-agreements
) else (
 echo Winget not found. Reading uninstall registry keys instead.
 echo.
 echo ===== 64-BIT INSTALLED APPS =====
 reg query "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall" /s /v DisplayName
 echo.
 echo ===== 32-BIT INSTALLED APPS =====
 reg query "HKLM\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall" /s /v DisplayName
)
) > "%LOG%" 2>&1

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\00_Common\Convert-TextReport.ps1" -TextPath "%LOG%" -Title "%~n0"


echo Saved to: %LOG%
if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)
endlocal

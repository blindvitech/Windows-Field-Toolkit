@echo off

setlocal

title Export Windows Event Logs - ADMIN

net session >nul 2>&1

if not "%errorlevel%"=="0" (

 echo Requesting Administrator privileges...
    powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\00_Common\Invoke-Elevated-Self.ps1" -ScriptPath "%~f0"
 exit /b

)

set "OUT=%~dp0..\Logs\%COMPUTERNAME%_EventLogs_%RANDOM%"
mkdir "%OUT%" >nul 2>&1
wevtutil epl System "%OUT%\System.evtx"
wevtutil epl Application "%OUT%\Application.evtx"
wevtutil epl Setup "%OUT%\Setup.evtx"
echo Saved to: %OUT%
if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

endlocal


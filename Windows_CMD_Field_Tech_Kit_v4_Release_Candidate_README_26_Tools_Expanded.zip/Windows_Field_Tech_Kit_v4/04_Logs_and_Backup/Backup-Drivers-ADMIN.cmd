@echo off

setlocal

title Backup Third-Party Drivers - ADMIN

net session >nul 2>&1

if not "%errorlevel%"=="0" (

 echo Requesting Administrator privileges...
    powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\00_Common\Invoke-Elevated-Self.ps1" -ScriptPath "%~f0"
 exit /b

)

set "OUT=%~dp0..\Logs\%COMPUTERNAME%_DriverBackup_%RANDOM%"
mkdir "%OUT%" >nul 2>&1
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\00_Common\Invoke-Native-Bridge.ps1" -FilePath "dism.exe" -Label "DISM Export Drivers" /Online /Export-Driver "/Destination:%OUT%"
echo.
echo Driver backup saved to: %OUT%
if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

endlocal


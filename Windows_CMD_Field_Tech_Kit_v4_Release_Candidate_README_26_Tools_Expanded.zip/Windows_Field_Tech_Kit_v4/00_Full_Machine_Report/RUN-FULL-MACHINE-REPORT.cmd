@echo off
title Full Machine Report

echo ============================================================
echo                 FULL MACHINE REPORT
echo ============================================================
echo.
echo This creates clean HTML, plain-text, and Markdown reports.
echo.
echo Includes:
echo - Windows / licensing / activation state + full product key
echo - BIOS, motherboard, CPU, RAM and graphics
echo - Disks, partitions, storage health and BitLocker
echo - Secure Boot and TPM
echo - Network, IP, DNS, gateway, routes and Wi-Fi
echo - Firewall, proxy and HOSTS file
echo - Local users, administrators, groups and profiles
echo - Domain / Entra join state
echo - Defender status
echo - Installed applications and hotfixes
echo - Services, startup items and scheduled tasks
echo - Printers, SMB shares and mapped drives
echo - Power, battery, pagefile and sleep states
echo - WinRE, boot entry and restore points
echo - Pending reboot state and optional features
echo - Recent critical errors, problem devices and listening ports
echo.
echo It DOES NOT export passwords, Wi-Fi keys, BitLocker recovery
echo passwords, or credential secrets.
echo It DOES show the full Windows product key when recoverable.
echo Run as Administrator for Secure Boot, TPM, WinRE, BCD,
echo restore-point, and optional-feature details.
echo.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Full-Machine-Report.ps1"
set "RC=%errorlevel%"
echo.
if not "%RC%"=="0" (
    echo Full Machine Report exited with error code %RC%.
    if "%SRMODE%"=="1" (
        echo Press any key to continue.
        pause >nul
    ) else (
        pause
    )
)
exit /b %RC%


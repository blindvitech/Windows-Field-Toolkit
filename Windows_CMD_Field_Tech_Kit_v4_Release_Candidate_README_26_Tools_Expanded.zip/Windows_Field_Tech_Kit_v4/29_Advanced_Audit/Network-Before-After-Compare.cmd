@echo off
setlocal EnableExtensions
title Network Before / After Compare

echo Network Before / After Compare
echo.
echo Capture a baseline before network work, then compare it against the after state.
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Network-Before-After-Compare.ps1"
set "RC=%errorlevel%"

if "%SRMODE%"=="1" (
    echo.
    if "%RC%"=="0" (
        echo Network Before / After Compare completed successfully.
    ) else (
        echo Network Before / After Compare returned error code %RC%.
    )
    echo Press any key to continue.
    pause >nul
) else (
    echo.
    pause
)

exit /b %RC%

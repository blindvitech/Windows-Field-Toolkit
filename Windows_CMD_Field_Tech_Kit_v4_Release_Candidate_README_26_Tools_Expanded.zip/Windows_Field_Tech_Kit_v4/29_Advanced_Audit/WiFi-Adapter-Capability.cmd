@echo off
setlocal EnableExtensions
title Wi-Fi Adapter Capability Report

echo Wi-Fi Adapter Capability Report
echo.
echo Collecting report data. This may take a moment.
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0WiFi-Adapter-Capability.ps1"
set "RC=%errorlevel%"

if "%SRMODE%"=="1" (
    echo.
    if "%RC%"=="0" (
        echo Wi-Fi Adapter Capability Report completed successfully.
    ) else (
        echo Wi-Fi Adapter Capability Report returned error code %RC%.
    )
    echo Press any key to continue.
    pause >nul
) else (
    echo.
    pause
)

exit /b %RC%

@echo off
setlocal EnableExtensions
title What Changed - Recent Changes Analyzer
echo What Changed? - Recent Changes Analyzer
echo.
echo Correlates update, driver/device, service, scheduled-task, application,
echo reboot/crash, hotfix, and reliability activity into one timeline.
echo.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Recent-Changes-Timeline.ps1"
set "RC=%errorlevel%"
echo.
if "%SRMODE%"=="1" (
  if "%RC%"=="0" (echo Recent changes analysis completed successfully.) else (echo Recent changes analysis returned error code %RC%.)
  echo Press any key to continue.
  pause >nul
) else (
  pause
)
exit /b %RC%

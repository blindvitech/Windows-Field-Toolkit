$screenReaderCommon = Join-Path (Split-Path $PSScriptRoot -Parent) "00_Common\ScreenReader-Common.ps1"
if (Test-Path -LiteralPath $screenReaderCommon -PathType Leaf) {
    . $screenReaderCommon
}

$ErrorActionPreference = "SilentlyContinue"
$ProgressPreference = "SilentlyContinue"

$toolkitRoot = Split-Path $PSScriptRoot -Parent
$logs = Join-Path $toolkitRoot "Logs"
if (-not (Test-Path -LiteralPath $logs)) {
    New-Item -ItemType Directory -Path $logs -Force | Out-Null
}

Write-Host "WHY DID THIS PC REBOOT?"
Write-Host ""
Write-Host "Choose the lookback period."
Write-Host "1. 7 days"
Write-Host "2. 14 days"
Write-Host "3. 30 days"
Write-Host "4. Custom number of days"
Write-Host ""

$choice = Read-ToolkitPrompt "Select 1 through 4"
$days = 14
switch ($choice) {
    "1" { $days = 7 }
    "2" { $days = 14 }
    "3" { $days = 30 }
    "4" {
        $custom = Read-ToolkitPrompt "Enter the number of days, from 1 through 365"
        if ($custom -match '^\d+$' -and [int]$custom -ge 1 -and [int]$custom -le 365) {
            $days = [int]$custom
        }
        else {
            Write-Host "Invalid custom value. Using 14 days."
        }
    }
    default { Write-Host "Using the default 14-day window." }
}

$start = (Get-Date).AddDays(-$days)
$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$basePath = Join-Path $logs ($env:COMPUTERNAME + "_Why_Did_This_PC_Reboot_" + $days + "days_" + $stamp)
$writer = Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"

function Get-Interpretation {
    param([int]$Id,[string]$Provider)
    switch ($Id) {
        41   { return "Windows detected an unclean shutdown or power loss. This event records the result, not necessarily the original cause." }
        1001 { return "A bugcheck/crash was recorded. Review the event text and dump inventory for the stop code/dump path." }
        1074 { return "A process or user initiated a planned shutdown or restart. The event text usually names the process, user, and reason." }
        1076 { return "A reason was supplied after an unexpected shutdown." }
        6005 { return "Windows Event Log service started; useful as a boot marker." }
        6006 { return "Windows Event Log service stopped cleanly; useful as a normal-shutdown marker." }
        6008 { return "Windows reports the previous shutdown was unexpected." }
        12   { return "Operating system startup marker from Kernel-General." }
        13   { return "Operating system shutdown marker from Kernel-General." }
        default { return "Relevant reboot/shutdown event." }
    }
}

$eventIds = 12,13,41,1001,1074,1076,6005,6006,6008
$rows = New-Object System.Collections.Generic.List[object]

try {
    Get-WinEvent -FilterHashtable @{LogName="System"; StartTime=$start; Id=$eventIds} -ErrorAction Stop |
        ForEach-Object {
            $msg = ($_.Message -replace "[\r\n]+"," " -replace "\s{2,}"," ").Trim()
            if ($msg.Length -gt 800) { $msg = $msg.Substring(0,800) + "..." }
            $rows.Add([pscustomobject]@{
                Time = $_.TimeCreated
                EventId = $_.Id
                Provider = $_.ProviderName
                Interpretation = Get-Interpretation $_.Id $_.ProviderName
                Details = $msg
            })
        }
}
catch {}

$sorted = @($rows | Sort-Object Time -Descending)

$lines = New-Object System.Collections.Generic.List[string]
$lines.Add("WHY DID THIS PC REBOOT?")
$lines.Add("Computer: " + $env:COMPUTERNAME)
$lines.Add("Generated: " + (Get-Date))
$lines.Add("Lookback: " + $days + " days")
$lines.Add("Events collected: " + $sorted.Count)
$lines.Add("")
$lines.Add("Interpretation guide:")
$lines.Add("- Event 1074: planned restart/shutdown initiated by a process or user.")
$lines.Add("- Event 6008 / Kernel-Power 41: unexpected/unclean shutdown indicators.")
$lines.Add("- Event 1001: bugcheck/crash record.")
$lines.Add("- Event 6005/6006 and Kernel-General 12/13: boot/shutdown markers.")
$lines.Add("")
$lines.Add("Important: Kernel-Power 41 and Event 6008 usually show that Windows did not shut down cleanly;")
$lines.Add("they do not by themselves prove whether the root cause was power loss, reset, freeze, crash, or hardware.")
$lines.Add("")
$lines.Add("REBOOT / SHUTDOWN EVENTS")
$lines.Add("=" * 78)

if ($sorted.Count -eq 0) {
    $lines.Add("(No matching reboot/shutdown events were collected.)")
}
else {
    $formatted = $sorted | Format-List Time,EventId,Provider,Interpretation,Details | Out-String -Width 260
    $lines.Add($formatted.TrimEnd())
}

$body = $lines -join [Environment]::NewLine

if (-not (Test-Path -LiteralPath $writer)) {
    Write-Host "Report writer not found:"
    Write-Host $writer
    exit 3
}

& $writer -BasePath $basePath -Title "Why Did This PC Reboot?" -Body $body

$html = $basePath + ".html"
$txt = $basePath + ".txt"
$md = $basePath + ".md"

if (-not (Test-Path -LiteralPath $html) -or -not (Test-Path -LiteralPath $txt) -or -not (Test-Path -LiteralPath $md)) {
    Write-Host "One or more report files were not created."
    exit 4
}

Write-Host ""
Write-Host "Reboot analysis complete."
Write-Host ("HTML: " + $html)
Write-Host ("Text: " + $txt)
Write-Host ("Markdown: " + $md)
try { Start-Process -FilePath $html } catch {}
exit 0

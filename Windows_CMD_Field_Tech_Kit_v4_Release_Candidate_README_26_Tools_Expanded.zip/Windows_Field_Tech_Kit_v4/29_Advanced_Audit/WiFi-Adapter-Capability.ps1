$ErrorActionPreference = "SilentlyContinue"
$ProgressPreference = "SilentlyContinue"

$toolkitRoot = Split-Path $PSScriptRoot -Parent
$foundation = Join-Path $toolkitRoot "00_Common\Foundation-Common.ps1"
if (Test-Path -LiteralPath $foundation -PathType Leaf) { . $foundation }
$logs = Join-Path $toolkitRoot "Logs"
if (-not (Test-Path -LiteralPath $logs)) {
    New-Item -ItemType Directory -Path $logs -Force | Out-Null
}

$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$basePath = Join-Path $logs ($env:COMPUTERNAME + "_WiFi_Adapter_Capability_" + $stamp)
$writer = Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"

$lines = New-Object System.Collections.Generic.List[string]

function Add-Section {
    param([string]$Title, $Data, [string]$Note = "")
    $lines.Add("")
    $lines.Add(("=" * 78))
    $lines.Add($Title)
    $lines.Add(("=" * 78))
    if ($Note) { $lines.Add("NOTE: " + $Note) }

    if ($null -eq $Data) {
        $lines.Add("(No data returned / not applicable)")
        return
    }

    $text = ($Data | Out-String -Width 260).TrimEnd()
    if ([string]::IsNullOrWhiteSpace($text)) {
        $lines.Add("(No data returned / not applicable)")
    }
    else {
        $lines.Add($text)
    }
}

$lines.Add("WI-FI ADAPTER CAPABILITY REPORT")
$lines.Add("Computer: " + $env:COMPUTERNAME)
$lines.Add("Generated: " + (Get-Date))
$lines.Add("")
$lines.Add("This report inventories local wireless adapter capability and driver state.")
$lines.Add("Supported bands/authentication/cipher details are taken from Windows NETSH output when available.")

Write-Host "Collecting Wi-Fi adapter capability information..."

$wirelessAdapters = @(Get-NetAdapter -Physical -ErrorAction SilentlyContinue |
    Where-Object {
        $_.InterfaceDescription -match '(?i)(wireless|wi-fi|wifi|802\.11|wlan)' -or
        $_.Name -match '(?i)(wi-fi|wifi|wlan|wireless)'
    } |
    Select-Object Name,InterfaceDescription,Status,LinkSpeed,MacAddress,DriverInformation,DriverFileName,DriverVersion)

if ($wirelessAdapters.Count -eq 0) {
    $wirelessAdapters = @(Get-NetAdapter -ErrorAction SilentlyContinue |
        Where-Object {
            $_.InterfaceDescription -match '(?i)(wireless|wi-fi|wifi|802\.11|wlan)' -or
            $_.Name -match '(?i)(wi-fi|wifi|wlan|wireless)'
        } |
        Select-Object Name,InterfaceDescription,Status,LinkSpeed,MacAddress,DriverInformation,DriverFileName,DriverVersion)
}
Add-Section "WIRELESS NETWORK ADAPTERS" $wirelessAdapters

$pnpDrivers = @(Get-CimInstance Win32_PnPSignedDriver -ErrorAction SilentlyContinue |
    Where-Object {
        $_.DeviceClass -eq "NET" -and
        ($_.DeviceName -match '(?i)(wireless|wi-fi|wifi|802\.11|wlan)' -or $_.Description -match '(?i)(wireless|wi-fi|wifi|802\.11|wlan)')
    } |
    Select-Object DeviceName,Description,Manufacturer,DriverProviderName,DriverVersion,DriverDate,InfName,IsSigned,Signer)
Add-Section "SIGNED DRIVER INVENTORY" $pnpDrivers

$wifiSanity = New-Object System.Collections.Generic.List[string]
foreach ($driver in $pnpDrivers) {
    $driverDate = $null
    try { $driverDate = [datetime]$driver.DriverDate } catch {}
    if ($driverDate -and $driverDate -lt (Get-Date).AddYears(-5)) {
        $wifiSanity.Add($driver.DeviceName + ": driver is older than five years (" + $driverDate.ToShortDateString() + "). Verify OEM support before updating.")
    }
    if ($driver.IsSigned -eq $false) {
        $wifiSanity.Add($driver.DeviceName + ": signed-driver inventory reports IsSigned=False.")
    }
}
foreach ($adapter in $wirelessAdapters) {
    if ($adapter.Status -eq "Disabled") { $wifiSanity.Add($adapter.Name + ": wireless adapter is disabled.") }
}

$wifiStats = @()
try {
    $wifiStats = @(Get-NetAdapterStatistics -ErrorAction Stop |
        Where-Object { $_.Name -in @($wirelessAdapters | Select-Object -ExpandProperty Name) } |
        Select-Object Name,ReceivedBytes,SentBytes,ReceivedDiscardedPackets,OutboundDiscardedPackets,ReceivedPacketErrors,OutboundPacketErrors)
    foreach ($s in $wifiStats) {
        $errors = 0
        try { $errors = [int64]$s.ReceivedPacketErrors + [int64]$s.OutboundPacketErrors } catch {}
        if ($errors -gt 0) { $wifiSanity.Add($s.Name + ": packet errors are non-zero (" + $errors + ").") }
    }
}
catch {}
Add-Section "WIRELESS ADAPTER STATISTICS" $wifiStats

$wifiPower = New-Object System.Collections.Generic.List[object]
foreach ($adapter in $wirelessAdapters) {
    try {
        $pm = Get-NetAdapterPowerManagement -Name $adapter.Name -ErrorAction Stop
        $wifiPower.Add([pscustomobject]@{
            Name=$adapter.Name
            AllowComputerToTurnOffDevice=$pm.AllowComputerToTurnOffDevice
            WakeOnMagicPacket=$pm.WakeOnMagicPacket
            WakeOnPattern=$pm.WakeOnPattern
        })
    } catch {}
}
Add-Section "WIRELESS POWER MANAGEMENT" $(if($wifiPower.Count -gt 0){$wifiPower.ToArray()}else{$null}) `
    "Power-management options vary by vendor driver. This section reports state only and does not change it."

Add-Section "WIRELESS ADAPTER SANITY FINDINGS" $(if($wifiSanity.Count -gt 0){$wifiSanity.ToArray()}else{@("No adapter sanity finding was triggered by the exposed Windows data.")}) `
    "Old drivers are review signals, not automatic update recommendations; OEM-supported versions may intentionally be older."

$advanced = @()
foreach ($adapter in $wirelessAdapters) {
    try {
        $advanced += Get-NetAdapterAdvancedProperty -Name $adapter.Name -ErrorAction Stop |
            Select-Object Name,DisplayName,DisplayValue,RegistryKeyword,RegistryValue
    }
    catch {}
}
Add-Section "ADAPTER ADVANCED PROPERTIES" $advanced `
    "Vendor drivers expose different property names; blank or missing items do not necessarily indicate a problem."

$netshDriversNative = Invoke-ToolkitNativeCommand -FilePath "netsh.exe" -Arguments @("wlan","show","drivers") -Label "WiFi Capability WLAN Drivers" -Action "WiFi Adapter Capability" -Quiet
$netshDrivers = (($netshDriversNative.Output -join [Environment]::NewLine) | Out-String -Width 260).TrimEnd()
Add-Section "NETSH WLAN SHOW DRIVERS" $netshDrivers `
    "This is the primary Windows capability view for supported radio types and authentication/cipher combinations."

$netshInterfacesNative = Invoke-ToolkitNativeCommand -FilePath "netsh.exe" -Arguments @("wlan","show","interfaces") -Label "WiFi Capability WLAN Interfaces" -Action "WiFi Adapter Capability" -Quiet
$netshInterfaces = (($netshInterfacesNative.Output -join [Environment]::NewLine) | Out-String -Width 260).TrimEnd()
Add-Section "CURRENT WLAN INTERFACE STATE" $netshInterfaces

$wlanService = Get-Service WlanSvc -ErrorAction SilentlyContinue |
    Select-Object Name,Status,StartType
Add-Section "WLAN AUTOCONFIG SERVICE" $wlanService

$body = $lines -join [Environment]::NewLine

if (-not (Test-Path -LiteralPath $writer)) {
    Write-Host "Report writer not found:"
    Write-Host $writer
    exit 3
}

& $writer -BasePath $basePath -Title "Wi-Fi Adapter Capability Report" -Body $body

$html = $basePath + ".html"
$txt = $basePath + ".txt"
$md = $basePath + ".md"

if (-not (Test-Path -LiteralPath $html) -or -not (Test-Path -LiteralPath $txt) -or -not (Test-Path -LiteralPath $md)) {
    Write-Host "One or more report files were not created."
    exit 4
}

Write-Host ""
Write-Host "Wi-Fi Adapter Capability Report complete."
Write-Host ("HTML: " + $html)
Write-Host ("Text: " + $txt)
Write-Host ("Markdown: " + $md)
try { Start-Process -FilePath $html } catch {}
exit 0

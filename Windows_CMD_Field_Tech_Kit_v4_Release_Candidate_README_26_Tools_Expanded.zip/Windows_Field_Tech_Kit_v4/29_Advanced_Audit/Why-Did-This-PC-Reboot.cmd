@echo off
setlocal EnableExtensions
title Why Did This PC Reboot?

echo Why Did This PC Reboot?
echo.
echo Collecting report data. This may take a moment.
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Why-Did-This-PC-Reboot.ps1"
set "RC=%errorlevel%"

if "%SRMODE%"=="1" (
    echo.
    if "%RC%"=="0" (
        echo Why Did This PC Reboot? completed successfully.
    ) else (
        echo Why Did This PC Reboot? returned error code %RC%.
    )
    echo Press any key to continue.
    pause >nul
) else (
    echo.
    pause
)

exit /b %RC%

$screenReaderCommon = Join-Path (Split-Path $PSScriptRoot -Parent) "00_Common\ScreenReader-Common.ps1"
if (Test-Path -LiteralPath $screenReaderCommon -PathType Leaf) { . $screenReaderCommon }

$ErrorActionPreference="SilentlyContinue"
$ProgressPreference="SilentlyContinue"
$toolkitRoot=Split-Path $PSScriptRoot -Parent
$logs=Join-Path $toolkitRoot "Logs"
if(-not(Test-Path -LiteralPath $logs)){New-Item -ItemType Directory -Path $logs -Force|Out-Null}
$writer=Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"

Write-Host "WHAT CHANGED? - RECENT CHANGES ANALYZER"
Write-Host "1. 24 hours"
Write-Host "2. 7 days"
Write-Host "3. 14 days"
Write-Host "4. 30 days"
Write-Host "5. Custom, 1 through 365 days"
$choice=Read-ToolkitPrompt "Select 1 through 5"
$days=7
switch($choice){
 "1"{$days=1}
 "2"{$days=7}
 "3"{$days=14}
 "4"{$days=30}
 "5"{
   $custom=Read-ToolkitPrompt "Enter days, 1 through 365"
   if($custom -match '^\d+$' -and [int]$custom -ge 1 -and [int]$custom -le 365){$days=[int]$custom}
 }
 default{$days=7}
}
$start=(Get-Date).AddDays(-$days)
$basePath=Join-Path $logs ($env:COMPUTERNAME+"_What_Changed_"+$days+"days_"+(Get-Date -Format "yyyyMMdd_HHmmss"))
$csvPath=$basePath+".csv"

$rows=New-Object System.Collections.Generic.List[object]
function Add-Change {
 param([datetime]$Time,[string]$Category,[string]$Source,[string]$Id,[string]$Summary)
 if(-not $Time -or $Time -lt $start){return}
 $clean=($Summary -replace "[\r\n]+"," " -replace "\s{2,}"," ").Trim()
 if($clean.Length -gt 700){$clean=$clean.Substring(0,700)+"..."}
 $rows.Add([pscustomobject]@{Timestamp=$Time;Category=$Category;Source=$Source;EventId=$Id;Summary=$clean})
}

Write-Host ("Collecting changes from the last "+$days+" day(s)...")

# Boot, shutdown, crash, service installation/configuration, and hardware errors.
try{
 Get-WinEvent -FilterHashtable @{LogName="System";StartTime=$start} -MaxEvents 2000 -ErrorAction Stop |
 Where-Object {
   $_.Id -in 12,13,41,1001,1074,1076,6005,6006,6008,7040,7045 -or
   $_.ProviderName -match '(?i)WHEA'
 } | ForEach-Object {
   $cat="System / reboot"
   if($_.Id -in 41,6008){$cat="Unexpected shutdown / power"}
   elseif($_.Id -eq 1001){$cat="Bugcheck / crash"}
   elseif($_.Id -eq 7040){$cat="Service start-type change"}
   elseif($_.Id -eq 7045){$cat="Service installed"}
   elseif($_.ProviderName -match '(?i)WHEA'){$cat="Hardware / WHEA"}
   Add-Change $_.TimeCreated $cat $_.ProviderName ([string]$_.Id) $_.Message
 }
}catch{}

# Windows Update.
try{
 Get-WinEvent -FilterHashtable @{LogName="Microsoft-Windows-WindowsUpdateClient/Operational";StartTime=$start} -MaxEvents 1000 -ErrorAction Stop |
 Where-Object{$_.Id -in 19,20,21,25,31,34,41,43,44} |
 ForEach-Object{Add-Change $_.TimeCreated "Windows Update" $_.ProviderName ([string]$_.Id) $_.Message}
}catch{}

# MSI application activity.
try{
 Get-WinEvent -FilterHashtable @{LogName="Application";ProviderName="MsiInstaller";StartTime=$start} -MaxEvents 1000 -ErrorAction Stop |
 Where-Object{$_.Id -in 1033,1034,11707,11708,11724,11725} |
 ForEach-Object{Add-Change $_.TimeCreated "Application install / removal" $_.ProviderName ([string]$_.Id) $_.Message}
}catch{}

# Device and driver setup.
foreach($logName in @(
 "Microsoft-Windows-DeviceSetupManager/Admin",
 "Microsoft-Windows-UserPnp/DeviceInstall",
 "Microsoft-Windows-Kernel-PnP/Configuration"
)){
 try{
   Get-WinEvent -FilterHashtable @{LogName=$logName;StartTime=$start} -MaxEvents 500 -ErrorAction Stop |
   ForEach-Object{Add-Change $_.TimeCreated "Device / driver change" $_.ProviderName ([string]$_.Id) $_.Message}
 }catch{}
}

# Scheduled task registration/update/removal.
try{
 Get-WinEvent -FilterHashtable @{LogName="Microsoft-Windows-TaskScheduler/Operational";StartTime=$start} -MaxEvents 800 -ErrorAction Stop |
 Where-Object{$_.Id -in 106,140,141,142} |
 ForEach-Object{Add-Change $_.TimeCreated "Scheduled task change" $_.ProviderName ([string]$_.Id) $_.Message}
}catch{}

# Reliability records catch application failures, hardware failures, update failures.
try{
 Get-CimInstance Win32_ReliabilityRecords -ErrorAction Stop |
 Where-Object{$_.TimeGenerated -ge $start} |
 Select-Object -First 700 |
 ForEach-Object{Add-Change $_.TimeGenerated "Reliability record" $_.SourceName ([string]$_.EventIdentifier) ($_.ProductName+" | "+$_.Message)}
}catch{}

# Hotfix installation dates.
try{
 Get-CimInstance Win32_QuickFixEngineering -ErrorAction Stop | ForEach-Object{
   $dt=$null;try{$dt=[datetime]$_.InstalledOn}catch{}
   if($dt -and $dt -ge $start){Add-Change $dt "Installed hotfix" "Win32_QuickFixEngineering" $_.HotFixID ($_.HotFixID+" | "+$_.Description+" | InstalledBy="+$_.InstalledBy)}
 }
}catch{}

# Uninstall registry install dates.
$uninstallPaths=@(
 "HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*",
 "HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*",
 "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*"
)
try{
 Get-ItemProperty $uninstallPaths -ErrorAction SilentlyContinue | Where-Object{$_.DisplayName -and $_.InstallDate} | ForEach-Object{
   $raw=[string]$_.InstallDate;$dt=$null
   if($raw -match '^\d{8}$'){try{$dt=[datetime]::ParseExact($raw,"yyyyMMdd",$null)}catch{}}
   elseif($raw -match '^\d{4}-\d{2}-\d{2}'){try{$dt=[datetime]$raw}catch{}}
   if($dt -and $dt -ge $start){Add-Change $dt "Application install record" "Uninstall registry" "" ($_.DisplayName+" "+$_.DisplayVersion+" | Publisher="+$_.Publisher)}
 }
}catch{}

$sorted=@($rows|Sort-Object Timestamp -Descending)
if($sorted.Count -gt 0){$sorted|Export-Csv -LiteralPath $csvPath -NoTypeInformation -Encoding UTF8}
else{"Timestamp,Category,Source,EventId,Summary"|Set-Content -LiteralPath $csvPath -Encoding UTF8}

$summary=@($sorted|Group-Object Category|Sort-Object Count -Descending|Select-Object Name,Count)
$last24=@($sorted|Where-Object{$_.Timestamp -ge (Get-Date).AddHours(-24)}|Select-Object -First 50)

# Current startup/service/task state is context, not proof of when it changed.
$startup=@()
try{$startup=@(Get-CimInstance Win32_StartupCommand -ErrorAction Stop|Select-Object Name,Command,Location,User)}catch{}
$autoServices=@()
try{$autoServices=@(Get-CimInstance Win32_Service -ErrorAction Stop|Where-Object{$_.StartMode -eq "Auto"}|Select-Object Name,DisplayName,State,StartMode,PathName)}catch{}
$recentTasks=@()
try{
 $recentTasks=@(Get-ScheduledTask -ErrorAction Stop|ForEach-Object{
   $info=$null;try{$info=$_|Get-ScheduledTaskInfo -ErrorAction Stop}catch{}
   if($info -and $info.LastRunTime -ge $start){
     [pscustomobject]@{TaskPath=$_.TaskPath;TaskName=$_.TaskName;State=$_.State;LastRunTime=$info.LastRunTime;LastTaskResult=$info.LastTaskResult}
   }
 }|Sort-Object LastRunTime -Descending|Select-Object -First 100)
}catch{}

$lines=New-Object System.Collections.Generic.List[string]
function Add-Section([string]$Title,$Data,[string]$Note=""){
 $lines.Add("");$lines.Add(("="*78));$lines.Add($Title);$lines.Add(("="*78));if($Note){$lines.Add("NOTE: "+$Note)}
 $x=($Data|Out-String -Width 280).TrimEnd();if($x){$lines.Add($x)}else{$lines.Add("(No data returned / no matching entries.)")}
}
$lines.Add("WHAT CHANGED? - RECENT CHANGES ANALYZER")
$lines.Add("Computer: "+$env:COMPUTERNAME);$lines.Add("Generated: "+(Get-Date));$lines.Add("Lookback: "+$days+" day(s)");$lines.Add("Entries: "+$sorted.Count)
$lines.Add("")
$lines.Add("This is a troubleshooting change timeline, not a forensic guarantee. Some Windows configuration sources do not preserve a reliable change timestamp.")
Add-Section "CHANGE COUNTS BY CATEGORY" $summary
Add-Section "MOST RECENT 24 HOURS" $last24
Add-Section "FULL CHANGE TIMELINE" $sorted
Add-Section "CURRENT STARTUP ITEMS - CONTEXT" $startup "Current state only; this section does not assert when an item was added."
Add-Section "CURRENT AUTOMATIC SERVICES - CONTEXT" $autoServices "Use Service Control Manager event 7040/7045 rows above when a timestamped service change is available."
Add-Section "SCHEDULED TASKS RUN DURING LOOKBACK - CONTEXT" $recentTasks

& $writer -BasePath $basePath -Title "What Changed? Recent Changes Analyzer" -Body ($lines -join [Environment]::NewLine)
$html=$basePath+".html";Write-Host("Entries: "+$sorted.Count);Write-Host("Report: "+$html);Write-Host("CSV: "+$csvPath)
try{Start-Process -FilePath $html}catch{}
exit 0

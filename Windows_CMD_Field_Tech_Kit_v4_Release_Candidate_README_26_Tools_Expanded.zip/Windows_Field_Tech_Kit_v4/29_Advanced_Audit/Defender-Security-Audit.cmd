@echo off
setlocal EnableExtensions
title Microsoft Defender Security Audit

echo Microsoft Defender Security Audit
echo.
echo Collecting report data. This may take a moment.
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Defender-Security-Audit.ps1"
set "RC=%errorlevel%"

if "%SRMODE%"=="1" (
    echo.
    if "%RC%"=="0" (
        echo Microsoft Defender Security Audit completed successfully.
    ) else (
        echo Microsoft Defender Security Audit returned error code %RC%.
    )
    echo Press any key to continue.
    pause >nul
) else (
    echo.
    pause
)

exit /b %RC%

$ErrorActionPreference = "SilentlyContinue"
$ProgressPreference = "SilentlyContinue"

$toolkitRoot = Split-Path $PSScriptRoot -Parent
$logs = Join-Path $toolkitRoot "Logs"
if (-not (Test-Path -LiteralPath $logs)) {
    New-Item -ItemType Directory -Path $logs -Force | Out-Null
}

$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$basePath = Join-Path $logs ($env:COMPUTERNAME + "_Defender_Security_Audit_" + $stamp)
$writer = Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"

$isAdmin = $false
try {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    $isAdmin = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}
catch {}

$lines = New-Object System.Collections.Generic.List[string]

function Add-Section {
    param(
        [string]$Title,
        $Data,
        [string]$Note = ""
    )

    $lines.Add("")
    $lines.Add(("=" * 78))
    $lines.Add($Title)
    $lines.Add(("=" * 78))
    if ($Note) { $lines.Add("NOTE: " + $Note) }

    if ($null -eq $Data) {
        $lines.Add("(No data returned / not applicable)")
        return
    }

    $text = ($Data | Out-String -Width 260).TrimEnd()
    if ([string]::IsNullOrWhiteSpace($text)) {
        $lines.Add("(No data returned / not applicable)")
    }
    else {
        $lines.Add($text)
    }
}

$lines.Add("MICROSOFT DEFENDER SECURITY AUDIT")
$lines.Add("Computer: " + $env:COMPUTERNAME)
$lines.Add("Generated: " + (Get-Date))
$lines.Add("User: " + $env:USERDOMAIN + "\" + $env:USERNAME)
$lines.Add("Running as Administrator: " + $isAdmin)
$lines.Add("")
$lines.Add("This tool is read-only. It does not change Defender settings, exclusions, or threat state.")

Write-Host "Collecting Microsoft Defender security audit..."

$mpStatusCmd = Get-Command Get-MpComputerStatus -ErrorAction SilentlyContinue
$mpPrefCmd = Get-Command Get-MpPreference -ErrorAction SilentlyContinue

if (-not $mpStatusCmd -or -not $mpPrefCmd) {
    Add-Section "DEFENDER AVAILABILITY" ([pscustomobject]@{
        DefenderCmdletsAvailable = $false
        GetMpComputerStatus = [bool]$mpStatusCmd
        GetMpPreference = [bool]$mpPrefCmd
        Note = "Microsoft Defender cmdlets are unavailable in this session. A third-party AV product, removed Defender components, or Windows edition/configuration may explain this."
    })

    $body = $lines -join [Environment]::NewLine
    & $writer -BasePath $basePath -Title "Microsoft Defender Security Audit" -Body $body
    exit 0
}

$status = Get-MpComputerStatus -ErrorAction SilentlyContinue
$pref = Get-MpPreference -ErrorAction SilentlyContinue

if ($status) {
    $statusSummary = [pscustomobject]@{
        AMServiceEnabled = $status.AMServiceEnabled
        AntivirusEnabled = $status.AntivirusEnabled
        AntispywareEnabled = $status.AntispywareEnabled
        RealTimeProtectionEnabled = $status.RealTimeProtectionEnabled
        BehaviorMonitorEnabled = $status.BehaviorMonitorEnabled
        IoavProtectionEnabled = $status.IoavProtectionEnabled
        NISEnabled = $status.NISEnabled
        OnAccessProtectionEnabled = $status.OnAccessProtectionEnabled
        IsTamperProtected = $status.IsTamperProtected
        DefenderSignaturesOutOfDate = $status.DefenderSignaturesOutOfDate
        AntivirusSignatureVersion = $status.AntivirusSignatureVersion
        AntivirusSignatureLastUpdated = $status.AntivirusSignatureLastUpdated
        AntispywareSignatureVersion = $status.AntispywareSignatureVersion
        AntispywareSignatureLastUpdated = $status.AntispywareSignatureLastUpdated
        NISSignatureVersion = $status.NISSignatureVersion
        NISSignatureLastUpdated = $status.NISSignatureLastUpdated
        AMEngineVersion = $status.AMEngineVersion
        AMProductVersion = $status.AMProductVersion
        QuickScanAge = $status.QuickScanAge
        FullScanAge = $status.FullScanAge
        QuickScanEndTime = $status.QuickScanEndTime
        FullScanEndTime = $status.FullScanEndTime
        RebootRequired = $status.RebootRequired
    }
    Add-Section "DEFENDER STATUS / HEALTH" $statusSummary
}

$svc = Get-Service WinDefend -ErrorAction SilentlyContinue |
    Select-Object Name,Status,StartType
Add-Section "DEFENDER SERVICE" $svc

if ($pref) {
    $policy = [pscustomobject]@{
        MAPSReporting = $pref.MAPSReporting
        SubmitSamplesConsent = $pref.SubmitSamplesConsent
        PUAProtection = $pref.PUAProtection
        EnableControlledFolderAccess = $pref.EnableControlledFolderAccess
        EnableNetworkProtection = $pref.EnableNetworkProtection
        DisableRealtimeMonitoring = $pref.DisableRealtimeMonitoring
        DisableBehaviorMonitoring = $pref.DisableBehaviorMonitoring
        DisableIOAVProtection = $pref.DisableIOAVProtection
        DisableScriptScanning = $pref.DisableScriptScanning
        DisableArchiveScanning = $pref.DisableArchiveScanning
        DisableRemovableDriveScanning = $pref.DisableRemovableDriveScanning
        DisableEmailScanning = $pref.DisableEmailScanning
        CloudBlockLevel = $pref.CloudBlockLevel
        CloudExtendedTimeout = $pref.CloudExtendedTimeout
        SignatureDisableUpdateOnStartupWithoutEngine = $pref.SignatureDisableUpdateOnStartupWithoutEngine
        SignatureScheduleDay = $pref.SignatureScheduleDay
        SignatureUpdateInterval = $pref.SignatureUpdateInterval
        ScanScheduleDay = $pref.ScanScheduleDay
        ScanScheduleTime = $pref.ScanScheduleTime
    }
    Add-Section "PROTECTION / CLOUD / SCAN POLICY" $policy

    $exclusions = New-Object System.Collections.Generic.List[object]
    foreach ($x in @($pref.ExclusionPath)) {
        if ($x) { $exclusions.Add([pscustomobject]@{Type="Path";Value=$x}) }
    }
    foreach ($x in @($pref.ExclusionProcess)) {
        if ($x) { $exclusions.Add([pscustomobject]@{Type="Process";Value=$x}) }
    }
    foreach ($x in @($pref.ExclusionExtension)) {
        if ($x) { $exclusions.Add([pscustomobject]@{Type="Extension";Value=$x}) }
    }
    foreach ($x in @($pref.ExclusionIpAddress)) {
        if ($x) { $exclusions.Add([pscustomobject]@{Type="IP Address";Value=$x}) }
    }

    if ($exclusions.Count -eq 0) {
        Add-Section "DEFENDER EXCLUSIONS" ([pscustomobject]@{Status="No configured exclusions returned"})
    }
    else {
        Add-Section "DEFENDER EXCLUSIONS" $exclusions `
            "Exclusions can materially reduce protection. Review unexpected entries carefully."
    }

    $asrIds = @($pref.AttackSurfaceReductionRules_Ids)
    $asrActions = @($pref.AttackSurfaceReductionRules_Actions)
    $asrRows = New-Object System.Collections.Generic.List[object]
    for ($i=0; $i -lt $asrIds.Count; $i++) {
        $action = ""
        if ($i -lt $asrActions.Count) { $action = $asrActions[$i] }
        $asrRows.Add([pscustomobject]@{
            RuleId = $asrIds[$i]
            Action = $action
        })
    }

    if ($asrRows.Count -eq 0) {
        Add-Section "ATTACK SURFACE REDUCTION RULES" ([pscustomobject]@{Status="No ASR rules returned"})
    }
    else {
        Add-Section "ATTACK SURFACE REDUCTION RULES" $asrRows
    }

    $cfaFolders = @($pref.ControlledFolderAccessProtectedFolders)
    if ($cfaFolders.Count -gt 0) {
        Add-Section "CONTROLLED FOLDER ACCESS PROTECTED FOLDERS" $cfaFolders
    }
}

$threats = @()
if (Get-Command Get-MpThreat -ErrorAction SilentlyContinue) {
    $threats = @(Get-MpThreat -ErrorAction SilentlyContinue |
        Select-Object ThreatID,ThreatName,SeverityID,CategoryID,DidThreatExecute,IsActive,Resources)
}
if ($threats.Count -eq 0) {
    Add-Section "CURRENT / KNOWN THREATS" ([pscustomobject]@{Status="No threat objects returned"})
}
else {
    Add-Section "CURRENT / KNOWN THREATS" $threats
}

$detections = @()
if (Get-Command Get-MpThreatDetection -ErrorAction SilentlyContinue) {
    $detections = @(Get-MpThreatDetection -ErrorAction SilentlyContinue |
        Sort-Object InitialDetectionTime -Descending |
        Select-Object -First 100 ThreatID,ThreatStatusID,InitialDetectionTime,LastThreatStatusChangeTime,ActionSuccess,Resources)
}
if ($detections.Count -eq 0) {
    Add-Section "RECENT THREAT DETECTIONS" ([pscustomobject]@{Status="No threat detections returned"})
}
else {
    Add-Section "RECENT THREAT DETECTIONS" $detections
}

$events = @()
try {
    $events = @(Get-WinEvent -FilterHashtable @{
        LogName="Microsoft-Windows-Windows Defender/Operational"
        StartTime=(Get-Date).AddDays(-14)
    } -ErrorAction Stop |
    Where-Object { $_.Level -in 1,2,3 -or $_.Id -in 1006,1007,1008,1015,1116,1117,1118,1119,2001,2003,2004,5001,5004,5007,5010,5012 } |
    Select-Object -First 150 TimeCreated,Id,LevelDisplayName,Message)
}
catch {}

if ($events.Count -eq 0) {
    Add-Section "DEFENDER OPERATIONAL EVENTS - LAST 14 DAYS" ([pscustomobject]@{Status="No matching Defender warning/error/change events returned"})
}
else {
    Add-Section "DEFENDER OPERATIONAL EVENTS - LAST 14 DAYS" $events
}

$body = $lines -join [Environment]::NewLine

if (-not (Test-Path -LiteralPath $writer)) {
    Write-Host "Report writer not found:"
    Write-Host $writer
    exit 3
}

& $writer -BasePath $basePath -Title "Microsoft Defender Security Audit" -Body $body

$html = $basePath + ".html"
$txt = $basePath + ".txt"
$md = $basePath + ".md"

if (-not (Test-Path -LiteralPath $html) -or -not (Test-Path -LiteralPath $txt) -or -not (Test-Path -LiteralPath $md)) {
    Write-Host "One or more report files were not created."
    exit 4
}

Write-Host ""
Write-Host "Microsoft Defender Security Audit complete."
Write-Host ("HTML: " + $html)
Write-Host ("Text: " + $txt)
Write-Host ("Markdown: " + $md)

try { Start-Process -FilePath $html } catch {}
exit 0

$screenReaderCommon = Join-Path (Split-Path $PSScriptRoot -Parent) "00_Common\ScreenReader-Common.ps1"
if (Test-Path -LiteralPath $screenReaderCommon -PathType Leaf) {
    . $screenReaderCommon
}

$ErrorActionPreference = "SilentlyContinue"
$ProgressPreference = "SilentlyContinue"

$toolkitRoot = Split-Path $PSScriptRoot -Parent
$foundation = Join-Path $toolkitRoot "00_Common\Foundation-Common.ps1"
if (Test-Path -LiteralPath $foundation -PathType Leaf) { . $foundation }
$logs = Join-Path $toolkitRoot "Logs"
if (-not (Test-Path -LiteralPath $logs)) {
    New-Item -ItemType Directory -Path $logs -Force | Out-Null
}

$baselinePath = Join-Path $logs ("NETWORK_COMPARE_BASELINE_" + $env:COMPUTERNAME + ".clixml")
$baselineTextPath = Join-Path $logs ("NETWORK_COMPARE_BASELINE_" + $env:COMPUTERNAME + ".txt")
$writer = Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"

function Get-NormalizedLines {
    param($Objects)
    if ($null -eq $Objects) { return @() }
    return @($Objects | ForEach-Object {
        ($_ | Out-String -Width 260).Trim()
    } | Where-Object { $_ } | Sort-Object -Unique)
}

function Get-NetworkSnapshot {
    $snapshot = [ordered]@{}
    $snapshot.Timestamp = Get-Date
    $snapshot.ComputerName = $env:COMPUTERNAME

    $snapshot.Adapters = (Get-NetAdapter -ErrorAction SilentlyContinue |
        Select-Object Name,InterfaceDescription,Status,LinkSpeed,MacAddress,ifIndex |
        Sort-Object Name |
        Format-Table -AutoSize |
        Out-String -Width 260).TrimEnd()

    $snapshot.IPAddresses = (Get-NetIPAddress -ErrorAction SilentlyContinue |
        Where-Object { $_.AddressState -ne "Tentative" } |
        Select-Object InterfaceAlias,AddressFamily,IPAddress,PrefixLength,PrefixOrigin,SuffixOrigin |
        Sort-Object InterfaceAlias,AddressFamily,IPAddress |
        Format-Table -AutoSize |
        Out-String -Width 260).TrimEnd()

    $snapshot.DNSServers = (Get-DnsClientServerAddress -ErrorAction SilentlyContinue |
        Select-Object InterfaceAlias,AddressFamily,@{N="ServerAddresses";E={$_.ServerAddresses -join ", "}} |
        Sort-Object InterfaceAlias,AddressFamily |
        Format-Table -AutoSize |
        Out-String -Width 260).TrimEnd()

    $snapshot.Routes = (Get-NetRoute -ErrorAction SilentlyContinue |
        Where-Object { $_.State -eq "Alive" -or $null -eq $_.State } |
        Select-Object AddressFamily,InterfaceAlias,DestinationPrefix,NextHop,RouteMetric,Protocol |
        Sort-Object AddressFamily,DestinationPrefix,InterfaceAlias,NextHop |
        Format-Table -AutoSize |
        Out-String -Width 260).TrimEnd()

    $snapshot.Profiles = (Get-NetConnectionProfile -ErrorAction SilentlyContinue |
        Select-Object InterfaceAlias,Name,NetworkCategory,IPv4Connectivity,IPv6Connectivity |
        Sort-Object InterfaceAlias |
        Format-Table -AutoSize |
        Out-String -Width 260).TrimEnd()

    $snapshot.FirewallProfiles = (Get-NetFirewallProfile -ErrorAction SilentlyContinue |
        Select-Object Name,Enabled,DefaultInboundAction,DefaultOutboundAction |
        Sort-Object Name |
        Format-Table -AutoSize |
        Out-String -Width 260).TrimEnd()

    $proxyNative = Invoke-ToolkitNativeCommand -FilePath "netsh.exe" -Arguments @("winhttp","show","proxy") -Label "Network Compare WinHTTP Proxy" -Action "Network Before After Compare" -Quiet
    $snapshot.WinHttpProxy = (($proxyNative.Output -join [Environment]::NewLine) | Out-String -Width 260).TrimEnd()

    $userProxy = Get-ItemProperty "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings" -ErrorAction SilentlyContinue
    $snapshot.UserProxy = ([pscustomobject]@{
        ProxyEnable = $userProxy.ProxyEnable
        ProxyServer = $userProxy.ProxyServer
        AutoConfigURL = $userProxy.AutoConfigURL
    } | Format-List | Out-String -Width 260).TrimEnd()

    $hostsPath = Join-Path $env:SystemRoot "System32\drivers\etc\hosts"
    if (Test-Path -LiteralPath $hostsPath) {
        $snapshot.HostsFile = (Get-Content -LiteralPath $hostsPath -ErrorAction SilentlyContinue | Out-String -Width 260).TrimEnd()
        $snapshot.HostsSHA256 = (Get-FileHash -LiteralPath $hostsPath -Algorithm SHA256 -ErrorAction SilentlyContinue).Hash
    }
    else {
        $snapshot.HostsFile = "(HOSTS file not found)"
        $snapshot.HostsSHA256 = ""
    }

    $wlanNative = Invoke-ToolkitNativeCommand -FilePath "netsh.exe" -Arguments @("wlan","show","interfaces") -Label "Network Compare WLAN Interfaces" -Action "Network Before After Compare" -Quiet
    $snapshot.WlanInterfaces = (($wlanNative.Output -join [Environment]::NewLine) | Out-String -Width 260).TrimEnd()
    $snapshot.IPConfig = (& ipconfig.exe /all 2>&1 | Out-String -Width 260).TrimEnd()

    return [pscustomobject]$snapshot
}

function Convert-SnapshotToText {
    param($Snapshot)
    $lines = New-Object System.Collections.Generic.List[string]
    $lines.Add("NETWORK SNAPSHOT")
    $lines.Add("Computer: " + $Snapshot.ComputerName)
    $lines.Add("Captured: " + $Snapshot.Timestamp)

    foreach ($name in @("Adapters","IPAddresses","DNSServers","Routes","Profiles","FirewallProfiles","WinHttpProxy","UserProxy","HostsSHA256","HostsFile","WlanInterfaces","IPConfig")) {
        $lines.Add("")
        $lines.Add(("=" * 78))
        $lines.Add($name)
        $lines.Add(("=" * 78))
        $value = $Snapshot.$name
        if ([string]::IsNullOrWhiteSpace([string]$value)) {
            $lines.Add("(No data returned)")
        }
        else {
            $lines.Add([string]$value)
        }
    }

    return ($lines -join [Environment]::NewLine)
}

function Add-DifferenceSection {
    param(
        [System.Collections.Generic.List[string]]$Lines,
        [string]$Name,
        [string]$Before,
        [string]$After
    )

    $Lines.Add("")
    $Lines.Add(("=" * 78))
    $Lines.Add($Name)
    $Lines.Add(("=" * 78))

    if ($Before -eq $After) {
        $Lines.Add("No change.")
        return
    }

    $beforeLines = @($Before -split "\r?\n" | ForEach-Object { $_.TrimEnd() } | Where-Object { $_ })
    $afterLines = @($After -split "\r?\n" | ForEach-Object { $_.TrimEnd() } | Where-Object { $_ })

    $diff = @(Compare-Object -ReferenceObject $beforeLines -DifferenceObject $afterLines -ErrorAction SilentlyContinue)
    if ($diff.Count -eq 0) {
        $Lines.Add("Content changed, but no line-level difference was produced.")
        return
    }

    $Lines.Add("Legend: <= baseline only / removed; => after only / added.")
    $Lines.Add(($diff | Select-Object InputObject,SideIndicator | Format-Table -Wrap -AutoSize | Out-String -Width 260).TrimEnd())
}

Write-Host "NETWORK BEFORE / AFTER COMPARE"
Write-Host ""
Write-Host "1. Capture or replace baseline."
Write-Host "2. Capture AFTER state and compare with saved baseline."
Write-Host "3. Show baseline path/status."
Write-Host "4. Delete saved baseline."
Write-Host "0. Return."
Write-Host ""

$choice = Read-ToolkitPrompt "Select an option"

switch ($choice) {
    "1" {
        if (Test-Path -LiteralPath $baselinePath) {
            $confirm = Read-ToolkitPrompt "A baseline already exists. Type YES to replace it" -SpellExactPhrase "YES"
            if ($confirm -cne "YES") {
                Write-Host "Baseline replacement canceled."
                exit 0
            }
        }

        Write-Host "Capturing network baseline..."
        $baseline = Get-NetworkSnapshot
        $baseline | Export-Clixml -LiteralPath $baselinePath
        Convert-SnapshotToText $baseline | Set-Content -LiteralPath $baselineTextPath -Encoding UTF8

        Write-Host ""
        Write-Host "Baseline saved."
        Write-Host ("State file: " + $baselinePath)
        Write-Host ("Readable copy: " + $baselineTextPath)
        exit 0
    }

    "2" {
        if (-not (Test-Path -LiteralPath $baselinePath)) {
            Write-Host "No saved baseline exists for this computer."
            Write-Host "Run option 1 before making network changes, then run option 2 afterward."
            exit 2
        }

        $before = Import-Clixml -LiteralPath $baselinePath
        $after = Get-NetworkSnapshot
        $stamp = Get-Date -Format "yyyyMMdd_HHmmss"
        $basePath = Join-Path $logs ($env:COMPUTERNAME + "_Network_Before_After_Compare_" + $stamp)
        $afterXml = $basePath + "_AFTER.clixml"
        $afterTxt = $basePath + "_AFTER.txt"

        $after | Export-Clixml -LiteralPath $afterXml
        Convert-SnapshotToText $after | Set-Content -LiteralPath $afterTxt -Encoding UTF8

        $lines = New-Object System.Collections.Generic.List[string]
        $lines.Add("NETWORK BEFORE / AFTER COMPARE")
        $lines.Add("Computer: " + $env:COMPUTERNAME)
        $lines.Add("Baseline captured: " + $before.Timestamp)
        $lines.Add("After captured: " + $after.Timestamp)
        $lines.Add("")
        $lines.Add("Only changed sections show line-level additions/removals.")

        foreach ($name in @("Adapters","IPAddresses","DNSServers","Routes","Profiles","FirewallProfiles","WinHttpProxy","UserProxy","HostsSHA256","HostsFile","WlanInterfaces","IPConfig")) {
            Add-DifferenceSection $lines $name ([string]$before.$name) ([string]$after.$name)
        }

        $body = $lines -join [Environment]::NewLine
        & $writer -BasePath $basePath -Title "Network Before / After Compare" -Body $body

        $html = $basePath + ".html"
        Write-Host ""
        Write-Host "Network comparison complete."
        Write-Host ("HTML: " + $html)
        Write-Host ("Text: " + $basePath + ".txt")
        Write-Host ("Markdown: " + $basePath + ".md")
        Write-Host ("After-state XML: " + $afterXml)
        Write-Host ("After-state text: " + $afterTxt)
        try { Start-Process -FilePath $html } catch {}
        exit 0
    }

    "3" {
        if (Test-Path -LiteralPath $baselinePath) {
            $baseline = Import-Clixml -LiteralPath $baselinePath
            Write-Host ("Baseline exists: " + $baselinePath)
            Write-Host ("Captured: " + $baseline.Timestamp)
            Write-Host ("Readable copy: " + $baselineTextPath)
        }
        else {
            Write-Host "No baseline is currently saved for this computer."
        }
        exit 0
    }

    "4" {
        if (-not (Test-Path -LiteralPath $baselinePath)) {
            Write-Host "No baseline exists."
            exit 0
        }
        $confirm = Read-ToolkitPrompt "Type DELETE to remove the saved baseline" -SpellExactPhrase "DELETE"
        if ($confirm -ceq "DELETE") {
            Remove-Item -LiteralPath $baselinePath -Force -ErrorAction SilentlyContinue
            Remove-Item -LiteralPath $baselineTextPath -Force -ErrorAction SilentlyContinue
            Write-Host "Baseline deleted."
        }
        else {
            Write-Host "Baseline deletion canceled."
        }
        exit 0
    }

    "0" { exit 0 }
    default {
        Write-Host "Choose 0 through 4."
        exit 1
    }
}

@echo off
setlocal EnableExtensions
title Reset Winsock and TCP-IP - ADMIN

net session >nul 2>&1
if not "%errorlevel%"=="0" (
    echo Requesting Administrator privileges...
    powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\00_Common\Invoke-Elevated-Self.ps1" -ScriptPath "%~f0"
    exit /b
)

echo RESET WINSOCK + TCP/IP
echo.
echo This will:
echo - Reset the Windows Winsock catalog.
echo - Reset the TCP/IP stack to Windows defaults where applicable.
echo - Flush the DNS resolver cache.
echo.
echo This is network-disruptive and a Windows reboot is strongly recommended afterward.
echo VPN clients, security software, static/specialized network settings, or custom network
echo components may require attention after the reset.
echo.
echo To prevent an accidental reset, type RESET exactly and press Enter.
if "%SRMODE%"=="1" echo A typed confirmation is required. Enter the word RESET to continue.
set "CONFIRM="
set /p "CONFIRM=Type RESET to continue, or press Enter to cancel: "
if /I not "%CONFIRM%"=="RESET" goto CANCELED

echo.
echo Resetting Winsock...
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\00_Common\Invoke-Native-Bridge.ps1" -FilePath "netsh.exe" -Label "Winsock Reset" -Action "Reset Winsock and TCP-IP" -Mutation winsock reset
set "WINSOCK_RC=%errorlevel%"

echo.
echo Resetting TCP/IP...
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\00_Common\Invoke-Native-Bridge.ps1" -FilePath "netsh.exe" -Label "TCP-IP Reset" -Action "Reset Winsock and TCP-IP" -Mutation int ip reset
set "IP_RC=%errorlevel%"

echo.
echo Flushing DNS...
ipconfig /flushdns
set "DNS_RC=%errorlevel%"

echo.
echo Reset commands completed.
echo Winsock return code: %WINSOCK_RC%
echo TCP/IP return code: %IP_RC%
echo DNS flush return code: %DNS_RC%
echo Reboot Windows before further network troubleshooting.

if not "%WINSOCK_RC%"=="0" goto RESET_ERROR
if not "%IP_RC%"=="0" goto RESET_ERROR
set "RC=0"
goto FINISH

:RESET_ERROR
set "RC=1"
goto FINISH

:CANCELED
echo.
echo Canceled. No changes were made.
set "RC=0"

:FINISH
echo.
if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)
exit /b %RC%

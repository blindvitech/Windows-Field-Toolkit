@echo off
setlocal
title Network Adapter Snapshot
set "LOGDIR=%~dp0..\Logs"
if not exist "%LOGDIR%" mkdir "%LOGDIR%"
set "LOG=%LOGDIR%\%COMPUTERNAME%_Adapters_%RANDOM%.txt"
(
echo NETWORK ADAPTER SNAPSHOT
echo Computer: %COMPUTERNAME%
echo Date: %DATE% %TIME%
echo.
echo ===== IPCONFIG =====
ipconfig /all
echo.
echo ===== INTERFACES =====
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\00_Common\Invoke-Native-Bridge.ps1" -FilePath "netsh.exe" -Label "Network Interfaces" interface show interface
echo.
echo ===== IPv4 CONFIG =====
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\00_Common\Invoke-Native-Bridge.ps1" -FilePath "netsh.exe" -Label "IPv4 Configuration" interface ipv4 show config
echo.
echo ===== IPv6 CONFIG =====
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\00_Common\Invoke-Native-Bridge.ps1" -FilePath "netsh.exe" -Label "IPv6 Interfaces" interface ipv6 show interface
echo.
echo ===== MAC ADDRESSES =====
getmac /v
) > "%LOG%" 2>&1

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\00_Common\Convert-TextReport.ps1" -TextPath "%LOG%" -Title "%~n0"


echo Saved to:
echo %LOG%
if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)
endlocal

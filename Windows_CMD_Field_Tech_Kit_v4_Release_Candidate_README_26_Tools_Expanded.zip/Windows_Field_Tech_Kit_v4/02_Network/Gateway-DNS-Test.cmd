@echo off
setlocal
title Gateway and DNS Test
for /f "tokens=3" %%G in ('route print ^| findstr /R /C:"^ *0\.0\.0\.0 *0\.0\.0\.0"') do (
    set "GW=%%G"
    goto :gotgw
)
:gotgw
echo ============================================================
echo GATEWAY / DNS TEST
echo ============================================================
echo.
if defined GW (
  echo Default Gateway: %GW%
  echo.
  ping -n 4 %GW%
) else (
  echo Could not determine the default IPv4 gateway.
)
echo.
echo Testing Cloudflare DNS reachability...
ping -n 4 1.1.1.1
echo.
echo Testing Google DNS reachability...
ping -n 4 8.8.8.8
echo.
echo Testing DNS resolution...
nslookup microsoft.com
echo.
echo Tracing route to Cloudflare...
tracert -d 1.1.1.1
if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)
endlocal

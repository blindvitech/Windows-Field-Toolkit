@echo off
setlocal EnableExtensions
title Windows Time Sync - ADMIN

net session >nul 2>&1
if not "%errorlevel%"=="0" (
    echo This action requires Administrator privileges.
    echo Relaunch the toolkit as Administrator and try again.
    echo.
    if "%SRMODE%"=="1" (
        echo Press any key to continue.
        pause >nul
    ) else (
        pause
    )
    exit /b 1
)

echo WINDOWS TIME STATUS / RESYNC
echo.
echo Current Windows Time status:
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\00_Common\Invoke-Native-Bridge.ps1" -FilePath "w32tm.exe" -Label "Windows Time Status" /query /status
echo.
echo The next action will request an immediate Windows Time resynchronization.
echo If the local clock is wrong, Windows may adjust the system time.
echo Applications, authentication, logs, and timestamps can be sensitive to clock changes.
echo.
if "%SRMODE%"=="1" echo Confirmation prompt follows. Press Y for yes or N for no.
choice /C YN /N /M "Force a time resync? [Y/N]: "
if errorlevel 2 goto CANCELED

echo.
echo Requesting time resynchronization...
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\00_Common\Invoke-Native-Bridge.ps1" -FilePath "w32tm.exe" -Label "Windows Time Resync" -Action "Windows Time Sync" -Mutation /resync
set "RC=%errorlevel%"

echo.
echo Updated Windows Time status:
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\00_Common\Invoke-Native-Bridge.ps1" -FilePath "w32tm.exe" -Label "Windows Time Status" /query /status

echo.
if "%RC%"=="0" (
    echo Time resynchronization request completed successfully.
) else (
    echo Time resynchronization returned error code %RC%.
)
goto FINISH

:CANCELED
echo.
echo Canceled. No changes were made.
set "RC=0"

:FINISH
echo.
if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)
exit /b %RC%

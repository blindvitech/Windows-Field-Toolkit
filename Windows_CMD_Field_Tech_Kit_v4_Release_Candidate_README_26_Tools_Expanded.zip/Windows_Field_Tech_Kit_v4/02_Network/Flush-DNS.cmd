@echo off
setlocal EnableExtensions
title Flush DNS Cache

echo FLUSH DNS CACHE
echo.
echo This will clear the Windows DNS resolver cache.
echo Cached DNS entries will be removed and rebuilt automatically as names are resolved again.
echo Network adapter settings, saved Wi-Fi profiles, and IP configuration are not changed.
echo.
if "%SRMODE%"=="1" echo Confirmation prompt follows. Press Y for yes or N for no.
choice /C YN /N /M "Continue? [Y/N]: "
if errorlevel 2 goto CANCELED

echo.
echo Flushing the DNS resolver cache...
ipconfig /flushdns
set "RC=%errorlevel%"

echo.
if "%RC%"=="0" (
    echo DNS cache flush completed successfully.
) else (
    echo DNS cache flush returned error code %RC%.
)
goto FINISH

:CANCELED
echo.
echo Canceled. No changes were made.
set "RC=0"

:FINISH
echo.
if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)
exit /b %RC%

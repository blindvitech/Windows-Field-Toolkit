@echo off
setlocal EnableExtensions
title Release and Renew DHCP - ADMIN

net session >nul 2>&1
if not "%errorlevel%"=="0" (
    echo Requesting Administrator privileges...
    powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\00_Common\Invoke-Elevated-Self.ps1" -ScriptPath "%~f0"
    exit /b
)

echo RELEASE / RENEW DHCP
echo.
echo This will release active DHCP leases and request new leases from the DHCP server.
echo Active DHCP network connections will drop temporarily while the lease is released.
echo Remote sessions, mapped resources, or network applications may disconnect.
echo Static IP configuration is not intentionally changed by this action.
echo.
if "%SRMODE%"=="1" echo Confirmation prompt follows. Press Y for yes or N for no.
choice /C YN /N /M "Continue? [Y/N]: "
if errorlevel 2 goto CANCELED

echo.
echo Releasing DHCP leases...
ipconfig /release
set "RELEASE_RC=%errorlevel%"

echo.
echo Renewing DHCP leases...
ipconfig /renew
set "RENEW_RC=%errorlevel%"

echo.
echo Current IP configuration:
ipconfig /all

echo.
if not "%RELEASE_RC%"=="0" goto DHCP_ERROR
if not "%RENEW_RC%"=="0" goto DHCP_ERROR
echo DHCP release / renew completed successfully.
set "RC=0"
goto FINISH

:DHCP_ERROR
echo DHCP operation completed with one or more command errors.
echo Release return code: %RELEASE_RC%
echo Renew return code: %RENEW_RC%
set "RC=1"
goto FINISH

:CANCELED
echo.
echo Canceled. No changes were made.
set "RC=0"

:FINISH
echo.
if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)
exit /b %RC%

@echo off
title Generate WLAN Report - ADMIN
net session >nul 2>&1
if not "%errorlevel%"=="0" (
    echo This script requires Administrator privileges.
    echo Right-click it and choose "Run as administrator".
    if "%SRMODE%"=="1" (
        echo Press any key to continue.
        pause >nul
    ) else (
        pause
    )
    exit /b 1
)
echo Generating the built-in Windows wireless report...
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\00_Common\Invoke-Native-Bridge.ps1" -FilePath "netsh.exe" -Label "WLAN Report" wlan show wlanreport
echo.
echo Windows normally saves it here:
echo %ProgramData%\Microsoft\Windows\WlanReport\wlan-report-latest.html
if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

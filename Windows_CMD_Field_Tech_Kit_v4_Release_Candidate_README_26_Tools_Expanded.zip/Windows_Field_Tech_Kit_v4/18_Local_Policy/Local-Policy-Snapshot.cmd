@echo off
setlocal EnableExtensions
title Local Policy Snapshot

echo Local Policy Snapshot
echo.
echo Collecting report data. This may take a moment.
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Local-Policy-Snapshot.ps1"
set "RC=%errorlevel%"

if "%SRMODE%"=="1" (
    echo.
    if "%RC%"=="0" (
        echo Local Policy Snapshot completed successfully.
    ) else (
        echo Local Policy Snapshot returned error code %RC%.
    )
    echo Press any key to continue.
    pause >nul
) else (
    echo.
    pause
)

exit /b %RC%

$ErrorActionPreference = "SilentlyContinue"
$ProgressPreference = "SilentlyContinue"

$toolkitRoot = Split-Path $PSScriptRoot -Parent
$logs = Join-Path $toolkitRoot "Logs"
if (-not (Test-Path -LiteralPath $logs)) {
    New-Item -ItemType Directory -Path $logs -Force | Out-Null
}

$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$basePath = Join-Path $logs ($env:COMPUTERNAME + "_Local_Policy_Snapshot_" + $stamp)
$writer = Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"

Write-Host "Collecting Local Policy Snapshot..."

$body = & {
Write-Output "===== PASSWORD / LOCKOUT POLICY ====="
net accounts
Write-Output "`n===== AUDIT POLICY SUMMARY ====="
auditpol /get /category:*
Write-Output "`n===== UAC ====="
Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -ErrorAction SilentlyContinue |
    Select-Object EnableLUA,ConsentPromptBehaviorAdmin,PromptOnSecureDesktop,FilterAdministratorToken
Write-Output "`n===== SMB SERVER ====="
Get-SmbServerConfiguration -ErrorAction SilentlyContinue |
    Select-Object EnableSMB1Protocol,EnableSMB2Protocol,RequireSecuritySignature,EnableSecuritySignature,EncryptData
Write-Output "`n===== SMB CLIENT ====="
Get-SmbClientConfiguration -ErrorAction SilentlyContinue |
    Select-Object RequireSecuritySignature,EnableSecuritySignature
Write-Output "`n===== NTLM POLICY ====="
Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -ErrorAction SilentlyContinue |
    Select-Object LmCompatibilityLevel,RestrictAnonymous,RestrictAnonymousSAM
} | Out-String -Width 240

if (-not (Test-Path -LiteralPath $writer)) {
    Write-Host "Report writer not found:"
    Write-Host $writer
    exit 3
}

& $writer -BasePath $basePath -Title "Local Policy Snapshot" -Body $body

$html = $basePath + ".html"
$txt = $basePath + ".txt"
$md = $basePath + ".md"

if (-not (Test-Path -LiteralPath $html) -or -not (Test-Path -LiteralPath $txt) -or -not (Test-Path -LiteralPath $md)) {
    Write-Host ""
    Write-Host "Collection finished, but one or more report files were not created."
    exit 4
}

Write-Host ""
Write-Host "Local Policy Snapshot complete."
Write-Host ("HTML: " + $html)
Write-Host ("Text: " + $txt)
Write-Host ("Markdown: " + $md)
exit 0

. "$PSScriptRoot\Repair-Common.ps1"

$action = "Print System Repair"

if (-not (Test-ToolkitAdmin)) {
    Write-Host "Administrator privileges are required."
    Write-RepairJournal $action "BLOCKED" "Not running as Administrator."
    exit 1
}

$logs = Get-ToolkitLogsRoot
$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$dest = Join-Path $logs ("PRINT_REPAIR_BACKUP_" + $env:COMPUTERNAME + "_" + $stamp)
New-Item -ItemType Directory -Path $dest -Force | Out-Null

Write-Host "Print System Repair"
Write-Host ""
Write-Host "Before changing anything, this tool inventories printers, drivers, and ports."
Write-Host "When PrintBRM is available it also attempts a printer configuration backup."
Write-Host ""
Write-Host "Repair action:"
Write-Host "- Stop the Print Spooler."
Write-Host "- Remove queued spool files only."
Write-Host "- Start the Print Spooler."
Write-Host "- Verify Spooler state."
Write-Host ""
Write-Host "Installed printers and printer drivers are not intentionally removed."
Write-Host ""

try {
    Get-Printer | Select-Object Name,DriverName,PortName,Shared,Published,PrinterStatus |
        Export-Csv -LiteralPath (Join-Path $dest "PRINTERS_BEFORE.csv") -NoTypeInformation -Encoding UTF8
    Get-PrinterDriver | Select-Object Name,Manufacturer,MajorVersion,DriverVersion,InfPath |
        Export-Csv -LiteralPath (Join-Path $dest "PRINTER_DRIVERS_BEFORE.csv") -NoTypeInformation -Encoding UTF8
    Get-PrinterPort | Select-Object Name,Description,PrinterHostAddress,PortNumber,Protocol |
        Export-Csv -LiteralPath (Join-Path $dest "PRINTER_PORTS_BEFORE.csv") -NoTypeInformation -Encoding UTF8
}
catch {
}

$printBrm = Join-Path $env:WINDIR "System32\spool\tools\PrintBrm.exe"
if (Test-Path -LiteralPath $printBrm) {
    try {
        & $printBrm -B -F (Join-Path $dest "PRINTBRM_BACKUP.printerExport") | Out-Null
    }
    catch {
    }
}

if (-not (Confirm-RepairAction "Continue with spooler queue cleanup and restart?")) {
    Write-Host "Canceled. The inventory backup was kept."
    Write-Host ("Backup location: " + $dest)
    Write-RepairJournal $action "CANCELED" ("Inventory backup=" + $dest)
    exit 0
}

Write-RepairJournal $action "STARTING" ("Backup=" + $dest)

try {
    Stop-Service -Name Spooler -Force -ErrorAction Stop
}
catch {
    Write-Host ("Could not stop Print Spooler: " + $_.Exception.Message)
    Write-RepairJournal $action "FAILED" $_.Exception.Message
    Write-RepairVerification -Action $action -Check "Print Spooler pre-clean stop" -Status "FAILED" -Details $_.Exception.Message
    exit 2
}

$queue = Join-Path $env:WINDIR "System32\spool\PRINTERS"
$queueBackup = Join-Path $dest "SPOOL_QUEUE_BEFORE"
$removed = 0
$removeFailures = 0
if (Test-Path -LiteralPath $queue) {
    $files = @(Get-ChildItem -LiteralPath $queue -Force -File -ErrorAction SilentlyContinue)
    if ($files.Count -gt 0) {
        New-Item -ItemType Directory -Path $queueBackup -Force | Out-Null
        foreach ($file in $files) {
            try {
                Copy-Item -LiteralPath $file.FullName -Destination (Join-Path $queueBackup $file.Name) -Force -ErrorAction Stop
            }
            catch {
                Write-Host ("Warning: could not back up queued spool file " + $file.Name + ": " + $_.Exception.Message)
            }
        }
    }

    foreach ($file in $files) {
        try {
            Remove-Item -LiteralPath $file.FullName -Force -ErrorAction Stop
            $removed++
        }
        catch {
            $removeFailures++
            Write-Host ("Could not remove queued spool file " + $file.Name + ": " + $_.Exception.Message)
        }
    }
}

try {
    Start-Service -Name Spooler -ErrorAction Stop
}
catch {
    Write-Host ("Could not restart Print Spooler: " + $_.Exception.Message)
    Write-RepairJournal $action "FAILED" ("Queue files removed=" + $removed + "; restart failed: " + $_.Exception.Message)
    Write-RepairVerification -Action $action -Check "Print Spooler restart post-state" -Status "FAILED" `
        -Details ("Queue files removed=" + $removed + "; " + $_.Exception.Message)
    exit 3
}

$svc = Get-Service Spooler -ErrorAction SilentlyContinue
try {
    Get-Printer | Select-Object Name,DriverName,PortName,Shared,Published,PrinterStatus |
        Export-Csv -LiteralPath (Join-Path $dest "PRINTERS_AFTER.csv") -NoTypeInformation -Encoding UTF8
}
catch {
}

$queueRemaining = 0
if (Test-Path -LiteralPath $queue) {
    $queueRemaining = @(Get-ChildItem -LiteralPath $queue -Force -File -ErrorAction SilentlyContinue).Count
}
$spoolerVerified = ($svc -and $svc.Status -eq "Running")
if ($spoolerVerified -and $queueRemaining -eq 0 -and $removeFailures -eq 0) {
    Write-RepairVerification -Action $action -Check "Print Spooler and queue post-state" -Status "VERIFIED" `
        -Details "Spooler is Running and the spool queue contains no remaining files."
}
elseif ($spoolerVerified) {
    Write-RepairVerification -Action $action -Check "Print Spooler and queue post-state" -Status "PARTIAL" `
        -Details ("Spooler is Running; queue files remaining=" + $queueRemaining + "; removal failures=" + $removeFailures)
}
else {
    Write-RepairVerification -Action $action -Check "Print Spooler and queue post-state" -Status "FAILED" `
        -Details ("Spooler state=" + $(if($svc){$svc.Status}else{"Unavailable"}) + "; queue files remaining=" + $queueRemaining)
}

Write-Host ""
Write-Host ("Queued spool files removed: " + $removed)
Write-Host ("Queued spool file removal failures: " + $removeFailures)
if (Test-Path -LiteralPath $queueBackup) { Write-Host ("Pre-cleanup spool-file backup: " + $queueBackup) }
Write-Host ("Print Spooler state: " + $svc.Status)
Write-Host ("Backup/inventory location: " + $dest)
Write-RepairJournal $action "COMPLETED" ("Queue files removed=" + $removed + "; RemoveFailures=" + $removeFailures + "; Spooler=" + $svc.Status + "; Backup=" + $dest)
exit 0

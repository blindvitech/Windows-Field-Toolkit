@echo off
setlocal EnableExtensions
title Windows Recovery Environment Repair

echo Windows Recovery Environment Repair
echo.
echo Starts with reagentc status and partition inventory, and exports BCD before WinRE changes.
echo It does not create/delete recovery partitions or invent a missing Winre.wim.
net session >nul 2>&1
if errorlevel 1 (
    echo Administrator privileges are required.
    echo Use Home option 4 to relaunch the toolkit as Administrator.
    if "%SRMODE%"=="1" (
        echo Press any key to continue.
        pause >nul
    ) else (
        pause
    )
    exit /b 1
)

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0WinRE-Repair.ps1"
set "RC=%errorlevel%"

if "%SRMODE%"=="1" (
    echo.
    echo Windows Recovery Environment Repair finished with return code %RC%.
    echo Press any key to continue.
    pause >nul
) else (
    echo.
    pause
)

exit /b %RC%

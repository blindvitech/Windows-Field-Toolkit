@echo off
setlocal EnableExtensions
title Windows Repair Chain

echo Windows Repair Chain
echo.
echo Runs DISM CheckHealth, ScanHealth, RestoreHealth, SFC, then verifies DISM again.
echo Offers the Repair Safety Backup first and logs every step.
net session >nul 2>&1
if errorlevel 1 (
    echo Administrator privileges are required.
    echo Use Home option 4 to relaunch the toolkit as Administrator.
    if "%SRMODE%"=="1" (
        echo Press any key to continue.
        pause >nul
    ) else (
        pause
    )
    exit /b 1
)

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Windows-Repair-Chain.ps1"
set "RC=%errorlevel%"

if "%SRMODE%"=="1" (
    echo.
    echo Windows Repair Chain finished with return code %RC%.
    echo Press any key to continue.
    pause >nul
) else (
    echo.
    pause
)

exit /b %RC%

. "$PSScriptRoot\Repair-Common.ps1"

$action = "Safe Free Space Recovery"

if (-not (Test-ToolkitAdmin)) {
    Write-Host "Administrator privileges are required."
    Write-RepairJournal $action "BLOCKED" "Not running as Administrator."
    exit 1
}

$logs = Get-ToolkitLogsRoot
$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$logPath = Join-Path $logs ("FREE_SPACE_RECOVERY_" + $env:COMPUTERNAME + "_" + $stamp + ".txt")

$userTemp = $env:TEMP
$windowsTemp = Join-Path $env:WINDIR "Temp"
$updateCache = Join-Path $env:WINDIR "SoftwareDistribution\Download"
$memoryDump = Join-Path $env:WINDIR "MEMORY.DMP"
$miniDump = Join-Path $env:WINDIR "Minidump"
$script:lastUpdateCacheServiceRestoreFailures = @()

function Get-PathSize {
    param([string]$Path)
    if (Test-Path -LiteralPath $Path -PathType Leaf) {
        try { return [int64](Get-Item -LiteralPath $Path -Force).Length } catch { return [int64]0 }
    }
    return Get-DirectorySizeBytes $Path
}

function Show-Analysis {
    $items = @(
        [pscustomobject]@{ Category="User temp"; Size=Get-PathSize $userTemp; Path=$userTemp },
        [pscustomobject]@{ Category="Windows temp"; Size=Get-PathSize $windowsTemp; Path=$windowsTemp },
        [pscustomobject]@{ Category="Windows Update download cache"; Size=Get-PathSize $updateCache; Path=$updateCache },
        [pscustomobject]@{ Category="MEMORY.DMP"; Size=Get-PathSize $memoryDump; Path=$memoryDump },
        [pscustomobject]@{ Category="Minidumps"; Size=Get-PathSize $miniDump; Path=$miniDump }
    )

    Write-Host ""
    Write-Host "Current cleanup candidates:"
    foreach ($item in $items) {
        Write-Host (" - {0}: {1}" -f $item.Category, (Format-Bytes $item.Size))
    }
    Write-Host ""
    return $items
}

function Remove-OldTempContent {
    param([string]$Path,[int]$OlderThanHours=48)
    if (-not (Test-Path -LiteralPath $Path)) { return [int64]0 }

    $cutoff = (Get-Date).AddHours(-$OlderThanHours)
    $before = Get-PathSize $Path

    Get-ChildItem -LiteralPath $Path -Force -ErrorAction SilentlyContinue |
        Where-Object { $_.LastWriteTime -lt $cutoff } |
        Remove-Item -Recurse -Force -ErrorAction SilentlyContinue

    $after = Get-PathSize $Path
    return [math]::Max([int64]0, ($before - $after))
}

function Remove-CrashDumps {
    $before = (Get-PathSize $memoryDump) + (Get-PathSize $miniDump)
    if (Test-Path -LiteralPath $memoryDump) {
        Remove-Item -LiteralPath $memoryDump -Force -ErrorAction SilentlyContinue
    }
    if (Test-Path -LiteralPath $miniDump) {
        Get-ChildItem -LiteralPath $miniDump -Force -File -ErrorAction SilentlyContinue |
            Remove-Item -Force -ErrorAction SilentlyContinue
    }
    $after = (Get-PathSize $memoryDump) + (Get-PathSize $miniDump)
    return [math]::Max([int64]0, ($before - $after))
}

function Clear-UpdateDownloadCache {
    $before = Get-PathSize $updateCache
    $stopped = New-Object System.Collections.Generic.List[string]
    foreach ($svcName in @("wuauserv","bits")) {
        $svc = Get-Service $svcName -ErrorAction SilentlyContinue
        if ($svc -and $svc.Status -eq "Running") {
            try {
                Stop-Service $svcName -Force -ErrorAction Stop
                $stopped.Add($svcName)
            }
            catch {
            }
        }
    }

    if (Test-Path -LiteralPath $updateCache) {
        Get-ChildItem -LiteralPath $updateCache -Force -ErrorAction SilentlyContinue |
            Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
    }

    $script:lastUpdateCacheServiceRestoreFailures = @()
    foreach ($svcName in $stopped) {
        try { Start-Service $svcName -ErrorAction Stop } catch {
            $script:lastUpdateCacheServiceRestoreFailures += ($svcName + " restart failed: " + $_.Exception.Message)
            continue
        }
        $svcAfter = Get-Service $svcName -ErrorAction SilentlyContinue
        if (-not $svcAfter -or $svcAfter.Status -ne "Running") {
            $script:lastUpdateCacheServiceRestoreFailures += ($svcName + " did not read back Running")
        }
    }

    $after = Get-PathSize $updateCache
    return [math]::Max([int64]0, ($before - $after))
}

function Clear-DoCache {
    $before = [int64]0
    $cmd = Get-Command Delete-DeliveryOptimizationCache -ErrorAction SilentlyContinue
    if (-not $cmd) {
        Write-Host "Delivery Optimization cleanup cmdlet is not available."
        return $false
    }

    try {
        Delete-DeliveryOptimizationCache -Force -ErrorAction Stop
        return $true
    }
    catch {
        Write-Host ("Delivery Optimization cleanup failed: " + $_.Exception.Message)
        return $false
    }
}

$driveBefore = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:'" -ErrorAction SilentlyContinue
$freeBefore = [int64]$driveBefore.FreeSpace
$analysis = Show-Analysis

Write-Host "SAFE FREE SPACE RECOVERY"
Write-Host "1. Conservative cleanup: user temp + Windows temp files older than 48 hours."
Write-Host "2. Delivery Optimization cache."
Write-Host "3. Windows Update download cache. Updates may need to re-download."
Write-Host "4. Crash dumps. WARNING: removes MEMORY.DMP and minidumps used for crash analysis."
Write-Host "5. Empty Recycle Bin for all drives."
Write-Host "6. Run conservative cleanup plus Delivery Optimization cache."
Write-Host "7. Analyze again."
Write-Host "0. Exit."
Write-Host ""

$totalReported = [int64]0
$changesAttempted = 0

while ($true) {
    $choice = Read-ToolkitPrompt "Select an option"

    switch ($choice) {
        "1" {
            if (Confirm-RepairAction "Delete temp content older than 48 hours?") {
                $changesAttempted++
                $a = Remove-OldTempContent $userTemp 48
                $b = Remove-OldTempContent $windowsTemp 48
                $freed = $a + $b
                $totalReported += $freed
                Write-Host ("Reported temp space removed: " + (Format-Bytes $freed))
                Write-RepairJournal $action "TEMP_CLEANUP" ("Reported removed=" + (Format-Bytes $freed))
                Write-RepairVerification -Action $action -Check "Conservative temp cleanup post-state" -Status "VERIFIED" `
                    -Details ("Pre/post directory measurements completed; measured removed=" + (Format-Bytes $freed))
            }
        }
        "2" {
            if (Confirm-RepairAction "Clear Delivery Optimization cache?") {
                $changesAttempted++
                $doOk = Clear-DoCache
                if ($doOk) {
                    Write-Host "Delivery Optimization cleanup command completed."
                    Write-RepairJournal $action "DELIVERY_OPTIMIZATION" "Cleanup command completed."
                    Write-RepairVerification -Action $action -Check "Delivery Optimization cleanup" -Status "PARTIAL" `
                        -Details "Cleanup cmdlet completed without exception; Windows exposes no consistent portable cache-size read-back in this workflow."
                }
                else {
                    Write-RepairJournal $action "DELIVERY_OPTIMIZATION_FAILED" "Cleanup cmdlet unavailable or failed."
                    Write-RepairVerification -Action $action -Check "Delivery Optimization cleanup" -Status "FAILED" `
                        -Details "Cleanup cmdlet was unavailable or returned an exception."
                }
            }
        }
        "3" {
            if (Confirm-RepairAction "Clear the Windows Update download cache?") {
                $changesAttempted++
                $cacheBefore = Get-PathSize $updateCache
                $freed = Clear-UpdateDownloadCache
                $cacheAfter = Get-PathSize $updateCache
                $totalReported += $freed
                Write-Host ("Reported Windows Update cache space removed: " + (Format-Bytes $freed))
                Write-RepairJournal $action "UPDATE_CACHE" ("Reported removed=" + (Format-Bytes $freed))
                $serviceIssues = @($script:lastUpdateCacheServiceRestoreFailures)
                Write-RepairVerification -Action $action -Check "Windows Update download cache post-state" `
                    -Status $(if($cacheAfter -le $cacheBefore -and $serviceIssues.Count -eq 0){"VERIFIED"}else{"PARTIAL"}) `
                    -Details ("Cache before=" + (Format-Bytes $cacheBefore) + "; after=" + (Format-Bytes $cacheAfter) + "; service restore issues=" + ($serviceIssues -join ", "))
            }
        }
        "4" {
            if (Confirm-RepairAction "Delete crash dumps? This removes evidence useful for blue-screen analysis.") {
                $changesAttempted++
                $freed = Remove-CrashDumps
                $totalReported += $freed
                $dumpRemaining = (Get-PathSize $memoryDump) + (Get-PathSize $miniDump)
                Write-Host ("Reported crash dump space removed: " + (Format-Bytes $freed))
                Write-RepairJournal $action "CRASH_DUMPS" ("Reported removed=" + (Format-Bytes $freed))
                Write-RepairVerification -Action $action -Check "Crash dump cleanup post-state" `
                    -Status $(if($dumpRemaining -eq 0){"VERIFIED"}else{"PARTIAL"}) `
                    -Details ("Measured removed=" + (Format-Bytes $freed) + "; dump data remaining=" + (Format-Bytes $dumpRemaining))
            }
        }
        "5" {
            if (Confirm-RepairAction "Empty the Recycle Bin? Files there may not be recoverable afterward.") {
                $changesAttempted++
                try {
                    Clear-RecycleBin -Force -ErrorAction Stop
                    Write-Host "Recycle Bin cleanup completed."
                    Write-RepairJournal $action "RECYCLE_BIN" "Clear-RecycleBin completed."
                    Write-RepairVerification -Action $action -Check "Recycle Bin cleanup" -Status "PARTIAL" `
                        -Details "Clear-RecycleBin returned without exception; this workflow does not enumerate every user's/all-drive Recycle Bin contents for independent proof."
                }
                catch {
                    Write-Host ("Recycle Bin cleanup failed: " + $_.Exception.Message)
                    Write-RepairJournal $action "RECYCLE_BIN_FAILED" $_.Exception.Message
                    Write-RepairVerification -Action $action -Check "Recycle Bin cleanup" -Status "FAILED" -Details $_.Exception.Message
                }
            }
        }
        "6" {
            if (Confirm-RepairAction "Run conservative temp cleanup plus Delivery Optimization cleanup?") {
                $changesAttempted++
                $a = Remove-OldTempContent $userTemp 48
                $b = Remove-OldTempContent $windowsTemp 48
                $freed = $a + $b
                $totalReported += $freed
                $doOk = Clear-DoCache
                Write-Host ("Reported temp space removed: " + (Format-Bytes $freed))
                Write-RepairJournal $action "CONSERVATIVE_PLUS_DO" ("Reported temp removed=" + (Format-Bytes $freed) + "; DO=" + $doOk)
                Write-RepairVerification -Action $action -Check "Conservative temp + Delivery Optimization cleanup" `
                    -Status $(if($doOk){"PARTIAL"}else{"PARTIAL"}) `
                    -Details ("Temp pre/post measurement verified removed=" + (Format-Bytes $freed) + "; Delivery Optimization cmdlet success=" + $doOk + ". DO cache has no consistent portable size read-back here.")
            }
        }
        "7" {
            $analysis = Show-Analysis
        }
        "0" {
            break
        }
        default {
            Write-Host "Choose 0 through 7."
        }
    }

    if ($choice -eq "0") { break }
}

$driveAfter = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:'" -ErrorAction SilentlyContinue
$freeAfter = [int64]$driveAfter.FreeSpace
$actualDelta = $freeAfter - $freeBefore

$report = @(
    "Safe Free Space Recovery",
    "Computer: " + $env:COMPUTERNAME,
    "Generated: " + (Get-Date),
    "C: free before: " + (Format-Bytes $freeBefore),
    "C: free after: " + (Format-Bytes $freeAfter),
    "C: free-space change during session: " + (Format-Bytes $actualDelta),
    "Reported removed by measurable cleanup functions: " + (Format-Bytes $totalReported),
    "",
    "No Downloads/Documents/Desktop content is targeted by this tool."
)
$report | Set-Content -LiteralPath $logPath -Encoding UTF8

if ($changesAttempted -eq 0) {
    Write-RepairVerification -Action $action -Check "Free-space recovery session" -Status "NOT_APPLICABLE" `
        -Details "No cleanup action was confirmed; analysis only."
}
elseif ($driveAfter -and (Test-Path -LiteralPath $logPath -PathType Leaf)) {
    Write-RepairVerification -Action $action -Check "Free-space post-state measurement" -Status "VERIFIED" `
        -Details ("Cleanup actions attempted=" + $changesAttempted + "; measured C: delta=" + (Format-Bytes $actualDelta) + "; report=" + $logPath)
}
else {
    Write-RepairVerification -Action $action -Check "Free-space post-state measurement" -Status "PARTIAL" `
        -Details "Cleanup actions ran, but the final free-space measurement or session report could not be fully verified."
}

Write-Host ""
Write-Host ("C: free-space change during session: " + (Format-Bytes $actualDelta))
Write-Host ("Session log: " + $logPath)
Write-RepairJournal $action "COMPLETED" ("C free-space delta=" + (Format-Bytes $actualDelta))
exit 0

. "$PSScriptRoot\Repair-Common.ps1"

$action = "Service Recovery"

if (-not (Test-ToolkitAdmin)) {
    Write-Host "Administrator privileges are required."
    Write-RepairJournal $action "BLOCKED" "Not running as Administrator."
    exit 1
}

$logs = Get-ToolkitLogsRoot
$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$session = Join-Path $logs ("SERVICE_RECOVERY_" + $env:COMPUTERNAME + "_" + $stamp)
New-Item -ItemType Directory -Path $session -Force | Out-Null

$inputName = (Read-ToolkitPrompt "Enter the service name, not the display name").Trim()
if ([string]::IsNullOrWhiteSpace($inputName)) {
    Write-Host "No service was selected."
    exit 0
}

$service = Get-Service -Name $inputName -ErrorAction SilentlyContinue
if (-not $service) {
    Write-Host "Service not found by that service name."
    Write-Host "Tip: use Services.msc or the Advanced Services Snapshot to find the internal service name."
    Write-RepairJournal $action "NOT_FOUND" $inputName
    exit 2
}

$name = $service.Name

function Verify-ServiceRunState {
    param([string]$Expected,[string]$Check)
    $verify = Test-RepairServiceState -Name $name -ExpectedState $Expected
    Write-RepairVerification -Action $action -Check $Check `
        -Status $(if($verify.Passed){"VERIFIED"}else{"FAILED"}) `
        -Details ("Expected=" + $Expected + "; actual=" + $verify.Actual + $(if($verify.Error){"; " + $verify.Error}else{""}))
}

function Verify-ServiceStartMode {
    param([string]$Expected,[string]$Check)
    $verify = Test-RepairServiceStartMode -Name $name -ExpectedMode $Expected
    Write-RepairVerification -Action $action -Check $Check `
        -Status $(if($verify.Passed){"VERIFIED"}else{"FAILED"}) `
        -Details ("Expected=" + $Expected + "; actual=" + $verify.Actual + $(if($verify.Error){"; " + $verify.Error}else{""}))
}

function Show-ServiceState {
    $svc = Get-Service -Name $name -ErrorAction SilentlyContinue
    $cim = Get-CimInstance Win32_Service -Filter ("Name='" + $name.Replace("'","''") + "'") -ErrorAction SilentlyContinue

    Write-Host ""
    Write-Host "SERVICE STATE"
    if ($cim) {
        [pscustomobject]@{
            Name=$cim.Name
            DisplayName=$cim.DisplayName
            State=$cim.State
            StartMode=$cim.StartMode
            StartName=$cim.StartName
            PathName=$cim.PathName
            ProcessId=$cim.ProcessId
            ExitCode=$cim.ExitCode
        } | Format-List
    }
    else {
        $svc | Format-List Name,DisplayName,Status,StartType
    }

    Write-Host "Dependencies:"
    @($svc.ServicesDependedOn | Select-Object Name,DisplayName,Status) | Format-Table -AutoSize
    Write-Host "Dependent services:"
    @($svc.DependentServices | Select-Object Name,DisplayName,Status) | Format-Table -AutoSize

    Write-Host "Configured service details:"
    sc.exe qc $name
    Write-Host "Failure/recovery configuration:"
    sc.exe qfailure $name

    $events = Get-WinEvent -FilterHashtable @{LogName="System"; ProviderName="Service Control Manager"; StartTime=(Get-Date).AddDays(-7)} -ErrorAction SilentlyContinue |
        Where-Object { $_.Message -match [regex]::Escape($name) -or $_.Message -match [regex]::Escape($svc.DisplayName) } |
        Select-Object -First 30 TimeCreated,Id,LevelDisplayName,Message
    Write-Host "Recent matching Service Control Manager events:"
    if ($events) { $events | Format-List } else { Write-Host "(No matching events found.)" }

    $stateFile = Join-Path $session ("SERVICE_STATE_" + (Get-Date -Format "HHmmss") + ".txt")
    $capture = @()
    $capture += ($cim | Format-List * | Out-String -Width 220)
    $capture += "`r`nSC QC:`r`n" + ((sc.exe qc $name) | Out-String)
    $capture += "`r`nSC QFAILURE:`r`n" + ((sc.exe qfailure $name) | Out-String)
    $capture += "`r`nRECENT EVENTS:`r`n" + (($events | Format-List | Out-String -Width 220))
    $capture | Set-Content -LiteralPath $stateFile -Encoding UTF8
    Write-Host ("State snapshot: " + $stateFile)
}

Show-ServiceState

while ($true) {
    Write-Host ""
    Write-Host "SERVICE RECOVERY ACTIONS"
    Write-Host "1. Start service."
    Write-Host "2. Restart service."
    Write-Host "3. Stop service."
    Write-Host "4. Set startup type Automatic."
    Write-Host "5. Set startup type Automatic, Delayed Start."
    Write-Host "6. Set startup type Manual."
    Write-Host "7. Set startup type Disabled. Advanced."
    Write-Host "8. Set failure action: restart service after 60 seconds on failure."
    Write-Host "9. Refresh service state."
    Write-Host "0. Return."
    Write-Host ""

    $choice = Read-ToolkitPrompt "Select an option"

    switch ($choice) {
        "1" {
            Write-Host "Starting a service can immediately activate Windows or application functionality."
            if (Confirm-RepairAction ("Start service " + $name + "?")) {
                try {
                    Start-Service -Name $name -ErrorAction Stop
                    Write-Host "Service started."
                    Write-RepairJournal $action "START" ("Service=" + $name)
                    Verify-ServiceRunState "Running" "Service start post-state"
                }
                catch {
                    Write-Host ("Start failed: " + $_.Exception.Message)
                    Write-RepairJournal $action "START_FAILED" ("Service=" + $name + "; " + $_.Exception.Message)
                    Write-RepairVerification -Action $action -Check "Service start post-state" -Status "FAILED" -Details $_.Exception.Message
                }
            }
            else {
                Write-Host "Canceled. No service state was changed."
                Write-RepairJournal $action "START_CANCELED" ("Service=" + $name)
            }
        }
        "2" {
            if (Confirm-RepairAction ("Restart service " + $name + "?")) {
                try {
                    Restart-Service -Name $name -Force -ErrorAction Stop
                    Write-Host "Service restarted."
                    Write-RepairJournal $action "RESTART" ("Service=" + $name)
                    Verify-ServiceRunState "Running" "Service restart post-state"
                }
                catch {
                    Write-Host ("Restart failed: " + $_.Exception.Message)
                    Write-RepairJournal $action "RESTART_FAILED" ("Service=" + $name + "; " + $_.Exception.Message)
                    Write-RepairVerification -Action $action -Check "Service restart post-state" -Status "FAILED" -Details $_.Exception.Message
                }
            }
            else {
                Write-Host "Canceled. No service restart was performed."
                Write-RepairJournal $action "RESTART_CANCELED" ("Service=" + $name)
            }
        }
        "3" {
            Write-Host "Stopping a service can interrupt Windows features or applications."
            if (Confirm-RepairAction ("Stop service " + $name + "?")) {
                try {
                    Stop-Service -Name $name -Force -ErrorAction Stop
                    Write-Host "Service stopped."
                    Write-RepairJournal $action "STOP" ("Service=" + $name)
                    Verify-ServiceRunState "Stopped" "Service stop post-state"
                }
                catch {
                    Write-Host ("Stop failed: " + $_.Exception.Message)
                    Write-RepairJournal $action "STOP_FAILED" ("Service=" + $name + "; " + $_.Exception.Message)
                    Write-RepairVerification -Action $action -Check "Service stop post-state" -Status "FAILED" -Details $_.Exception.Message
                }
            }
            else {
                Write-Host "Canceled. No service stop was performed."
                Write-RepairJournal $action "STOP_CANCELED" ("Service=" + $name)
            }
        }
        "4" {
            if (Confirm-RepairAction ("Set " + $name + " startup type to Automatic?")) {
                try {
                    Set-Service -Name $name -StartupType Automatic -ErrorAction Stop
                    Write-RepairJournal $action "STARTUP_AUTO" ("Service=" + $name)
                    Verify-ServiceStartMode "Auto" "Automatic startup post-state"
                }
                catch {
                    Write-Host ("Startup-type change failed: " + $_.Exception.Message)
                    Write-RepairJournal $action "STARTUP_AUTO_FAILED" ("Service=" + $name + "; " + $_.Exception.Message)
                    Write-RepairVerification -Action $action -Check "Automatic startup post-state" -Status "FAILED" -Details $_.Exception.Message
                }
            }
        }
        "5" {
            if (Confirm-RepairAction ("Set " + $name + " to Automatic Delayed Start?")) {
                sc.exe config $name start= delayed-auto
                $delayedRc = $LASTEXITCODE
                Write-RepairJournal $action "STARTUP_DELAYED_AUTO" ("Service=" + $name + "; ExitCode=" + $delayedRc)
                $modeVerify = Test-RepairServiceStartMode -Name $name -ExpectedMode "Auto"
                $delayedValue = (Get-ItemProperty -LiteralPath ("HKLM:\SYSTEM\CurrentControlSet\Services\" + $name) -Name DelayedAutostart -ErrorAction SilentlyContinue).DelayedAutostart
                $delayedPassed = ($delayedRc -eq 0 -and $modeVerify.Passed -and $delayedValue -eq 1)
                Write-RepairVerification -Action $action -Check "Delayed Automatic startup post-state" `
                    -Status $(if($delayedPassed){"VERIFIED"}else{"FAILED"}) `
                    -Details ("SC exit code=" + $delayedRc + "; StartMode=" + $modeVerify.Actual + "; DelayedAutostart=" + $delayedValue)
            }
        }
        "6" {
            if (Confirm-RepairAction ("Set " + $name + " startup type to Manual?")) {
                try {
                    Set-Service -Name $name -StartupType Manual -ErrorAction Stop
                    Write-RepairJournal $action "STARTUP_MANUAL" ("Service=" + $name)
                    Verify-ServiceStartMode "Manual" "Manual startup post-state"
                }
                catch {
                    Write-Host ("Startup-type change failed: " + $_.Exception.Message)
                    Write-RepairJournal $action "STARTUP_MANUAL_FAILED" ("Service=" + $name + "; " + $_.Exception.Message)
                    Write-RepairVerification -Action $action -Check "Manual startup post-state" -Status "FAILED" -Details $_.Exception.Message
                }
            }
        }
        "7" {
            Write-Host "Disabling the wrong Windows service can break system functionality."
            $exact = Read-ToolkitPrompt ("To confirm disabling this service, type its exact service name " + $name)
            if ($exact -cne $name) {
                Write-Host "Canceled. Exact confirmation did not match; no service configuration was changed."
            }
            else {
                try {
                    Set-Service -Name $name -StartupType Disabled -ErrorAction Stop
                    Write-RepairJournal $action "STARTUP_DISABLED" ("Service=" + $name)
                    Verify-ServiceStartMode "Disabled" "Disabled startup post-state"
                }
                catch {
                    Write-Host ("Disable failed: " + $_.Exception.Message)
                    Write-RepairJournal $action "STARTUP_DISABLED_FAILED" ("Service=" + $name + "; " + $_.Exception.Message)
                    Write-RepairVerification -Action $action -Check "Disabled startup post-state" -Status "FAILED" -Details $_.Exception.Message
                }
            }
        }
        "8" {
            Write-Host "This changes the service Recovery tab behavior."
            Write-Host "First failure: Restart after 60 seconds."
            Write-Host "Second failure: Restart after 60 seconds."
            Write-Host "Later failures: No configured action."
            Write-Host "Failure count resets after 1 day."
            if (Confirm-RepairAction ("Apply these failure actions to " + $name + "?")) {
                sc.exe failure $name reset= 86400 actions= restart/60000
                $failureRc = $LASTEXITCODE
                Write-RepairJournal $action "FAILURE_ACTIONS" ("Service=" + $name + "; ExitCode=" + $failureRc)
                $failureReadBack = ((sc.exe qfailure $name 2>&1) | Out-String -Width 220).Trim()
                $qRc = $LASTEXITCODE
                Write-RepairVerification -Action $action -Check "Service failure-action post-state" `
                    -Status $(if($failureRc -eq 0 -and $qRc -eq 0){"VERIFIED"}else{"FAILED"}) `
                    -Details ("config exit code=" + $failureRc + "; qfailure exit code=" + $qRc + "; read-back=" + $failureReadBack)
            }
        }
        "9" { Show-ServiceState }
        "0" { break }
        default { Write-Host "Choose 0 through 9." }
    }

    if ($choice -eq "0") { break }
}

Show-ServiceState
Write-RepairJournal $action "COMPLETED" ("Service=" + $name + "; Session=" + $session)
exit 0

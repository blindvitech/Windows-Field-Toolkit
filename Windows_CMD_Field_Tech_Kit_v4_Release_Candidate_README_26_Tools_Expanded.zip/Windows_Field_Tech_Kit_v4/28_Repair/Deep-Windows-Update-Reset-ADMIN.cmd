@echo off
setlocal EnableExtensions
title Deep Windows Update Reset

echo Deep Windows Update Reset
echo.
echo Resets Windows Update working data with timestamped rollback copies.
echo It does not delete SoftwareDistribution or catroot2 outright.
net session >nul 2>&1
if errorlevel 1 (
    echo Administrator privileges are required.
    echo Use Home option 4 to relaunch the toolkit as Administrator.
    if "%SRMODE%"=="1" (
        echo Press any key to continue.
        pause >nul
    ) else (
        pause
    )
    exit /b 1
)

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Deep-Windows-Update-Reset.ps1"
set "RC=%errorlevel%"

if "%SRMODE%"=="1" (
    echo.
    echo Deep Windows Update Reset finished with return code %RC%.
    echo Press any key to continue.
    pause >nul
) else (
    echo.
    pause
)

exit /b %RC%

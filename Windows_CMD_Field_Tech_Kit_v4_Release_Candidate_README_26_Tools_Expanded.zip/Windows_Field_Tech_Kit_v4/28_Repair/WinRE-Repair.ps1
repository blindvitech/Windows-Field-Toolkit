. "$PSScriptRoot\Repair-Common.ps1"

$action = "Windows Recovery Environment Repair"

if (-not (Test-ToolkitAdmin)) {
    Write-Host "Administrator privileges are required."
    Write-RepairJournal $action "BLOCKED" "Not running as Administrator."
    exit 1
}

$logs = Get-ToolkitLogsRoot
$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$session = Join-Path $logs ("WINRE_REPAIR_" + $env:COMPUTERNAME + "_" + $stamp)
New-Item -ItemType Directory -Path $session -Force | Out-Null

function Save-WinREState {
    $infoResult = Invoke-ToolkitNativeCommand -FilePath "reagentc.exe" -Arguments @("/info") -Label "REAgentC State Capture" -Action $action -LogPath (Join-Path $session "REAGENTC_INFO_NATIVE.txt") -Quiet
    $infoResult.Output | Tee-Object -FilePath (Join-Path $session "REAGENTC_INFO.txt") | ForEach-Object { Write-Host $_ }
    Get-Partition -ErrorAction SilentlyContinue |
        Select-Object DiskNumber,PartitionNumber,DriveLetter,Type,GptType,@{N="SizeGB";E={[math]::Round($_.Size/1GB,2)}} |
        Export-Csv -LiteralPath (Join-Path $session "PARTITIONS.csv") -NoTypeInformation -Encoding UTF8
}

function Backup-BCD {
    $path = Join-Path $session ("BCD_Backup_" + (Get-Date -Format "HHmmss") + ".bcd")
    $result = Invoke-ToolkitNativeCommand -FilePath "bcdedit.exe" -Arguments @("/export",$path) -Label "BCD Export Before WinRE Change" -Action $action -LogPath (Join-Path $session ("BCD_EXPORT_" + (Get-Date -Format "HHmmssfff") + ".txt")) -Quiet
    $result.Output | ForEach-Object { Write-Host $_ }
    if ($result.ExitCode -eq 0 -and (Test-Path -LiteralPath $path)) {
        Write-Host ("BCD backup: " + $path)
        return $path
    }
    Write-Host "BCD export did not create the expected backup file."
    return ""
}

function Verify-WinREEnabled {
    param([string]$CheckName,[string]$ExpectedPath = "")

    $verifyResult = Invoke-ToolkitNativeCommand -FilePath "reagentc.exe" -Arguments @("/info") -Label "REAgentC Verification" -Action $action -Quiet
    $infoText = (($verifyResult.Output -join [Environment]::NewLine) | Out-String -Width 260).Trim()
    $rc = $verifyResult.ExitCode
    $enabledEnglish = $infoText -match '(?im)^\s*Windows RE status:\s*Enabled\s*$'
    $pathMatched = $true
    if ($ExpectedPath) {
        $pathMatched = $infoText.IndexOf($ExpectedPath,[System.StringComparison]::OrdinalIgnoreCase) -ge 0
    }

    if ($rc -eq 0 -and $enabledEnglish -and $pathMatched) {
        Write-RepairVerification -Action $action -Check $CheckName -Status "VERIFIED" -Details "REAgentC post-state reports Windows RE Enabled."
    }
    elseif ($rc -eq 0 -and $enabledEnglish) {
        Write-RepairVerification -Action $action -Check $CheckName -Status "PARTIAL" -Details ("WinRE is Enabled, but the requested path was not visible in the immediate REAgentC output. " + $infoText)
    }
    elseif ($rc -eq 0) {
        Write-RepairVerification -Action $action -Check $CheckName -Status "PARTIAL" -Details ("REAgentC /info succeeded, but the English 'Enabled' status token could not be confirmed. Output may be localized. " + $infoText)
    }
    else {
        Write-RepairVerification -Action $action -Check $CheckName -Status "FAILED" -Details ("REAgentC /info exit code=" + $rc + ". " + $infoText)
    }
}

function Invoke-ReagentcChecked {
    param(
        [Parameter(Mandatory=$true)][string[]]$Arguments,
        [Parameter(Mandatory=$true)][string]$JournalStep
    )

    $isBootRiskMutation = @($Arguments | Where-Object { $_ -match '(?i)^/(enable|disable|setreimage)$' }).Count -gt 0
    if ($isBootRiskMutation) {
        $guardReason = "Windows Recovery Environment registration changes can alter recovery or boot configuration."
        if (-not (Invoke-BitLockerBootRiskPreflight -Action $action -Reason $guardReason)) {
            Write-Host "WinRE mutation blocked because the BitLocker boot-risk preflight did not pass."
            Write-RepairJournal $action "BITLOCKER_GUARD_BLOCKED" ("JournalStep=" + $JournalStep + "; Arguments=" + ($Arguments -join " "))
            return $false
        }
    }

    $nativeLog = Join-Path $session ("REAGENTC_" + $JournalStep + "_" + (Get-Date -Format "HHmmssfff") + ".txt")
    $result = Invoke-ToolkitNativeCommand -FilePath "reagentc.exe" -Arguments $Arguments -Label ("REAgentC " + $JournalStep) -Action $action -Mutation:$isBootRiskMutation -LogPath $nativeLog -Quiet
    $result.Output | ForEach-Object { Write-Host $_ }

    Write-RepairJournal $action $JournalStep ("Arguments=" + ($Arguments -join " ") + "; ExitCode=" + $result.ExitCode + "; Result=" + $result.Status + "; Session=" + $session)
    if ($result.Status -notin @("SUCCESS","REBOOT_REQUIRED")) {
        Write-Host ("REAgentC did not complete successfully. Result=" + $result.Status + "; exit code=" + $result.ExitCode + ". The remaining steps in this action will not continue automatically.")
        return $false
    }
    return $true
}

Save-WinREState

$defaultRecovery = Join-Path $env:WINDIR "System32\Recovery"
$defaultWim = Join-Path $defaultRecovery "Winre.wim"

Write-Host ""
Write-Host ("Default WinRE image path: " + $defaultWim)
Write-Host ("Image present there: " + (Test-Path -LiteralPath $defaultWim))
Write-Host ("Session folder: " + $session)

while ($true) {
    Write-Host ""
    Write-Host "WINRE REPAIR ACTIONS"
    Write-Host "1. Refresh reagentc /info."
    Write-Host "2. Enable WinRE using the currently registered image/location."
    Write-Host "3. Re-register WinRE from Windows\System32\Recovery, if Winre.wim exists there."
    Write-Host "4. Set a technician-supplied folder containing Winre.wim, then enable WinRE."
    Write-Host "5. Disable then re-enable currently registered WinRE. Advanced."
    Write-Host "0. Return."
    Write-Host ""

    $choice = Read-ToolkitPrompt "Select an option"

    switch ($choice) {
        "1" {
            $refresh = Invoke-ToolkitNativeCommand -FilePath "reagentc.exe" -Arguments @("/info") -Label "REAgentC Refresh" -Action $action
        }
        "2" {
            Backup-BCD | Out-Null
            if (Confirm-RepairAction "Run reagentc /enable using the currently registered configuration?") {
                $ok = Invoke-ReagentcChecked @("/enable") "ENABLE"
                if ($ok) {
                    [void](Invoke-ReagentcChecked @("/info") "INFO_AFTER_ENABLE")
                    Verify-WinREEnabled "WinRE enable post-state"
                }
                else {
                    Write-RepairVerification -Action $action -Check "WinRE enable post-state" -Status "FAILED" -Details "REAgentC /enable failed before post-state verification."
                }
            }
            else {
                Write-Host "Canceled. WinRE was not enabled."
                Write-RepairJournal $action "ENABLE_CANCELED" ""
            }
        }
        "3" {
            if (-not (Test-Path -LiteralPath $defaultWim)) {
                Write-Host ("Winre.wim was not found at " + $defaultWim)
                Write-Host "No re-registration was attempted."
                continue
            }

            Backup-BCD | Out-Null
            Write-Host ("WinRE will be registered from: " + $defaultRecovery)
            if (Confirm-RepairPhrase "This will disable the current WinRE registration, point Windows to the default recovery-image path, and re-enable WinRE." "WINRE") {
                $ok = Invoke-ReagentcChecked @("/disable") "REREGISTER_DEFAULT_DISABLE"
                if ($ok) { $ok = Invoke-ReagentcChecked @("/setreimage","/path",$defaultRecovery) "REREGISTER_DEFAULT_SETREIMAGE" }
                if ($ok) { $ok = Invoke-ReagentcChecked @("/enable") "REREGISTER_DEFAULT_ENABLE" }
                if ($ok) {
                    [void](Invoke-ReagentcChecked @("/info") "REREGISTER_DEFAULT_INFO")
                    Verify-WinREEnabled "WinRE default re-registration post-state"
                }
                else {
                    Write-RepairVerification -Action $action -Check "WinRE default re-registration post-state" -Status "FAILED" -Details "A REAgentC mutation step failed before verification."
                }
                Write-RepairJournal $action "REREGISTER_DEFAULT" ("Path=" + $defaultRecovery + "; Success=" + $ok + "; Session=" + $session)
            }
            else {
                Write-Host "Canceled. WinRE registration was not changed."
                Write-RepairJournal $action "REREGISTER_DEFAULT_CANCELED" ("Path=" + $defaultRecovery)
            }
        }
        "4" {
            $folder = (Read-ToolkitPrompt "Folder containing Winre.wim").Trim().Trim('"')
            if (-not (Test-Path -LiteralPath $folder -PathType Container)) {
                Write-Host "Folder not found."
                continue
            }
            $wim = Join-Path $folder "Winre.wim"
            if (-not (Test-Path -LiteralPath $wim -PathType Leaf)) {
                Write-Host "Winre.wim was not found in that folder."
                continue
            }

            Backup-BCD | Out-Null
            Write-Host ("Selected WinRE image: " + $wim)
            if (Confirm-RepairPhrase "This will change the registered WinRE image location to the selected technician-supplied folder and enable WinRE." "WINRE") {
                $ok = Invoke-ReagentcChecked @("/setreimage","/path",$folder) "SET_CUSTOM_REIMAGE_PATH"
                if ($ok) { $ok = Invoke-ReagentcChecked @("/enable") "SET_CUSTOM_REIMAGE_ENABLE" }
                if ($ok) {
                    [void](Invoke-ReagentcChecked @("/info") "SET_CUSTOM_REIMAGE_INFO")
                    Verify-WinREEnabled "WinRE custom image post-state"
                }
                else {
                    Write-RepairVerification -Action $action -Check "WinRE custom image post-state" -Status "FAILED" -Details "A REAgentC mutation step failed before verification."
                }
                Write-RepairJournal $action "SET_CUSTOM_REIMAGE" ("Path=" + $folder + "; Success=" + $ok + "; Session=" + $session)
            }
            else {
                Write-Host "Canceled. The WinRE image location was not changed."
                Write-RepairJournal $action "SET_CUSTOM_REIMAGE_CANCELED" ("Path=" + $folder)
            }
        }
        "5" {
            Backup-BCD | Out-Null
            Write-Host "This toggles the currently registered WinRE configuration off and back on."
            if (Confirm-RepairPhrase "This will disable and then re-enable the currently registered WinRE configuration." "WINRE") {
                $ok = Invoke-ReagentcChecked @("/disable") "TOGGLE_REGISTRATION_DISABLE"
                if ($ok) { $ok = Invoke-ReagentcChecked @("/enable") "TOGGLE_REGISTRATION_ENABLE" }
                if ($ok) {
                    [void](Invoke-ReagentcChecked @("/info") "TOGGLE_REGISTRATION_INFO")
                    Verify-WinREEnabled "WinRE toggle post-state"
                }
                else {
                    Write-RepairVerification -Action $action -Check "WinRE toggle post-state" -Status "FAILED" -Details "A REAgentC mutation step failed before verification."
                }
                Write-RepairJournal $action "TOGGLE_REGISTRATION" ("Success=" + $ok + "; Session=" + $session)
            }
            else {
                Write-Host "Canceled. WinRE registration was not toggled."
                Write-RepairJournal $action "TOGGLE_REGISTRATION_CANCELED" ""
            }
        }
        "0" { break }
        default { Write-Host "Choose 0 through 5." }
    }

    if ($choice -eq "0") { break }
}

Save-WinREState
Write-RepairJournal $action "COMPLETED" ("Session=" + $session)
exit 0

. "$PSScriptRoot\Repair-Common.ps1"

$action = "Safe Process Investigation"
$logs = Get-ToolkitLogsRoot

Write-Host "Safe Process Investigation"
Write-Host ""
Write-Host "Read-only investigation of a running process."
Write-Host "Administrator rights are not required, but elevation may reveal more details."
Write-Host ""

$inputValue = Read-ToolkitPrompt "Enter a process ID or process name"
if ([string]::IsNullOrWhiteSpace($inputValue)) {
    Write-Host "No process was selected."
    exit 0
}

$proc = $null
if ($inputValue -match '^\d+$') {
    $proc = Get-Process -Id ([int]$inputValue) -ErrorAction SilentlyContinue
}
else {
    $matches = @(Get-Process -Name $inputValue -ErrorAction SilentlyContinue)
    if ($matches.Count -gt 1) {
        Write-Host ""
        Write-Host "Multiple matching processes were found:"
        $matches | Select-Object Id,ProcessName,Path | Format-Table -AutoSize
        $pidChoice = Read-ToolkitPrompt "Enter the PID to investigate"
        if ($pidChoice -match '^\d+$') {
            $proc = Get-Process -Id ([int]$pidChoice) -ErrorAction SilentlyContinue
        }
    }
    elseif ($matches.Count -eq 1) {
        $proc = $matches[0]
    }
}

if (-not $proc) {
    Write-Host "Process not found or access was denied."
    Write-RepairJournal $action "NOT_FOUND" $inputValue
    exit 2
}

$pidValue = $proc.Id
$cim = Get-CimInstance Win32_Process -Filter ("ProcessId=" + $pidValue) -ErrorAction SilentlyContinue
$parent = $null
if ($cim -and $cim.ParentProcessId) {
    $parent = Get-Process -Id $cim.ParentProcessId -ErrorAction SilentlyContinue
}

$owner = ""
if ($cim) {
    try {
        $ownerResult = Invoke-CimMethod -InputObject $cim -MethodName GetOwner -ErrorAction Stop
        if ($ownerResult.ReturnValue -eq 0) {
            $owner = $ownerResult.Domain + "\" + $ownerResult.User
        }
    }
    catch {
    }
}

$path = ""
try { $path = $proc.Path } catch {}
if ([string]::IsNullOrWhiteSpace($path) -and $cim) { $path = $cim.ExecutablePath }

$signature = $null
$hash = $null
if ($path -and (Test-Path -LiteralPath $path)) {
    try { $signature = Get-AuthenticodeSignature -LiteralPath $path } catch {}
    try { $hash = Get-FileHash -LiteralPath $path -Algorithm SHA256 } catch {}
}

$tcp = @(Get-NetTCPConnection -OwningProcess $pidValue -ErrorAction SilentlyContinue |
    Select-Object State,LocalAddress,LocalPort,RemoteAddress,RemotePort)
$udp = @(Get-NetUDPEndpoint -OwningProcess $pidValue -ErrorAction SilentlyContinue |
    Select-Object LocalAddress,LocalPort)

$services = @(Get-CimInstance Win32_Service -Filter ("ProcessId=" + $pidValue) -ErrorAction SilentlyContinue |
    Select-Object Name,DisplayName,State,StartMode)

$modules = @()
try {
    $modules = @($proc.Modules | Select-Object -First 75 ModuleName,FileName,FileVersionInfo)
}
catch {
}

$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$reportPath = Join-Path $logs ("PROCESS_INVESTIGATION_" + $env:COMPUTERNAME + "_PID" + $pidValue + "_" + $stamp + ".txt")

$report = New-Object System.Collections.Generic.List[string]
$report.Add("SAFE PROCESS INVESTIGATION")
$report.Add("Generated: " + (Get-Date))
$report.Add("Computer: " + $env:COMPUTERNAME)
$report.Add("")
$report.Add("Process Name: " + $proc.ProcessName)
$report.Add("PID: " + $pidValue)
$report.Add("Path: " + $path)
$report.Add("Owner: " + $owner)
$report.Add("Start Time: " + $(try { $proc.StartTime } catch { "" }))
$report.Add("CPU Seconds: " + $proc.CPU)
$report.Add("Working Set MB: " + [math]::Round($proc.WorkingSet64 / 1MB,2))
if ($cim) {
    $report.Add("Command Line: " + $cim.CommandLine)
    $report.Add("Parent PID: " + $cim.ParentProcessId)
}
if ($parent) {
    $report.Add("Parent Process: " + $parent.ProcessName)
}
if ($signature) {
    $report.Add("Signature Status: " + $signature.Status)
    $report.Add("Signer: " + $signature.SignerCertificate.Subject)
}
if ($hash) {
    $report.Add("SHA256: " + $hash.Hash)
}
$report.Add("")
$report.Add("TCP Connections:")
$report.Add(($tcp | Format-Table -AutoSize | Out-String -Width 220).TrimEnd())
$report.Add("")
$report.Add("UDP Endpoints:")
$report.Add(($udp | Format-Table -AutoSize | Out-String -Width 220).TrimEnd())
$report.Add("")
$report.Add("Associated Services:")
$report.Add(($services | Format-Table -AutoSize | Out-String -Width 220).TrimEnd())
$report.Add("")
$report.Add("Loaded Modules, first 75 when accessible:")
$report.Add(($modules | Format-Table -AutoSize | Out-String -Width 220).TrimEnd())

$report | Set-Content -LiteralPath $reportPath -Encoding UTF8

Write-Host ""
Write-Host "Process summary:"
Write-Host ("Name: " + $proc.ProcessName)
Write-Host ("PID: " + $pidValue)
Write-Host ("Path: " + $path)
Write-Host ("Owner: " + $owner)
if ($signature) {
    Write-Host ("Signature: " + $signature.Status)
    if ($signature.SignerCertificate) {
        Write-Host ("Signer: " + $signature.SignerCertificate.Subject)
    }
}
if ($hash) {
    Write-Host ("SHA256: " + $hash.Hash)
}
Write-Host ("TCP connections: " + $tcp.Count)
Write-Host ("UDP endpoints: " + $udp.Count)
Write-Host ("Associated services: " + $services.Count)
Write-Host ("Report: " + $reportPath)
Write-Host ""

if ($hash) {
    Write-Host "Optional actions:"
    Write-Host "C. Copy SHA256 hash to clipboard."
    Write-Host "V. Open this SHA256 on VirusTotal."
    Write-Host "Enter. Return without an online lookup."
    $next = Read-ToolkitPrompt "Select an optional action"
    if ($next -match '(?i)^c$') {
        try {
            Set-Clipboard -Value $hash.Hash -ErrorAction Stop
            Write-Host "SHA256 copied to clipboard."
        }
        catch {
            $hash.Hash | clip.exe
            Write-Host "SHA256 copied to clipboard."
        }
    }
    elseif ($next -match '(?i)^v$') {
        $url = "https://www.virustotal.com/gui/file/" + $hash.Hash
        Start-Process $url
        Write-Host "Opened VirusTotal in the default browser."
    }
}

Write-RepairJournal $action "COMPLETED" ("PID=" + $pidValue + "; Process=" + $proc.ProcessName + "; Report=" + $reportPath)
exit 0

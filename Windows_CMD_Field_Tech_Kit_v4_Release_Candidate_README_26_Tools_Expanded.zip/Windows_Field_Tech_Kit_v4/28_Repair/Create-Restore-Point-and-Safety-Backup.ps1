param(
    [switch]$Confirmed
)

. "$PSScriptRoot\Repair-Common.ps1"

$action = "Create Restore Point and Repair Safety Backup"

if (-not (Test-ToolkitAdmin)) {
    Write-Host "Administrator privileges are required."
    Write-RepairJournal $action "BLOCKED" "Not running as Administrator."
    exit 1
}

Write-Host "CREATE RESTORE POINT + REPAIR SAFETY BACKUP"
Write-Host ""
Write-Host "This will attempt to create a Windows System Restore point and export repair-state"
Write-Host "configuration such as BCD, firewall policy, drivers, services, features, updates,"
Write-Host "installed applications, printers, routes, and Winsock information."
Write-Host "It is not a full disk image or user-file backup."
Write-Host ""

if (-not $Confirmed) {
    if (-not (Confirm-RepairAction "Create the restore point and repair safety backup?")) {
        Write-Host "Canceled. No restore point or safety backup was created."
        Write-RepairJournal $action "CANCELED" "User declined safety backup."
        exit 0
    }
}

$logs = Get-ToolkitLogsRoot
$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$dest = Join-Path $logs ("REPAIR_SAFETY_BACKUP_" + $env:COMPUTERNAME + "_" + $stamp)
New-Item -ItemType Directory -Path $dest -Force | Out-Null

Write-Host ("Destination: " + $dest)
Write-Host ""
Write-RepairJournal $action "STARTING" $dest

$summary = New-Object System.Collections.Generic.List[string]
$summary.Add("Repair Safety Backup")
$summary.Add("Computer: " + $env:COMPUTERNAME)
$summary.Add("Generated: " + (Get-Date))
$summary.Add("User: " + $env:USERDOMAIN + "\" + $env:USERNAME)
$summary.Add("")

# Restore point is best-effort and may be restricted by System Restore configuration/frequency.
$rpDescription = "Field Tech Toolkit - Before Repair " + $stamp
$rpStatus = ""
$rpCreated = $false
if (-not (Get-Command Checkpoint-Computer -ErrorAction SilentlyContinue)) {
    $rpStatus = "Restore point was not created: Checkpoint-Computer is unavailable in this Windows/PowerShell context."
}
else {
    try {
        Checkpoint-Computer -Description $rpDescription -RestorePointType "MODIFY_SETTINGS" -ErrorAction Stop
        $rpCreated = $true
        $rpStatus = "Restore point created successfully."
    }
    catch {
        $rpStatus = "Restore point was not created: " + $_.Exception.Message
    }
}
$summary.Add($rpStatus)
$rpStatus | Set-Content -LiteralPath (Join-Path $dest "RESTORE_POINT_STATUS.txt") -Encoding UTF8

# Configuration backups / inventories through the shared native runner.
$bcdPath = Join-Path $dest "BCD_Backup.bcd"
$bcdResult = Invoke-ToolkitNativeCommand -FilePath "bcdedit.exe" -Arguments @("/export",$bcdPath) -Label "BCD Safety Export" -Action $action -LogPath (Join-Path $dest "BCD_EXPORT_NATIVE.txt") -Quiet
$summary.Add("BCD export result: " + $bcdResult.Status + " (exit " + $bcdResult.ExitCode + ").")

$firewallPath = Join-Path $dest "Windows_Firewall_Policy.wfw"
$firewallResult = Invoke-ToolkitNativeCommand -FilePath "netsh.exe" -Arguments @("advfirewall","export",$firewallPath) -Label "Firewall Policy Export" -Action $action -LogPath (Join-Path $dest "FIREWALL_EXPORT_NATIVE.txt") -Quiet
$summary.Add("Firewall policy export result: " + $firewallResult.Status + " (exit " + $firewallResult.ExitCode + ").")

$inventoryCommands = @(
    [pscustomobject]@{File="ipconfig.exe"; Args=@("/all"); Out="IPCONFIG_ALL.txt"; Label="IPConfig All"},
    [pscustomobject]@{File="route.exe"; Args=@("print"); Out="ROUTES.txt"; Label="Route Table"},
    [pscustomobject]@{File="netsh.exe"; Args=@("winsock","show","catalog"); Out="WINSOCK_CATALOG.txt"; Label="Winsock Catalog"},
    [pscustomobject]@{File="driverquery.exe"; Args=@("/v","/fo","csv"); Out="DRIVERS.csv"; Label="Driver Query"},
    [pscustomobject]@{File="sc.exe"; Args=@("query","state=","all"); Out="SERVICES.txt"; Label="Service Query"},
    [pscustomobject]@{File="dism.exe"; Args=@("/online","/Get-Features","/Format:Table"); Out="WINDOWS_FEATURES.txt"; Label="Windows Feature Inventory"}
)

foreach ($item in $inventoryCommands) {
    $nativeLog = Join-Path $dest ("NATIVE_" + ($item.Label -replace '[^A-Za-z0-9_.-]+','_') + ".txt")
    $result = Invoke-ToolkitNativeCommand -FilePath $item.File -Arguments $item.Args -Label $item.Label -Action $action -LogPath $nativeLog -Quiet
    $result.Output | Set-Content -LiteralPath (Join-Path $dest $item.Out) -Encoding UTF8
}

try {
    Get-CimInstance Win32_QuickFixEngineering |
        Select-Object HotFixID,Description,InstalledBy,InstalledOn |
        Sort-Object InstalledOn -Descending |
        Export-Csv -LiteralPath (Join-Path $dest "HOTFIXES.csv") -NoTypeInformation -Encoding UTF8
}
catch {
}

try {
    Get-ItemProperty "HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*",
                     "HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*" |
        Where-Object DisplayName |
        Select-Object DisplayName,DisplayVersion,Publisher,InstallDate |
        Sort-Object DisplayName |
        Export-Csv -LiteralPath (Join-Path $dest "INSTALLED_APPS.csv") -NoTypeInformation -Encoding UTF8
}
catch {
}

try {
    Get-Printer | Select-Object Name,DriverName,PortName,Shared,Published |
        Export-Csv -LiteralPath (Join-Path $dest "PRINTERS.csv") -NoTypeInformation -Encoding UTF8
}
catch {
}

$summary.Add("")
$summary.Add("This is a repair-state/configuration backup, not a full disk image or user-file backup.")
$summary | Set-Content -LiteralPath (Join-Path $dest "README_BACKUP.txt") -Encoding UTF8

$requiredBackupFiles = @(
    "README_BACKUP.txt","RESTORE_POINT_STATUS.txt","IPCONFIG_ALL.txt","ROUTES.txt",
    "WINSOCK_CATALOG.txt","DRIVERS.csv","SERVICES.txt","WINDOWS_FEATURES.txt"
)
$missingBackupFiles = @($requiredBackupFiles | Where-Object {
    $candidate = Join-Path $dest $_
    if (-not (Test-Path -LiteralPath $candidate -PathType Leaf)) {
        $true
    }
    else {
        try { (Get-Item -LiteralPath $candidate -ErrorAction Stop).Length -le 0 } catch { $true }
    }
})
if ($missingBackupFiles.Count -eq 0) {
    Write-RepairVerification -Action $action -Check "Repair safety backup artifacts" -Status "VERIFIED" `
        -Details ("Required backup artifacts present: " + $requiredBackupFiles.Count + ". Backup=" + $dest)
}
else {
    Write-RepairVerification -Action $action -Check "Repair safety backup artifacts" -Status "FAILED" `
        -Details ("Missing required backup artifacts: " + ($missingBackupFiles -join ", "))
}

if ($rpCreated) {
    if (Get-Command Get-ComputerRestorePoint -ErrorAction SilentlyContinue) {
        try {
            $rpMatch = @(Get-ComputerRestorePoint -ErrorAction Stop | Where-Object Description -eq $rpDescription | Select-Object -First 1)
            if ($rpMatch) {
                Write-RepairVerification -Action $action -Check "System Restore point" -Status "VERIFIED" `
                    -Details ("Restore point is visible in System Restore inventory: " + $rpDescription)
            }
            else {
                Write-RepairVerification -Action $action -Check "System Restore point" -Status "PARTIAL" `
                    -Details "Checkpoint-Computer returned successfully, but the new restore point was not found in the immediate inventory query."
            }
        }
        catch {
            Write-RepairVerification -Action $action -Check "System Restore point" -Status "PARTIAL" `
                -Details ("Checkpoint-Computer returned successfully, but restore-point inventory verification failed: " + $_.Exception.Message)
        }
    }
    else {
        Write-RepairVerification -Action $action -Check "System Restore point" -Status "PARTIAL" `
            -Details "Checkpoint-Computer returned successfully; Get-ComputerRestorePoint is unavailable for independent read-back verification."
    }
}
else {
    Write-RepairVerification -Action $action -Check "System Restore point" -Status "PARTIAL" -Details $rpStatus
}

Write-Host ""
Write-Host $rpStatus
Write-Host "Configuration backup complete."
Write-Host ("Saved to: " + $dest)
Write-Host "This is not a full system image or user-data backup."
Write-RepairJournal $action "COMPLETED" ($rpStatus + " Backup=" + $dest)
exit 0

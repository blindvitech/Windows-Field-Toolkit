. "$PSScriptRoot\Repair-Common.ps1"

$action = "Disk and File-System Health Repair"

if (-not (Test-ToolkitAdmin)) {
    Write-Host "Administrator privileges are required."
    Write-RepairJournal $action "BLOCKED" "Not running as Administrator."
    exit 1
}

$logs = Get-ToolkitLogsRoot
$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$logPath = Join-Path $logs ("DISK_FILESYSTEM_HEALTH_" + $env:COMPUTERNAME + "_" + $stamp + ".txt")
$repairAttempted = $false

function Show-DiskHealth {
    $report = New-Object System.Collections.Generic.List[string]
    $report.Add("DISK / FILE-SYSTEM HEALTH")
    $report.Add("Generated: " + (Get-Date))
    $report.Add("")

    Write-Host ""
    Write-Host "Physical disks:"
    $physical = Get-PhysicalDisk -ErrorAction SilentlyContinue |
        Select-Object FriendlyName,MediaType,BusType,HealthStatus,OperationalStatus,@{N="SizeGB";E={[math]::Round($_.Size/1GB,2)}}
    if ($physical) {
        $physical | Format-Table -AutoSize
        $report.Add(($physical | Format-Table -AutoSize | Out-String -Width 220).TrimEnd())
    }
    else {
        Write-Host "(Physical disk data unavailable.)"
        $report.Add("(Physical disk data unavailable.)")
    }

    Write-Host ""
    Write-Host "Reliability counters:"
    $reliability = @()
    try {
        $reliability = Get-PhysicalDisk | Get-StorageReliabilityCounter |
            Select-Object DeviceId,Temperature,TemperatureMax,ReadErrorsTotal,WriteErrorsTotal,Wear,PowerOnHours
    }
    catch {}
    if ($reliability) {
        $reliability | Format-Table -AutoSize
        $report.Add("")
        $report.Add("Reliability counters:")
        $report.Add(($reliability | Format-Table -AutoSize | Out-String -Width 220).TrimEnd())
    }
    else {
        Write-Host "(Reliability counters unavailable for one or more storage devices.)"
        $report.Add("")
        $report.Add("(Reliability counters unavailable.)")
    }

    Write-Host ""
    Write-Host "Volumes:"
    $vols = Get-Volume -ErrorAction SilentlyContinue |
        Select-Object DriveLetter,FileSystemLabel,FileSystem,HealthStatus,OperationalStatus,
            @{N="SizeGB";E={[math]::Round($_.Size/1GB,2)}},
            @{N="FreeGB";E={[math]::Round($_.SizeRemaining/1GB,2)}}
    $vols | Format-Table -AutoSize
    $report.Add("")
    $report.Add("Volumes:")
    $report.Add(($vols | Format-Table -AutoSize | Out-String -Width 220).TrimEnd())

    $report.Add("")
    $report.Add("Dirty-bit queries:")
    Write-Host ""
    Write-Host "Dirty-bit status:"
    foreach ($v in $vols | Where-Object DriveLetter) {
        $letter = [string]$v.DriveLetter
        $dirty = cmd.exe /d /c ("fsutil dirty query " + $letter + ":") 2>&1 | Out-String
        Write-Host ($dirty.TrimEnd())
        $report.Add($dirty.TrimEnd())
    }

    $events = Get-WinEvent -FilterHashtable @{LogName="System"; StartTime=(Get-Date).AddDays(-7); Level=1,2,3} -ErrorAction SilentlyContinue |
        Where-Object { $_.ProviderName -match '(?i)(disk|ntfs|storahci|stornvme|volmgr|volsnap)' } |
        Select-Object -First 100 TimeCreated,Id,ProviderName,LevelDisplayName,Message

    Write-Host ""
    Write-Host "Recent storage/file-system warnings and errors, last 7 days:"
    if ($events) {
        $events | Format-Table -Wrap -AutoSize
        $report.Add("")
        $report.Add("Recent storage/file-system events:")
        $report.Add(($events | Format-List | Out-String -Width 220).TrimEnd())
    }
    else {
        Write-Host "(No matching warning/error events found.)"
        $report.Add("")
        $report.Add("(No matching warning/error events found.)")
    }

    $report | Set-Content -LiteralPath $logPath -Encoding UTF8
    Write-Host ""
    Write-Host ("Snapshot saved to: " + $logPath)
}

Show-DiskHealth

while ($true) {
    Write-Host ""
    Write-Host "DISK / FILE-SYSTEM ACTIONS"
    Write-Host "1. Run online CHKDSK scan on a drive letter. Read-only scan."
    Write-Host "2. Run Repair-Volume Scan on a drive letter. Read-only scan."
    Write-Host "3. Run CHKDSK /F on a drive letter. Windows may require a reboot or dismount."
    Write-Host "4. Refresh health snapshot."
    Write-Host "0. Return."
    Write-Host ""

    $choice = Read-ToolkitPrompt "Select an option"
    if ($choice -eq "0") { break }

    if ($choice -in @("1","2","3")) {
        $letter = (Read-ToolkitPrompt "Drive letter, for example C").Trim().TrimEnd(":")
        if ($letter -notmatch '^[A-Za-z]$') {
            Write-Host "Enter one drive letter only."
            continue
        }
        $letter = $letter.ToUpper()
    }

    switch ($choice) {
        "1" {
            Write-RepairJournal $action "SCAN_START" ("chkdsk " + $letter + ": /scan")
            $scanResult = Invoke-ToolkitNativeCommand -FilePath "chkdsk.exe" -Arguments @(($letter + ":"),"/scan") -Label ("CHKDSK Scan " + $letter + ":") -Action $action
            $rc = $scanResult.ExitCode
            Write-RepairJournal $action "SCAN_END" ("Drive=" + $letter + ": ExitCode=" + $rc + "; Result=" + $scanResult.Status)
        }
        "2" {
            if (-not (Get-Command Repair-Volume -ErrorAction SilentlyContinue)) {
                Write-Host "Repair-Volume is unavailable in this Windows/PowerShell context."
                Write-RepairJournal $action "REPAIR_VOLUME_SCAN_UNAVAILABLE" ("Drive=" + $letter + ":")
                continue
            }
            Write-RepairJournal $action "REPAIR_VOLUME_SCAN_START" ("Drive=" + $letter + ":")
            try {
                $result = Repair-Volume -DriveLetter $letter -Scan -ErrorAction Stop
                Write-Host ("Repair-Volume result: " + $result)
                Write-RepairJournal $action "REPAIR_VOLUME_SCAN_END" ("Drive=" + $letter + ": Result=" + $result)
            }
            catch {
                Write-Host ("Repair-Volume scan failed: " + $_.Exception.Message)
                Write-RepairJournal $action "REPAIR_VOLUME_SCAN_FAILED" $_.Exception.Message
            }
        }
        "3" {
            Write-Host ""
            Write-Host "CHKDSK /F can modify file-system metadata."
            Write-Host "For an in-use volume, Windows may ask to dismount it or schedule the repair for reboot."
            if (Confirm-RepairPhrase ("CHKDSK /F can modify file-system metadata on " + $letter + ": and may require a dismount or reboot.") "FIX") {
                $repairAttempted = $true
                Write-RepairJournal $action "CHKDSK_F_START" ("Drive=" + $letter + ":")
                $repairResult = Invoke-ToolkitNativeCommand -FilePath "chkdsk.exe" -Arguments @(($letter + ":"),"/f") -Label ("CHKDSK Repair " + $letter + ":") -Action $action -Mutation
                $rc = $repairResult.ExitCode
                Write-Host ("CHKDSK /F finished with exit code " + $rc + ".")
                Write-RepairJournal $action "CHKDSK_F_END" ("Drive=" + $letter + ": ExitCode=" + $rc + "; Result=" + $repairResult.Status)

                $dirtyAfter = ((cmd.exe /d /c ("fsutil dirty query " + $letter + ":") 2>&1) | Out-String -Width 220).Trim()
                $scheduleAfter = ((cmd.exe /d /c ("chkntfs " + $letter + ":") 2>&1) | Out-String -Width 220).Trim()
                if ($rc -eq 0 -and $dirtyAfter -match '(?i)is NOT Dirty') {
                    Write-RepairVerification -Action $action -Check ("CHKDSK /F post-state " + $letter + ":") -Status "VERIFIED" `
                        -Details ("File system reports not dirty after repair. " + $dirtyAfter)
                }
                elseif ($rc -eq 0 -and $scheduleAfter -match '(?i)(scheduled|next reboot|next restart)') {
                    Write-RepairVerification -Action $action -Check ("CHKDSK /F post-state " + $letter + ":") -Status "PENDING_REBOOT" `
                        -Details ("Windows indicates a scheduled/reboot-dependent file-system check. Dirty query=" + $dirtyAfter + "; CHKNTFS=" + $scheduleAfter)
                }
                elseif ($rc -eq 0) {
                    Write-RepairVerification -Action $action -Check ("CHKDSK /F post-state " + $letter + ":") -Status "PARTIAL" `
                        -Details ("CHKDSK returned 0, but the immediate clean-state read-back was inconclusive or localized. Dirty query=" + $dirtyAfter + "; CHKNTFS=" + $scheduleAfter)
                }
                else {
                    Write-RepairVerification -Action $action -Check ("CHKDSK /F post-state " + $letter + ":") -Status "FAILED" `
                        -Details ("CHKDSK exit code=" + $rc + "; Dirty query=" + $dirtyAfter + "; CHKNTFS=" + $scheduleAfter)
                }
            }
            else {
                Write-Host "Canceled. No file-system repair was started."
                Write-RepairJournal $action "CHKDSK_F_CANCELED" ("Drive=" + $letter + ":")
            }
        }
        "4" { Show-DiskHealth }
        default { if ($choice -ne "0") { Write-Host "Choose 0 through 4." } }
    }
}

if (-not $repairAttempted) {
    Write-RepairVerification -Action $action -Check "Disk/file-system repair session" -Status "NOT_APPLICABLE" `
        -Details "No CHKDSK /F repair was confirmed; only health/scan actions were used."
}
Write-RepairJournal $action "COMPLETED" ("Snapshot=" + $logPath)
exit 0

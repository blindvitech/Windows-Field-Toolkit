@echo off
setlocal EnableExtensions
title Service Recovery

echo Service Recovery
echo.
echo Inspects dependencies, configuration, failure actions, and recent Service Control Manager events first.
echo Changes are selected individually and logged.
net session >nul 2>&1
if errorlevel 1 (
    echo Administrator privileges are required.
    echo Use Home option 4 to relaunch the toolkit as Administrator.
    if "%SRMODE%"=="1" (
        echo Press any key to continue.
        pause >nul
    ) else (
        pause
    )
    exit /b 1
)

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Service-Recovery.ps1"
set "RC=%errorlevel%"

if "%SRMODE%"=="1" (
    echo.
    echo Service Recovery finished with return code %RC%.
    echo Press any key to continue.
    pause >nul
) else (
    echo.
    pause
)

exit /b %RC%

@echo off
setlocal EnableExtensions
title Create Restore Point and Repair Safety Backup

echo Create Restore Point and Repair Safety Backup
echo.
echo Creates a best-effort System Restore point plus a configuration safety backup.
echo This is NOT a full disk image or user-file backup.
net session >nul 2>&1
if errorlevel 1 (
    echo Administrator privileges are required.
    echo Use Home option 4 to relaunch the toolkit as Administrator.
    if "%SRMODE%"=="1" (
        echo Press any key to continue.
        pause >nul
    ) else (
        pause
    )
    exit /b 1
)

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Create-Restore-Point-and-Safety-Backup.ps1"
set "RC=%errorlevel%"

if "%SRMODE%"=="1" (
    echo.
    echo Create Restore Point and Repair Safety Backup finished with return code %RC%.
    echo Press any key to continue.
    pause >nul
) else (
    echo.
    pause
)

exit /b %RC%

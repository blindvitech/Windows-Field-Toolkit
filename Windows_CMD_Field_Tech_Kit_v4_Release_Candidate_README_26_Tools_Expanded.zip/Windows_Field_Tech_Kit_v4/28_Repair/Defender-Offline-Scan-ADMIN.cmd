@echo off
setlocal EnableExtensions
title Microsoft Defender Offline Scan

echo Microsoft Defender Offline Scan
echo.
echo WARNING: This can reboot Windows to run an offline malware scan.
echo Save open work before continuing.
net session >nul 2>&1
if errorlevel 1 (
    echo Administrator privileges are required.
    echo Use Home option 4 to relaunch the toolkit as Administrator.
    if "%SRMODE%"=="1" (
        echo Press any key to continue.
        pause >nul
    ) else (
        pause
    )
    exit /b 1
)

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Defender-Offline-Scan.ps1"
set "RC=%errorlevel%"

exit /b %RC%

. "$PSScriptRoot\Repair-Common.ps1"

$action = "Microsoft Defender Offline Scan"

if (-not (Test-ToolkitAdmin)) {
    Write-Host "Administrator privileges are required."
    Write-RepairJournal $action "BLOCKED" "Not running as Administrator."
    exit 1
}

Write-Host "Microsoft Defender Offline Scan"
Write-Host ""
Write-Host "This uses the built-in Windows Defender Offline environment."
Write-Host "Windows will reboot to perform the scan if the request is accepted."
Write-Host "Save open work before continuing."
Write-Host ""

$status = Get-MpComputerStatus -ErrorAction SilentlyContinue
if ($status) {
    Write-Host ("Antivirus enabled: " + $status.AntivirusEnabled)
    Write-Host ("Real-time protection: " + $status.RealTimeProtectionEnabled)
    Write-Host ("Signature version: " + $status.AntivirusSignatureVersion)
    Write-Host ("Signature last updated: " + $status.AntivirusSignatureLastUpdated)
    Write-Host ""
}

if (-not (Get-Command Start-MpWDOScan -ErrorAction SilentlyContinue)) {
    Write-Host "Start-MpWDOScan is not available on this Windows installation."
    Write-RepairJournal $action "FAILED" "Start-MpWDOScan cmdlet unavailable."
    exit 2
}

if (-not (Confirm-RepairPhrase "Defender Offline may reboot Windows immediately. Save all open work before continuing." "REBOOT")) {
    Write-Host "Canceled. No changes were made and no offline scan was started."
    Write-RepairJournal $action "CANCELED" "User declined typed REBOOT confirmation."
    exit 0
}

Write-RepairJournal $action "STARTING" "Offline scan requested; reboot expected."
Write-Host ""
Write-Host "Requesting Defender Offline Scan now. Windows may reboot immediately."

try {
    Start-MpWDOScan
    Write-RepairJournal $action "REQUESTED" "Start-MpWDOScan returned without exception."
    Write-RepairVerification -Action $action -Check "Defender Offline scan request" -Status "PENDING_REBOOT" `
        -Details "The request was accepted without exception. The actual offline scan and its result can only be verified after the reboot/scan cycle completes."
    exit 0
}
catch {
    Write-Host ("Defender Offline Scan request failed: " + $_.Exception.Message)
    Write-RepairJournal $action "FAILED" $_.Exception.Message
    Write-RepairVerification -Action $action -Check "Defender Offline scan request" -Status "FAILED" -Details $_.Exception.Message
    exit 3
}

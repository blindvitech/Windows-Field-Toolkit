@echo off
setlocal EnableExtensions
title Safe Process Investigation

echo Safe Process Investigation
echo.
echo Read-only process inspection: path, owner, command line, signature, SHA256, connections, services, and modules.
echo Optional VirusTotal lookup uses the SHA256 hash only.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Safe-Process-Investigation.ps1"
set "RC=%errorlevel%"

if "%SRMODE%"=="1" (
    echo.
    echo Safe Process Investigation finished with return code %RC%.
    echo Press any key to continue.
    pause >nul
) else (
    echo.
    pause
)

exit /b %RC%

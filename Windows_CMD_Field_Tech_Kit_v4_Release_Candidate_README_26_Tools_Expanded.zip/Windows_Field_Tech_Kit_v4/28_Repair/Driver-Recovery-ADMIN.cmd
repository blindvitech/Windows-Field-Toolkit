@echo off
setlocal EnableExtensions
title Driver Recovery

echo Driver Recovery
echo.
echo Backs up/inventories drivers first, then offers rescan, restart, reinstall, or selected OEM package removal.
echo Driver removal requires exact package-name confirmation and does not use /force.
net session >nul 2>&1
if errorlevel 1 (
    echo Administrator privileges are required.
    echo Use Home option 4 to relaunch the toolkit as Administrator.
    if "%SRMODE%"=="1" (
        echo Press any key to continue.
        pause >nul
    ) else (
        pause
    )
    exit /b 1
)

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Driver-Recovery.ps1"
set "RC=%errorlevel%"

if "%SRMODE%"=="1" (
    echo.
    echo Driver Recovery finished with return code %RC%.
    echo Press any key to continue.
    pause >nul
) else (
    echo.
    pause
)

exit /b %RC%

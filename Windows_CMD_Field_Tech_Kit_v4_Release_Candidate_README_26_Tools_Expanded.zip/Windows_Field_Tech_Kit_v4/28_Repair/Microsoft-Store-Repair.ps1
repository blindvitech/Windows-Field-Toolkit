. "$PSScriptRoot\Repair-Common.ps1"

$action = "Microsoft Store Repair"

if (-not (Test-ToolkitAdmin)) {
    Write-Host "Administrator privileges are required."
    Write-RepairJournal $action "BLOCKED" "Not running as Administrator."
    exit 1
}

Write-Host "Microsoft Store Repair"
Write-Host ""
Write-Host "This repair is limited to the Microsoft Store package and Store cache."
Write-Host "It does not re-register every AppX package on the computer."
Write-Host ""
Write-Host "Planned steps:"
Write-Host "1. Run WSReset."
Write-Host "2. Reset the Microsoft.WindowsStore app package when supported."
Write-Host "3. Re-register only the Microsoft Store package manifest."
Write-Host ""

if (-not (Confirm-RepairAction "Continue with Microsoft Store repair?")) {
    Write-Host "Canceled. No changes were made."
    Write-RepairJournal $action "CANCELED" "User declined repair."
    exit 0
}

Write-RepairJournal $action "STARTING" "WSReset + Store package reset/re-register."

$failures = New-Object System.Collections.Generic.List[string]

try {
    Write-Host ""
    Write-Host "Running WSReset..."
    Start-Process -FilePath "wsreset.exe" -Wait
}
catch {
    $failures.Add("WSReset: " + $_.Exception.Message)
}

$pkg = Get-AppxPackage -AllUsers -Name "Microsoft.WindowsStore" -ErrorAction SilentlyContinue | Select-Object -First 1
if (-not $pkg) {
    $failures.Add("Microsoft.WindowsStore package not found.")
}
else {
    if (Get-Command Reset-AppxPackage -ErrorAction SilentlyContinue) {
        try {
            Write-Host "Resetting Microsoft Store package..."
            $pkg | Reset-AppxPackage -ErrorAction Stop
        }
        catch {
            $failures.Add("Reset-AppxPackage: " + $_.Exception.Message)
        }
    }

    try {
        Write-Host "Re-registering Microsoft Store package..."
        $manifest = Join-Path $pkg.InstallLocation "AppxManifest.xml"
        if (Test-Path -LiteralPath $manifest) {
            Add-AppxPackage -DisableDevelopmentMode -Register $manifest -ErrorAction Stop
        }
        else {
            $failures.Add("Store AppxManifest.xml not found.")
        }
    }
    catch {
        $failures.Add("Store re-registration: " + $_.Exception.Message)
    }
}

Write-Host ""
$verifyPkg = Get-AppxPackage -AllUsers -Name "Microsoft.WindowsStore" -ErrorAction SilentlyContinue | Select-Object -First 1
$verifyManifest = $null
if ($verifyPkg -and $verifyPkg.InstallLocation) {
    $verifyManifest = Join-Path $verifyPkg.InstallLocation "AppxManifest.xml"
}
if ($verifyPkg -and $verifyManifest -and (Test-Path -LiteralPath $verifyManifest -PathType Leaf)) {
    Write-RepairVerification -Action $action -Check "Microsoft Store package registration" -Status "VERIFIED" `
        -Details ("Package present after repair; manifest exists at " + $verifyManifest)
}
elseif ($verifyPkg) {
    Write-RepairVerification -Action $action -Check "Microsoft Store package registration" -Status "PARTIAL" `
        -Details "Store package is present after repair, but its manifest could not be independently confirmed."
}
else {
    Write-RepairVerification -Action $action -Check "Microsoft Store package registration" -Status "FAILED" `
        -Details "Microsoft.WindowsStore package was not found after the repair attempt."
}

if ($failures.Count -eq 0) {
    Write-Host "Microsoft Store repair completed without reported errors."
    Write-RepairJournal $action "COMPLETED" "No reported errors."
    exit 0
}

Write-Host "Microsoft Store repair completed with one or more warnings:"
$failures | ForEach-Object { Write-Host (" - " + $_) }
Write-RepairJournal $action "COMPLETED_WITH_WARNINGS" ($failures -join " | ")
exit 2

. "$PSScriptRoot\Repair-Common.ps1"

$action = "Deep Windows Update Reset"

if (-not (Test-ToolkitAdmin)) {
    Write-Host "Administrator privileges are required."
    Write-RepairJournal $action "BLOCKED" "Not running as Administrator."
    exit 1
}

$logs = Get-ToolkitLogsRoot
$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$backup = Join-Path $logs ("WINDOWS_UPDATE_RESET_" + $env:COMPUTERNAME + "_" + $stamp)
New-Item -ItemType Directory -Path $backup -Force | Out-Null

$services = @("bits","wuauserv","cryptsvc","msiserver")
$serviceState = foreach ($name in $services) {
    Get-CimInstance Win32_Service -Filter ("Name='" + $name + "'") -ErrorAction SilentlyContinue |
        Select-Object Name,State,StartMode,PathName
}
$serviceState | Export-Csv -LiteralPath (Join-Path $backup "SERVICES_BEFORE.csv") -NoTypeInformation -Encoding UTF8

try {
    Get-ItemProperty "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" -ErrorAction SilentlyContinue |
        Format-List * | Out-String -Width 220 |
        Set-Content -LiteralPath (Join-Path $backup "WINDOWS_UPDATE_POLICY.txt") -Encoding UTF8
}
catch {}

Write-Host "DEEP WINDOWS UPDATE RESET"
Write-Host ""
Write-Host "This resets local Windows Update working data while preserving rollback copies."
Write-Host ""
Write-Host "Planned actions:"
Write-Host "- Stop BITS, Windows Update, Cryptographic Services, and Windows Installer."
Write-Host "- Rename SoftwareDistribution instead of deleting it."
Write-Host "- Rename catroot2 instead of deleting it."
Write-Host "- Rename BITS qmgr database files when present."
Write-Host "- Restore each service to its pre-reset running/stopped state when possible."
Write-Host "- Preserve the configured startup mode; this tool does not change service startup types."
Write-Host "- Save before/after service state and a repair journal entry."
Write-Host ""
Write-Host ("Backup/log folder: " + $backup)
Write-Host ""

if (-not (Confirm-RepairPhrase "This will stop update-related services and rename Windows Update working data to rollback copies." "RESET")) {
    Write-Host "Canceled. No Windows Update working data was reset."
    Write-RepairJournal $action "CANCELED" ("Typed RESET confirmation declined. Backup folder=" + $backup)
    exit 0
}

Write-RepairJournal $action "STARTING" ("Backup=" + $backup)

foreach ($name in $services) {
    try {
        Stop-Service -Name $name -Force -ErrorAction Stop
        Write-Host ("Stopped " + $name)
    }
    catch {
        Write-Host ("Could not stop " + $name + ": " + $_.Exception.Message)
    }
}

$softwareDistribution = Join-Path $env:WINDIR "SoftwareDistribution"
$catroot2 = Join-Path $env:WINDIR "System32\catroot2"
$qmgrDir = Join-Path $env:ProgramData "Microsoft\Network\Downloader"
$resetFailures = New-Object System.Collections.Generic.List[string]
$renamedPaths = New-Object System.Collections.Generic.List[string]

function Rename-ResetPath {
    param([string]$Path,[string]$Label)
    if (-not (Test-Path -LiteralPath $Path)) {
        Write-Host ($Label + " not found; nothing to rename.")
        return ""
    }

    $parent = Split-Path $Path -Parent
    $leaf = Split-Path $Path -Leaf
    $newLeaf = $leaf + ".FieldTechBackup." + $stamp
    try {
        Rename-Item -LiteralPath $Path -NewName $newLeaf -ErrorAction Stop
        $newPath = Join-Path $parent $newLeaf
        Write-Host ($Label + " renamed to " + $newLeaf)
        return $newPath
    }
    catch {
        $resetFailures.Add($Label + " rename failed: " + $_.Exception.Message)
        Write-Host ($Label + " rename failed: " + $_.Exception.Message)
        return ""
    }
}

$sdBackup = Rename-ResetPath $softwareDistribution "SoftwareDistribution"
if ($sdBackup) { $renamedPaths.Add($sdBackup) }
$catBackup = Rename-ResetPath $catroot2 "catroot2"
if ($catBackup) { $renamedPaths.Add($catBackup) }

if (Test-Path -LiteralPath $qmgrDir) {
    Get-ChildItem -LiteralPath $qmgrDir -Filter "qmgr*.dat" -File -ErrorAction SilentlyContinue | ForEach-Object {
        $newName = $_.Name + ".FieldTechBackup." + $stamp
        try {
            Rename-Item -LiteralPath $_.FullName -NewName $newName -ErrorAction Stop
            $renamedPaths.Add((Join-Path $_.DirectoryName $newName))
            Write-Host ("Renamed BITS database file " + $_.Name)
        }
        catch {
            $resetFailures.Add("Could not rename " + $_.Name + ": " + $_.Exception.Message)
            Write-Host ("Could not rename " + $_.Name + ": " + $_.Exception.Message)
        }
    }
}

Write-Host ""
Write-Host "Restoring update-service running/stopped state from the pre-reset snapshot..."
foreach ($name in $services) {
    $before = @($serviceState | Where-Object Name -eq $name | Select-Object -First 1)
    if (-not $before) {
        Write-Host ("No pre-reset service state was captured for " + $name + "; leaving current state unchanged.")
        continue
    }

    if ($before.State -eq "Running") {
        try {
            Start-Service -Name $name -ErrorAction Stop
            Write-Host ("Restored " + $name + " to Running.")
        }
        catch {
            Write-Host ("Could not restore " + $name + " to Running: " + $_.Exception.Message)
        }
    }
    else {
        try {
            $current = Get-Service -Name $name -ErrorAction Stop
            if ($current.Status -ne "Stopped") {
                Stop-Service -Name $name -Force -ErrorAction Stop
            }
            Write-Host ("Restored " + $name + " to Stopped.")
        }
        catch {
            Write-Host ("Could not restore " + $name + " to Stopped: " + $_.Exception.Message)
        }
    }
}

$after = foreach ($name in $services) {
    Get-CimInstance Win32_Service -Filter ("Name='" + $name + "'") -ErrorAction SilentlyContinue |
        Select-Object Name,State,StartMode,PathName
}
$after | Export-Csv -LiteralPath (Join-Path $backup "SERVICES_AFTER.csv") -NoTypeInformation -Encoding UTF8

$serviceMismatches = New-Object System.Collections.Generic.List[string]
foreach ($before in $serviceState) {
    if (-not $before.Name) { continue }
    $current = Get-Service -Name $before.Name -ErrorAction SilentlyContinue
    if (-not $current) {
        $serviceMismatches.Add($before.Name + " unavailable after reset")
        continue
    }
    $expected = if ($before.State -eq "Running") { "Running" } else { "Stopped" }
    if ([string]$current.Status -ne $expected) {
        $serviceMismatches.Add($before.Name + " expected=" + $expected + " actual=" + $current.Status)
    }
}
$missingRollbackCopies = @($renamedPaths | Where-Object { -not (Test-Path -LiteralPath $_) })
if ($resetFailures.Count -eq 0 -and $serviceMismatches.Count -eq 0 -and $missingRollbackCopies.Count -eq 0) {
    Write-RepairVerification -Action $action -Check "Windows Update reset post-state" -Status "VERIFIED" `
        -Details ("Rollback copies verified=" + $renamedPaths.Count + "; service states restored=" + $serviceState.Count)
}
else {
    $verifyDetails = @()
    if ($resetFailures.Count -gt 0) { $verifyDetails += ("reset failures=" + ($resetFailures -join " | ")) }
    if ($serviceMismatches.Count -gt 0) { $verifyDetails += ("service mismatches=" + ($serviceMismatches -join " | ")) }
    if ($missingRollbackCopies.Count -gt 0) { $verifyDetails += ("missing rollback copies=" + ($missingRollbackCopies -join ", ")) }
    Write-RepairVerification -Action $action -Check "Windows Update reset post-state" -Status "PARTIAL" `
        -Details ($verifyDetails -join "; ")
}

Write-Host ""
Write-Host "Deep Windows Update reset completed."
Write-Host "Windows will recreate fresh working folders as needed."
Write-Host ("Rollback copies remain beside the original Windows Update folders with timestamped FieldTechBackup names.")
Write-Host ("Log folder: " + $backup)
Write-RepairJournal $action "COMPLETED" ("Backup=" + $backup)
exit 0

@echo off
setlocal EnableExtensions
title BitLocker Protection Control

echo BitLocker Protection Control
echo.
echo Read-only status plus controlled temporary suspension or resume of the OS volume.
echo Recovery passwords are never displayed or written to toolkit logs.
net session >nul 2>&1
if errorlevel 1 (
    echo Administrator privileges are required.
    echo Use Home option 4 to relaunch the toolkit as Administrator.
    if "%SRMODE%"=="1" (
        echo Press any key to continue.
        pause >nul
    ) else (
        pause
    )
    exit /b 1
)

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0BitLocker-Protection-Control.ps1" -ScreenReaderMode "%SRMODE%"
set "RC=%errorlevel%"

if "%SRMODE%"=="1" (
    echo.
    echo BitLocker Protection Control finished with return code %RC%.
    echo Press any key to continue.
    pause >nul
) else (
    echo.
    pause
)

exit /b %RC%

param(
    [string]$ScreenReaderMode = ""
)

. "$PSScriptRoot\Repair-Common.ps1"

$ErrorActionPreference = "Continue"
$ProgressPreference = "SilentlyContinue"

$action = "BitLocker Protection Control"
$screenReaderEnabled = (
    $ScreenReaderMode -eq "1" -or
    $env:SRMODE -eq "1" -or
    $env:FIELDTECH_SCREEN_READER -eq "1"
)
if ($screenReaderEnabled) {
    $env:SRMODE = "1"
}


if (-not (Test-ToolkitAdmin)) {
    Write-Host "Administrator privileges are required."
    Write-RepairJournal $action "BLOCKED" "Not running as Administrator."
    exit 1
}

$required = @("Get-BitLockerVolume","Suspend-BitLocker","Resume-BitLocker")
$missing = @()
foreach ($name in $required) {
    if (-not (Get-Command $name -ErrorAction SilentlyContinue)) {
        $missing += $name
    }
}

if ($missing.Count -gt 0) {
    Write-Host "BitLocker PowerShell support is not available on this Windows installation."
    Write-Host ("Missing command(s): " + ($missing -join ", "))
    Write-Host "No BitLocker changes were made."
    Write-RepairVerification $action "BitLocker command availability" "NOT_APPLICABLE" ("Missing=" + ($missing -join ","))
    exit 2
}

$mountPoint = [string]$env:SystemDrive
if ([string]::IsNullOrWhiteSpace($mountPoint)) {
    $mountPoint = "C:"
}

function Get-OsBitLockerState {
    try {
        return Get-BitLockerVolume -MountPoint $script:mountPoint -ErrorAction Stop
    }
    catch {
        return $null
    }
}

function Get-ProtectorTypes {
    param($Volume)

    $types = @()
    if ($Volume -and $Volume.KeyProtector) {
        foreach ($kp in $Volume.KeyProtector) {
            $name = [string]$kp.KeyProtectorType
            if (-not [string]::IsNullOrWhiteSpace($name)) {
                $types += $name
            }
        }
    }
    return @($types | Sort-Object -Unique)
}

function Get-BitLockerAssessment {
    param($Volume)

    if (-not $Volume) { return "UNKNOWN" }

    $volumeStatus = [string]$Volume.VolumeStatus
    $protection = [string]$Volume.ProtectionStatus
    $types = Get-ProtectorTypes $Volume
    $hasRecovery = @($types | Where-Object { $_ -eq "RecoveryPassword" }).Count -gt 0

    if ($volumeStatus -eq "FullyDecrypted") {
        return "UNPROTECTED"
    }

    if ($protection -eq "Off" -and $volumeStatus -ne "FullyDecrypted") {
        return "ATTENTION - PROTECTION SUSPENDED"
    }

    if ($protection -eq "On" -and -not $hasRecovery) {
        return "ATTENTION - NO RECOVERY PROTECTOR DETECTED"
    }

    if ($protection -eq "On" -and $volumeStatus -eq "FullyEncrypted") {
        return "HEALTHY"
    }

    if ($volumeStatus -match '(?i)Progress|Encrypt|Decrypt') {
        return "TRANSITIONING"
    }

    return "ATTENTION"
}

function Show-BitLockerStatus {
    $v = Get-OsBitLockerState

    Write-Host ""
    if ($script:screenReaderEnabled) {
        Write-Host "BitLocker operating system volume status."
    }
    else {
        Write-Host "BITLOCKER OS VOLUME STATUS"
    }

    if (-not $v) {
        Write-Host ("OS Volume ............. " + $script:mountPoint)
        Write-Host "Status ................ Unable to query BitLocker state."
        Write-Host "No recovery material was requested or displayed."
        return $null
    }

    $types = Get-ProtectorTypes $v
    $hasRecovery = @($types | Where-Object { $_ -eq "RecoveryPassword" }).Count -gt 0
    $hasTpm = @($types | Where-Object { $_ -match '(?i)^Tpm' }).Count -gt 0

    Write-Host ("OS Volume ............. " + $v.MountPoint)
    Write-Host ("Volume Status ......... " + $v.VolumeStatus)
    Write-Host ("Encryption ............ " + $v.EncryptionPercentage + "%")
    Write-Host ("Encryption Method ..... " + $v.EncryptionMethod)
    Write-Host ("Protection ............ " + $v.ProtectionStatus)
    Write-Host ("Lock Status ........... " + $v.LockStatus)
    Write-Host ("TPM Protector ......... " + $(if ($hasTpm) { "PRESENT" } else { "NOT DETECTED" }))
    Write-Host ("Recovery Protector .... " + $(if ($hasRecovery) { "PRESENT" } else { "NOT DETECTED" }))
    Write-Host ("Protector Types ....... " + $(if ($types.Count -gt 0) { $types -join ", " } else { "None detected" }))
    Write-Host ("Assessment ............ " + (Get-BitLockerAssessment $v))
    Write-Host "Recovery passwords are not displayed or logged by this tool."

    return $v
}

function Invoke-TemporarySuspend {
    param(
        [Parameter(Mandatory=$true)]
        [ValidateRange(1,3)]
        [int]$RebootCount
    )

    $before = Show-BitLockerStatus
    if (-not $before) {
        Write-Host ""
        Write-Host "Unable to verify BitLocker state. Suspension is blocked."
        Write-RepairJournal $action "BLOCKED" "Unable to query OS-volume BitLocker state."
        return
    }

    $volumeStatus = [string]$before.VolumeStatus
    $protection = [string]$before.ProtectionStatus

    if ($volumeStatus -eq "FullyDecrypted") {
        Write-Host ""
        Write-Host "The OS volume is fully decrypted. There is no BitLocker protection to suspend."
        Write-RepairVerification $action "Temporary suspend eligibility" "NOT_APPLICABLE" "OS volume is FullyDecrypted."
        return
    }

    if ($protection -eq "Off") {
        Write-Host ""
        Write-Host "BitLocker protection is already off or suspended on the OS volume."
        Write-Host "No additional suspension was applied."
        Write-RepairVerification $action "Temporary suspend eligibility" "PARTIAL" "ProtectionStatus is already Off; no mutation performed."
        return
    }

    $types = Get-ProtectorTypes $before
    $hasRecovery = @($types | Where-Object { $_ -eq "RecoveryPassword" }).Count -gt 0

    Write-Host ""
    Write-Host "BITLOCKER TEMPORARY SUSPEND"
    Write-Host ("Target: " + $script:mountPoint + " operating system volume")
    Write-Host ("Duration: next " + $RebootCount + $(if ($RebootCount -eq 1) { " reboot" } else { " reboots" }))
    Write-Host "Encryption state: UNCHANGED"
    Write-Host "Boot protection: TEMPORARILY SUSPENDED"
    Write-Host "Maximum configured duration in this toolkit: 3 reboots"
    Write-Host "Rollback: AVAILABLE - Resume BitLocker"
    Write-Host "Verification: REQUIRED"

    if (-not $hasRecovery) {
        Write-Host ""
        Write-Host "WARNING: No Recovery Password protector was detected."
        Write-Host "This toolkit has NOT verified that usable recovery material exists elsewhere."
    }

    Write-Host ""
    Write-Host "BitLocker remains encrypted, but boot protection will be temporarily relaxed."
    Write-Host "If another reboot is already pending, the next restart can consume one of the selected reboots."
    Write-Host ""

    if (-not (Confirm-RepairPhrase "Confirm temporary BitLocker suspension." "SUSPEND")) {
        Write-Host "Canceled. BitLocker protection was not changed."
        Write-RepairJournal $action "CANCELED" ("Suspend request canceled; RebootCount=" + $RebootCount)
        return
    }

    try {
        Write-RepairJournal $action "START" ("Suspend OS volume; MountPoint=" + $script:mountPoint + "; RebootCount=" + $RebootCount + "; RecoveryProtectorDetected=" + $hasRecovery)
        Suspend-BitLocker -MountPoint $script:mountPoint -RebootCount $RebootCount -ErrorAction Stop | Out-Null
    }
    catch {
        Write-Host ("Suspend-BitLocker failed: " + $_.Exception.Message)
        Write-RepairVerification $action "Temporary BitLocker suspend" "FAILED" ("RebootCount=" + $RebootCount + "; Error=" + $_.Exception.Message)
        return
    }

    Start-Sleep -Milliseconds 500
    $after = Get-OsBitLockerState

    if ($after -and [string]$after.ProtectionStatus -eq "Off" -and [string]$after.VolumeStatus -ne "FullyDecrypted") {
        Write-RepairVerification $action "Temporary BitLocker suspend" "VERIFIED" ("ProtectionStatus=Off; RequestedRebootCount=" + $RebootCount + "; Encryption remains " + $after.VolumeStatus)
    }
    elseif ($after) {
        Write-RepairVerification $action "Temporary BitLocker suspend" "PARTIAL" ("RequestedRebootCount=" + $RebootCount + "; ProtectionStatus=" + $after.ProtectionStatus + "; VolumeStatus=" + $after.VolumeStatus)
    }
    else {
        Write-RepairVerification $action "Temporary BitLocker suspend" "PARTIAL" ("Suspend command completed but post-state could not be queried; RequestedRebootCount=" + $RebootCount)
    }

    [void](Show-BitLockerStatus)
}

function Invoke-ResumeProtection {
    $before = Show-BitLockerStatus
    if (-not $before) {
        Write-Host ""
        Write-Host "Unable to verify BitLocker state. Resume is blocked."
        Write-RepairJournal $action "BLOCKED" "Unable to query OS-volume BitLocker state."
        return
    }

    if ([string]$before.VolumeStatus -eq "FullyDecrypted") {
        Write-Host ""
        Write-Host "The OS volume is fully decrypted. There is no BitLocker protection to resume."
        Write-RepairVerification $action "Resume BitLocker eligibility" "NOT_APPLICABLE" "OS volume is FullyDecrypted."
        return
    }

    if ([string]$before.ProtectionStatus -eq "On") {
        Write-Host ""
        Write-Host "BitLocker protection is already ON. No change is needed."
        Write-RepairVerification $action "Resume BitLocker" "VERIFIED" "ProtectionStatus was already On."
        return
    }

    Write-Host ""
    Write-Host "RESUME BITLOCKER NOW"
    Write-Host ("Target: " + $script:mountPoint + " operating system volume")
    Write-Host "This will end the temporary suspension early and restore BitLocker boot protection."

    if (-not (Confirm-RepairAction "Resume BitLocker protection now?")) {
        Write-Host "Canceled. BitLocker protection was not changed."
        Write-RepairJournal $action "CANCELED" "Resume request canceled."
        return
    }

    try {
        Write-RepairJournal $action "START" ("Resume OS volume; MountPoint=" + $script:mountPoint)
        Resume-BitLocker -MountPoint $script:mountPoint -ErrorAction Stop | Out-Null
    }
    catch {
        Write-Host ("Resume-BitLocker failed: " + $_.Exception.Message)
        Write-RepairVerification $action "Resume BitLocker" "FAILED" ("Error=" + $_.Exception.Message)
        return
    }

    Start-Sleep -Milliseconds 500
    $after = Get-OsBitLockerState

    if ($after -and [string]$after.ProtectionStatus -eq "On") {
        Write-RepairVerification $action "Resume BitLocker" "VERIFIED" ("ProtectionStatus=On; VolumeStatus=" + $after.VolumeStatus)
    }
    elseif ($after) {
        Write-RepairVerification $action "Resume BitLocker" "PARTIAL" ("ProtectionStatus=" + $after.ProtectionStatus + "; VolumeStatus=" + $after.VolumeStatus)
    }
    else {
        Write-RepairVerification $action "Resume BitLocker" "PARTIAL" "Resume command completed but post-state could not be queried."
    }

    [void](Show-BitLockerStatus)
}

Write-RepairJournal $action "SESSION_START" ("MountPoint=" + $mountPoint + "; ScreenReaderMode=" + $screenReaderEnabled)

while ($true) {
    [void](Show-BitLockerStatus)
    Write-Host ""

    if ($screenReaderEnabled) {
        Write-Host "BitLocker Protection Control menu."
        Write-Host "Option 1. Refresh BitLocker status. Read-only."
        Write-Host "Option 2. Temporarily suspend BitLocker protection for one reboot. State-changing."
        Write-Host "Option 3. Temporarily suspend BitLocker protection for two reboots. State-changing."
        Write-Host "Option 4. Temporarily suspend BitLocker protection for three reboots. State-changing. This is the toolkit maximum."
        Write-Host "Option 5. Resume BitLocker protection now. State-changing."
        Write-Host "Type 99, B, BACK, or RETURN to return to the Repair menu."
        Write-Host "Type Q, QUIT, EXIT, or X to return to the Repair menu."
    }
    else {
        Write-Host "BITLOCKER PROTECTION CONTROL"
        Write-Host " 1. Refresh status. READ-ONLY."
        Write-Host " 2. Suspend for 1 reboot."
        Write-Host " 3. Suspend for 2 reboots."
        Write-Host " 4. Suspend for 3 reboots. MAXIMUM."
        Write-Host " 5. Resume BitLocker now."
        Write-Host "99 / B / BACK / RETURN. Back to Repair menu."
        Write-Host "Q / QUIT / EXIT / X. Back to Repair menu."
    }

    Write-Host ""
    $choice = (Read-ToolkitPrompt "Select an option").Trim()

    if ($choice -match '(?i)^(99|B|BACK|RETURN|Q|QUIT|EXIT|X)$') {
        if ($screenReaderEnabled) {
            Write-Host "Returning to the toolkit Repair menu."
        }
        break
    }

    switch ($choice) {
        "1" { continue }
        "2" { Invoke-TemporarySuspend -RebootCount 1 }
        "3" { Invoke-TemporarySuspend -RebootCount 2 }
        "4" { Invoke-TemporarySuspend -RebootCount 3 }
        "5" { Invoke-ResumeProtection }
        default { Write-Host "Choose 1 through 5, or use 99, B, BACK, RETURN, Q, QUIT, EXIT, or X." }
    }
}

Write-RepairJournal $action "SESSION_END" ("MountPoint=" + $mountPoint)
exit 0

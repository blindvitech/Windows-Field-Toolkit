@echo off
setlocal EnableExtensions
title Safe Free Space Recovery

echo Safe Free Space Recovery
echo.
echo Analyzes and selectively cleans safe Windows storage targets.
echo It never targets Downloads, Documents, or Desktop files.
net session >nul 2>&1
if errorlevel 1 (
    echo Administrator privileges are required.
    echo Use Home option 4 to relaunch the toolkit as Administrator.
    if "%SRMODE%"=="1" (
        echo Press any key to continue.
        pause >nul
    ) else (
        pause
    )
    exit /b 1
)

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Safe-Free-Space-Recovery.ps1"
set "RC=%errorlevel%"

if "%SRMODE%"=="1" (
    echo.
    echo Safe Free Space Recovery finished with return code %RC%.
    echo Press any key to continue.
    pause >nul
) else (
    echo.
    pause
)

exit /b %RC%

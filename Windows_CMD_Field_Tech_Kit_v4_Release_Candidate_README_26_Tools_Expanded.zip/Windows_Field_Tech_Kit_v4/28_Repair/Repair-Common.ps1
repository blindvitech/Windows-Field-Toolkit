$screenReaderCommon = Join-Path (Split-Path $PSScriptRoot -Parent) "00_Common\ScreenReader-Common.ps1"
if (Test-Path -LiteralPath $screenReaderCommon -PathType Leaf) {
    . $screenReaderCommon
}
else {
    function Test-ToolkitScreenReaderMode { return ($env:SRMODE -eq "1" -or $env:FIELDTECH_SCREEN_READER -eq "1") }
    function Write-SRAnnouncement { param([string]$Message); if (Test-ToolkitScreenReaderMode) { Write-Host $Message } }
    function Read-ToolkitPrompt {
        param([string]$Prompt = "")
        if ($Prompt) { return Microsoft.PowerShell.Utility\Read-Host $Prompt }
        return Microsoft.PowerShell.Utility\Read-Host
    }
}

$foundationCommon = Join-Path (Split-Path $PSScriptRoot -Parent) "00_Common\Foundation-Common.ps1"
if (Test-Path -LiteralPath $foundationCommon -PathType Leaf) {
    . $foundationCommon
}
else {
    throw "Required toolkit foundation helper is missing: $foundationCommon"
}

$ToolkitRuntimeContext = Initialize-ToolkitRuntimeContext
$repairCallerScript = [string]$MyInvocation.ScriptName
$repairCallerLeaf = $(if ($repairCallerScript) { Split-Path $repairCallerScript -Leaf } else { "" })
$ToolkitRepairProcessMarker = ""
if ($repairCallerLeaf -ine "Safe-Process-Investigation.ps1") {
    $ToolkitRepairProcessMarker = Initialize-ToolkitRepairProcess -CallerScript $repairCallerScript
}
$script:ToolkitOperationIds = @{}

$ErrorActionPreference = "Continue"
$ProgressPreference = "SilentlyContinue"

function Test-ToolkitAdmin {
    try {
        $id = [Security.Principal.WindowsIdentity]::GetCurrent()
        $p = New-Object Security.Principal.WindowsPrincipal($id)
        return $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    }
    catch {
        return $false
    }
}

function Get-ToolkitLogsRoot {
    return Get-ToolkitLogRoot
}

function Get-RepairOperationId {
    param([Parameter(Mandatory=$true)][string]$Action)

    if (-not $script:ToolkitOperationIds.ContainsKey($Action)) {
        $script:ToolkitOperationIds[$Action] = [guid]::NewGuid().ToString("N")
    }
    return [string]$script:ToolkitOperationIds[$Action]
}

function Write-RepairJournal {
    param(
        [Parameter(Mandatory=$true)][string]$Action,
        [Parameter(Mandatory=$true)][string]$Status,
        [string]$Details = ""
    )

    $operationId = Get-RepairOperationId -Action $Action
    $sessionId = Get-ToolkitSessionId
    $cleanDetails = ($Details -replace "[\r\n]+"," ")

    try {
        $logs = Get-ToolkitLogsRoot
        $journal = Join-Path $logs "REPAIR_SESSION_JOURNAL.txt"
        $caseContext = Get-ToolkitCaseContext
        $caseId = $(if ($caseContext.CaseId) { [string]$caseContext.CaseId } else { "" })
        $line = "{0} | Session={1} | Operation={2} | Case={3} | Computer={4} | User={5}\{6} | Action={7} | Status={8} | Details={9}" -f `
            (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $sessionId, $operationId, $caseId, $env:COMPUTERNAME, $env:USERDOMAIN, $env:USERNAME, `
            $Action, $Status, $cleanDetails
        Add-Content -LiteralPath $journal -Value $line -Encoding UTF8
    }
    catch {
    }

    Write-ToolkitOperationLedger -Action $Action -Event $Status -OperationId $operationId -Details $cleanDetails

    if ($Status -match '(?i)^(COMPLETED|COMPLETED_WITH_WARNINGS|CANCELED|FAILED|BLOCKED|SESSION_END)$') {
        [void]$script:ToolkitOperationIds.Remove($Action)
    }
}


function Confirm-RepairAction {
    param([Parameter(Mandatory=$true)][string]$Prompt)

    while ($true) {
        $answer = Read-ToolkitPrompt ($Prompt + " Type Y for yes or N for no")
        if ($answer -match '(?i)^y(?:es)?$') { return $true }
        if ($answer -match '(?i)^n(?:o)?$') { return $false }
        Write-Host "Please type Y or N."
    }
}


function Confirm-RepairPhrase {
    param(
        [Parameter(Mandatory=$true)][string]$Prompt,
        [Parameter(Mandatory=$true)][string]$Phrase
    )

    Write-Host $Prompt
    Write-Host ("To continue, type " + $Phrase + " exactly.")
    $answer = Read-ToolkitPrompt "Confirmation"
    return ($answer -ceq $Phrase)
}

function Invoke-BitLockerBootRiskPreflight {
    param(
        [Parameter(Mandatory=$true)][string]$Action,
        [Parameter(Mandatory=$true)][string]$Reason
    )

    $mountPoint = [string]$env:SystemDrive
    if ([string]::IsNullOrWhiteSpace($mountPoint)) {
        $mountPoint = "C:"
    }

    Write-Host ""
    Write-Host "BITLOCKER BOOT-RISK PREFLIGHT"
    Write-Host ("Target ................. " + $mountPoint + " operating system volume")
    Write-Host ("Reason ................. " + $Reason)
    Write-Host "This check never displays or logs BitLocker recovery passwords."

    $getBitLocker = Get-Command Get-BitLockerVolume -ErrorAction SilentlyContinue
    $suspendBitLocker = Get-Command Suspend-BitLocker -ErrorAction SilentlyContinue

    if (-not $getBitLocker -or -not $suspendBitLocker) {
        Write-Host ""
        Write-Host "BitLocker PowerShell status/suspend support is unavailable."
        Write-Host "The toolkit cannot safely determine or suspend the OS-volume protection state."
        Write-Host "The boot-sensitive action is blocked by default."
        Write-Host ""
        if (Confirm-RepairPhrase "Only continue if you independently verified BitLocker handling for this machine." "RISK") {
            Write-RepairJournal $Action "BITLOCKER_PREFLIGHT_BYPASS" "BitLocker cmdlets unavailable; technician entered RISK."
            Write-Host "BitLocker preflight bypass accepted. No BitLocker changes were made by the toolkit."
            return $true
        }

        Write-Host "Canceled. The boot-sensitive action was not started."
        Write-RepairJournal $Action "BITLOCKER_PREFLIGHT_BLOCKED" "BitLocker cmdlets unavailable; no bypass."
        return $false
    }

    $volume = $null
    try {
        $volume = Get-BitLockerVolume -MountPoint $mountPoint -ErrorAction Stop
    }
    catch {
        Write-Host ""
        Write-Host ("BitLocker status could not be queried: " + $_.Exception.Message)
        Write-Host "The boot-sensitive action is blocked by default."
        Write-Host ""
        if (Confirm-RepairPhrase "Only continue if you independently verified BitLocker handling for this machine." "RISK") {
            Write-RepairJournal $Action "BITLOCKER_PREFLIGHT_BYPASS" "BitLocker query failed; technician entered RISK."
            Write-Host "BitLocker preflight bypass accepted. No BitLocker changes were made by the toolkit."
            return $true
        }

        Write-Host "Canceled. The boot-sensitive action was not started."
        Write-RepairJournal $Action "BITLOCKER_PREFLIGHT_BLOCKED" "BitLocker query failed; no bypass."
        return $false
    }

    $volumeStatus = [string]$volume.VolumeStatus
    $protectionStatus = [string]$volume.ProtectionStatus

    $protectorTypes = @()
    if ($volume.KeyProtector) {
        foreach ($protector in $volume.KeyProtector) {
            $typeName = [string]$protector.KeyProtectorType
            if (-not [string]::IsNullOrWhiteSpace($typeName)) {
                $protectorTypes += $typeName
            }
        }
    }
    $protectorTypes = @($protectorTypes | Sort-Object -Unique)
    $hasRecoveryPasswordProtector = @($protectorTypes | Where-Object { $_ -eq "RecoveryPassword" }).Count -gt 0

    Write-Host ("Volume Status .......... " + $volumeStatus)
    Write-Host ("Encryption ............. " + $volume.EncryptionPercentage + "%")
    Write-Host ("Protection ............. " + $protectionStatus)
    Write-Host ("Recovery Protector ..... " + $(if ($hasRecoveryPasswordProtector) { "PRESENT" } else { "NOT DETECTED" }))

    if ($volumeStatus -eq "FullyDecrypted") {
        Write-Host "BitLocker is not protecting this OS volume. No suspension is required."
        Write-RepairJournal $Action "BITLOCKER_PREFLIGHT_PASS" "OS volume FullyDecrypted; no suspension required."
        return $true
    }

    if ($protectionStatus -eq "Off") {
        Write-Host "BitLocker protection is already OFF or suspended. No additional suspension was applied."
        Write-RepairJournal $Action "BITLOCKER_PREFLIGHT_PASS" ("ProtectionStatus=Off; VolumeStatus=" + $volumeStatus)
        return $true
    }

    if ($protectionStatus -ne "On") {
        Write-Host ""
        Write-Host ("BitLocker protection state is not safely classifiable: " + $protectionStatus)
        Write-Host "The boot-sensitive action is blocked."
        Write-RepairJournal $Action "BITLOCKER_PREFLIGHT_BLOCKED" ("Unclassified ProtectionStatus=" + $protectionStatus)
        return $false
    }

    if (-not $hasRecoveryPasswordProtector) {
        Write-Host ""
        Write-Host "WARNING: No Recovery Password protector was detected."
        Write-Host "The toolkit has NOT verified that usable recovery material exists elsewhere."
    }

    Write-Host ""
    Write-Host "This action can affect boot or recovery configuration."
    Write-Host "Temporarily suspending BitLocker reduces the chance of an unexpected recovery prompt."
    Write-Host "Encryption remains in place while protection is suspended."
    Write-Host ""
    Write-Host "Choose the temporary suspension duration:"
    Write-Host "1. One reboot"
    Write-Host "2. Two reboots"
    Write-Host "3. Three reboots - toolkit maximum"
    Write-Host "0. Cancel the boot-sensitive action"
    Write-Host ""

    $choice = (Read-ToolkitPrompt "Suspension reboot count").Trim()
    if ($choice -notmatch '^[1-3]$') {
        Write-Host "Canceled. BitLocker was not changed and the boot-sensitive action was not started."
        Write-RepairJournal $Action "BITLOCKER_PREFLIGHT_CANCELED" ("Selection=" + $choice)
        return $false
    }

    $rebootCount = [int]$choice

    Write-Host ""
    Write-Host ("BitLocker will be suspended for the next " + $rebootCount + $(if ($rebootCount -eq 1) { " reboot." } else { " reboots." }))
    Write-Host "Maximum configured duration: 3 reboots."
    Write-Host "Encryption state: UNCHANGED."
    Write-Host "Resume BitLocker Now remains available from Repair item 14."

    if (-not (Confirm-RepairPhrase "Confirm temporary BitLocker suspension before this boot-sensitive action." "SUSPEND")) {
        Write-Host "Canceled. BitLocker was not changed and the boot-sensitive action was not started."
        Write-RepairJournal $Action "BITLOCKER_PREFLIGHT_CANCELED" ("RebootCount=" + $rebootCount + "; typed confirmation failed.")
        return $false
    }

    try {
        Write-RepairJournal $Action "BITLOCKER_SUSPEND_START" ("MountPoint=" + $mountPoint + "; RebootCount=" + $rebootCount + "; Reason=" + $Reason + "; RecoveryProtectorDetected=" + $hasRecoveryPasswordProtector)
        Suspend-BitLocker -MountPoint $mountPoint -RebootCount $rebootCount -ErrorAction Stop | Out-Null
    }
    catch {
        Write-Host ("Suspend-BitLocker failed: " + $_.Exception.Message)
        Write-RepairVerification $Action "BitLocker boot-risk preflight" "FAILED" ("Suspend failed; RebootCount=" + $rebootCount + "; Error=" + $_.Exception.Message)
        return $false
    }

    Start-Sleep -Milliseconds 500

    $after = $null
    try {
        $after = Get-BitLockerVolume -MountPoint $mountPoint -ErrorAction Stop
    }
    catch {
    }

    if ($after -and [string]$after.ProtectionStatus -eq "Off" -and [string]$after.VolumeStatus -ne "FullyDecrypted") {
        Write-RepairVerification $Action "BitLocker boot-risk preflight" "VERIFIED" ("ProtectionStatus=Off; RequestedRebootCount=" + $rebootCount + "; Encryption remains " + $after.VolumeStatus)
        return $true
    }

    if ($after) {
        Write-RepairVerification $Action "BitLocker boot-risk preflight" "FAILED" ("Suspend command returned but ProtectionStatus=" + $after.ProtectionStatus + "; boot-sensitive action blocked.")
    }
    else {
        Write-RepairVerification $Action "BitLocker boot-risk preflight" "FAILED" "Suspend command returned but post-state could not be verified; boot-sensitive action blocked."
    }

    return $false
}


function Get-DirectorySizeBytes {
    param([string]$Path)

    if (-not (Test-Path -LiteralPath $Path)) {
        return [int64]0
    }

    try {
        return [int64]((Get-ChildItem -LiteralPath $Path -Force -File -Recurse -ErrorAction SilentlyContinue |
            Measure-Object -Property Length -Sum).Sum)
    }
    catch {
        return [int64]0
    }
}

function Format-Bytes {
    param([int64]$Bytes)
    $sign = ""
    $value = [int64]$Bytes
    if ($value -lt 0) {
        $sign = "-"
        $value = [math]::Abs($value)
    }
    if ($value -ge 1TB) { return ($sign + ("{0:N2} TB" -f ($value / 1TB))) }
    if ($value -ge 1GB) { return ($sign + ("{0:N2} GB" -f ($value / 1GB))) }
    if ($value -ge 1MB) { return ($sign + ("{0:N2} MB" -f ($value / 1MB))) }
    if ($value -ge 1KB) { return ($sign + ("{0:N2} KB" -f ($value / 1KB))) }
    return ($sign + ("{0} bytes" -f $value))
}


function Write-RepairVerification {
    param(
        [Parameter(Mandatory=$true)][string]$Action,
        [Parameter(Mandatory=$true)][string]$Check,
        [Parameter(Mandatory=$true)]
        [ValidateSet("VERIFIED","PARTIAL","FAILED","PENDING_REBOOT","NOT_APPLICABLE")]
        [string]$Status,
        [string]$Details = ""
    )

    $cleanDetails = ($Details -replace "[\r\n]+"," ").Trim()
    Write-Host ("Verification [" + $Status + "]: " + $Check)
    if ($cleanDetails) {
        Write-Host ("  " + $cleanDetails)
    }
    $verificationEvent = "VERIFY_" + $Status
    Write-RepairJournal $Action $verificationEvent ("Check=" + $Check + "; " + $cleanDetails)
    if ($Status -ne "NOT_APPLICABLE") {
        Write-ToolkitMutationLedger -Action $Action -Event $verificationEvent -OperationId (Get-RepairOperationId -Action $Action) -Details ("Check=" + $Check + "; " + $cleanDetails)
    }

    $resultState = switch ($Status) {
        "VERIFIED" { "SUCCESS" }
        "PARTIAL" { "PARTIAL" }
        "FAILED" { "FAILED" }
        "PENDING_REBOOT" { "REBOOT_REQUIRED" }
        "NOT_APPLICABLE" { "UNSUPPORTED" }
        default { "PARTIAL" }
    }

    $result = New-ToolkitResult -Status $resultState -Operation ($Action + " - " + $Check) -Details $cleanDetails
    Write-ToolkitResult $result
}

function Test-RepairServiceState {
    param(
        [Parameter(Mandatory=$true)][string]$Name,
        [Parameter(Mandatory=$true)][ValidateSet("Running","Stopped")][string]$ExpectedState
    )

    try {
        $svc = Get-Service -Name $Name -ErrorAction Stop
        return [pscustomobject]@{
            Passed = ([string]$svc.Status -eq $ExpectedState)
            Actual = [string]$svc.Status
            Error = ""
        }
    }
    catch {
        return [pscustomobject]@{Passed=$false;Actual="Unavailable";Error=$_.Exception.Message}
    }
}

function Test-RepairServiceStartMode {
    param(
        [Parameter(Mandatory=$true)][string]$Name,
        [Parameter(Mandatory=$true)][string]$ExpectedMode
    )

    try {
        $escaped = $Name.Replace("'","''")
        $svc = Get-CimInstance Win32_Service -Filter ("Name='" + $escaped + "'") -ErrorAction Stop
        return [pscustomobject]@{
            Passed = ([string]$svc.StartMode -ieq $ExpectedMode)
            Actual = [string]$svc.StartMode
            Error = ""
        }
    }
    catch {
        return [pscustomobject]@{Passed=$false;Actual="Unavailable";Error=$_.Exception.Message}
    }
}

@echo off
setlocal EnableExtensions
title DISM Service Center

net session >nul 2>&1
if not "%errorlevel%"=="0" (
    echo Administrator privileges are required for the DISM Service Center.
    echo Requesting elevation through Windows User Account Control.
    powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\00_Common\Invoke-Elevated-Self.ps1" -ScriptPath "%~f0"
    exit /b %errorlevel%
)

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0DISM-Service-Center.ps1" -ScreenReaderMode "%SRMODE%"
set "RC=%errorlevel%"

echo.
if "%RC%"=="0" (
    echo DISM Service Center closed normally.
) else (
    echo DISM Service Center returned error code %RC%.
)

if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

exit /b %RC%

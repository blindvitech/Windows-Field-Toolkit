. "$PSScriptRoot\Repair-Common.ps1"

$action = "Driver Recovery"

if (-not (Test-ToolkitAdmin)) {
    Write-Host "Administrator privileges are required."
    Write-RepairJournal $action "BLOCKED" "Not running as Administrator."
    exit 1
}

$logs = Get-ToolkitLogsRoot
$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$session = Join-Path $logs ("DRIVER_RECOVERY_" + $env:COMPUTERNAME + "_" + $stamp)
New-Item -ItemType Directory -Path $session -Force | Out-Null

$enumDriversInitial = Invoke-ToolkitNativeCommand -FilePath "pnputil.exe" -Arguments @("/enum-drivers") -Label "PnPUtil Driver Inventory" -Action $action -LogPath (Join-Path $session "PNPUTIL_ENUM_DRIVERS_NATIVE.txt") -Quiet
$enumDriversInitial.Output | Set-Content -LiteralPath (Join-Path $session "PNPUTIL_ENUM_DRIVERS.txt") -Encoding UTF8
$enumDevicesInitial = Invoke-ToolkitNativeCommand -FilePath "pnputil.exe" -Arguments @("/enum-devices","/problem") -Label "PnPUtil Problem Device Inventory" -Action $action -LogPath (Join-Path $session "PNPUTIL_PROBLEM_DEVICES_NATIVE.txt") -Quiet
$enumDevicesInitial.Output | Set-Content -LiteralPath (Join-Path $session "PNPUTIL_PROBLEM_DEVICES.txt") -Encoding UTF8
$driverQueryInitial = Invoke-ToolkitNativeCommand -FilePath "driverquery.exe" -Arguments @("/v","/fo","csv") -Label "DriverQuery Inventory" -Action $action -LogPath (Join-Path $session "DRIVERQUERY_NATIVE.txt") -Quiet
$driverQueryInitial.Output | Set-Content -LiteralPath (Join-Path $session "DRIVERQUERY.csv") -Encoding UTF8

function Show-ProblemDevices {
    Write-Host ""
    Write-Host "Problem devices:"
    $devices = Get-PnpDevice -PresentOnly -ErrorAction SilentlyContinue |
        Where-Object Status -ne "OK" |
        Select-Object Status,Class,FriendlyName,InstanceId
    if ($devices) {
        $devices | Format-Table -Wrap -AutoSize
    }
    else {
        Write-Host "(No present problem devices were reported.)"
    }
}

Write-Host "DRIVER RECOVERY"
Write-Host ("Session folder: " + $session)
Show-ProblemDevices

while ($true) {
    Write-Host ""
    Write-Host "DRIVER RECOVERY ACTIONS"
    Write-Host "1. Export all third-party driver packages."
    Write-Host "2. Rescan Plug and Play devices."
    Write-Host "3. Restart a selected device by Instance ID."
    Write-Host "4. Install/reinstall drivers from an INF folder."
    Write-Host "5. Advanced: remove a selected OEM driver package after backup."
    Write-Host "6. Show problem devices again."
    Write-Host "0. Return."
    Write-Host ""

    $choice = Read-ToolkitPrompt "Select an option"

    switch ($choice) {
        "1" {
            $dest = Join-Path $session "EXPORTED_DRIVERS"
            New-Item -ItemType Directory -Path $dest -Force | Out-Null
            Write-Host ("Exporting third-party drivers to: " + $dest)
            $exportResult = Invoke-ToolkitNativeCommand -FilePath "pnputil.exe" -Arguments @("/export-driver","*",$dest) -Label "PnPUtil Export Drivers" -Action $action
            $exportRc = $exportResult.ExitCode
            Write-RepairJournal $action "EXPORT_DRIVERS" ("Destination=" + $dest + "; ExitCode=" + $exportRc)
            $exportedInf = @(Get-ChildItem -LiteralPath $dest -Filter "*.inf" -File -Recurse -ErrorAction SilentlyContinue).Count
            Write-RepairVerification -Action $action -Check "Third-party driver export" `
                -Status $(if($exportRc -eq 0){"VERIFIED"}else{"FAILED"}) `
                -Details ("PnPUtil exit code=" + $exportRc + "; exported INF files=" + $exportedInf + "; destination=" + $dest)
        }
        "2" {
            Write-Host "A Plug and Play rescan can cause Windows to rediscover hardware and refresh device state."
            if (Confirm-RepairAction "Run the Plug and Play device rescan?") {
                Write-Host "Rescanning Plug and Play devices..."
                $problemBefore = @(Get-PnpDevice -PresentOnly -ErrorAction SilentlyContinue | Where-Object Status -ne "OK").Count
                $scanResult = Invoke-ToolkitNativeCommand -FilePath "pnputil.exe" -Arguments @("/scan-devices") -Label "PnPUtil Scan Devices" -Action $action -Mutation
                $scanRc = $scanResult.ExitCode
                $problemAfter = @(Get-PnpDevice -PresentOnly -ErrorAction SilentlyContinue | Where-Object Status -ne "OK").Count
                Write-RepairJournal $action "SCAN_DEVICES" ("ExitCode=" + $scanRc)
                Write-RepairVerification -Action $action -Check "Plug and Play rescan" `
                    -Status $(if($scanRc -eq 0){"VERIFIED"}else{"FAILED"}) `
                    -Details ("PnPUtil exit code=" + $scanRc + "; problem devices before=" + $problemBefore + "; after=" + $problemAfter)
            }
            else {
                Write-Host "Canceled. No device rescan was started."
                Write-RepairJournal $action "SCAN_DEVICES_CANCELED" ""
            }
        }
        "3" {
            $id = Read-ToolkitPrompt "Paste the exact device Instance ID"
            if ([string]::IsNullOrWhiteSpace($id)) { continue }
            Write-Host ("Selected device: " + $id)
            if (Confirm-RepairAction "Restart this device? Active connections or applications using it may be interrupted.") {
                $restartResult = Invoke-ToolkitNativeCommand -FilePath "pnputil.exe" -Arguments @("/restart-device",$id) -Label "PnPUtil Restart Device" -Action $action -Mutation
                $restartRc = $restartResult.ExitCode
                Write-RepairJournal $action "RESTART_DEVICE" ("InstanceId=" + $id + "; ExitCode=" + $restartRc)
                $deviceAfter = Get-PnpDevice -InstanceId $id -ErrorAction SilentlyContinue
                if ($restartRc -eq 0 -and $deviceAfter -and $deviceAfter.Status -eq "OK") {
                    Write-RepairVerification -Action $action -Check "Device restart" -Status "VERIFIED" -Details ("InstanceId=" + $id + "; status=OK")
                }
                elseif ($restartRc -eq 0) {
                    Write-RepairVerification -Action $action -Check "Device restart" -Status "PARTIAL" -Details ("InstanceId=" + $id + "; post-state=" + $(if($deviceAfter){$deviceAfter.Status}else{"Unavailable"}))
                }
                else {
                    Write-RepairVerification -Action $action -Check "Device restart" -Status "FAILED" -Details ("InstanceId=" + $id + "; PnPUtil exit code=" + $restartRc)
                }
            }
            else {
                Write-Host "Canceled. No device restart was performed."
                Write-RepairJournal $action "RESTART_DEVICE_CANCELED" ("InstanceId=" + $id)
            }
        }
        "4" {
            $folder = Read-ToolkitPrompt "Folder containing INF driver files"
            if (-not (Test-Path -LiteralPath $folder -PathType Container)) {
                Write-Host "Folder not found."
                continue
            }
            $infCount = @(Get-ChildItem -LiteralPath $folder -Filter "*.inf" -File -Recurse -ErrorAction SilentlyContinue).Count
            Write-Host ("INF files found: " + $infCount)
            if ($infCount -eq 0) {
                Write-Host "No INF files were found."
                continue
            }
            Write-Host "Installing drivers can replace the active driver for matching hardware."
            if (Confirm-RepairAction "Add these driver packages and install matching drivers?") {
                $pattern = Join-Path $folder "*.inf"
                $problemBefore = @(Get-PnpDevice -PresentOnly -ErrorAction SilentlyContinue | Where-Object Status -ne "OK").Count
                $installResult = Invoke-ToolkitNativeCommand -FilePath "pnputil.exe" -Arguments @("/add-driver",$pattern,"/subdirs","/install") -Label "PnPUtil Add Install Drivers" -Action $action -Mutation
                $installRc = $installResult.ExitCode
                $problemAfter = @(Get-PnpDevice -PresentOnly -ErrorAction SilentlyContinue | Where-Object Status -ne "OK").Count
                Write-RepairJournal $action "INSTALL_DRIVERS" ("Folder=" + $folder + "; INFCount=" + $infCount + "; ExitCode=" + $installRc)
                Write-RepairVerification -Action $action -Check "Driver package add/install" `
                    -Status $(if($installRc -eq 0){"VERIFIED"}else{"FAILED"}) `
                    -Details ("PnPUtil exit code=" + $installRc + "; source INF files=" + $infCount + "; problem devices before=" + $problemBefore + "; after=" + $problemAfter)
            }
            else {
                Write-Host "Canceled. No driver packages were installed."
                Write-RepairJournal $action "INSTALL_DRIVERS_CANCELED" ("Folder=" + $folder)
            }
        }
        "5" {
            Write-Host ""
            Write-Host "ADVANCED DRIVER PACKAGE REMOVAL"
            Write-Host "This can make hardware stop working until a compatible driver is installed."
            Write-Host "Only Microsoft-style published names such as oem42.inf are accepted."
            Write-Host ""
            $package = (Read-ToolkitPrompt "Published driver package name, for example oem42.inf").Trim()
            if ($package -notmatch '^(?i)oem\d+\.inf$') {
                Write-Host "The package name must match oem<number>.inf."
                continue
            }

            $backup = Join-Path $session ("BEFORE_REMOVE_" + ($package -replace '\.','_'))
            New-Item -ItemType Directory -Path $backup -Force | Out-Null
            Write-Host "Exporting all third-party drivers before removal..."
            $backupResult = Invoke-ToolkitNativeCommand -FilePath "pnputil.exe" -Arguments @("/export-driver","*",$backup) -Label "PnPUtil Pre-Removal Driver Export" -Action $action
            $backupRc = $backupResult.ExitCode
            Write-RepairJournal $action "REMOVE_DRIVER_BACKUP" ("Package=" + $package + "; Backup=" + $backup + "; ExitCode=" + $backupRc)
            if ($backupRc -ne 0) {
                Write-Host ("Driver export returned exit code " + $backupRc + ".")
                Write-Host "Package removal is blocked because the pre-removal driver backup did not complete successfully."
                Write-RepairJournal $action "REMOVE_DRIVER_BLOCKED" ("Package=" + $package + "; BackupExitCode=" + $backupRc)
                Write-RepairVerification -Action $action -Check "Pre-removal driver backup" -Status "FAILED" `
                    -Details ("Package=" + $package + "; PnPUtil export exit code=" + $backupRc)
                continue
            }

            $confirmText = Read-ToolkitPrompt ("To confirm removal, type the exact package name " + $package)
            if ($confirmText -cne $package) {
                Write-Host "Exact confirmation did not match. Removal canceled."
                Write-RepairJournal $action "REMOVE_DRIVER_CANCELED" ("Package=" + $package)
                continue
            }

            Write-Host ("Removing " + $package + " without /force and without automatic reboot.")
            $removeResult = Invoke-ToolkitNativeCommand -FilePath "pnputil.exe" -Arguments @("/delete-driver",$package,"/uninstall") -Label ("PnPUtil Remove " + $package) -Action $action -Mutation
            $removeRc = $removeResult.ExitCode
            if ($removeRc -eq 0) {
                Write-Host "Driver package removal completed successfully."
            }
            else {
                Write-Host ("Driver package removal returned exit code " + $removeRc + ".")
                Write-Host "Review PnPUtil output; the driver package may still be present or in use."
            }
            Write-RepairJournal $action "REMOVE_DRIVER_PACKAGE" ("Package=" + $package + "; Backup=" + $backup + "; ExitCode=" + $removeRc)
            $enumAfterResult = Invoke-ToolkitNativeCommand -FilePath "pnputil.exe" -Arguments @("/enum-drivers") -Label "PnPUtil Post-Removal Driver Inventory" -Action $action -Quiet
            $enumAfter = ($enumAfterResult.Output -join [Environment]::NewLine)
            $packageStillPresent = $enumAfter -match [regex]::Escape($package)
            if ($removeRc -eq 0 -and -not $packageStillPresent) {
                Write-RepairVerification -Action $action -Check "OEM driver package removal" -Status "VERIFIED" `
                    -Details ("Package " + $package + " is absent from the post-removal PnPUtil driver inventory.")
            }
            elseif ($removeRc -eq 0) {
                Write-RepairVerification -Action $action -Check "OEM driver package removal" -Status "PARTIAL" `
                    -Details ("PnPUtil returned 0, but " + $package + " still appears in the post-removal inventory.")
            }
            else {
                Write-RepairVerification -Action $action -Check "OEM driver package removal" -Status "FAILED" `
                    -Details ("PnPUtil exit code=" + $removeRc + "; package still present=" + $packageStillPresent)
            }
        }
        "6" { Show-ProblemDevices }
        "0" { break }
        default { Write-Host "Choose 0 through 6." }
    }

    if ($choice -eq "0") { break }
}

Write-RepairJournal $action "COMPLETED" ("Session=" + $session)
exit 0

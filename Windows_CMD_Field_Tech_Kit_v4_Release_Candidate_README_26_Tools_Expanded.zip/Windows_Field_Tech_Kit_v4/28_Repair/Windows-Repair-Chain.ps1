. "$PSScriptRoot\Repair-Common.ps1"

$action = "Windows Repair Chain"

if (-not (Test-ToolkitAdmin)) {
    Write-Host "Administrator privileges are required."
    Write-RepairJournal $action "BLOCKED" "Not running as Administrator."
    exit 1
}

$logs = Get-ToolkitLogsRoot
$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$logPath = Join-Path $logs ("WINDOWS_REPAIR_CHAIN_" + $env:COMPUTERNAME + "_" + $stamp + ".txt")

Write-Host "WINDOWS REPAIR CHAIN"
Write-Host ""
Write-Host "Sequence:"
Write-Host "1. DISM CheckHealth"
Write-Host "2. DISM ScanHealth"
Write-Host "3. DISM RestoreHealth"
Write-Host "4. SFC /scannow"
Write-Host "5. DISM CheckHealth again"
Write-Host "6. SFC /verifyonly post-repair verification"
Write-Host ""
Write-Host "RestoreHealth and SFC can repair Windows component/system files."
Write-Host "The process can take a significant amount of time."
Write-Host ""

if (Confirm-RepairAction "Create a Restore Point + Repair Safety Backup before the chain?") {
    Write-Host ""
    Write-Host "Creating safety backup first..."
    & powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "$PSScriptRoot\Create-Restore-Point-and-Safety-Backup.ps1" -Confirmed
    Write-Host ("Safety-backup process returned exit code " + $LASTEXITCODE + ".")
    Write-Host ""
}

if (-not (Confirm-RepairPhrase "The chain will run DISM RestoreHealth and SFC /scannow, which can repair Windows component and protected system files." "REPAIR")) {
    Write-Host "Canceled. No repair-chain commands were started."
    Write-RepairJournal $action "CANCELED" "Typed REPAIR confirmation declined."
    exit 0
}

Write-RepairJournal $action "STARTING" ("Log=" + $logPath)

$steps = New-Object System.Collections.Generic.List[object]

function Run-Step {
    param(
        [Parameter(Mandatory=$true)][string]$Name,
        [Parameter(Mandatory=$true)][string]$FilePath,
        [string[]]$Arguments = @(),
        [switch]$Mutation
    )

    Write-Host ""
    Write-Host ("===== " + $Name + " =====")
    Add-Content -LiteralPath $logPath -Value ("`r`n===== " + $Name + " =====") -Encoding UTF8

    $nativeLog = Join-Path $logs ("WINDOWS_REPAIR_CHAIN_NATIVE_" + ($Name -replace '[^A-Za-z0-9_.-]+','_') + "_" + (Get-Date -Format "yyyyMMdd_HHmmssfff") + ".txt")
    $result = Invoke-ToolkitNativeCommand -FilePath $FilePath -Arguments $Arguments -Label $Name -Action $action -Mutation:$Mutation -LogPath $nativeLog -Quiet

    $result.Output | ForEach-Object { Write-Host $_ }
    $result.Output | Out-File -LiteralPath $logPath -Append -Encoding UTF8
    $steps.Add([pscustomobject]@{
        Step = $Name
        ExitCode = $result.ExitCode
        Status = $result.Status
        RebootRequired = $result.RebootRequired
        NativeLog = $result.LogPath
    })
    Write-RepairJournal $action "STEP" ($Name + " ExitCode=" + $result.ExitCode + "; Result=" + $result.Status + "; NativeLog=" + $result.LogPath)
}

"WINDOWS REPAIR CHAIN`r`nGenerated: $(Get-Date)`r`nComputer: $env:COMPUTERNAME" |
    Set-Content -LiteralPath $logPath -Encoding UTF8

Run-Step -Name "DISM CheckHealth" -FilePath "dism.exe" -Arguments @("/Online","/Cleanup-Image","/CheckHealth")
Run-Step -Name "DISM ScanHealth" -FilePath "dism.exe" -Arguments @("/Online","/Cleanup-Image","/ScanHealth")
Run-Step -Name "DISM RestoreHealth" -FilePath "dism.exe" -Arguments @("/Online","/Cleanup-Image","/RestoreHealth") -Mutation
Run-Step -Name "SFC Scannow" -FilePath "sfc.exe" -Arguments @("/scannow") -Mutation
Run-Step -Name "DISM CheckHealth After Repair" -FilePath "dism.exe" -Arguments @("/Online","/Cleanup-Image","/CheckHealth")
Run-Step -Name "SFC VerifyOnly After Repair" -FilePath "sfc.exe" -Arguments @("/verifyonly")

Write-Host ""
Write-Host "Repair chain summary:"
$steps | Format-Table -AutoSize
Write-Host ("Full log: " + $logPath)

$postDism = @($steps | Where-Object Step -eq "DISM CheckHealth After Repair" | Select-Object -First 1)
$postSfc = @($steps | Where-Object Step -eq "SFC VerifyOnly After Repair" | Select-Object -First 1)
if ($postDism -and $postSfc -and $postDism.ExitCode -eq 0 -and $postSfc.ExitCode -eq 0) {
    Write-RepairVerification -Action $action -Check "Windows repair chain post-state" -Status "VERIFIED" `
        -Details "Independent post-repair DISM CheckHealth and SFC /verifyonly both returned exit code 0."
}
elseif ($postDism -or $postSfc) {
    Write-RepairVerification -Action $action -Check "Windows repair chain post-state" -Status "FAILED" `
        -Details ("Post DISM=" + $(if($postDism){$postDism.ExitCode}else{"missing"}) + "; post SFC=" + $(if($postSfc){$postSfc.ExitCode}else{"missing"}))
}
else {
    Write-RepairVerification -Action $action -Check "Windows repair chain post-state" -Status "FAILED" -Details "Post-repair verification steps did not run."
}

$rebootSteps = @($steps | Where-Object RebootRequired)
$nonzero = @($steps | Where-Object { $_.ExitCode -ne 0 -and -not $_.RebootRequired })
if ($nonzero.Count -eq 0 -and $rebootSteps.Count -gt 0) {
    Write-RepairJournal $action "COMPLETED_WITH_WARNINGS" ("Repair commands completed; reboot required by " + ($rebootSteps.Step -join ", ") + ". Log=" + $logPath)
    exit 3
}
if ($nonzero.Count -eq 0) {
    Write-RepairJournal $action "COMPLETED" ("All commands returned exit code 0. Log=" + $logPath)
    exit 0
}

Write-Host ""
Write-Host "One or more commands returned a nonzero exit code. Review the log before deciding on the next repair step."
Write-RepairJournal $action "COMPLETED_WITH_WARNINGS" ("Nonzero steps=" + $nonzero.Count + "; Log=" + $logPath)
exit 2

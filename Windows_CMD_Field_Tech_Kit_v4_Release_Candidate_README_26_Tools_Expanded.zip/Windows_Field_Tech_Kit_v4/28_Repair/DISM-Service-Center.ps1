param(
    [string]$ScreenReaderMode = ""
)

. "$PSScriptRoot\Repair-Common.ps1"

$ErrorActionPreference = "Continue"
$ProgressPreference = "SilentlyContinue"

$action = "DISM Service Center"

$screenReaderEnabled = (
    $ScreenReaderMode -eq "1" -or
    $env:SRMODE -eq "1" -or
    $env:FIELDTECH_SCREEN_READER -eq "1"
)
if ($screenReaderEnabled) {
    $env:SRMODE = "1"
}


function Write-DismAccessibilityAnnouncement {
    param([Parameter(Mandatory=$true)][string]$Message)

    if ($script:screenReaderEnabled) {
        Write-Host $Message
    }
}

function Write-DismMenuNavigationHelp {
    param([switch]$Submenu)

    if ($script:screenReaderEnabled) {
        if ($Submenu) {
            Write-Host "Navigation. Type 99, B, BACK, or RETURN to go back one DISM menu level."
        }
        else {
            Write-Host "Navigation. Type 99, B, BACK, or RETURN to return to the toolkit Repair menu."
        }
        Write-Host "Type Q, QUIT, EXIT, or X to exit the DISM Service Center."
    }
    else {
        if ($Submenu) {
            Write-Host "99 / B / BACK / RETURN. Back one menu."
        }
        else {
            Write-Host "99 / B / BACK / RETURN. Return to Repair menu."
        }
        Write-Host "Q / QUIT / EXIT / X. Exit DISM Service Center."
    }
}

if (-not (Test-ToolkitAdmin)) {
    Write-Host "Administrator privileges are required."
    Write-RepairJournal $action "BLOCKED" "Not running as Administrator."
    exit 1
}

$dismPath = Join-Path $env:WINDIR "System32\dism.exe"
if (-not (Test-Path -LiteralPath $dismPath -PathType Leaf)) {
    Write-Host "DISM was not found at the expected Windows path:"
    Write-Host $dismPath
    Write-RepairJournal $action "BLOCKED" "DISM executable not found."
    exit 2
}

$logs = Get-ToolkitLogsRoot
$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$session = Join-Path $logs ("DISM_SERVICE_CENTER_" + $env:COMPUTERNAME + "_" + $stamp)
New-Item -ItemType Directory -Path $session -Force | Out-Null

$offlineImage = ""
$operationCounter = 0
$exitServiceCenter = $false

function Resolve-DismMenuChoice {
    param(
        [Parameter(Mandatory=$true)][string]$InputValue,
        [switch]$Submenu
    )

    $value = $InputValue.Trim()

    if ($value -match '(?i)^(Q|QUIT|EXIT|X)$') {
        Write-DismAccessibilityAnnouncement "Exiting the DISM Service Center and returning control to the toolkit."
        $script:exitServiceCenter = $true
        return "__EXIT__"
    }

    if ($value -match '(?i)^(B|BACK|RETURN)$') {
        if ($Submenu) {
            Write-DismAccessibilityAnnouncement "Returning one DISM menu level."
            return "__BACK__"
        }
        Write-DismAccessibilityAnnouncement "Returning to the toolkit Repair menu."
        return "__EXIT__"
    }

    if ($value -eq "99") {
        if ($Submenu) {
            Write-DismAccessibilityAnnouncement "Returning one DISM menu level."
            return "__BACK__"
        }
        Write-DismAccessibilityAnnouncement "Returning to the toolkit Repair menu."
        return "__EXIT__"
    }

    return $value
}

$osInfo = Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
$osBuild = 0
if ($osInfo -and $osInfo.BuildNumber) {
    [void]([int]::TryParse([string]$osInfo.BuildNumber,[ref]$osBuild))
}

function New-OperationLogPath {
    param([Parameter(Mandatory=$true)][string]$Label)

    $script:operationCounter++
    $safe = ($Label -replace '[^A-Za-z0-9_.-]+','_').Trim("_")
    if ([string]::IsNullOrWhiteSpace($safe)) { $safe = "DISM" }

    return Join-Path $session (
        "{0:D3}_{1}_{2}.txt" -f
        $script:operationCounter,
        (Get-Date -Format "HHmmss"),
        $safe
    )
}

function Get-TargetArguments {
    param([string]$ImagePath)

    if ([string]::IsNullOrWhiteSpace($ImagePath)) {
        return @("/Online")
    }

    return @(("/Image:" + $ImagePath))
}

function Invoke-DismOperation {
    param(
        [Parameter(Mandatory=$true)][string]$Label,
        [Parameter(Mandatory=$true)][string[]]$Arguments,
        [switch]$Mutation
    )

    $logPath = New-OperationLogPath $Label

    Write-Host ""
    if ($script:screenReaderEnabled) {
        Write-Host ("Starting DISM operation: " + $Label + ".")
        Write-Host ($(if ($Mutation) { "This operation can change Windows or the selected image." } else { "This operation is read-only." }))
        Write-Host ("Operation log will be saved to " + $logPath)
    }
    else {
        Write-Host ("--- " + $Label + " ---")
        Write-Host ("DISM arguments: " + ($Arguments -join " "))
        Write-Host ("Operation log: " + $logPath)
    }
    Write-Host ""

    if ($Mutation) {
        Write-RepairJournal $action "DISM_START" ("Label=" + $Label + "; Arguments=" + ($Arguments -join " "))
    }

    $native = Invoke-ToolkitNativeCommand -FilePath $dismPath -Arguments $Arguments -Label ("DISM " + $Label) -Action $action -Mutation:$Mutation -LogPath $logPath -Quiet
    $outputLines = @($native.Output)
    $outputLines | ForEach-Object { Write-Host $_ }

    $text = ($outputLines -join [Environment]::NewLine)
    $rc = [int]$native.ExitCode
    $duration = $native.DurationSeconds
    $rebootRequired = [bool]$native.RebootRequired

    Write-Host ""
    if ($script:screenReaderEnabled) {
        Write-Host ("DISM operation finished: " + $Label + ".")
        Write-Host ("Native DISM exit code " + $rc + ". Duration " + $duration + " seconds.")
    }
    else {
        Write-Host ("Native DISM exit code: " + $rc)
        Write-Host ("Duration: " + $duration + " seconds")
    }
    if ($rebootRequired) {
        Write-Host "DISM indicates that a restart may be required."
    }

    if ($Mutation) {
        Write-RepairJournal $action "DISM_END" (
            "Label=" + $Label +
            "; ExitCode=" + $rc +
            "; Result=" + $native.Status +
            "; RebootRequired=" + $rebootRequired +
            "; Log=" + $logPath
        )
    }

    return [pscustomobject]@{
        Label = $Label
        ExitCode = $rc
        Output = $text
        LogPath = $logPath
        DurationSeconds = $duration
        RebootRequired = $rebootRequired
        ResultStatus = $native.Status
    }
}

function Get-DismHealthState {
    param(
        [string]$ImagePath = "",
        [string]$Label = "CheckHealth"
    )

    $args = New-Object System.Collections.Generic.List[string]
    foreach ($item in @(Get-TargetArguments $ImagePath)) { $args.Add($item) }
    $args.Add("/Cleanup-Image")
    $args.Add("/CheckHealth")

    $result = Invoke-DismOperation -Label $Label -Arguments $args.ToArray()

    $state = "UNKNOWN"
    if ($result.ExitCode -ne 0) {
        $state = "ERROR"
    }
    elseif ($result.Output -match '(?i)No component store corruption detected') {
        $state = "HEALTHY"
    }
    elseif ($result.Output -match '(?i)The component store is repairable') {
        $state = "REPAIRABLE"
    }
    elseif ($result.Output -match '(?i)The component store cannot be repaired') {
        $state = "NON_REPAIRABLE"
    }

    return [pscustomobject]@{
        State = $state
        ExitCode = $result.ExitCode
        Output = $result.Output
        LogPath = $result.LogPath
        RebootRequired = $result.RebootRequired
    }
}

function Write-DismRepairVerification {
    param(
        [Parameter(Mandatory=$true)][string]$Check,
        [Parameter(Mandatory=$true)]$HealthResult,
        [switch]$OperationRebootRequired
    )

    if ($OperationRebootRequired) {
        Write-RepairVerification $action $Check "PENDING_REBOOT" (
            "Post-state=" + $HealthResult.State + "; CheckHealthExitCode=" + $HealthResult.ExitCode
        )
        return
    }

    switch ($HealthResult.State) {
        "HEALTHY" {
            Write-RepairVerification $action $Check "VERIFIED" "Post-repair CheckHealth reports no component-store corruption."
        }
        "REPAIRABLE" {
            Write-RepairVerification $action $Check "FAILED" "Component store remains repairable after the attempted repair."
        }
        "NON_REPAIRABLE" {
            Write-RepairVerification $action $Check "FAILED" "Component store reports non-repairable corruption."
        }
        "ERROR" {
            Write-RepairVerification $action $Check "FAILED" ("Post-repair CheckHealth returned exit code " + $HealthResult.ExitCode + ".")
        }
        default {
            Write-RepairVerification $action $Check "PARTIAL" (
                "CheckHealth completed but its localized/text result could not be classified automatically. ExitCode=" +
                $HealthResult.ExitCode + "; review " + $HealthResult.LogPath
            )
        }
    }
}

function Invoke-SfcVerifyOnly {
    $label = "SFC_VerifyOnly"
    $logPath = New-OperationLogPath $label

    Write-Host ""
    Write-Host "--- SFC /VERIFYONLY ---"

    $native = Invoke-ToolkitNativeCommand -FilePath "sfc.exe" -Arguments @("/verifyonly") -Label "SFC VerifyOnly" -Action $action -LogPath $logPath -Quiet
    $output = @($native.Output)
    $output | ForEach-Object { Write-Host $_ }

    $text = ($output -join [Environment]::NewLine)
    $state = "UNKNOWN"
    if ($text -match '(?i)did not find any integrity violations') {
        $state = "HEALTHY"
    }
    elseif ($text -match '(?i)found integrity violations') {
        $state = "INTEGRITY_VIOLATIONS"
    }
    elseif ($native.ExitCode -ne 0) {
        $state = "ERROR"
    }

    return [pscustomobject]@{
        State = $state
        ExitCode = [int]$native.ExitCode
        Output = $text
        LogPath = $logPath
    }
}

function Invoke-OnlineCheckHealth {
    $result = Get-DismHealthState -Label "Online_CheckHealth"
    Write-Host ""
    Write-Host ("Classified component-store state: " + $result.State)
}

function Invoke-OnlineScanHealth {
    [void](Invoke-DismOperation -Label "Online_ScanHealth" -Arguments @("/Online","/Cleanup-Image","/ScanHealth"))
}

function Invoke-OnlineRestoreHealth {
    Write-Host ""
    Write-Host "RestoreHealth can change the Windows component store."
    Write-Host "Windows Update may be contacted for repair content unless a source or policy prevents it."

    if (-not (Confirm-RepairAction "Run DISM RestoreHealth against the running Windows installation?")) {
        Write-Host "Canceled. No DISM repair was started."
        Write-RepairJournal $action "RESTOREHEALTH_CANCELED" "Online default source."
        return
    }

    $result = Invoke-DismOperation -Label "Online_RestoreHealth" -Arguments @(
        "/Online","/Cleanup-Image","/RestoreHealth"
    ) -Mutation

    $post = Get-DismHealthState -Label "Online_PostRestore_CheckHealth"
    Write-DismRepairVerification -Check "Online RestoreHealth" -HealthResult $post -OperationRebootRequired:$result.RebootRequired
}

function Read-RepairSource {
    $path = (Read-ToolkitPrompt "Repair source path: WIM, ESD, or source folder").Trim().Trim('"')
    if ([string]::IsNullOrWhiteSpace($path)) {
        Write-Host "No source selected."
        return $null
    }

    if (-not (Test-Path -LiteralPath $path)) {
        Write-Host "Source path was not found."
        return $null
    }

    $item = Get-Item -LiteralPath $path -ErrorAction SilentlyContinue
    if (-not $item) {
        Write-Host "Source path could not be opened."
        return $null
    }

    if ($item.PSIsContainer) {
        return [pscustomobject]@{
            Kind = "Folder"
            Path = $item.FullName
            SourceSpec = $item.FullName
            Index = 0
        }
    }

    $ext = $item.Extension.ToLowerInvariant()
    if ($ext -notin @(".wim",".esd")) {
        Write-Host "Select an install.wim, install.esd, or a repair-source folder."
        return $null
    }

    $infoArgs = @("/Get-WimInfo",("/WimFile:" + $item.FullName))
    [void](Invoke-DismOperation -Label "RepairSource_GetWimInfo" -Arguments $infoArgs)

    $indexText = (Read-ToolkitPrompt "Image index to use").Trim()
    $index = 0
    if (-not [int]::TryParse($indexText,[ref]$index) -or $index -lt 1) {
        Write-Host "Enter a valid image index of 1 or greater."
        return $null
    }

    $kind = $(if ($ext -eq ".wim") { "WIM" } else { "ESD" })
    $prefix = $(if ($kind -eq "WIM") { "WIM:" } else { "ESD:" })

    $indexCheck = Invoke-DismOperation -Label "RepairSource_VerifyIndex" -Arguments @(
        "/Get-WimInfo",
        ("/WimFile:" + $item.FullName),
        ("/Index:" + $index)
    )
    if ($indexCheck.ExitCode -ne 0) {
        Write-Host "The selected image index could not be opened. Repair source selection was canceled."
        return $null
    }

    return [pscustomobject]@{
        Kind = $kind
        Path = $item.FullName
        SourceSpec = ($prefix + $item.FullName + ":" + $index)
        Index = $index
    }
}

function Invoke-SourceAssistedRestore {
    Write-Host ""
    Write-Host "SOURCE-ASSISTED RESTOREHEALTH"
    Write-Host "Use repair media that matches the installed Windows release, architecture, and edition as closely as possible."
    Write-Host "The toolkit will inspect WIM/ESD metadata but will not silently assume an image index."

    $source = Read-RepairSource
    if (-not $source) { return }

    Write-Host ""
    Write-Host ("Selected source kind: " + $source.Kind)
    Write-Host ("Selected source: " + $source.Path)
    if ($source.Index -gt 0) { Write-Host ("Selected image index: " + $source.Index) }

    $limit = Read-ToolkitPrompt "Use /LimitAccess to prevent Windows Update fallback? Type Y or N"
    $useLimitAccess = ($limit -match '(?i)^y(?:es)?$')

    if (-not (Confirm-RepairAction "Run source-assisted RestoreHealth against the running Windows installation?")) {
        Write-Host "Canceled. No source-assisted DISM repair was started."
        Write-RepairJournal $action "SOURCE_RESTORE_CANCELED" ("Source=" + $source.Path)
        return
    }

    $args = New-Object System.Collections.Generic.List[string]
    $args.Add("/Online")
    $args.Add("/Cleanup-Image")
    $args.Add("/RestoreHealth")
    $args.Add(("/Source:" + $source.SourceSpec))
    if ($useLimitAccess) { $args.Add("/LimitAccess") }

    $result = Invoke-DismOperation -Label "Online_SourceAssisted_RestoreHealth" -Arguments $args.ToArray() -Mutation

    $post = Get-DismHealthState -Label "Online_PostSourceRestore_CheckHealth"
    Write-DismRepairVerification -Check "Source-assisted RestoreHealth" -HealthResult $post -OperationRebootRequired:$result.RebootRequired
}

function Invoke-AnalyzeComponentStore {
    param([string]$ImagePath = "")

    $args = New-Object System.Collections.Generic.List[string]
    foreach ($item in @(Get-TargetArguments $ImagePath)) { $args.Add($item) }
    $args.Add("/Cleanup-Image")
    $args.Add("/AnalyzeComponentStore")
    [void](Invoke-DismOperation -Label $(if ($ImagePath) { "Offline_AnalyzeComponentStore" } else { "Online_AnalyzeComponentStore" }) -Arguments $args.ToArray())
}

function Invoke-StartComponentCleanup {
    Write-Host ""
    Write-Host "StartComponentCleanup removes superseded component versions that Windows no longer needs."
    Write-Host "This can change the component store but does not use /ResetBase."

    if (-not (Confirm-RepairAction "Run standard StartComponentCleanup?")) {
        Write-Host "Canceled. Component cleanup was not started."
        Write-RepairJournal $action "COMPONENT_CLEANUP_CANCELED" ""
        return
    }

    $result = Invoke-DismOperation -Label "Online_StartComponentCleanup" -Arguments @(
        "/Online","/Cleanup-Image","/StartComponentCleanup"
    ) -Mutation

    $post = Invoke-DismOperation -Label "Online_PostCleanup_AnalyzeComponentStore" -Arguments @(
        "/Online","/Cleanup-Image","/AnalyzeComponentStore"
    )

    if ($result.RebootRequired) {
        Write-RepairVerification $action "StartComponentCleanup" "PENDING_REBOOT" ("DISM exit code=" + $result.ExitCode)
    }
    elseif ($result.ExitCode -eq 0 -and $post.ExitCode -eq 0) {
        Write-RepairVerification $action "StartComponentCleanup" "VERIFIED" "Cleanup returned success and post-cleanup component-store analysis completed."
    }
    elseif ($result.ExitCode -eq 0) {
        Write-RepairVerification $action "StartComponentCleanup" "PARTIAL" "Cleanup returned success but post-cleanup analysis did not complete successfully."
    }
    else {
        Write-RepairVerification $action "StartComponentCleanup" "FAILED" ("Cleanup exit code=" + $result.ExitCode)
    }
}

function Invoke-OnlineInventory {
    Write-Host ""
    Write-Host "COMPONENT STORE / PACKAGE INVENTORY"

    [void](Invoke-DismOperation -Label "Online_GetPackages" -Arguments @("/Online","/Get-Packages"))
    [void](Invoke-DismOperation -Label "Online_GetCapabilities" -Arguments @("/Online","/Get-Capabilities"))
    [void](Invoke-DismOperation -Label "Online_GetFeatures" -Arguments @("/Online","/Get-Features","/Format:Table"))
}

function Invoke-FeatureInventory {
    [void](Invoke-DismOperation -Label "Online_GetFeatures" -Arguments @("/Online","/Get-Features","/Format:Table"))
}

function Invoke-DriverInventory {
    [void](Invoke-DismOperation -Label "Online_GetDrivers" -Arguments @("/Online","/Get-Drivers","/All","/Format:Table"))
}

function Invoke-ImageInfo {
    $path = (Read-ToolkitPrompt "WIM or ESD path").Trim().Trim('"')
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
        Write-Host "Image file not found."
        return
    }

    $ext = [IO.Path]::GetExtension($path).ToLowerInvariant()
    if ($ext -notin @(".wim",".esd")) {
        Write-Host "Select a .wim or .esd file."
        return
    }

    [void](Invoke-DismOperation -Label "Image_GetWimInfo" -Arguments @(
        "/Get-WimInfo",
        ("/WimFile:" + $path)
    ))
}

function Copy-DismEvidence {
    $evidence = Join-Path $session ("EVIDENCE_" + (Get-Date -Format "HHmmss"))
    New-Item -ItemType Directory -Path $evidence -Force | Out-Null

    $sources = @(
        (Join-Path $env:WINDIR "Logs\DISM\dism.log"),
        (Join-Path $env:WINDIR "Logs\CBS\CBS.log")
    )

    foreach ($source in $sources) {
        if (Test-Path -LiteralPath $source -PathType Leaf) {
            try {
                Copy-Item -LiteralPath $source -Destination $evidence -Force -ErrorAction Stop
                Write-Host ("Copied " + $source)
            }
            catch {
                Write-Host ("Could not copy " + $source + ": " + $_.Exception.Message)
            }
        }
        else {
            Write-Host ("Not found: " + $source)
        }
    }

    return $evidence
}

function Show-DismLogs {
    Write-Host ""
    Write-Host ("Windows DISM log: " + (Join-Path $env:WINDIR "Logs\DISM\dism.log"))
    Write-Host ("Windows CBS log : " + (Join-Path $env:WINDIR "Logs\CBS\CBS.log"))
    Write-Host ("Toolkit session : " + $session)
    Write-Host ""

    $evidence = Copy-DismEvidence
    Write-Host ("Evidence copy folder: " + $evidence)
}

function Create-DismDiagnosticBundle {
    Write-Host ""
    Write-Host "Collecting a read-only DISM diagnostic bundle..."

    [void](Get-DismHealthState -Label "Bundle_CheckHealth")
    [void](Invoke-DismOperation -Label "Bundle_AnalyzeComponentStore" -Arguments @(
        "/Online","/Cleanup-Image","/AnalyzeComponentStore"
    ))
    [void](Invoke-DismOperation -Label "Bundle_GetCurrentEdition" -Arguments @(
        "/Online","/Get-CurrentEdition"
    ))

    $evidence = Copy-DismEvidence

    $bundle = Join-Path $logs (
        "DISM_DIAGNOSTIC_BUNDLE_" + $env:COMPUTERNAME + "_" + (Get-Date -Format "yyyyMMdd_HHmmss") + ".zip"
    )

    try {
        Compress-Archive -Path (Join-Path $session "*") -DestinationPath $bundle -Force -ErrorAction Stop
        Write-Host ("Diagnostic bundle: " + $bundle)
    }
    catch {
        Write-Host ("Could not create diagnostic ZIP: " + $_.Exception.Message)
        Write-Host ("Collected files remain in: " + $session)
    }
}

function Invoke-GuidedRepairSequence {
    Write-Host ""
    Write-Host "GUIDED DISM REPAIR SEQUENCE"
    Write-Host "1. Capture CheckHealth."
    Write-Host "2. Run ScanHealth."
    Write-Host "3. Ask before RestoreHealth."
    Write-Host "4. Re-run CheckHealth."
    Write-Host "5. Run SFC /verifyonly."
    Write-Host "6. Save verification evidence."
    Write-Host ""

    $before = Get-DismHealthState -Label "Guided_01_CheckHealth"
    $scan = Invoke-DismOperation -Label "Guided_02_ScanHealth" -Arguments @(
        "/Online","/Cleanup-Image","/ScanHealth"
    )

    Write-Host ""
    Write-Host ("Initial CheckHealth classification: " + $before.State)
    Write-Host ("ScanHealth exit code: " + $scan.ExitCode)

    if (-not (Confirm-RepairAction "Continue with DISM RestoreHealth?")) {
        Write-Host "Canceled before the state-changing RestoreHealth step."
        Write-RepairJournal $action "GUIDED_REPAIR_CANCELED" "Stopped before RestoreHealth."
        return
    }

    $restore = Invoke-DismOperation -Label "Guided_03_RestoreHealth" -Arguments @(
        "/Online","/Cleanup-Image","/RestoreHealth"
    ) -Mutation

    $after = Get-DismHealthState -Label "Guided_04_PostRestore_CheckHealth"
    $sfc = Invoke-SfcVerifyOnly

    Write-DismRepairVerification -Check "Guided DISM RestoreHealth" -HealthResult $after -OperationRebootRequired:$restore.RebootRequired

    switch ($sfc.State) {
        "HEALTHY" {
            Write-RepairVerification $action "SFC /verifyonly after guided DISM repair" "VERIFIED" "SFC reports no integrity violations."
        }
        "INTEGRITY_VIOLATIONS" {
            Write-RepairVerification $action "SFC /verifyonly after guided DISM repair" "PARTIAL" "SFC still reports integrity violations; consider SFC /scannow after reviewing the DISM result."
        }
        "ERROR" {
            Write-RepairVerification $action "SFC /verifyonly after guided DISM repair" "FAILED" ("SFC exit code=" + $sfc.ExitCode)
        }
        default {
            Write-RepairVerification $action "SFC /verifyonly after guided DISM repair" "PARTIAL" ("SFC result could not be classified automatically. Log=" + $sfc.LogPath)
        }
    }
}

function Select-OfflineImage {
    $path = (Read-ToolkitPrompt "Offline image root or mount directory, for example D:\ or C:\Mount").Trim().Trim('"')
    if ([string]::IsNullOrWhiteSpace($path)) {
        Write-Host "No offline image selected."
        return
    }

    if (-not (Test-Path -LiteralPath $path -PathType Container)) {
        Write-Host "Folder not found."
        return
    }

    $windowsDir = Join-Path $path "Windows"
    $system32 = Join-Path $windowsDir "System32"
    if (-not (Test-Path -LiteralPath $system32 -PathType Container)) {
        Write-Host "That path does not look like an offline Windows image root because Windows\System32 was not found."
        return
    }

    $script:offlineImage = (Get-Item -LiteralPath $path).FullName
    Write-Host ("Offline image root selected: " + $script:offlineImage)
}

function Require-OfflineImage {
    if ([string]::IsNullOrWhiteSpace($script:offlineImage)) {
        Write-Host "Select an offline Windows directory first."
        return $false
    }

    if (-not (Test-Path -LiteralPath $script:offlineImage -PathType Container)) {
        Write-Host "The selected offline Windows directory is no longer available."
        $script:offlineImage = ""
        return $false
    }

    return $true
}

function Invoke-OfflineRestoreHealth {
    if (-not (Require-OfflineImage)) { return }

    Write-Host ""
    Write-Host ("Offline target: " + $script:offlineImage)
    Write-Host "RestoreHealth can change the selected offline Windows image."

    if (-not (Confirm-RepairAction "Run RestoreHealth on the selected offline Windows image?")) {
        Write-Host "Canceled. No offline DISM repair was started."
        Write-RepairJournal $action "OFFLINE_RESTORE_CANCELED" ("Image=" + $script:offlineImage)
        return
    }

    $args = @(
        ("/Image:" + $script:offlineImage),
        "/Cleanup-Image",
        "/RestoreHealth"
    )

    $result = Invoke-DismOperation -Label "Offline_RestoreHealth" -Arguments $args -Mutation
    $post = Get-DismHealthState -ImagePath $script:offlineImage -Label "Offline_PostRestore_CheckHealth"
    Write-DismRepairVerification -Check "Offline RestoreHealth" -HealthResult $post -OperationRebootRequired:$result.RebootRequired
}

function Invoke-OfflineAddDriver {
    if (-not (Require-OfflineImage)) { return }

    $driverPath = (Read-ToolkitPrompt "INF file or folder containing INF files").Trim().Trim('"')
    if (-not (Test-Path -LiteralPath $driverPath)) {
        Write-Host "Driver path not found."
        return
    }

    $item = Get-Item -LiteralPath $driverPath -ErrorAction SilentlyContinue
    if (-not $item) { return }

    $args = New-Object System.Collections.Generic.List[string]
    $args.Add(("/Image:" + $script:offlineImage))
    $args.Add("/Add-Driver")
    $args.Add(("/Driver:" + $item.FullName))
    if ($item.PSIsContainer) { $args.Add("/Recurse") }

    Write-Host ""
    Write-Host "Adding drivers changes the selected offline Windows image."
    if (-not (Confirm-RepairAction "Add the selected driver package(s) to the offline image?")) {
        Write-Host "Canceled. No offline driver package was added."
        Write-RepairJournal $action "OFFLINE_ADD_DRIVER_CANCELED" ("Path=" + $item.FullName)
        return
    }

    $result = Invoke-DismOperation -Label "Offline_AddDriver" -Arguments $args.ToArray() -Mutation
    $verify = Invoke-DismOperation -Label "Offline_VerifyDrivers" -Arguments @(
        ("/Image:" + $script:offlineImage),
        "/Get-Drivers",
        "/All",
        "/Format:Table"
    )

    if ($result.ExitCode -eq 0 -and $verify.ExitCode -eq 0) {
        Write-RepairVerification $action "Offline Add-Driver" "PARTIAL" "Add-Driver returned success and post-change driver inventory completed. DISM may rename imported INF packages, so the exact added package is not auto-classified."
    }
    elseif ($result.ExitCode -eq 0) {
        Write-RepairVerification $action "Offline Add-Driver" "PARTIAL" "Add-Driver returned success but post-change driver inventory failed."
    }
    else {
        Write-RepairVerification $action "Offline Add-Driver" "FAILED" ("DISM exit code=" + $result.ExitCode)
    }
}

function Invoke-OfflineFeatureChange {
    param([ValidateSet("Enable","Disable")][string]$Mode)

    if (-not (Require-OfflineImage)) { return }

    $feature = (Read-ToolkitPrompt "Exact DISM feature name").Trim()
    if ([string]::IsNullOrWhiteSpace($feature) -or $feature -notmatch '^[A-Za-z0-9_.-]+$') {
        Write-Host "Feature name contains unsupported characters."
        return
    }

    $verb = $(if ($Mode -eq "Enable") { "/Enable-Feature" } else { "/Disable-Feature" })
    $args = New-Object System.Collections.Generic.List[string]
    $args.Add(("/Image:" + $script:offlineImage))
    $args.Add($verb)
    $args.Add(("/FeatureName:" + $feature))
    if ($Mode -eq "Enable") { $args.Add("/All") }

    Write-Host ""
    Write-Host ($Mode + " changes the selected offline Windows image.")
    if (-not (Confirm-RepairAction ($Mode + " feature " + $feature + " in the offline image?"))) {
        Write-Host "Canceled. No offline feature state was changed."
        Write-RepairJournal $action "OFFLINE_FEATURE_CANCELED" ("Mode=" + $Mode + "; Feature=" + $feature)
        return
    }

    $result = Invoke-DismOperation -Label ("Offline_" + $Mode + "Feature_" + $feature) -Arguments $args.ToArray() -Mutation
    $verify = Invoke-DismOperation -Label ("Offline_VerifyFeature_" + $feature) -Arguments @(
        ("/Image:" + $script:offlineImage),
        "/Get-FeatureInfo",
        ("/FeatureName:" + $feature)
    )

    $expected = $(if ($Mode -eq "Enable") { "Enabled" } else { "Disabled" })
    $matched = $verify.Output -match ("(?im)^\s*State\s*:\s*" + [regex]::Escape($expected) + "\s*$")

    if ($result.RebootRequired) {
        Write-RepairVerification $action ("Offline " + $Mode + " Feature") "PENDING_REBOOT" ("Feature=" + $feature)
    }
    elseif ($result.ExitCode -eq 0 -and $verify.ExitCode -eq 0 -and $matched) {
        Write-RepairVerification $action ("Offline " + $Mode + " Feature") "VERIFIED" ("Feature=" + $feature + "; State=" + $expected)
    }
    elseif ($result.ExitCode -eq 0 -and $verify.ExitCode -eq 0) {
        Write-RepairVerification $action ("Offline " + $Mode + " Feature") "PARTIAL" ("Feature state could not be classified automatically; review " + $verify.LogPath)
    }
    else {
        Write-RepairVerification $action ("Offline " + $Mode + " Feature") "FAILED" ("Feature=" + $feature + "; ExitCode=" + $result.ExitCode)
    }
}


function Invoke-OfflinePackageAdd {
    if (-not (Require-OfflineImage)) { return }

    $path = (Read-ToolkitPrompt "CAB or MSU package path").Trim().Trim('"')
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
        Write-Host "Package file not found."
        return
    }

    $ext = [IO.Path]::GetExtension($path).ToLowerInvariant()
    if ($ext -notin @(".cab",".msu")) {
        Write-Host "Select a .cab or .msu package."
        return
    }

    Write-Host ""
    Write-Host "Adding a package changes the selected offline Windows image."
    Write-Host "Offline package state can remain install-pending until that image boots."

    if (-not (Confirm-RepairAction "Add this package to the offline image?")) {
        Write-Host "Canceled. No offline package was added."
        Write-RepairJournal $action "OFFLINE_ADD_PACKAGE_CANCELED" ("Path=" + $path)
        return
    }

    $result = Invoke-DismOperation -Label "Offline_AddPackage" -Arguments @(
        ("/Image:" + $script:offlineImage),
        "/Add-Package",
        ("/PackagePath:" + $path)
    ) -Mutation

    $verify = Invoke-DismOperation -Label "Offline_AfterAddPackage_GetPackages" -Arguments @(
        ("/Image:" + $script:offlineImage),
        "/Get-Packages"
    )

    if ($result.ExitCode -eq 0 -and $verify.ExitCode -eq 0) {
        Write-RepairVerification $action "Offline Add-Package" "PENDING_REBOOT" "DISM accepted the package and post-operation inventory completed. Offline package servicing may remain install-pending until the image boots."
    }
    elseif ($result.ExitCode -eq 0) {
        Write-RepairVerification $action "Offline Add-Package" "PARTIAL" "DISM accepted the package but post-operation inventory failed."
    }
    else {
        Write-RepairVerification $action "Offline Add-Package" "FAILED" ("ExitCode=" + $result.ExitCode)
    }
}

function Invoke-OfflinePackageRemove {
    if (-not (Require-OfflineImage)) { return }

    $package = (Read-ToolkitPrompt "Exact DISM package identity to remove from the offline image").Trim()
    if ([string]::IsNullOrWhiteSpace($package) -or $package.Length -gt 512) {
        Write-Host "Package identity is empty or too long."
        return
    }

    Write-Host ""
    Write-Host "Removing a package can make the offline image unbootable or remove required servicing content."

    $confirm = Read-ToolkitPrompt "Type REMOVE exactly to continue" -SpellExactPhrase "REMOVE"
    if ($confirm -cne "REMOVE") {
        Write-Host "Canceled. No offline package was removed."
        Write-RepairJournal $action "OFFLINE_REMOVE_PACKAGE_CANCELED" ("Package=" + $package)
        return
    }

    [void](Invoke-DismOperation -Label "Offline_BeforeRemovePackage_GetPackages" -Arguments @(
        ("/Image:" + $script:offlineImage),
        "/Get-Packages"
    ))

    $result = Invoke-DismOperation -Label "Offline_RemovePackage" -Arguments @(
        ("/Image:" + $script:offlineImage),
        "/Remove-Package",
        ("/PackageName:" + $package)
    ) -Mutation

    $verify = Invoke-DismOperation -Label "Offline_AfterRemovePackage_GetPackages" -Arguments @(
        ("/Image:" + $script:offlineImage),
        "/Get-Packages"
    )

    $stillPresent = $verify.Output.IndexOf($package,[System.StringComparison]::OrdinalIgnoreCase) -ge 0

    if ($result.ExitCode -eq 0 -and $verify.ExitCode -eq 0 -and -not $stillPresent) {
        Write-RepairVerification $action "Offline Remove-Package" "PENDING_REBOOT" ("Package no longer appears in the offline inventory; boot the image to complete/verify servicing: " + $package)
    }
    elseif ($result.ExitCode -eq 0 -and $verify.ExitCode -eq 0) {
        Write-RepairVerification $action "Offline Remove-Package" "PARTIAL" ("Package still appears in inventory or may be pending removal: " + $package)
    }
    elseif ($result.ExitCode -eq 0) {
        Write-RepairVerification $action "Offline Remove-Package" "PARTIAL" "Removal returned success but post-operation inventory failed."
    }
    else {
        Write-RepairVerification $action "Offline Remove-Package" "FAILED" ("Package=" + $package + "; ExitCode=" + $result.ExitCode)
    }
}

function Invoke-OnlineFeatureChange {
    param([ValidateSet("Enable","Disable")][string]$Mode)

    $feature = (Read-ToolkitPrompt "Exact DISM feature name").Trim()
    if ([string]::IsNullOrWhiteSpace($feature) -or $feature -notmatch '^[A-Za-z0-9_.-]+$') {
        Write-Host "Feature name contains unsupported characters."
        return
    }

    $verb = $(if ($Mode -eq "Enable") { "/Enable-Feature" } else { "/Disable-Feature" })
    $args = New-Object System.Collections.Generic.List[string]
    $args.Add("/Online")
    $args.Add($verb)
    $args.Add(("/FeatureName:" + $feature))
    if ($Mode -eq "Enable") { $args.Add("/All") }

    Write-Host ""
    Write-Host ($Mode + " changes the running Windows installation and may require a restart.")

    if (-not (Confirm-RepairAction ($Mode + " feature " + $feature + " on the running Windows installation?"))) {
        Write-Host "Canceled. No online feature state was changed."
        Write-RepairJournal $action "ONLINE_FEATURE_CANCELED" ("Mode=" + $Mode + "; Feature=" + $feature)
        return
    }

    $result = Invoke-DismOperation -Label ("Online_" + $Mode + "Feature_" + $feature) -Arguments $args.ToArray() -Mutation
    $verify = Invoke-DismOperation -Label ("Online_VerifyFeature_" + $feature) -Arguments @(
        "/Online",
        "/Get-FeatureInfo",
        ("/FeatureName:" + $feature)
    )

    $expected = $(if ($Mode -eq "Enable") { "Enabled" } else { "Disabled" })
    $matched = $verify.Output -match ("(?im)^\s*State\s*:\s*" + [regex]::Escape($expected) + "\s*$")

    if ($result.RebootRequired) {
        Write-RepairVerification $action ("Online " + $Mode + " Feature") "PENDING_REBOOT" ("Feature=" + $feature)
    }
    elseif ($result.ExitCode -eq 0 -and $verify.ExitCode -eq 0 -and $matched) {
        Write-RepairVerification $action ("Online " + $Mode + " Feature") "VERIFIED" ("Feature=" + $feature + "; State=" + $expected)
    }
    elseif ($result.ExitCode -eq 0 -and $verify.ExitCode -eq 0) {
        Write-RepairVerification $action ("Online " + $Mode + " Feature") "PARTIAL" ("Feature state could not be classified automatically; review " + $verify.LogPath)
    }
    else {
        Write-RepairVerification $action ("Online " + $Mode + " Feature") "FAILED" ("Feature=" + $feature + "; ExitCode=" + $result.ExitCode)
    }
}

function Show-OfflineMenu {
    while ($true) {
        Write-Host ""
        if ($script:screenReaderEnabled) {
            Write-Host "Offline Windows Image Servicing menu."
            Write-Host ("Selected offline image root: " + $(if ($script:offlineImage) { $script:offlineImage } else { "none selected" }))
            Write-Host "Option 1. Select an offline Windows image root or mount directory. Selection only."
            Write-Host "Option 2. CheckHealth. Read-only."
            Write-Host "Option 3. ScanHealth. Read-only."
            Write-Host "Option 4. RestoreHealth. State-changing. Changes the selected offline image."
            Write-Host "Option 5. Analyze Component Store. Read-only."
            Write-Host "Option 6. List packages. Read-only."
            Write-Host "Option 7. List Windows features. Read-only."
            Write-Host "Option 8. List drivers. Read-only."
            Write-Host "Option 9. Add driver packages. State-changing. Changes the selected offline image."
            Write-Host "Option 10. Enable a Windows feature. State-changing. Changes the selected offline image."
            Write-Host "Option 11. Disable a Windows feature. State-changing. Changes the selected offline image."
            Write-Host "Option 12. Add a CAB or MSU package. State-changing. Changes the selected offline image."
            Write-Host "Option 13. Remove a package by exact identity. High-impact state-changing action."
            Write-Host "Option 14. Inspect a WIM or ESD file. Read-only."
        }
        else {
            Write-Host "OFFLINE WINDOWS IMAGE SERVICING"
            Write-Host ("Selected image: " + $(if ($script:offlineImage) { $script:offlineImage } else { "(none)" }))
            Write-Host ""
            Write-Host " 1. Select offline Windows directory."
            Write-Host " 2. CheckHealth. Read-only."
            Write-Host " 3. ScanHealth. Read-only."
            Write-Host " 4. RestoreHealth. Changes offline image."
            Write-Host " 5. Analyze Component Store. Read-only."
            Write-Host " 6. List packages. Read-only."
            Write-Host " 7. List features. Read-only."
            Write-Host " 8. List drivers. Read-only."
            Write-Host " 9. Add driver package(s). Changes offline image."
            Write-Host "10. Enable feature. Changes offline image."
            Write-Host "11. Disable feature. Changes offline image."
            Write-Host "12. Add CAB / MSU package. Changes offline image."
            Write-Host "13. Remove package by exact identity. Changes offline image."
            Write-Host "14. Inspect WIM / ESD file. Read-only."
        }
        Write-DismMenuNavigationHelp -Submenu
        Write-Host ""

        $choice = Resolve-DismMenuChoice -InputValue (Read-ToolkitPrompt "Select an option") -Submenu
        if ($choice -eq "__EXIT__") { return }
        if ($choice -eq "__BACK__") { return }

        switch ($choice) {
            "1" { Select-OfflineImage }
            "2" {
                if (Require-OfflineImage) {
                    $r = Get-DismHealthState -ImagePath $script:offlineImage -Label "Offline_CheckHealth"
                    Write-Host ("Classified component-store state: " + $r.State)
                }
            }
            "3" {
                if (Require-OfflineImage) {
                    [void](Invoke-DismOperation -Label "Offline_ScanHealth" -Arguments @(
                        ("/Image:" + $script:offlineImage),
                        "/Cleanup-Image",
                        "/ScanHealth"
                    ))
                }
            }
            "4" { Invoke-OfflineRestoreHealth }
            "5" {
                if (Require-OfflineImage) { Invoke-AnalyzeComponentStore -ImagePath $script:offlineImage }
            }
            "6" {
                if (Require-OfflineImage) {
                    [void](Invoke-DismOperation -Label "Offline_GetPackages" -Arguments @(
                        ("/Image:" + $script:offlineImage),
                        "/Get-Packages"
                    ))
                }
            }
            "7" {
                if (Require-OfflineImage) {
                    [void](Invoke-DismOperation -Label "Offline_GetFeatures" -Arguments @(
                        ("/Image:" + $script:offlineImage),
                        "/Get-Features",
                        "/Format:Table"
                    ))
                }
            }
            "8" {
                if (Require-OfflineImage) {
                    [void](Invoke-DismOperation -Label "Offline_GetDrivers" -Arguments @(
                        ("/Image:" + $script:offlineImage),
                        "/Get-Drivers",
                        "/All",
                        "/Format:Table"
                    ))
                }
            }
            "9" { Invoke-OfflineAddDriver }
            "10" { Invoke-OfflineFeatureChange -Mode "Enable" }
            "11" { Invoke-OfflineFeatureChange -Mode "Disable" }
            "12" { Invoke-OfflinePackageAdd }
            "13" { Invoke-OfflinePackageRemove }
            "14" { Invoke-ImageInfo }
            default { Write-Host "Choose 1 through 14, B/BACK/RETURN, Q/QUIT/EXIT/X, or 99." }
        }
    }
}

function Invoke-ResetBase {
    Write-Host ""
    Write-Host "ADVANCED: STARTCOMPONENTCLEANUP /RESETBASE"
    Write-Host ""
    Write-Host "WARNING - IRREVERSIBLE SERVICING ACTION"
    if ($script:screenReaderEnabled) {
        Write-Host "Screen reader warning. ResetBase is an irreversible, high-impact servicing operation."
        Write-Host "Three exact typed confirmations are required before DISM can start."
    }
    Write-Host ""
    Write-Host "This permanently removes superseded component versions."
    Write-Host "After /ResetBase, currently installed superseded updates cannot be uninstalled."
    Write-Host "This toolkit cannot restore those removed superseded component versions or make"
    Write-Host "those installed updates uninstallable again after /ResetBase completes."
    Write-Host ""
    Write-Host "INITIAL ACKNOWLEDGEMENT"
    Write-Host "Before the existing ResetBase confirmations, acknowledge that you understand"
    Write-Host "this operation is irreversible and can remove normal update rollback capability."
    Write-Host ""
    Write-Host "Type I UNDERSTAND exactly to continue to the existing ResetBase confirmations."
    if ($script:screenReaderEnabled) {
        Write-Host "Screen reader spelling: I, space, U N D E R S T A N D."
    }
    Write-Host "Any other entry cancels without making component-store changes."
    Write-Host ""

    $acknowledge = Read-ToolkitPrompt "Initial ResetBase acknowledgement" -SpellExactPhrase "I UNDERSTAND"
    if ($acknowledge -cne "I UNDERSTAND") {
        Write-Host ""
        Write-Host "Canceled. Initial acknowledgement did not match."
        Write-Host "/ResetBase was not started. No component-store changes were made."
        Write-RepairJournal $action "RESETBASE_CANCELED_ACK" "Initial acknowledgement was not I UNDERSTAND."
        return
    }

    Write-RepairJournal $action "RESETBASE_ACKNOWLEDGED" "Technician entered I UNDERSTAND before the existing ResetBase confirmation gates."
    Write-Host ""

    Write-Host "First confirmation requires the exact word RESETBASE."
    Write-Host "Spelling: R E S E T B A S E. All letters are uppercase."
    Write-Host "There are no spaces, hyphens, or other punctuation."
    Write-Host ""

    if (-not (Confirm-RepairPhrase "First confirmation: this is an irreversible component-store cleanup operation." "RESETBASE")) {
        Write-Host "Canceled. /ResetBase was not started."
        Write-RepairJournal $action "RESETBASE_CANCELED_STAGE1" "First confirmation was not completed."
        return
    }

    Write-Host ""
    Write-Host "SECOND AND FINAL CONFIRMATION"
    if ($script:screenReaderEnabled) {
        Write-Host "Screen reader warning. This is the final confirmation gate. Any entry other than ResetBase-Confirm cancels and returns to the Advanced DISM menu."
    }
    Write-Host ""
    Write-Host "ResetBase will permanently remove superseded component versions."
    Write-Host "Updates affected by /ResetBase will no longer be removable/uninstallable afterward."
    Write-Host "This toolkit cannot reverse that servicing decision after DISM completes."
    Write-Host ""
    Write-Host "To confirm this action, enter ResetBase-Confirm exactly."
    Write-Host "Capital R, capital B, hyphen, capital C. No spaces."
    Write-Host "Exact phrase: ResetBase-Confirm"
    Write-Host "Any other entry, including 0 or pressing Enter, returns to the Advanced DISM menu"
    Write-Host "without making changes."
    Write-Host ""

    $finalConfirm = Read-ToolkitPrompt "Final ResetBase confirmation"

    if ($finalConfirm -cne "ResetBase-Confirm") {
        Write-Host ""
        Write-Host "Canceled. Final confirmation did not match."
        Write-Host "/ResetBase was not started. No component-store changes were made."
        Write-Host "Returning to the Advanced DISM menu."
        Write-RepairJournal $action "RESETBASE_CANCELED_STAGE2" "Final confirmation was not ResetBase-Confirm."
        return
    }

    Write-RepairJournal $action "RESETBASE_CONFIRMED" "Initial acknowledgement plus both existing ResetBase confirmation stages completed."

    [void](Invoke-DismOperation -Label "Before_ResetBase_AnalyzeComponentStore" -Arguments @(
        "/Online","/Cleanup-Image","/AnalyzeComponentStore"
    ))

    $result = Invoke-DismOperation -Label "Online_StartComponentCleanup_ResetBase" -Arguments @(
        "/Online","/Cleanup-Image","/StartComponentCleanup","/ResetBase"
    ) -Mutation

    $post = Invoke-DismOperation -Label "After_ResetBase_AnalyzeComponentStore" -Arguments @(
        "/Online","/Cleanup-Image","/AnalyzeComponentStore"
    )

    if ($result.RebootRequired) {
        Write-RepairVerification $action "StartComponentCleanup /ResetBase" "PENDING_REBOOT" ("ExitCode=" + $result.ExitCode)
    }
    elseif ($result.ExitCode -eq 0 -and $post.ExitCode -eq 0) {
        Write-RepairVerification $action "StartComponentCleanup /ResetBase" "VERIFIED" "ResetBase returned success and post-operation analysis completed."
    }
    elseif ($result.ExitCode -eq 0) {
        Write-RepairVerification $action "StartComponentCleanup /ResetBase" "PARTIAL" "ResetBase returned success but post-operation analysis failed."
    }
    else {
        Write-RepairVerification $action "StartComponentCleanup /ResetBase" "FAILED" ("ExitCode=" + $result.ExitCode)
    }
}

function Invoke-OnlinePackageRemove {
    $package = (Read-ToolkitPrompt "Exact DISM package identity to remove").Trim()
    if ([string]::IsNullOrWhiteSpace($package) -or $package.Length -gt 512) {
        Write-Host "Package identity is empty or too long."
        return
    }

    Write-Host ""
    Write-Host "Removing a Windows package can make updates or Windows features unavailable."
    Write-Host "This is an advanced operation and may require a restart."

    $confirm = Read-ToolkitPrompt "Type REMOVE exactly to continue" -SpellExactPhrase "REMOVE"
    if ($confirm -cne "REMOVE") {
        Write-Host "Canceled. No package was removed."
        Write-RepairJournal $action "REMOVE_PACKAGE_CANCELED" ("Package=" + $package)
        return
    }

    [void](Invoke-DismOperation -Label "Before_RemovePackage_GetPackages" -Arguments @("/Online","/Get-Packages"))

    $result = Invoke-DismOperation -Label "Online_RemovePackage" -Arguments @(
        "/Online","/Remove-Package",("/PackageName:" + $package)
    ) -Mutation

    $verify = Invoke-DismOperation -Label "After_RemovePackage_GetPackages" -Arguments @("/Online","/Get-Packages")
    $stillPresent = $verify.Output.IndexOf($package,[System.StringComparison]::OrdinalIgnoreCase) -ge 0

    if ($result.RebootRequired) {
        Write-RepairVerification $action "Remove-Package" "PENDING_REBOOT" ("Package=" + $package)
    }
    elseif ($result.ExitCode -eq 0 -and $verify.ExitCode -eq 0 -and -not $stillPresent) {
        Write-RepairVerification $action "Remove-Package" "VERIFIED" ("Package no longer appears in post-operation package inventory: " + $package)
    }
    elseif ($result.ExitCode -eq 0 -and $verify.ExitCode -eq 0) {
        Write-RepairVerification $action "Remove-Package" "PARTIAL" ("Package still appears in inventory or may be pending removal: " + $package)
    }
    else {
        Write-RepairVerification $action "Remove-Package" "FAILED" ("Package=" + $package + "; ExitCode=" + $result.ExitCode)
    }
}

function Invoke-OnlinePackageAdd {
    $path = (Read-ToolkitPrompt "CAB or MSU package path").Trim().Trim('"')
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
        Write-Host "Package file not found."
        return
    }

    $ext = [IO.Path]::GetExtension($path).ToLowerInvariant()
    if ($ext -notin @(".cab",".msu")) {
        Write-Host "Select a .cab or .msu package."
        return
    }

    if ($ext -eq ".msu" -and $script:osBuild -gt 0 -and $script:osBuild -lt 22000) {
        Write-Host "Online DISM Add-Package for .msu files is supported on Windows 11 version 21H2 and later."
        Write-Host ("Detected build: " + $script:osBuild + ". Use a supported servicing method or an offline image for this package.")
        return
    }

    Write-Host ""
    Write-Host "Adding a package changes the running Windows installation and may require a restart."

    if (-not (Confirm-RepairAction "Add this package to the running Windows installation?")) {
        Write-Host "Canceled. No package was added."
        Write-RepairJournal $action "ADD_PACKAGE_CANCELED" ("Path=" + $path)
        return
    }

    $result = Invoke-DismOperation -Label "Online_AddPackage" -Arguments @(
        "/Online","/Add-Package",("/PackagePath:" + $path)
    ) -Mutation

    $verify = Invoke-DismOperation -Label "After_AddPackage_GetPackages" -Arguments @("/Online","/Get-Packages")

    if ($result.RebootRequired) {
        Write-RepairVerification $action "Add-Package" "PENDING_REBOOT" ("Path=" + $path)
    }
    elseif ($result.ExitCode -eq 0 -and $verify.ExitCode -eq 0) {
        Write-RepairVerification $action "Add-Package" "PARTIAL" "Package addition returned success and post-operation inventory completed. Exact package identity is not auto-derived for every CAB/MSU form."
    }
    elseif ($result.ExitCode -eq 0) {
        Write-RepairVerification $action "Add-Package" "PARTIAL" "Package addition returned success but post-operation inventory failed."
    }
    else {
        Write-RepairVerification $action "Add-Package" "FAILED" ("ExitCode=" + $result.ExitCode)
    }
}

function Invoke-RevertPendingActions {
    if (-not (Require-OfflineImage)) { return }

    Write-Host ""
    Write-Host "REVERT PENDING ACTIONS - OFFLINE IMAGE ONLY"
    Write-Host "This recovery operation is intended for an offline Windows image that cannot complete pending servicing actions."
    Write-Host "Do not use it casually on a healthy installation."

    if (-not (Confirm-RepairPhrase "This changes pending servicing state in the selected offline Windows image." "REVERT")) {
        Write-Host "Canceled. Pending actions were not reverted."
        Write-RepairJournal $action "REVERT_PENDING_CANCELED" ("Image=" + $script:offlineImage)
        return
    }

    $result = Invoke-DismOperation -Label "Offline_RevertPendingActions" -Arguments @(
        ("/Image:" + $script:offlineImage),
        "/Cleanup-Image",
        "/RevertPendingActions"
    ) -Mutation

    if ($result.ExitCode -eq 0) {
        Write-RepairVerification $action "RevertPendingActions" "PENDING_REBOOT" "DISM accepted the offline recovery operation; boot the repaired image and verify servicing state."
    }
    else {
        Write-RepairVerification $action "RevertPendingActions" "FAILED" ("ExitCode=" + $result.ExitCode)
    }
}

function Invoke-MountWim {
    $wim = (Read-ToolkitPrompt "WIM file path").Trim().Trim('"')
    if (-not (Test-Path -LiteralPath $wim -PathType Leaf) -or [IO.Path]::GetExtension($wim) -ine ".wim") {
        Write-Host "Select an existing .wim file."
        return
    }

    [void](Invoke-DismOperation -Label "Mount_GetWimInfo" -Arguments @("/Get-WimInfo",("/WimFile:" + $wim)))

    $indexText = (Read-ToolkitPrompt "Image index to mount").Trim()
    $index = 0
    if (-not [int]::TryParse($indexText,[ref]$index) -or $index -lt 1) {
        Write-Host "Invalid image index."
        return
    }

    $mountDir = (Read-ToolkitPrompt "Empty mount directory").Trim().Trim('"')
    if (-not (Test-Path -LiteralPath $mountDir -PathType Container)) {
        Write-Host "Mount directory must already exist."
        return
    }

    if (@(Get-ChildItem -LiteralPath $mountDir -Force -ErrorAction SilentlyContinue).Count -gt 0) {
        Write-Host "Mount directory is not empty."
        return
    }

    if (-not (Confirm-RepairPhrase "Mounting a WIM creates a persistent DISM mount until it is unmounted." "MOUNT")) {
        Write-Host "Canceled. Image was not mounted."
        return
    }

    $result = Invoke-DismOperation -Label "Mount_Image" -Arguments @(
        "/Mount-Image",
        ("/ImageFile:" + $wim),
        ("/Index:" + $index),
        ("/MountDir:" + $mountDir)
    ) -Mutation

    $verify = Invoke-DismOperation -Label "Verify_MountedImages" -Arguments @("/Get-MountedImageInfo")
    $found = $verify.Output.IndexOf($mountDir,[System.StringComparison]::OrdinalIgnoreCase) -ge 0

    if ($result.ExitCode -eq 0 -and $verify.ExitCode -eq 0 -and $found) {
        Write-RepairVerification $action "Mount WIM" "VERIFIED" ("Mounted image is listed at " + $mountDir)
    }
    elseif ($result.ExitCode -eq 0) {
        Write-RepairVerification $action "Mount WIM" "PARTIAL" ("Mount returned success but post-mount inventory did not clearly show " + $mountDir)
    }
    else {
        Write-RepairVerification $action "Mount WIM" "FAILED" ("ExitCode=" + $result.ExitCode)
    }
}

function Invoke-UnmountWim {
    param([ValidateSet("Commit","Discard")][string]$Mode)

    $mountDir = (Read-ToolkitPrompt "Mounted image directory").Trim().Trim('"')
    if (-not (Test-Path -LiteralPath $mountDir -PathType Container)) {
        Write-Host "Mount directory not found."
        return
    }

    $phrase = $(if ($Mode -eq "Commit") { "COMMIT" } else { "DISCARD" })
    $description = $(if ($Mode -eq "Commit") {
        "Committing writes all mounted-image changes back to the WIM."
    } else {
        "Discarding abandons all uncommitted mounted-image changes."
    })

    if (-not (Confirm-RepairPhrase $description $phrase)) {
        Write-Host "Canceled. Mounted image was not unmounted."
        return
    }

    $modeArg = $(if ($Mode -eq "Commit") { "/Commit" } else { "/Discard" })
    $result = Invoke-DismOperation -Label ("Unmount_Image_" + $Mode) -Arguments @(
        "/Unmount-Image",
        ("/MountDir:" + $mountDir),
        $modeArg
    ) -Mutation

    $verify = Invoke-DismOperation -Label "Verify_MountedImages_AfterUnmount" -Arguments @("/Get-MountedImageInfo")
    $stillFound = $verify.Output.IndexOf($mountDir,[System.StringComparison]::OrdinalIgnoreCase) -ge 0

    if ($result.ExitCode -eq 0 -and $verify.ExitCode -eq 0 -and -not $stillFound) {
        Write-RepairVerification $action ("Unmount WIM " + $Mode) "VERIFIED" ("Mount directory is no longer listed as an active DISM image: " + $mountDir)
    }
    elseif ($result.ExitCode -eq 0) {
        Write-RepairVerification $action ("Unmount WIM " + $Mode) "PARTIAL" "Unmount returned success but mounted-image inventory could not confirm removal."
    }
    else {
        Write-RepairVerification $action ("Unmount WIM " + $Mode) "FAILED" ("ExitCode=" + $result.ExitCode)
    }
}

function Show-AdvancedMenu {
    while ($true) {
        Write-Host ""
        if ($script:screenReaderEnabled) {
            Write-Host "Advanced and High-Impact DISM Operations menu."
            Write-Host "These options require extra care. State-changing and irreversible actions are explicitly identified."
            Write-Host "Option 1. Start Component Cleanup with ResetBase. IRREVERSIBLE. Requires three exact typed confirmations."
            Write-Host "Option 2. Remove an online Windows package by exact identity. High-impact state-changing action."
            Write-Host "Option 3. Add an online CAB or MSU package. State-changing."
            Write-Host "Option 4. Enable an online Windows feature. State-changing."
            Write-Host "Option 5. Disable an online Windows feature. State-changing."
            Write-Host "Option 6. Revert Pending Actions. Offline image only. Recovery action. State-changing."
            Write-Host "Option 7. Mount a WIM image. State-changing DISM mount state."
            Write-Host "Option 8. Unmount a WIM and commit changes. High-impact. Writes mounted-image changes back."
            Write-Host "Option 9. Unmount a WIM and discard changes. High-impact. Discards uncommitted changes."
            Write-Host "Option 10. Show mounted image inventory. Read-only."
        }
        else {
            Write-Host "ADVANCED / HIGH-IMPACT DISM OPERATIONS"
            Write-Host ""
            Write-Host " 1. StartComponentCleanup /ResetBase. IRREVERSIBLE."
            Write-Host " 2. Remove online package by exact identity."
            Write-Host " 3. Add online CAB/MSU package."
            Write-Host " 4. Enable online Windows feature."
            Write-Host " 5. Disable online Windows feature."
            Write-Host " 6. RevertPendingActions. OFFLINE IMAGE ONLY."
            Write-Host " 7. Mount WIM."
            Write-Host " 8. Unmount WIM and COMMIT."
            Write-Host " 9. Unmount WIM and DISCARD."
            Write-Host "10. Show mounted image inventory. Read-only."
        }
        Write-DismMenuNavigationHelp -Submenu
        Write-Host ""

        $choice = Resolve-DismMenuChoice -InputValue (Read-ToolkitPrompt "Select an option") -Submenu
        if ($choice -eq "__EXIT__") { return }
        if ($choice -eq "__BACK__") { return }

        switch ($choice) {
            "1" { Invoke-ResetBase }
            "2" { Invoke-OnlinePackageRemove }
            "3" { Invoke-OnlinePackageAdd }
            "4" { Invoke-OnlineFeatureChange -Mode "Enable" }
            "5" { Invoke-OnlineFeatureChange -Mode "Disable" }
            "6" { Invoke-RevertPendingActions }
            "7" { Invoke-MountWim }
            "8" { Invoke-UnmountWim -Mode "Commit" }
            "9" { Invoke-UnmountWim -Mode "Discard" }
            "10" { [void](Invoke-DismOperation -Label "Get_MountedImageInfo" -Arguments @("/Get-MountedImageInfo")) }
            default { Write-Host "Choose 1 through 10, B/BACK/RETURN, Q/QUIT/EXIT/X, or 99." }
        }
    }
}

function Show-Preflight {
    Write-Host "DISM SERVICE CENTER"
    Write-Host ""
    Write-Host ("Computer: " + $env:COMPUTERNAME)

    if ($script:osInfo) {
        Write-Host ("Windows: " + $script:osInfo.Caption + " | Build " + $script:osInfo.BuildNumber + " | " + $script:osInfo.OSArchitecture)
    }
    else {
        Write-Host "Windows identity: unavailable"
    }

    Write-Host "Elevation: Administrator"
    if ($script:screenReaderEnabled) {
        Write-Host "Screen Reader Mode: Enabled. Inherited from the main toolkit context."
    }
    else {
        Write-Host "Screen Reader Mode: Disabled."
    }
    Write-Host ("DISM: " + $dismPath)
    Write-Host ("Session logs: " + $session)
    Write-Host ""

    [void](Invoke-DismOperation -Label "Preflight_GetCurrentEdition" -Arguments @("/Online","/Get-CurrentEdition"))
}

Write-RepairJournal $action "SESSION_START" ("Session=" + $session + "; ScreenReaderMode=" + $script:screenReaderEnabled)
Show-Preflight

while ($true) {
    Write-Host ""
    if ($script:screenReaderEnabled) {
        Write-Host "DISM Service Center main menu."
        Write-Host "Option 1. CheckHealth. Fast component-store corruption flag check. Read-only."
        Write-Host "Option 2. ScanHealth. Full component-store corruption scan. Read-only."
        Write-Host "Option 3. RestoreHealth. State-changing repair of the running Windows component store."
        Write-Host "Option 4. RestoreHealth with a WIM, ESD, or folder repair source. State-changing."
        Write-Host "Option 5. Analyze Component Store. Read-only."
        Write-Host "Option 6. Start Component Cleanup. State-changing cleanup. Does not use ResetBase."
        Write-Host "Option 7. Component Store, Package, Capability, and Feature Inventory. Read-only."
        Write-Host "Option 8. Windows Feature Inventory. Read-only."
        Write-Host "Option 9. Driver Inventory through DISM. Read-only."
        Write-Host "Option 10. Image, WIM, or ESD Information. Read-only."
        Write-Host "Option 11. Offline Windows Image Servicing submenu."
        Write-Host "Option 12. DISM and CBS Logs plus evidence copy. Read-only collection."
        Write-Host "Option 13. DISM Diagnostic Bundle. Read-only diagnostic collection."
        Write-Host "Option 14. Recommended Guided Repair Sequence. Includes read-only assessment followed by an explicit confirmation before RestoreHealth."
        Write-Host "Option 90. Advanced and High-Impact Operations submenu."
    }
    else {
        Write-Host "DISM SERVICE CENTER"
        Write-Host ""
        Write-Host " 1. CheckHealth. Fast corruption flag check. READ-ONLY."
        Write-Host " 2. ScanHealth. Full component-store scan. READ-ONLY."
        Write-Host " 3. RestoreHealth. Repair running Windows."
        Write-Host " 4. RestoreHealth with WIM / ESD / folder source."
        Write-Host " 5. Analyze Component Store. READ-ONLY."
        Write-Host " 6. Start Component Cleanup."
        Write-Host " 7. Component Store / Package Inventory. READ-ONLY."
        Write-Host " 8. Windows Feature Inventory. READ-ONLY."
        Write-Host " 9. Driver Inventory via DISM. READ-ONLY."
        Write-Host "10. Image / WIM / ESD Information. READ-ONLY."
        Write-Host "11. Offline Windows Image Servicing."
        Write-Host "12. DISM / CBS Logs and Evidence Copy."
        Write-Host "13. DISM Diagnostic Bundle."
        Write-Host "14. Recommended Guided Repair Sequence."
        Write-Host "90. Advanced / High-Impact Operations."
    }
    Write-DismMenuNavigationHelp
    Write-Host ""

    $choice = Resolve-DismMenuChoice -InputValue (Read-ToolkitPrompt "Select an option")
    if ($choice -eq "__EXIT__") { break }

    switch ($choice) {
        "1" { Invoke-OnlineCheckHealth }
        "2" { Invoke-OnlineScanHealth }
        "3" { Invoke-OnlineRestoreHealth }
        "4" { Invoke-SourceAssistedRestore }
        "5" { Invoke-AnalyzeComponentStore }
        "6" { Invoke-StartComponentCleanup }
        "7" { Invoke-OnlineInventory }
        "8" { Invoke-FeatureInventory }
        "9" { Invoke-DriverInventory }
        "10" { Invoke-ImageInfo }
        "11" {
            Show-OfflineMenu
            if (-not $script:exitServiceCenter) {
                Write-DismAccessibilityAnnouncement "Returned to the DISM Service Center main menu."
            }
        }
        "12" { Show-DismLogs }
        "13" { Create-DismDiagnosticBundle }
        "14" { Invoke-GuidedRepairSequence }
        "90" {
            Show-AdvancedMenu
            if (-not $script:exitServiceCenter) {
                Write-DismAccessibilityAnnouncement "Returned to the DISM Service Center main menu."
            }
        }
        default { Write-Host "Choose 1 through 14, 90, B/BACK/RETURN, Q/QUIT/EXIT/X, or 99." }
    }

    if ($script:exitServiceCenter) { break }
}

Write-RepairJournal $action "SESSION_END" ("Session=" + $session + "; ExitRequested=" + $script:exitServiceCenter)
Write-Host ""
Write-Host ("DISM Service Center session folder: " + $session)
exit 0

@echo off
setlocal EnableExtensions
title Disk and File-System Health / Repair

echo Disk and File-System Health / Repair
echo.
echo Health snapshot first; repair actions are selected separately.
echo CHKDSK /F is confirmed because it can modify file-system metadata.
net session >nul 2>&1
if errorlevel 1 (
    echo Administrator privileges are required.
    echo Use Home option 4 to relaunch the toolkit as Administrator.
    if "%SRMODE%"=="1" (
        echo Press any key to continue.
        pause >nul
    ) else (
        pause
    )
    exit /b 1
)

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Disk-FileSystem-Health-Repair.ps1"
set "RC=%errorlevel%"

if "%SRMODE%"=="1" (
    echo.
    echo Disk and File-System Health / Repair finished with return code %RC%.
    echo Press any key to continue.
    pause >nul
) else (
    echo.
    pause
)

exit /b %RC%

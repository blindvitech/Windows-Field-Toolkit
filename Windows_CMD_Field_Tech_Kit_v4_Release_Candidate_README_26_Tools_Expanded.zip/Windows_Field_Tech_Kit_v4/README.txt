WINDOWS CMD FIELD TECH TOOLKIT v4
=================================

Portable Windows 10/11 troubleshooting, diagnostic, repair, and documentation
toolkit for field technicians.

Release line:
  Shared Diagnostic Engine + Evidence Correlation

Primary launcher:
  RUN-WINDOWS-FIELD-TECH.cmd

Toolkit surface:
  Basic:     25 tools
  Advanced:  76 tools
  Tools:     43 tools
  Repair:    14 tools
  Total:    158 numbered tools

For a full handoff/release description, also read:
  Documentation\RELEASE-MANIFEST-v4.txt


CURRENT BUILD SNAPSHOT
======================

This README describes the current v4 platform. The numbered-tool catalog shown
above is the authoritative current surface.

Additional platform capabilities:
- native-CMD WinPE / WinRE Offline Companion;
- active Collect Case artifact recorder;
- shared diagnostic/evidence correlation engine;
- Known-Good protected-core recovery;
- build-keyed first-run AUTO-VERIFIED validation;
- screen-reader/accessibility mode;
- guarded repair, verification, journaling, and rollback-oriented workflows.

The WinPE companion is separate from the 158-tool main catalog.

Build identity is the SHA-256 of the current Known-Good manifest. Do not use the
v4 release-line baseline date as the identity of a particular build. For the
current BuildId and field-validation state, read:
  FIELD-VALIDATION-STATUS.txt


CONTENTS / DOCUMENT MAP
=======================

Start here:
- QUICK START
- OPERATING MODEL
- WHAT THE TOOLKIT COVERS
- FIELD WORKFLOW RECOMMENDATION
- IMPORTANT LIMITATIONS
- RELEASE STATUS

Core platform:
- FULL MACHINE REPORT
- TOOLKIT v4 DIAGNOSTIC ENGINE
- EVIDENCE CORRELATION
- CAPABILITY / QUERY STATUS
- REPORT METADATA
- FOUNDATION HEALTH
- KNOWN-GOOD CORE / TOOLKIT INTEGRITY

Safety / accessibility:
- SAFETY / PRIVACY
- REPAIR MENU
- SCREEN READER / ACCESSIBILITY MODE
- RESETBASE THREE-GATE INTENT CONFIRMATION
- SMB CREDENTIAL MEMORY HYGIENE

Troubleshooting / field workflows:
- NETWORK TROUBLESHOOTING INVESTIGATORS
- SMB CONNECTIVITY / TROUBLESHOOTING INVESTIGATOR
- WINDOWS SERVICING / UPDATE HEALTH REPORT
- DOMAIN TRUST / AD HEALTH + SHARED CONFIDENCE
- COLLECT CASE - LIVE ARTIFACT CAPTURE

Offline recovery:
- WINPE / WINRE OFFLINE COMPANION

Additional handoff/audit documentation:
- Documentation\RELEASE-MANIFEST-v4.txt       current platform/release handoff
- Documentation\SCRIPT-AUDIT.txt              current audit summary + history
- Documentation\ACCESSIBILITY-AUDIT.txt       current accessibility summary + history
- Documentation\REPAIR-CONFIRMATION-AUDIT.txt repair confirmation contract
- Documentation\STATE-CHANGE-CONFIRMATION-AUDIT.txt
                                               non-Repair state-change contract


QUICK START
===========

Normal Windows:
1. Extract the toolkit to a local folder on the Windows PC being serviced.
2. Run:
     RUN-WINDOWS-FIELD-TECH.cmd
3. If the troubleshooting session should be preserved as one case, start
   Tools -> Collect Case before running the other diagnostics.
4. Use BASIC or ADVANCED for diagnostics and inventory.
5. Use TOOLS for support, case, reporting, validation, and utility functions.
6. Use REPAIR only when a state-changing action is actually needed.
7. If Collect Case is active, finish with Case Closeout so the final sweep,
   case report, and refreshed ZIP are created.
8. Review normal output in:
     Logs\

WinPE / WinRE:
- Launch the same RUN-WINDOWS-FIELD-TECH.cmd.
- MiniNT detection occurs before the first PowerShell dependency and
  automatically routes to the native-CMD Offline Companion.
- See 90_WinPE_Offline_Companion\README-WINPE.txt for offline recovery scope.

Administrator-required tools request elevation through Windows UAC.

Screen-reader users can press A in the launcher or start with:

  RUN-WINDOWS-FIELD-TECH.cmd /accessibility

or:

  RUN-WINDOWS-FIELD-TECH.cmd /screenreader


OPERATING MODEL
===============

The toolkit follows this workflow:

  Identify -> Inventory -> Audit -> Diagnose -> Repair -> Verify -> Document

Read-only tools run immediately.

State-changing repair tools are intentionally separated and follow this pattern:

  explain -> confirm -> perform -> verify -> journal

The toolkit never auto-confirms repair actions.


WHAT THE TOOLKIT COVERS
=======================

SYSTEM / HARDWARE
-----------------
- Full-machine inventory and reporting
- Manufacturer/model/serial and Windows identity
- CPU, physical RAM, graphics, motherboard, BIOS/UEFI
- TPM and Secure Boot
- Battery state and capacity where exposed
- Physical disks, partitions, volumes, and free space
- Storage controllers, SMART/reliability data where exposed
- Plug-and-Play problem devices
- Driver inventory
- Hardware Acceptance Test
- WHEA / hardware-error investigation

WINDOWS / RECOVERY / UPDATE
---------------------------
- Windows edition, version, build, architecture, and activation state
- Windows Update readiness
- Update history and failure investigation
- Pending reboot detection
- Windows Recovery Environment state
- Optional Windows features
- Hyper-V / WSL / Sandbox state
- Restore points and VSS snapshots
- Boot / startup / power / sleep / wake investigation
- Services and scheduled-task investigation
- SFC / DISM / CHKDSK repair workflows

NETWORK / CONNECTIVITY
----------------------
- Adapter inventory and health context
- IP configuration, routes, DNS, gateways, and profiles
- Wi-Fi information and adapter capability
- Internet / gateway / DNS tests
- Port testing
- IPv6 snapshot
- Firewall state
- Proxy / HOSTS state
- SMB shares, connections, and mapped drives
- Network path investigation
- Before/after network comparison
- Controlled network reset/repair workflows

SECURITY / ACCOUNTS
-------------------
- Microsoft Defender state
- Local users and Administrators
- Local security baseline comparison
- Authentication/logon investigation
- BitLocker status and protector-type reporting
- Entra ID / Active Directory join state
- Certificate / TLS audit
- Remote-access state
- Security posture summaries

APPLICATION / USER / PERIPHERAL
-------------------------------
- Installed software inventory
- Activation/licensing deep dive
- Browser health
- Application crash/hang investigation
- User profile health
- Printer investigation
- USB/removable-device history
- Peripheral inventory

CASE / DOCUMENTATION / SUPPORT
------------------------------
- Machine intake summary
- Collect Case baseline + ACTIVE_CASE_ONLY live artifact capture
- Automatic mirroring of subsequent toolkit Logs/reports while the case is ACTIVE
- Case-filtered operation/mutation/repair-journal activity evidence
- Technician notes
- Case closeout with final sweep, consolidated report, and refreshed ZIP
- No active case = normal report/log behavior; no case mirroring
- Full-machine before/after comparison
- Change comparison dashboard
- Support bundle creation
- Share-safe report creation
- Report/export index
- Toolkit Self-Test
- Toolkit Foundation Health
- Known-Good toolkit rebuild


FULL MACHINE REPORT
===================

Main report launcher:

  00_Full_Machine_Report\RUN-FULL-MACHINE-REPORT.cmd

The Full Machine Report covers major system, firmware, hardware, storage,
network, security, account, application, service, recovery, power, and recent
event state.

Report formats may include:

  .txt
  .md
  .html
  .meta.json

Diagnostic tools may also write:

  .csv
  .evidence.json

Reports are written under:

  Logs\


TOOLKIT v4 DIAGNOSTIC ENGINE
============================

Toolkit v4 uses a shared diagnostic-evidence layer so major diagnostic tools
apply consistent interpretation rules.

Shared behaviors include:
- deterministic EvidenceId generation
- Windows event classification
- storage HarddiskN -> Get-Disk mapping
- internal/fixed vs removable/no-media storage classification
- Windows Error Reporting classification
- historical LiveKernelEvent replay detection
- capability/query failure classification
- cross-report evidence correlation

Confidence vocabulary:

  CONFIRMED
  LIKELY
  POSSIBLE
  CONTEXT
  UNKNOWN

Correlation means evidence appears related or identical across reports.
It does NOT prove causation.


EVIDENCE CORRELATION
====================

Diagnostic .evidence.json sidecars can share deterministic EvidenceId values.

When evidence sidecars are written, Toolkit v4 rebuilds:

  Logs\EVIDENCE_CORRELATION_INDEX.json
  Logs\EVIDENCE_CORRELATION_INDEX.txt

The correlation index shows when the same underlying source evidence appears in
multiple diagnostic reports or ToolIds.

This is useful when, for example, one Windows storage event appears in both:
- SMART / Drive Deep Dive
- Crash Correlation / Reliability Investigator

The index helps prevent one source event from being mistaken for several
independent failures.


CAPABILITY / QUERY STATUS
=========================

When Windows cannot provide a requested data point, Toolkit v4 distinguishes
WHY instead of treating every blank result the same.

Possible states include:

  Not Supported
  Driver/API Did Not Expose
  Requires Elevation
  Not Applicable
  Query/API Failed
  Unknown/Indeterminate

Example:
A RAID/VMD storage controller may prevent Windows from exposing NVMe SMART or
reliability counters. That is not automatically a drive failure and is not
treated as a clean SMART pass either.


REPORT METADATA
===============

The shared report writer creates:

  <report>.meta.json

Metadata can include:
- Toolkit version
- ToolId
- release line
- report schema version
- Known-Good build identity
- session ID
- computer name
- generated time

Diagnostic sidecars may also contain:
- findings
- evidence
- capability/query status
- EvidenceId
- confidence
- source/provider/event identity
- device context
- source/artifact/observation timestamps


TIMESTAMP MEANINGS
==================

EventTimestamp / TimeCreated
  When the source Windows event occurred.

ArtifactTimestamp
  When a referenced artifact itself was created, when known.
  Example: an older watchdog dump later re-reported by Windows Error Reporting.

ObservedAt
  When Toolkit v4 collected/classified the evidence.


SAFETY / PRIVACY
================

The toolkit is designed NOT to collect or store:
- passwords
- password hashes
- Wi-Fi passwords or saved Wi-Fi keys
- authentication tokens
- browser session secrets
- BitLocker recovery passwords / recovery keys

BitLocker tools may report:
- protection state
- volume state
- protector TYPES

They do not intentionally print recovery secrets.

Windows licensing tools may recover/display a full Windows product key locally
when it is legitimately exposed by firmware or validated Windows licensing
data. This is treated as sensitive local diagnostic information.

Share-safe workflows are designed to redact sensitive identifiers before
external sharing, but automated redaction is best-effort. Always review a
share-safe report before sending it outside the organization.


REPAIR MENU
===========

The REPAIR menu is intentionally separate from diagnostic menus.

Repair workflows may include:
- SFC / DISM repair
- Windows Update repair
- network repair/reset
- Print Spooler cleanup
- service recovery
- CHKDSK / storage repair workflows
- BitLocker protection control
- other technician-confirmed state changes

Repairs use explicit confirmation and verification.

Boot-risk or encryption-related operations retain additional safety checks.

The toolkit does not silently:
- disable BitLocker
- expose recovery secrets
- change boot configuration
- reset networking
- alter firewall/security state
- perform destructive storage work


SCREEN READER / ACCESSIBILITY MODE
==================================

Enable from the launcher by pressing:

  A

Or launch with:

  /accessibility
  /screenreader

Environment-variable support:

  FIELDTECH_SCREEN_READER=1

Screen Reader Mode:
- avoids visual-only menu behavior
- reduces unnecessary screen clearing
- states administrator requirements in text
- provides explicit prompt wording
- preserves tool behavior and safety controls
- does not change the actual diagnostic/repair operation

Interactive PowerShell tools use the shared screen-reader prompt helper.

See:
  Documentation\ACCESSIBILITY-AUDIT.txt


TOOLKIT SELF-TEST
=================

Tools 35 - Toolkit Self-Test supports:

1. Quick
   Checks launcher, foundation, catalog, logging, and basic runtime state.

2. Full
   Runs complete static/native/trust/regression checks plus disposable
   Known-Good extraction simulation.

3. Full, No Simulation
   Runs complete checks without the disposable extraction simulation.

4. Diagnostic Logic
   Runs sanitized diagnostic-classifier and evidence-correlation fixtures
   without changing Windows state.

Recommended release validation sequence:

  Quick
  Diagnostic Logic
  Full
  Toolkit Foundation Health


FOUNDATION HEALTH
=================

Tools 43 - Toolkit Foundation Health reports:
- Toolkit version/build identity
- session/runtime state
- elevation
- PowerShell / Windows information
- pending reboot state
- BitLocker / WinRE context
- capability availability
- diagnostic-engine health
- diagnostic classifier version
- release-manifest presence
- evidence-correlation index state/counts
- foundation-file presence
- repair journal / ledger state


KNOWN-GOOD CORE / TOOLKIT INTEGRITY
===================================

Protected core trust files live under:

  26_Tools\KnownGood\

Important files:

  Toolkit-Core-KnownGood.zip
  Toolkit-Core-Manifest.json
  Toolkit-Core-KnownGood.sha256
  Toolkit-Core-Manifest.sha256

The Known-Good workflow is intended to:
- detect missing or modified protected toolkit files
- restore known protected files from the embedded archive
- preserve unexpected/custom files
- avoid changing Windows configuration during toolkit rebuild

The Known-Good manifest hash is the authoritative build identity.


SUPPORT BUNDLE
==============

The Support Bundle workflow collects a portable diagnostic package and includes
integrity hashes plus a verifier.

The hashes provide integrity evidence only.

They are NOT a digital signature and do not prove who created the bundle.


SHARE-SAFE REPORTING
====================

Share-safe reporting creates a redacted COPY of supported reports.

The original report is not modified.

Redaction may target:
- full product keys
- computer/user identifiers
- serial numbers
- MAC addresses
- SIDs
- IP host portions
- Wi-Fi identifiers
- other identifier-heavy content

Always manually review a share-safe copy before external distribution.


TOOLKIT VERSION / RELEASE IDENTITY
==================================

Human-readable version:

  VERSION.txt

Machine-readable version:

  00_Common\Toolkit-Version.json

Human-readable release/handoff manifest:

  Documentation\RELEASE-MANIFEST-v4.txt

Static implementation/audit notes:

  Documentation\SCRIPT-AUDIT.txt

Accessibility audit:

  Documentation\ACCESSIBILITY-AUDIT.txt

Version-date meaning:
- VERSION.txt and Toolkit-Version.json carry the v4 release-line baseline date.
- The current build identity is the Known-Good manifest SHA-256.
- FIELD-VALIDATION-STATUS.txt is the technician-facing source for current
  BuildId and UNVALIDATED / AUTO-VERIFIED / VALIDATED state.


FOLDER GUIDE
============

Documentation
  Release manifest and static audit/reference documents.

00_Common
  Shared foundation, report writer, diagnostic engine, runtime/version data,
  accessibility helpers, catalog, compatibility, retention, and launch helpers.

00_Full_Machine_Report
  Comprehensive machine report.

01_Diagnostics / 02_Network / 03_Windows_Repair / 04_Logs_and_Backup
  Core everyday field diagnostics, networking, repair support, logging, and
  backup utilities.

05_Security_and_Accounts through 13_Network_Triage
  Focused security, hardware, intake, Windows-state, and network diagnostic
  groups.

14_Windows_Configuration
  Windows build/edition, .NET, pagefile, hibernation/Fast Startup,
  virtualization-feature, and pending-reboot status.

15_Storage_and_Recovery
  Disk/partition layout, BitLocker protector summary, shadow-copy inventory,
  and non-destructive Robocopy recovery assistance.

16_Browser_and_Network_Sanity through 24_Software_and_Licensing
  Advanced browser/network, remote-access, policy, update-readiness, storage,
  reliability, performance, security-posture, software, and licensing
  diagnostics.

25_Peripherals
  Peripheral and connected-device inventory.

26_Tools
  Technician field helpers and toolkit-maintenance utilities, including PKTMON
  capture/status, serial/service-tag and machine-ID helpers, automatic OEM
  support-page lookup, vendor/support/research links, report indexing, Menu
  Search, Self-Test, Foundation Health, and Known-Good rebuild.

27_Support_Bundle
  Support-bundle and share-safe workflows.

28_Repair
  Shared repair framework and controlled repair tools.

29_Advanced_Audit
  Higher-level audit and change-analysis tools.

30_Assessment_Case
  Case collection, investigators, comparisons, notes, and closeout.

31_Hardware_Acceptance
  Read-only hardware acceptance screening.

90_WinPE_Offline_Companion
  Native-CMD WinPE/WinRE offline detection, inventory, recovery, data-rescue,
  logging, driver/network bring-up, and guarded servicing/boot workflows.

Logs
  Generated reports, evidence sidecars, case folders, ledgers, correlation
  indexes, and support outputs.


FIELD WORKFLOW RECOMMENDATION
=============================

For an unfamiliar PC:

1. If this job should be preserved as one troubleshooting record, start Collect
   Case before the other tools.
2. Run Machine Intake or Full Machine Report.
3. Run the focused diagnostic that matches the complaint.
4. Review capability/query status before assuming missing data means healthy.
5. Review evidence correlation when multiple reports cover the same failure.
6. Perform repair only after the diagnosis supports it.
7. Re-run the relevant diagnostic after repair.
8. If Collect Case is active, add technician notes as needed and run Case
   Closeout; otherwise save/export the normal report as needed.


IMPORTANT LIMITATIONS
=====================

- Windows and hardware drivers do not expose every OEM/firmware/SMART metric.
- Event correlation is not proof of causation.
- A missing telemetry field is not automatically a failure.
- A healthy Windows status field is not a substitute for destructive/OEM
  diagnostics when hardware failure is strongly suspected.
- Hardware Acceptance is not a CPU/GPU/RAM stress test.
- SMART / Drive Deep Dive does not replace vendor drive diagnostics.
- Automated redaction must still be reviewed by a technician.
- Managed/domain/enterprise systems may have policies that intentionally differ
  from standalone-PC expectations.


RELEASE STATUS
==============

This build should be treated as field-validated only after the Windows release
validation sequence passes on an actual Windows machine.

Recommended:

  Tools 35 -> Quick
  Tools 35 -> Diagnostic Logic
  Tools 35 -> Full
  Tools 43 -> Toolkit Foundation Health

Then spot-check:
  ADV-006 SMART / Drive Deep Dive
  ADV-007 Crash Correlation / Reliability Investigator
  ADV-070 Hardware Acceptance Test

Active-case field check:
1. Start Collect Case.
2. Run at least one tri-report diagnostic and Full Machine Report.
3. Confirm the normal Logs outputs still exist.
4. Confirm the active case contains Artifacts\LogsMirror, Activity,
   CASE_ARTIFACTS.jsonl, and CASE_TOOL_RUNS.jsonl evidence.
5. Run Case Closeout and confirm the final sweep/report/ZIP complete.
6. Confirm later tools return to normal non-mirroring behavior after closeout.

WinPE / WinRE field check:
- boot a real WinPE/WinRE session;
- launch RUN-WINDOWS-FIELD-TECH.cmd;
- confirm automatic offline-companion handoff;
- validate detection/inventory first, then deliberately exercise only the
  recovery actions appropriate for the test machine.

Confirm:
- .meta.json sidecars are created
- .evidence.json sidecars are created for supported diagnostic tools
- EVIDENCE_CORRELATION_INDEX.json/.txt appears once overlapping evidence exists



SESSION CLOSEOUT / EXIT DIAGNOSTICS
===================================
Normal toolkit exit verifies that the session-state JSON was persisted as
CLOSED with an Ended timestamp.

The shared atomic writer retries File.Replace for transient existing-file
replacement failures. If replacement remains unavailable, it uses a same-folder
recoverable swap strategy that preserves/restores the old destination if the
new staged file cannot be moved into place. The final destination content is
read back and verified.

Every launcher exit writes:
  Logs\LAST_EXIT_STATUS.json
  Logs\LAST_EXIT_STATUS.txt

If closeout fails, the toolkit also appends:
  Logs\EXIT_ERRORS.jsonl

A clean exit does not pause. A failed closeout pauses before the terminal closes
so the technician can read the message, while the persistent Logs artifacts
retain the error even if the console is missed.


OPERATIONAL RESILIENCE / SESSION CONTINUITY
===========================================

Toolkit v4 detects stale prior SESSION_STATE files that still say ACTIVE.

On startup:
- if a prior session records a launcher PID that is no longer running, the
  prior state is changed to INTERRUPTED;
- legacy ACTIVE session files without a launcher PID are treated conservatively
  and are only marked interrupted after a grace period;
- interrupted-session detections are appended to:
    Logs\INTERRUPTED_SESSIONS.jsonl
- the launcher prints a startup notice when interrupted prior sessions are
  recovered.

A live prior launcher process is not marked interrupted.

EVIDENCE INDEX HEALTH
=====================

Toolkit Foundation Health checks whether the evidence-correlation index is
current relative to the newest diagnostic .evidence.json sidecar.

Possible index-health states include:
  CURRENT
  STALE
  MISSING
  UNREADABLE
  NO_SIDECARS

NO_SIDECARS is healthy and simply means no diagnostic evidence sidecars have
been created yet. STALE/MISSING/UNREADABLE are attention conditions.

EXIT LOG HYGIENE / RETENTION
============================

The current exit status is intentionally kept as one canonical pair:

  Logs\LAST_EXIT_STATUS.json
  Logs\LAST_EXIT_STATUS.txt

Successful canonical writes remove obsolete emergency/timestamped
LAST_EXIT_STATUS variants.

Historical closeout failures remain in:

  Logs\EXIT_ERRORS.jsonl

EXIT_ERRORS is append-only during normal toolkit operation. Retention
Maintenance handles old entries individually and never silently deletes them:
the technician can archive, typed-confirm purge, dry-run, or skip. Malformed
entries that cannot be safely dated are retained.

FIELD VALIDATION STATUS
=======================

The toolkit root contains:

  FIELD-VALIDATION-STATUS.txt

It records:
- UNVALIDATED, AUTO-VERIFIED, or VALIDATED
- current Known-Good BuildId
- automatic first-run verification time/result
- full validation timestamp when applicable
- validation details

A changed build identity automatically resets the marker to UNVALIDATED.

On the first launch of a build, First-Run Validation performs build-keyed
integrity/runtime checks and lightweight diagnostic fixtures. If it has no
CRITICAL failures, the marker becomes AUTO-VERIFIED immediately. WARNING items
are preserved as an ATTENTION result but do not require a Full Self-Test before
the toolkit can be used.

AUTO-VERIFIED does not mean full field validation. On a fresh clean first-run
PASS, the launcher leaves the AUTO-VERIFIED result visible for three seconds
before opening the Home menu. Subsequent launches of that same build do not
repeat the delay. ATTENTION and CRITICAL paths retain technician acknowledgement
behavior.

A successful Tools 35 Full Self-Test records a build-specific validation
candidate under Logs. Tools 43 Foundation Health changes the root marker to
VALIDATED only when that same build has a Full Self-Test PASS and Foundation
Health is HEALTHY.

FIELD-VALIDATION-STATUS.txt is intentionally outside the protected Known-Good
core so runtime validation state can change without making the toolkit appear
corrupted.


NETWORK TROUBLESHOOTING INVESTIGATORS
=====================================

Advanced includes three read-only network investigators:

ADV-071 - DNS Resolution Chain Investigator
  Traces local DNS context from HOSTS and DNS-client suffix/NRPT state through
  configured resolver addresses, the normal Windows resolver, each configured
  resolver individually, public comparison resolvers, DNS cache state, and
  recent DNS Client warning/error events. It highlights configured-resolver
  failures and mixed resolver behavior without automatically changing DNS.

ADV-072 - DHCP Lease / State Deep Dive
  Examines DHCP-enabled adapters, DHCP server/lease timing, IPv4 origin and
  lifetime state, APIPA addressing, DHCP Client service state, TCP/IP interface
  registry lease context, ipconfig /all, and recent DHCP Client events.

ADV-073 - Network Driver / Event Correlation
  Correlates network adapter state with signed-driver inventory, adapter power
  management, packet/error statistics, and recent network-stack / WLAN / DHCP /
  OEM-driver events. Repeated warning/error groups are surfaced as likely
  instability context, not asserted as proof that a driver caused the event.

All three generate TXT/Markdown/HTML reports plus metadata. They also create
diagnostic .evidence.json sidecars so matching Windows events can participate in
the evidence-correlation index.


SMB CONNECTIVITY / TROUBLESHOOTING INVESTIGATOR
===============================================

ADV-074 is a menu-driven SMB diagnostic with five modes:

1. Local SMB Client Health
   Read-only client configuration, signing/security state, active SMB
   connections, mappings, SMB client interfaces, Workstation service,
   SMB1 feature query, and recent SMB Client events.

2. Troubleshoot Server / Host
   Read-only DNS, TCP 445, route/interface, existing SMB-session context,
   and recent target-related SMB Client events.

3. Troubleshoot UNC Share
   Read-only share-path parsing, DNS, TCP 445, existing SMB connections and
   mappings, and relevant SMB Client events. It does not mount the share.

4. SMB Event Investigator
   Read-only SMB Client event timeline plus repeated warning/error grouping.

5. Credentialed SMB Share Access Test
   Active one-shot authentication workflow. This mode:
   - explains account-lockout risk before authentication;
   - requires the exact confirmation phrase AUTH TEST;
   - uses the native Windows credential dialog and an in-memory PSCredential;
   - validates credentials against IPC$ before testing the requested share;
   - uses Windows MPR connection APIs rather than a persistent drive mapping;
   - performs at most one credential/share workflow and never retries or sprays;
   - never uses cmdkey or persists credentials;
   - never disconnects unrelated/existing SMB sessions;
   - refuses the isolated test when existing SMB state for the same server could
     invalidate or interfere with the result;
   - performs only a minimal read-only share-root access check after connection;
   - removes only temporary SMB connections created by the test;
   - never writes the tested username, password, server/share/UNC identity, raw
     native return code, or raw authentication error to toolkit logs/reports.

Credential-test persistent output is intentionally sanitized. It records only
that a test was attempted, whether TCP 445 was reachable first, a coarse result
classification, the test stage, and temporary-connection cleanup status.

Possible sanitized result classes include:
  NETWORK_FAILURE_BEFORE_AUTHENTICATION
  EXISTING_SESSION_PRESENT_TEST_NOT_ATTEMPTED
  CREDENTIAL_DIALOG_FAILED
  CREDENTIALS_REJECTED
  AUTHENTICATION_OR_SERVER_ACCESS_REJECTED
  IPC_AUTH_VALIDATION_UNAVAILABLE
  IPC_AUTH_SESSION_CLEANUP_FAILED
  SHARE_ACCESS_DENIED
  AUTH_SUCCESS_SHARE_ACCESS_DENIED
  NETWORK_PATH_NOT_FOUND
  SHARE_NOT_FOUND
  EXISTING_SESSION_CONFLICT
  TEST_FAILED_INDETERMINATE
  AUTHENTICATION_TIMEOUT
  SUCCESS

Modes 1-4 may include the explicitly entered target in their troubleshooting
reports because target identity is needed to make those passive reports useful.
Mode 5 deliberately does not persist its target or credential identity.

SMB event evidence uses the shared WindowsEvent category so relevant SMB Client
events can correlate with other diagnostic reports.

Authentication progress/status behavior
---------------------------------------
ADV-074 reports preflight, credential prompt, authentication, elapsed time,
result, sanitized-report, and completion stages through plain-text STATUS
messages.

The staged SMB credential/share workflow has a 45-second overall timeout and
runs in a disposable background PowerShell job. While Windows processes the
request, the foreground console reports elapsed time approximately every 3
seconds. If the timeout is reached, the job is stopped and the persistent
result is AUTHENTICATION_TIMEOUT.

Status output and persistent reports omit username, password, server/share/UNC
identity, raw native return codes, and raw authentication errors.

KIT-WIDE STATUS AND SCREEN-READER CONTEXT
=========================================
The shared screen-reader prompt layer announces each PowerShell prompt once
without synthetic "Prompt:" or "Input:" labels, keeping the question and typed
response in a cleaner reading order for Narrator/NVDA/JAWS-style console use.

Write-ToolkitStatus emits plain-text "STATUS:" messages without relying on
color, cursor movement, progress bars, or animation.

The shared launcher/search runner announces numbered-tool start and completion.
Long-running native commands also receive a lightweight heartbeat:
- first status after approximately 5 seconds;
- additional status about every 10 seconds;
- explicit timeout status when configured;
- completion status when the command returns.

Quick native commands do not receive periodic heartbeat messages.

User-facing UNC examples use the standard Windows form:
  \\server\share


SCREEN-READER-ONLY SPELLING FOR EXACT CONFIRMATIONS
==================================================
Exact typed safety confirmations support an SR-only spelling hint through the
shared Read-ToolkitPrompt helper.

Normal console mode keeps the concise prompt.

In Screen Reader Mode, a prompt such as:
  Type AUTH TEST exactly to perform one authentication attempt
is announced with this spelling hint:
  Screen reader spelling: A U T H, space, T E S T.

The shared helper is used for exact safety phrases including AUTH TEST, PURGE,
REBUILD, REMOVE, YES, and DELETE. Dynamic identifiers such as service names,
device IDs, and package names are not automatically spelled character by
character because those values can be long and are already presented directly.




WINDOWS-NATIVE SMB CREDENTIAL DIALOG
====================================
ADV-074 uses the Windows Credential UI API directly through
CredUIPromptForWindowsCredentials.

The native Windows dialog is parented to the current foreground window and
remains open until the technician submits credentials or chooses Cancel. There
is intentionally no artificial timeout on the human credential-entry step.

After Windows returns the credential, ADV-074 converts it immediately into an
in-memory PSCredential, clears the temporary StringBuilder buffers used to
unpack it, and continues into the one-shot SMB test.

The actual SMB authentication/share-access worker retains a 45-second timeout.
Credential dialog failures persist only CREDENTIAL_DIALOG_FAILED; canceling the
dialog does not attempt SMB authentication.

Privacy rules:
- username is not logged;
- password is not logged or persisted;
- server/share/UNC identity is not persisted by credential mode;
- raw credential errors are not persisted;
- no cmdkey, retries, spraying, or automatic session disconnects.


NATIVE SMB CREDENTIAL TEST BACKEND
=================================
ADV-074 credential testing uses Windows MPR APIs for temporary SMB connections
and native return-code classification.

After the native Windows Credential UI returns an in-memory PSCredential, the
45-second worker begins with server credential validation and then, when safe,
tests the requested UNC share. Windows native return codes are classified before
any share-root access probe:

  0    -> connection established
  5    -> access/authentication rejected
  53   -> NETWORK_PATH_NOT_FOUND
  67   -> SHARE_NOT_FOUND
  86   -> CREDENTIALS_REJECTED
  1219 -> EXISTING_SESSION_CONFLICT
  1326 -> CREDENTIALS_REJECTED

Other codes remain TEST_FAILED_INDETERMINATE rather than being guessed from
exception wording.

After the requested-share connection succeeds, the worker performs one minimal
read-only share-root check. Only temporary connections created by that workflow
are disconnected with WNetCancelConnection2. Pre-existing SMB sessions are
detected before the credential test and are never automatically disconnected.

WNetAddConnection2W requires the password in plaintext at the native API
boundary. The toolkit converts SecureString to a temporary unmanaged UTF-16
buffer inside the isolated worker, passes that buffer directly as IntPtr, and
zeroes/frees it in finally. Persistent output contains only sanitized
classification/stage/cleanup state and never username, password,
server/share/UNC identity, or raw native return codes.


TWO-STAGE SMB CREDENTIAL / SHARE DIAGNOSIS
=========================================
ADV-074 separates server credential validation from requested-share access.

Stage 1 uses the submitted credential against the server's IPC$ endpoint. If
Windows returns a definitive logon failure (for example 1326 or 86), the result
is CREDENTIALS_REJECTED and the requested share is not tested.

If IPC$ succeeds, the temporary IPC$ connection created by the test is removed.
Only after that cleanup is verified does Stage 2 connect to the requested share
with the same credential. This lets a later Windows 67 result be treated as
SHARE_NOT_FOUND because credential validity has already been established.

If IPC$ is unavailable on a server, the toolkit reports
IPC_AUTH_VALIDATION_UNAVAILABLE instead of guessing whether credentials are
valid. If the temporary IPC$ session cannot be removed, the workflow stops with
IPC_AUTH_SESSION_CLEANUP_FAILED rather than risk session reuse or disruption.

A correct credential may therefore create two short SMB connections during one
diagnostic workflow: one temporary IPC$ authentication connection and one
temporary requested-share connection. A bad credential stops after Stage 1.

The 45-second worker timeout applies to the overall credential/share workflow.
Privacy rules apply to both stages: neither IPC$ nor the requested target,
username, password, raw native return codes, or raw errors are persisted.


RESETBASE THREE-GATE INTENT CONFIRMATION
=======================================
The irreversible DISM StartComponentCleanup /ResetBase path requires three exact
typed confirmation gates before DISM can run:

Gate 1 - acknowledgement:
  I UNDERSTAND

Gate 2 - confirmation:
  RESETBASE

Gate 3 - final confirmation:
  ResetBase-Confirm

All three must match exactly. Any mismatch cancels without running ResetBase.
In Screen Reader Mode, I UNDERSTAND uses the shared exact-phrase spelling
helper; the ResetBase prompts provide explicit spelling/instruction text.

The three-gate sequence makes technician intent explicit before an operation
that permanently removes superseded component versions and reduces normal
update rollback capability.


LONG-REPORT HTML NAVIGATION
===========================
Long technician reports use a shared offline sectioned HTML presentation layer.

TXT, Markdown, JSON, metadata, evidence sidecars, and other structured outputs
remain authoritative. HTML is presentation-only.

The shared renderer provides:
- clickable section navigation at the top of the report;
- native HTML details/summary expand/collapse sections;
- Expand all and Collapse all controls;
- Back to top links;
- summary/warning-style sections opened by default;
- large inventories and raw/evidence sections collapsed by default;
- no web server, external JavaScript library, or Internet dependency.

The shared Write-TriReport helper automatically uses sectioned HTML when a
report body is long enough (5,000+ characters) and contains at least four
standard toolkit section headers. Short reports keep the compact single-page
HTML view.

Dedicated sectioned presentation is also enabled for:
- Full Machine Report;
- Full Machine Before / After Compare;
- Case Closeout Report.

This is intentionally a presentation improvement, not a change to diagnostic
content or repair behavior.


WINDOWS SERVICING / UPDATE HEALTH REPORT
========================================
Advanced tool 75 is a read-only umbrella report for Windows servicing and
Windows Update health.

The report is intentionally broad, similar in presentation to Full Machine
Report, but scoped to servicing. It uses the shared sectioned HTML renderer so
summary, warnings, and recommendations are visible first while large evidence
and inventory sections stay collapsed until needed.

Coverage includes:
- Windows/build/servicing identity;
- pending reboot indicators;
- Windows Update / servicing service state;
- Windows Update history and recent failures;
- Windows Update Operational events;
- Setup / servicing events;
- DISM CheckHealth;
- DISM AnalyzeComponentStore when elevated;
- Windows servicing package inventory when elevated;
- servicing stack / rollup package context;
- installed hotfixes;
- Windows Update policy context;
- filtered recent CBS and DISM log evidence;
- a conservative overall correlation summary and recommended next actions.

The tool does NOT run cleanup, RestoreHealth, ResetBase, update reset, update
installation, package changes, or any other servicing mutation.

Administrator rights are recommended for the deepest package/component-store
sections, but the report still runs without elevation and marks unavailable
coverage rather than forcing a repair/elevation workflow.


DOMAIN TRUST / AD HEALTH + SHARED CONFIDENCE
===========================================
Advanced tool 76 is a read-only Domain Trust / AD Health Investigator.

It correlates:
- AD domain membership;
- configured DNS servers;
- AD domain-controller SRV discovery;
- Windows domain-controller discovery;
- selected core AD TCP reachability;
- computer secure-channel state;
- Windows Time source/status;
- recent Netlogon, Group Policy, Kerberos/LsaSrv, and Windows Time events;
- a cause-oriented matrix that distinguishes DNS/discovery, network/DC
  reachability, secure-channel trust, time/Kerberos context, and
  authentication/logon evidence.

The investigator does NOT join/unjoin the domain, reset or repair the secure
channel, change DNS, change Windows Time, or modify credentials.

The shared qualitative assessment-confidence model is defined in
00_Common/Assessment-Confidence.ps1:

  CONFIRMED
  STRONG_EVIDENCE
  POSSIBLE
  INDETERMINATE
  NOT_TESTED

These labels intentionally avoid invented numeric percentages. The Domain Trust
investigator and Windows Servicing / Update Health Report use this vocabulary in
their technician-facing assessment summaries.

The lower-level diagnostic evidence engine retains its established classifier
vocabulary for compatibility. Assessment confidence is an umbrella-report /
conclusion layer rather than a replacement for diagnostic evidence labels.


BASIC TO ADVANCED FOLLOW-UP ROUTING
===================================
The Basic menu can print a concise NEXT STEP suggestion after a Basic tool
finishes successfully. These are routing hints only; no Advanced tool is
launched automatically.

The routing helper runs as a separate PowerShell process
(00_Common/Show-Basic-Next-Step.ps1). It cannot change launcher labels, GOTO
targets, menu-return variables, or the parent CMD environment.

Examples:
- DNS symptoms -> Advanced 71
- DHCP symptoms -> Advanced 72
- adapter/driver concerns -> Advanced 73
- SMB symptoms -> Advanced 74
- servicing/SFC/DISM concerns -> Advanced 75
- domain trust/sign-in concerns -> Advanced 76
- printer issues -> Advanced 65
- storage concerns -> Advanced 6 / 67

MENU INPUT HARDENING
====================
Every main launcher menu clears the current choice variable immediately before
each "Select an option" prompt. This prevents a blank/stray Enter from reusing a
previous menu selection or carrying a number across menus.


FULL MACHINE REPORT PROGRESS
============================

Full Machine Report shows eleven major progress stages from system identity
through final report writing. In the normal visual console, those stages update
one STATUS line in place instead of adding eleven separate lines.

Screen Reader Mode deliberately keeps ordinary line-by-line STATUS announcements
so progress remains accessible. Redirected/non-interactive output also uses
line-oriented status instead of carriage-return updates. Collection behavior,
report contents, and privacy rules are unaffected by progress presentation.


LONG-PATH / ATOMIC STATE-WRITE HARDENING
========================================

Toolkit state files are written atomically. Atomic staging uses short
same-directory names (.fttmp_<nonce> / .ftbak_<nonce>) rather than appending a
full GUID to the destination filename.

This avoids a Windows PowerShell 5.1 / .NET path-length failure in which a valid
SESSION_STATE_<id>.json destination could exceed the path budget only after a
long temporary suffix was appended. The destination, staging file, and fallback
backup remain in the same directory/volume for replacement safety.

The release ZIP also uses a short internal root folder so extracting a
descriptive ZIP into a same-named outer folder does not needlessly duplicate a
very long path.


SMB CREDENTIAL MEMORY HYGIENE
=============================

Advanced 74 credentialed SMB testing uses the native Windows credential dialog,
performs one explicitly confirmed authentication workflow, and never writes the
tested password, username, server/share identifier, or raw authentication error
to persistent output.

The password is converted from SecureString to a temporary unmanaged Unicode
buffer only for the native WNetAddConnection2W call. That buffer is passed
directly as IntPtr and is zeroed/freed with ZeroFreeGlobalAllocUnicode in the
worker finally block. The SMB worker does not call PtrToStringUni and therefore
does not create an immutable managed System.String copy of the password.

Windows credential UI still necessarily handles the entered password in its
mutable credential buffers before it is converted to SecureString; those
StringBuilder buffers are explicitly cleared by the toolkit.


WINPE / WINRE OFFLINE COMPANION
===============================

The native-CMD Offline Companion is located under:
  90_WinPE_Offline_Companion

It is separate from the 158-tool main catalog.

If the root launcher detects the Windows PE / Windows RE MiniNT environment, it
hands off to the offline companion before invoking PowerShell. The companion is
therefore usable in a base WinPE environment without adding WinPE-PowerShell.

Offline workflows include:
- offline Windows detection and build evidence;
- disk / volume layout inventory;
- offline SFC verify or confirmed repair;
- offline DISM CheckHealth, ScanHealth, package inventory, or confirmed
  RestoreHealth;
- conservative BCDBOOT-based Boot / EFI repair;
- BitLocker status and privacy-safe password/.BEK unlock paths;
- read-only offline registry audit;
- non-destructive Robocopy data rescue;
- recovery-log harvesting;
- WinPE driver/network bring-up and SMB mapping;
- pending-servicing inspection and explicitly confirmed RevertPendingActions.

The offline companion intentionally does not automate formatting, partition
creation/deletion, bootrec /fixmbr, bootrec /fixboot, 48-digit BitLocker
recovery-password entry, or offline registry editing.

See:
  90_WinPE_Offline_Companion\README-WINPE.txt
  90_WinPE_Offline_Companion\WINPE-MEDIA-BUILD-GUIDE.txt


COLLECT CASE - LIVE ARTIFACT CAPTURE
====================================

Collect Case Mode takes an initial read-only baseline and then acts as an active
case recorder until Case Closeout.

While a case is ACTIVE:
- tools launched from the main toolkit menus or Menu Search continue writing
  their reports/logs to the normal Logs locations;
- after each tool returns, newly created or updated toolkit files under Logs
  are mirrored into:
    CASE_...\Artifacts\LogsMirror
- operation and mutation ledgers are not copied wholesale because the global
  files may contain other cases. Entries matching the active CaseId are
  snapshot under:
    CASE_...\Activity
- matching repair-journal evidence and a case-specific tool-run ledger are also
  maintained under Activity;
- CASE_ARTIFACTS.jsonl records source-relative path, captured path, size,
  timestamp, tool context, and SHA-256 for mirrored artifacts.

Case Closeout performs one final sweep from the case start time before it marks
the case CLOSED. This catches toolkit files created directly or otherwise not
seen by the normal menu/search post-tool capture.

When no case is ACTIVE, normal report/log behavior is unchanged and no output
is mirrored into a case folder.

Shared global indexes/ledgers and other CASE_ folders are deliberately excluded
from raw mirroring to prevent unrelated case/session material from being pulled
into the active case. Case-specific filtered snapshots are used instead.

END
===

Primary launcher:
  RUN-WINDOWS-FIELD-TECH.cmd

Current BuildId / validation state:
  FIELD-VALIDATION-STATUS.txt

Release manifest / handoff:
  Documentation\RELEASE-MANIFEST-v4.txt

Audit history:
  Documentation\SCRIPT-AUDIT.txt
  Documentation\ACCESSIBILITY-AUDIT.txt


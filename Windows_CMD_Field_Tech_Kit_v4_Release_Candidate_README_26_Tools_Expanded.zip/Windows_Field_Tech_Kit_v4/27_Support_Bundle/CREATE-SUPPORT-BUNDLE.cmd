@echo off
title Create Support Bundle
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Create-Support-Bundle.ps1"
echo.
if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)


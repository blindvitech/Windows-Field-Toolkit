param(
    [string]$LogsRoot = (Join-Path $PSScriptRoot "..\Logs")
)

$ErrorActionPreference = "Stop"

function Replace-PlainSectionBody {
    param(
        [string]$Text,
        [string[]]$Titles
    )

    $lines = $Text -split "\r?\n"
    $out = New-Object System.Collections.Generic.List[string]
    $i = 0

    while ($i -lt $lines.Count) {
        if ($lines[$i] -match '^={20,}$' -and ($i + 2) -lt $lines.Count -and $lines[$i + 2] -match '^={20,}$') {
            $title = $lines[$i + 1].Trim()
            if ($Titles -contains $title) {
                $out.Add($lines[$i])
                $out.Add($lines[$i + 1])
                $out.Add($lines[$i + 2])
                $out.Add("[REDACTED IN SHARE-SAFE COPY]")
                $i += 3

                while ($i -lt $lines.Count) {
                    if ($lines[$i] -match '^={20,}$' -and ($i + 2) -lt $lines.Count -and $lines[$i + 2] -match '^={20,}$') {
                        break
                    }
                    $i++
                }
                continue
            }
        }

        $out.Add($lines[$i])
        $i++
    }

    return ($out -join [Environment]::NewLine)
}

function Replace-HtmlSectionBody {
    param(
        [string]$Text,
        [string[]]$Titles
    )

    foreach ($title in $Titles) {
        $escaped = [regex]::Escape([System.Net.WebUtility]::HtmlEncode($title))
        $pattern = "(?is)<section><details(?: open)?><summary>" + $escaped + "</summary>.*?</details></section>"
        $replacement = "<section><details><summary>" +
            [System.Net.WebUtility]::HtmlEncode($title) +
            "</summary><div class='sectionbody'><div class='note'>Redacted in share-safe copy.</div><pre>[REDACTED IN SHARE-SAFE COPY]</pre></div></details></section>"
        $Text = [regex]::Replace($Text, $pattern, $replacement)
    }

    return $Text
}

function Redact-Text {
    param(
        [string]$Text,
        [string]$ComputerName,
        [bool]$IsHtml = $false
    )

    # Remove whole sections where identifiers are the primary content.
    $privateSections = @(
        "FULL WINDOWS PRODUCT KEY",
        "BIOS / Firmware",
        "Baseboard / Motherboard",
        "Network Profiles",
        "Saved Wi-Fi Profile Names",
        "10. LOCAL USER ACCOUNTS",
        "Local Administrators",
        "User Profiles"
    )

    if ($IsHtml) {
        $Text = Replace-HtmlSectionBody -Text $Text -Titles $privateSections
    }
    else {
        $Text = Replace-PlainSectionBody -Text $Text -Titles $privateSections
    }

    # Account/user context.
    $Text = [regex]::Replace($Text, '(?im)(User running report:\s*)[^\r\n<]+', '$1[REDACTED USER]')
    $Text = [regex]::Replace($Text, '(?is)(<strong>Run by:</strong>\s*)[^<]+', '$1[REDACTED USER]')
    $Text = [regex]::Replace($Text, '(?im)(^\s*UserName\s*:\s*).+$', '$1[REDACTED USER]')
    $Text = [regex]::Replace($Text, '(?i)C:\\Users\\[^\\\s<]+', 'C:\Users\[REDACTED USER]')

    # Wi-Fi identifiers.
    $Text = [regex]::Replace($Text, '(?im)(^\s*SSID\s*:\s*).+$', '$1[REDACTED SSID]')
    $Text = [regex]::Replace($Text, '(?im)(^\s*Profile\s*:\s*).+$', '$1[REDACTED SSID]')
    $Text = [regex]::Replace($Text, '(?im)(All User Profile\s*:\s*).+$', '$1[REDACTED SSID]')

    # Serial-number object fields.
    $Text = [regex]::Replace($Text, '(?im)(^\s*SerialNumber\s*:\s*).+$', '$1[REDACTED SERIAL]')
    $Text = [regex]::Replace($Text, '(?im)(^\s*(?:Service Tag|Serial / Service Tag)\s*:\s*).+$', '$1[REDACTED SERIAL]')

    # Windows keys, MAC addresses, and SIDs.
    $Text = [regex]::Replace($Text, '(?i)\b[A-Z0-9]{5}(?:-[A-Z0-9]{5}){4}\b', '[REDACTED PRODUCT KEY]')
    $Text = [regex]::Replace($Text, '(?i)\b(?:[0-9A-F]{2}[:-]){5}[0-9A-F]{2}\b', '[REDACTED MAC]')
    $Text = [regex]::Replace($Text, '(?i)\bS-\d+(?:-\d+){2,}\b', '[REDACTED SID]')

    # Email addresses if one appears in application/account output.
    $Text = [regex]::Replace($Text, '(?i)\b[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}\b', '[REDACTED EMAIL]')

    # Mask IPv4 host portions but leave common wildcard/loopback values alone.
    $ipv4Pattern = '(?<![\d.])(?:\d{1,3}\.){3}\d{1,3}(?![\d.])'
    $Text = [regex]::Replace($Text, $ipv4Pattern, {
        param($m)
        $v = $m.Value
        if ($v -in @("0.0.0.0","127.0.0.1","255.255.255.255")) {
            return $v
        }
        $parts = $v.Split(".")
        if ($parts.Count -eq 4) {
            return ($parts[0..2] -join ".") + ".x"
        }
        return "[REDACTED IPv4]"
    })

    # Mask likely IPv6 addresses. Preserve :: and ::1.
    $ipv6Pattern = '(?i)(?<![0-9a-f:])(?:[0-9a-f]{0,4}:){2,7}[0-9a-f]{0,4}(?![0-9a-f:])'
    $Text = [regex]::Replace($Text, $ipv6Pattern, {
        param($m)
        if ($m.Value -in @("::","::1")) {
            return $m.Value
        }
        if ($m.Value -notmatch '(?i)[a-f]' -and $m.Value -notmatch '::') {
            return $m.Value
        }
        return "[REDACTED IPv6]"
    })

    # Finally remove the report computer name everywhere it appears.
    if (-not [string]::IsNullOrWhiteSpace($ComputerName)) {
        $Text = $Text -replace [regex]::Escape($ComputerName), "[REDACTED COMPUTER]"
    }

    return $Text
}

if (-not (Test-Path -LiteralPath $LogsRoot)) {
    Write-Host "Logs folder was not found: $LogsRoot"
    Write-Host "Run the Full Machine Report first."
    exit 2
}

$latestHtml = Get-ChildItem -LiteralPath $LogsRoot -Filter "*_FULL_MACHINE_REPORT_*.html" -File -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -notmatch "SHARE_SAFE" } |
    Sort-Object LastWriteTime -Descending |
    Select-Object -First 1

if (-not $latestHtml) {
    Write-Host "No Full Machine Report HTML file was found in:"
    Write-Host $LogsRoot
    Write-Host "Run the Full Machine Report first."
    exit 3
}

$stem = [System.IO.Path]::GetFileNameWithoutExtension($latestHtml.Name)
$marker = "_FULL_MACHINE_REPORT_"
$idx = $stem.IndexOf($marker, [System.StringComparison]::OrdinalIgnoreCase)
$computerName = ""
if ($idx -gt 0) {
    $computerName = $stem.Substring(0, $idx)
}

$sourceFiles = @(
    $latestHtml.FullName,
    (Join-Path $LogsRoot ($stem + ".txt")),
    (Join-Path $LogsRoot ($stem + ".md"))
) | Where-Object { Test-Path -LiteralPath $_ }

$reportStamp = Get-Date -Format "yyyyMMdd_HHmmss"
if ($idx -ge 0) {
    $candidateStamp = $stem.Substring($idx + $marker.Length)
    if ($candidateStamp -match '^\d{8}_\d{6}$') {
        $reportStamp = $candidateStamp
    }
}

$created = New-Object System.Collections.Generic.List[string]

foreach ($source in $sourceFiles) {
    $ext = [System.IO.Path]::GetExtension($source)
    $dest = Join-Path $LogsRoot ("SHARE_SAFE_FULL_MACHINE_REPORT_" + $reportStamp + $ext)
    $content = Get-Content -LiteralPath $source -Raw -Encoding UTF8
    $redacted = Redact-Text -Text $content -ComputerName $computerName -IsHtml ($ext -ieq ".html")

    if ($ext -ieq ".html") {
        $banner = "<div class='note'><strong>SHARE-SAFE COPY:</strong> Sensitive identifiers were automatically redacted. Review this file before external sharing; automated redaction is best-effort.</div>"
        $redacted = $redacted -replace '(?i)<body>', ('<body>' + $banner)
        $redacted = $redacted -replace '(?i)<title>.*?</title>', '<title>Share-Safe Full Machine Report</title>'
        $redacted = $redacted -replace '(?i)<h1>Full Machine Report</h1>', '<h1>Share-Safe Full Machine Report</h1>'
    }
    elseif ($ext -ieq ".md") {
        $redacted = "# SHARE-SAFE COPY`r`n`r`nSensitive identifiers were automatically redacted. Review before external sharing; automated redaction is best-effort.`r`n`r`n" + $redacted
    }
    else {
        $redacted = "SHARE-SAFE COPY`r`nSensitive identifiers were automatically redacted. Review before external sharing; automated redaction is best-effort.`r`n`r`n" + $redacted
    }

    Set-Content -LiteralPath $dest -Value $redacted -Encoding UTF8
    $created.Add($dest)
}

Write-Host ""
Write-Host "Share-safe report copies created:"
foreach ($item in $created) {
    Write-Host $item
}
Write-Host ""
Write-Host "Important: automated redaction is best-effort. Review the share-safe copy before sending it outside your organization."

$htmlOut = $created | Where-Object { $_ -like "*.html" } | Select-Object -First 1
if ($htmlOut) {
    try {
        Start-Process -FilePath $htmlOut
    }
    catch {
        Write-Host "The HTML copy was created but could not be opened automatically."
    }
}

exit 0

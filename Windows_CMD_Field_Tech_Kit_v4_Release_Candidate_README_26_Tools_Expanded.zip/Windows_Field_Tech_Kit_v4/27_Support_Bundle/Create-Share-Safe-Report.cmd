@echo off
setlocal EnableExtensions
title Create Share-Safe Full Machine Report

echo Create Share-Safe Full Machine Report
echo.
echo This creates redacted copies of the newest Full Machine Report in the Logs folder.
echo The original technician report is not modified.
echo.
echo It redacts or masks product keys, computer/user identifiers, serial-number fields,
echo MAC addresses, SIDs, Wi-Fi identifiers, and IP host portions, and removes selected
echo identifier-heavy report sections.
echo.
echo IMPORTANT: Automated redaction is best-effort. Review the share-safe copy before
echo sending it to a vendor, third party, or public location.
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Create-Share-Safe-Report.ps1"
set "RC=%errorlevel%"

if "%SRMODE%"=="1" (
    echo.
    echo Share-safe report tool finished with return code %RC%.
    echo Press any key to continue.
    pause >nul
) else (
    echo.
    pause
)

exit /b %RC%

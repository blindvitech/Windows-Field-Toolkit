$ErrorActionPreference = "SilentlyContinue"
$ProgressPreference = "SilentlyContinue"

$toolkitRoot = Split-Path $PSScriptRoot -Parent
$foundation = Join-Path $toolkitRoot "00_Common\Foundation-Common.ps1"
if (Test-Path -LiteralPath $foundation -PathType Leaf) {
    . $foundation
    $runtime = Initialize-ToolkitRuntimeContext
    $root = Get-ToolkitLogRoot
    $build = Get-ToolkitBuildIdentity
    $case = Get-ToolkitCaseContext
}
else {
    $root = Join-Path $PSScriptRoot "..\Logs"
    if (-not (Test-Path -LiteralPath $root)) { New-Item -ItemType Directory -Path $root -Force | Out-Null }
    $runtime = $null
    $build = [pscustomobject]@{BuildId="UNKNOWN";ManifestSHA256="";RootName=(Split-Path $toolkitRoot -Leaf)}
    $case = [pscustomobject]@{CaseId="";CasePath=""}
}

$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$bundleDir = Join-Path $root "${env:COMPUTERNAME}_SupportBundle_$stamp"
New-Item -ItemType Directory -Path $bundleDir -Force | Out-Null

function Write-Tri {
    param([string]$Name,[string]$Title,[scriptblock]$Script)
    $body = (& $Script | Out-String -Width 240)
    $basePath = Join-Path $bundleDir $Name
    & (Join-Path $PSScriptRoot "..\00_Common\Write-TriReport.ps1") -BasePath $basePath -Title $Title -Body $body
}

Write-Tri "System" "System Summary" {
    Get-CimInstance Win32_ComputerSystem
    Get-CimInstance Win32_OperatingSystem
    Get-CimInstance Win32_BIOS
}
Write-Tri "Network" "Network Summary" {
    Get-NetAdapter
    Get-NetIPConfiguration
    Get-NetConnectionProfile
    route print
}
Write-Tri "Security" "Security Summary" {
    try { "SecureBoot: $(Confirm-SecureBootUEFI)" } catch {}
    Get-Tpm
    Get-BitLockerVolume | Select-Object MountPoint,VolumeType,VolumeStatus,ProtectionStatus,EncryptionMethod,EncryptionPercentage,LockStatus,@{N="ProtectorTypes";E={@($_.KeyProtector | ForEach-Object {[string]$_.KeyProtectorType}) -join ", "}}
    Get-MpComputerStatus | Select AntivirusEnabled,RealTimeProtectionEnabled,AntivirusSignatureLastUpdated
    Get-NetFirewallProfile
    Get-LocalGroupMember Administrators
}
Write-Tri "RecentErrors" "Recent Critical and Error Events" {
    Get-WinEvent -FilterHashtable @{LogName='System';StartTime=(Get-Date).AddDays(-7);Level=1,2} -MaxEvents 100
}
Write-Tri "ProblemDevices" "Problem Devices" {
    Get-PnpDevice -PresentOnly | Where Status -ne 'OK'
}
Write-Tri "UpdateState" "Windows Update State" {
    Get-Service wuauserv,bits,cryptsvc,usosvc
    Get-HotFix | Sort InstalledOn -Descending | Select -First 30
}
Write-Tri "Accounts" "Local Accounts and Administrators" {
    Get-LocalUser
    Get-LocalGroupMember Administrators
}
Write-Tri "Storage" "Storage Summary" {
    Get-PhysicalDisk
    Get-Disk
    Get-Volume
}

# Add a portable verifier and evidence explanation before hashing the bundle
# contents. These hashes provide integrity evidence; they are NOT a digital
# signature and do not prove who created the bundle.
$verifyScript = @'
param(
    [string]$BundleDirectory = $PSScriptRoot
)

$manifestPath = Join-Path $BundleDirectory "SUPPORT_BUNDLE_MANIFEST.json"
$manifestHashPath = Join-Path $BundleDirectory "SUPPORT_BUNDLE_MANIFEST.sha256"

if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf)) {
    Write-Host "FAIL: SUPPORT_BUNDLE_MANIFEST.json is missing."
    exit 1
}
if (-not (Test-Path -LiteralPath $manifestHashPath -PathType Leaf)) {
    Write-Host "FAIL: SUPPORT_BUNDLE_MANIFEST.sha256 is missing."
    exit 1
}

$expectedManifestHash = (Get-Content -LiteralPath $manifestHashPath -Raw).Trim().ToUpperInvariant()
$actualManifestHash = (Get-FileHash -LiteralPath $manifestPath -Algorithm SHA256).Hash.ToUpperInvariant()
if ($expectedManifestHash -ne $actualManifestHash) {
    Write-Host "FAIL: Support-bundle manifest hash does not match."
    Write-Host ("Expected: " + $expectedManifestHash)
    Write-Host ("Actual:   " + $actualManifestHash)
    exit 1
}

$manifest = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
$failures = New-Object System.Collections.Generic.List[string]

foreach ($entry in @($manifest.Files)) {
    $path = Join-Path $BundleDirectory ([string]$entry.Path)
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
        $failures.Add("MISSING: " + [string]$entry.Path)
        continue
    }

    $actual = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToUpperInvariant()
    $expected = ([string]$entry.SHA256).ToUpperInvariant()
    if ($actual -ne $expected) {
        $failures.Add("HASH MISMATCH: " + [string]$entry.Path)
    }
}

if ($failures.Count -gt 0) {
    Write-Host "SUPPORT BUNDLE VERIFICATION: FAILED"
    $failures | ForEach-Object { Write-Host $_ }
    exit 1
}

Write-Host "SUPPORT BUNDLE VERIFICATION: PASS"
Write-Host ("Manifest SHA256: " + $actualManifestHash)
Write-Host ("Files verified: " + @($manifest.Files).Count)
Write-Host "Evidence model: SHA256 integrity evidence only; bundle is NOT digitally signed."
exit 0
'@

$verifyPath = Join-Path $bundleDir "VERIFY-SUPPORT-BUNDLE.ps1"
$verifyScript | Set-Content -LiteralPath $verifyPath -Encoding UTF8

$evidenceReadme = @"
WINDOWS FIELD TECH TOOLKIT - SUPPORT BUNDLE EVIDENCE

Sensitivity: INTERNAL

This bundle contains SHA256 integrity evidence:
- SUPPORT_BUNDLE_MANIFEST.json lists the collected report files and their hashes.
- SUPPORT_BUNDLE_MANIFEST.sha256 verifies the manifest itself.
- VERIFY-SUPPORT-BUNDLE.ps1 verifies the manifest and every listed report.
- The ZIP has a separate .zip.sha256 sidecar next to the archive.

IMPORTANT:
These hashes are NOT a digital signature. They can detect later modification
when compared to the recorded hashes, but they do not cryptographically prove
who created the bundle.

Credential secrets and BitLocker recovery-password values are not intentionally
included by this workflow.
"@
$evidenceReadme | Set-Content -LiteralPath (Join-Path $bundleDir "SUPPORT_BUNDLE_README.txt") -Encoding UTF8

# Build a support-bundle manifest before compression. The bundle is INTERNAL:
# it contains machine, network, account-name, and event information but no
# credential secrets or BitLocker recovery-password values.
$fileEntries = New-Object System.Collections.Generic.List[object]
foreach ($file in Get-ChildItem -LiteralPath $bundleDir -File -ErrorAction SilentlyContinue | Sort-Object Name) {
    $hash = ""
    try {
        $hash = (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256 -ErrorAction Stop).Hash.ToUpperInvariant()
    }
    catch {
    }

    $fileEntries.Add([pscustomobject]@{
        Path = $file.Name
        Size = $file.Length
        SHA256 = $hash
        Sensitivity = "INTERNAL"
    })
}

$manifest = [ordered]@{
    SchemaVersion = 1
    Generated = (Get-Date).ToString("o")
    BundleSensitivity = "INTERNAL"
    EvidenceModel = "SHA256 integrity evidence"
    DigitalSignatureStatus = "NOT SIGNED"
    ContainsCredentialSecrets = $false
    BitLockerRecoveryPasswordsIncluded = $false
    Computer = $env:COMPUTERNAME
    User = ($env:USERDOMAIN + "\" + $env:USERNAME)
    SessionId = $(if ($runtime) { [string]$runtime.SessionId } elseif ($env:FIELDTECH_SESSION_ID) { [string]$env:FIELDTECH_SESSION_ID } else { "" })
    ActiveCaseId = [string]$case.CaseId
    ToolkitBuildId = [string]$build.BuildId
    ToolkitManifestSHA256 = [string]$build.ManifestSHA256
    ToolkitRootName = [string]$build.RootName
    Windows = [ordered]@{
        Caption = $(if ($runtime) { [string]$runtime.WindowsCaption } else { "" })
        Version = $(if ($runtime) { [string]$runtime.WindowsVersion } else { "" })
        Build = $(if ($runtime) { [string]$runtime.WindowsBuild } else { "" })
        Architecture = $(if ($runtime) { [string]$runtime.ProcessArchitecture } else { [string]$env:PROCESSOR_ARCHITECTURE })
        PowerShell = $PSVersionTable.PSVersion.ToString()
    }
    Files = $fileEntries.ToArray()
}

$manifestPath = Join-Path $bundleDir "SUPPORT_BUNDLE_MANIFEST.json"
$manifest | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $manifestPath -Encoding UTF8

$manifestHash = ""
try {
    $manifestHash = (Get-FileHash -LiteralPath $manifestPath -Algorithm SHA256 -ErrorAction Stop).Hash.ToUpperInvariant()
    $manifestHash | Set-Content -LiteralPath (Join-Path $bundleDir "SUPPORT_BUNDLE_MANIFEST.sha256") -Encoding ASCII
}
catch {
}

$zipPath = "$bundleDir.zip"
Compress-Archive -Path (Join-Path $bundleDir '*') -DestinationPath $zipPath -Force

$zipHashPath = $zipPath + ".sha256"
$zipHash = ""
try {
    $zipHash = (Get-FileHash -LiteralPath $zipPath -Algorithm SHA256 -ErrorAction Stop).Hash.ToUpperInvariant()
    $zipHash | Set-Content -LiteralPath $zipHashPath -Encoding ASCII
}
catch {
}

Write-Host "Support bundle created:"
Write-Host $zipPath
Write-Host ("Bundle sensitivity: INTERNAL")
Write-Host ("Toolkit build: " + $build.BuildId)
Write-Host ("Manifest: " + $manifestPath)
if ($manifestHash) { Write-Host ("Manifest SHA256: " + $manifestHash) }
if ($zipHash) {
    Write-Host ("ZIP SHA256: " + $zipHash)
    Write-Host ("ZIP checksum file: " + $zipHashPath)
}
Write-Host "Integrity evidence is SHA256-based and is NOT a digital signature."
Write-Host "After extracting the bundle, run VERIFY-SUPPORT-BUNDLE.ps1 to verify the manifest and listed files."

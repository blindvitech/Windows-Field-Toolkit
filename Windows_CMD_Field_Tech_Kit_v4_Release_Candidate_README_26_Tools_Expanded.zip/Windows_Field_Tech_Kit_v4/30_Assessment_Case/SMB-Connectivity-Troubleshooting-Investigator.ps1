$screenReaderCommon = Join-Path (Split-Path $PSScriptRoot -Parent) "00_Common\ScreenReader-Common.ps1"
if (Test-Path -LiteralPath $screenReaderCommon -PathType Leaf) { . $screenReaderCommon }

$ErrorActionPreference = "SilentlyContinue"
$ProgressPreference = "SilentlyContinue"

$toolkitRoot = Split-Path $PSScriptRoot -Parent
$foundation = Join-Path $toolkitRoot "00_Common\Foundation-Common.ps1"
$diagnostic = Join-Path $toolkitRoot "00_Common\Diagnostic-Evidence.ps1"
$writer = Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"
if (Test-Path -LiteralPath $foundation -PathType Leaf) { . $foundation }
if (Test-Path -LiteralPath $diagnostic -PathType Leaf) { . $diagnostic }

$logs = Get-ToolkitLogRoot
$toolId = $(if($env:FIELDTECH_TOOL_ID){$env:FIELDTECH_TOOL_ID}else{"ADV-074"})


function Add-Section {
    param(
        [System.Collections.Generic.List[string]]$Lines,
        [string]$Title,
        $Value
    )
    $Lines.Add("")
    $Lines.Add(("=" * 78))
    $Lines.Add($Title)
    $Lines.Add(("=" * 78))
    $text = ($Value | Out-String -Width 300).TrimEnd()
    if($text){$Lines.Add($text)}else{$Lines.Add("(No data returned)")}
}

function Get-SmbEventData {
    param(
        [datetime]$StartTime = (Get-Date).AddHours(-48),
        [string]$MatchText = ""
    )

    $events = New-Object System.Collections.Generic.List[object]
    $notes = New-Object System.Collections.Generic.List[string]
    foreach($logName in @(
        "Microsoft-Windows-SMBClient/Connectivity",
        "Microsoft-Windows-SMBClient/Security",
        "Microsoft-Windows-SMBClient/Operational"
    )) {
        try {
            $rows = @(Get-WinEvent -FilterHashtable @{LogName=$logName;StartTime=$StartTime} -ErrorAction Stop |
                Select-Object -First 250 TimeCreated,Id,Level,LevelDisplayName,ProviderName,LogName,Message)
            foreach($row in $rows) {
                if([string]::IsNullOrWhiteSpace($MatchText) -or
                   ([string]$row.Message).IndexOf($MatchText,[System.StringComparison]::OrdinalIgnoreCase) -ge 0) {
                    $events.Add($row)
                }
            }
        }
        catch {
            $notes.Add(($logName + ": " + $_.Exception.Message))
        }
    }

    try {
        $rows = @(Get-WinEvent -FilterHashtable @{LogName="System";ProviderName="Microsoft-Windows-SMBClient";StartTime=$StartTime} -ErrorAction Stop |
            Select-Object -First 150 TimeCreated,Id,Level,LevelDisplayName,ProviderName,LogName,Message)
        foreach($row in $rows) {
            if([string]::IsNullOrWhiteSpace($MatchText) -or
               ([string]$row.Message).IndexOf($MatchText,[System.StringComparison]::OrdinalIgnoreCase) -ge 0) {
                $events.Add($row)
            }
        }
    }
    catch {
        $notes.Add(("System / Microsoft-Windows-SMBClient: " + $_.Exception.Message))
    }

    return [pscustomobject]@{
        Events=@($events.ToArray() | Sort-Object TimeCreated -Descending)
        Notes=$notes.ToArray()
    }
}

function Convert-SmbEventsToEvidence {
    param([object[]]$Events)
    $items = New-Object System.Collections.Generic.List[object]
    foreach($evt in @($Events)) {
        $msg = ([string]$evt.Message).Trim()
        $items.Add([pscustomobject]@{
            EvidenceId = Get-ToolkitEvidenceId -Category "WindowsEvent" -Source ([string]$evt.ProviderName) `
                -EventId ([string]$evt.Id) -Timestamp $evt.TimeCreated -Device "" -Evidence $msg
            Class = "SMB Client Event"
            DeviceContext = ""
            Timestamp = $evt.TimeCreated
            Source = [string]$evt.ProviderName
            EventId = [string]$evt.Id
            Evidence = $msg
        })
    }
    return $items.ToArray()
}

function Write-StandardSmbReport {
    param(
        [string]$Title,
        [System.Collections.Generic.List[string]]$Lines,
        [object[]]$Findings=@(),
        [object[]]$Evidence=@(),
        [object[]]$Capabilities=@()
    )
    $stamp=Get-Date -Format "yyyyMMdd_HHmmss"
    $safeTitle=$Title -replace '[^A-Za-z0-9_-]','_'
    $basePath=Join-Path $logs ($env:COMPUTERNAME+"_"+$safeTitle+"_"+$stamp)
    $body=$Lines.ToArray() -join [Environment]::NewLine
    & $writer -BasePath $basePath -Title $Title -Body $body -ToolId $toolId
    if(Get-Command Write-ToolkitDiagnosticSidecar -ErrorAction SilentlyContinue) {
        Write-ToolkitDiagnosticSidecar -BasePath $basePath -ToolkitRoot $toolkitRoot -ToolId $toolId `
            -Title $Title -Findings $Findings -Evidence $Evidence -Capabilities $Capabilities
    }
    Write-Host ("Report: " + $basePath + ".html")
    try { Start-Process -FilePath ($basePath + ".html") } catch {}
}

function Invoke-LocalSmbClientHealth {
    $findings=New-Object System.Collections.Generic.List[object]
    $capabilities=New-Object System.Collections.Generic.List[object]
    $lines=New-Object System.Collections.Generic.List[string]

    $clientConfig=$null
    try {
        $clientConfig=Get-SmbClientConfiguration -ErrorAction Stop |
            Select-Object EnableSecuritySignature,RequireSecuritySignature,EnableInsecureGuestLogons,
                EnableMultiChannel,EnableLargeMtu,ConnectionCountPerRssNetworkInterface,
                DirectoryCacheLifetime,FileInfoCacheLifetime,FileNotFoundCacheLifetime,SessionTimeout
        $capabilities.Add((New-ToolkitCapabilityStatus -Capability "SMB client configuration" -Available $true -Status "Available" -Detail "SMB client configuration returned." -SourceTool $toolId))
    } catch {
        $class=Get-ToolkitCapabilityFailureClassification -ExceptionMessage $_.Exception.Message -Context "Get-SmbClientConfiguration"
        $capabilities.Add((New-ToolkitCapabilityStatus -Capability "SMB client configuration" -Available $false -Status $class.Label -Detail $class.Detail -SourceTool $toolId))
    }

    $connections=@(Get-SmbConnection -ErrorAction SilentlyContinue |
        Select-Object ServerName,ShareName,Dialect,NumOpens,ContinuouslyAvailable,Encrypted,Signed)
    $mappings=@(Get-SmbMapping -ErrorAction SilentlyContinue |
        Select-Object LocalPath,RemotePath,Status)
    $interfaces=@(Get-SmbClientNetworkInterface -ErrorAction SilentlyContinue |
        Select-Object InterfaceIndex,IPAddress,RssCapable,RdmaCapable,LinkSpeed)
    $workstation=Get-Service -Name LanmanWorkstation -ErrorAction SilentlyContinue |
        Select-Object Name,Status,StartType

    $smb1State=""
    try {
        $smb1=Get-WindowsOptionalFeature -Online -FeatureName SMB1Protocol -ErrorAction Stop
        $smb1State=[string]$smb1.State
        $capabilities.Add((New-ToolkitCapabilityStatus -Capability "SMB1 optional feature query" -Available $true -Status "Available" -Detail ("State: "+$smb1State) -SourceTool $toolId))
    } catch {
        $class=Get-ToolkitCapabilityFailureClassification -ExceptionMessage $_.Exception.Message -Context "SMB1 optional feature query"
        $capabilities.Add((New-ToolkitCapabilityStatus -Capability "SMB1 optional feature query" -Available $false -Status $class.Label -Detail $class.Detail -SourceTool $toolId))
    }

    if($workstation -and [string]$workstation.Status -ne "Running") {
        $findings.Add((New-ToolkitDiagnosticFinding -Severity "ERROR" -Category "SMB" -Confidence "Confirmed" `
            -Evidence "Workstation service is not running." -Action "Investigate the LanmanWorkstation service before share-level troubleshooting." `
            -SourceTool $toolId -Source "Service"))
    }
    if($clientConfig -and $clientConfig.EnableInsecureGuestLogons -eq $true) {
        $findings.Add((New-ToolkitDiagnosticFinding -Severity "WARNING" -Category "SMB" -Confidence "Confirmed" `
            -Evidence "SMB client allows insecure guest logons." -Action "Verify this is intentional; do not weaken SMB security as a troubleshooting shortcut." `
            -SourceTool $toolId -Source "Get-SmbClientConfiguration"))
    }
    if($smb1State -eq "Enabled") {
        $findings.Add((New-ToolkitDiagnosticFinding -Severity "WARNING" -Category "SMB" -Confidence "Confirmed" `
            -Evidence "SMB1Protocol optional feature is enabled." -Action "Confirm legacy SMB1 is genuinely required." `
            -SourceTool $toolId -Source "WindowsOptionalFeature"))
    }

    $eventData=Get-SmbEventData
    $evidence=Convert-SmbEventsToEvidence -Events $eventData.Events

    $lines.Add("SMB LOCAL CLIENT HEALTH")
    $lines.Add("Computer: "+$env:COMPUTERNAME)
    $lines.Add("Generated: "+(Get-Date))
    $lines.Add("")
    $lines.Add("Read-only SMB client health snapshot. No credentials are requested.")
    Add-Section -Lines $lines -Title "SMB CLIENT CONFIGURATION" -Value $clientConfig
    Add-Section -Lines $lines -Title "ACTIVE SMB CONNECTIONS" -Value $connections
    Add-Section -Lines $lines -Title "SMB MAPPINGS" -Value $mappings
    Add-Section -Lines $lines -Title "SMB CLIENT NETWORK INTERFACES" -Value $interfaces
    Add-Section -Lines $lines -Title "WORKSTATION SERVICE" -Value $workstation
    Add-Section -Lines $lines -Title "SMB1 OPTIONAL FEATURE" -Value $smb1State
    Add-Section -Lines $lines -Title "RECENT SMB CLIENT EVENTS (48H)" -Value $eventData.Events
    Add-Section -Lines $lines -Title "EVENT QUERY NOTES" -Value $eventData.Notes
    Add-Section -Lines $lines -Title "DIAGNOSTIC FINDINGS" -Value $findings.ToArray()
    Add-Section -Lines $lines -Title "CAPABILITY / QUERY STATUS" -Value $capabilities.ToArray()

    Write-StandardSmbReport -Title "SMB_Local_Client_Health" -Lines $lines `
        -Findings $findings.ToArray() -Evidence $evidence -Capabilities $capabilities.ToArray()
}

function Invoke-SmbHostTroubleshoot {
    $target=(Read-ToolkitPrompt "Server hostname or IP address").Trim()
    if([string]::IsNullOrWhiteSpace($target)){Write-Host "No target entered.";return}

    $findings=New-Object System.Collections.Generic.List[object]
    $capabilities=New-Object System.Collections.Generic.List[object]
    $lines=New-Object System.Collections.Generic.List[string]

    $dns=@()
    $dnsError=""
    try {$dns=@(Resolve-DnsName -Name $target -ErrorAction Stop | Select-Object Name,Type,IPAddress,NameHost)}
    catch {$dnsError=$_.Exception.Message}

    $tcp=$false
    try {$tcp=[bool](Test-NetConnection -ComputerName $target -Port 445 -InformationLevel Quiet -WarningAction SilentlyContinue)}
    catch {$tcp=$false}

    $route=$null
    try {
        $addr=@($dns | Where-Object IPAddress | Select-Object -First 1).IPAddress
        if($addr){$route=Find-NetRoute -RemoteIPAddress $addr -ErrorAction SilentlyContinue | Select-Object InterfaceAlias,InterfaceIndex,NextHop,RouteMetric}
    } catch {}

    $existing=@(Get-SmbConnection -ErrorAction SilentlyContinue |
        Where-Object { [string]$_.ServerName -ieq $target } |
        Select-Object ServerName,ShareName,Dialect,NumOpens,Encrypted,Signed)

    $eventData=Get-SmbEventData -MatchText $target
    $evidence=Convert-SmbEventsToEvidence -Events $eventData.Events

    if(-not $dns -and $target -notmatch '^\d{1,3}(\.\d{1,3}){3}$') {
        $findings.Add((New-ToolkitDiagnosticFinding -Severity "ERROR" -Category "SMB" -Confidence "Likely" `
            -Evidence "Target name did not resolve." -Action "Fix name resolution before treating the issue as SMB authentication or permissions." `
            -SourceTool $toolId -Source "Resolve-DnsName"))
    }
    if(-not $tcp) {
        $findings.Add((New-ToolkitDiagnosticFinding -Severity "ERROR" -Category "SMB" -Confidence "Confirmed" `
            -Evidence "TCP 445 was not reachable for the requested target." -Action "Investigate routing, host availability, firewall, VLAN, or SMB service reachability before authentication testing." `
            -SourceTool $toolId -Source "Test-NetConnection"))
    }
    elseif($tcp) {
        $findings.Add((New-ToolkitDiagnosticFinding -Severity "INFO" -Category "SMB" -Confidence "Confirmed" `
            -Evidence "TCP 445 is reachable for the requested target." -Action "Transport is available; continue with SMB session/share/authentication context." `
            -SourceTool $toolId -Source "Test-NetConnection"))
    }

    $lines.Add("SMB SERVER / HOST TROUBLESHOOT")
    $lines.Add("Computer: "+$env:COMPUTERNAME)
    $lines.Add("Generated: "+(Get-Date))
    $lines.Add("Target: "+$target)
    $lines.Add("")
    $lines.Add("Read-only host-level SMB troubleshooting.")
    Add-Section -Lines $lines -Title "DNS RESOLUTION" -Value $(if($dns.Count -gt 0){$dns}else{$dnsError})
    Add-Section -Lines $lines -Title "TCP 445 REACHABILITY" -Value ([pscustomobject]@{Reachable=$tcp})
    Add-Section -Lines $lines -Title "ROUTE / INTERFACE CONTEXT" -Value $route
    Add-Section -Lines $lines -Title "EXISTING SMB CONNECTIONS TO TARGET" -Value $existing
    Add-Section -Lines $lines -Title "TARGET-RELATED SMB EVENTS (48H)" -Value $eventData.Events
    Add-Section -Lines $lines -Title "EVENT QUERY NOTES" -Value $eventData.Notes
    Add-Section -Lines $lines -Title "DIAGNOSTIC FINDINGS" -Value $findings.ToArray()

    Write-StandardSmbReport -Title "SMB_Server_Host_Troubleshoot" -Lines $lines -Findings $findings.ToArray() -Evidence $evidence -Capabilities $capabilities.ToArray()
}

function Get-UncParts {
    param([string]$Path)
    if($Path -match '^\\\\(?<server>[^\\]+)\\(?<share>[^\\]+)(?:\\.*)?$') {
        return [pscustomobject]@{
            Server=$matches["server"]
            Share=$matches["share"]
            Root=("\\\\"+$matches["server"]+"\\"+$matches["share"])
        }
    }
    return $null
}

function Invoke-UncShareTroubleshoot {
    $unc=(Read-ToolkitPrompt "UNC path, for example \\server\share").Trim()
    $parts=Get-UncParts -Path $unc
    if(-not $parts){Write-Host "Enter a valid UNC share path such as \\server\share.";return}

    $findings=New-Object System.Collections.Generic.List[object]
    $lines=New-Object System.Collections.Generic.List[string]

    $dns=@()
    try {$dns=@(Resolve-DnsName -Name $parts.Server -ErrorAction Stop | Select-Object Name,Type,IPAddress,NameHost)} catch {}
    $tcp=$false
    try {$tcp=[bool](Test-NetConnection -ComputerName $parts.Server -Port 445 -InformationLevel Quiet -WarningAction SilentlyContinue)} catch {}

    $connections=@(Get-SmbConnection -ErrorAction SilentlyContinue |
        Where-Object { [string]$_.ServerName -ieq [string]$parts.Server } |
        Select-Object ServerName,ShareName,Dialect,NumOpens,Encrypted,Signed)
    $mappings=@(Get-SmbMapping -ErrorAction SilentlyContinue |
        Where-Object { ([string]$_.RemotePath).StartsWith(("\\\\"+$parts.Server+"\"),[System.StringComparison]::OrdinalIgnoreCase) } |
        Select-Object LocalPath,RemotePath,Status)

    $eventData=Get-SmbEventData -MatchText $parts.Server
    $evidence=Convert-SmbEventsToEvidence -Events $eventData.Events

    if(-not $tcp) {
        $findings.Add((New-ToolkitDiagnosticFinding -Severity "ERROR" -Category "SMB" -Confidence "Confirmed" `
            -Evidence "TCP 445 is not reachable for the UNC server." -Action "Resolve transport reachability before testing credentials or share permissions." `
            -SourceTool $toolId -Source "Test-NetConnection"))
    }
    elseif(@($connections | Where-Object {[string]$_.ShareName -ieq [string]$parts.Share}).Count -gt 0) {
        $findings.Add((New-ToolkitDiagnosticFinding -Severity "INFO" -Category "SMB" -Confidence "Confirmed" `
            -Evidence "An SMB connection to the requested share already exists." -Action "Review the negotiated dialect/signing/encryption and existing session context." `
            -SourceTool $toolId -Source "Get-SmbConnection"))
    }

    $lines.Add("SMB UNC SHARE TROUBLESHOOT")
    $lines.Add("Computer: "+$env:COMPUTERNAME)
    $lines.Add("Generated: "+(Get-Date))
    $lines.Add("UNC path: "+$parts.Root)
    $lines.Add("")
    $lines.Add("Read-only share-level context. No credentials are requested and no share is mounted.")
    Add-Section -Lines $lines -Title "DNS RESOLUTION" -Value $dns
    Add-Section -Lines $lines -Title "TCP 445 REACHABILITY" -Value ([pscustomobject]@{Reachable=$tcp})
    Add-Section -Lines $lines -Title "EXISTING SMB CONNECTIONS" -Value $connections
    Add-Section -Lines $lines -Title "EXISTING SMB MAPPINGS" -Value $mappings
    Add-Section -Lines $lines -Title "TARGET-RELATED SMB EVENTS (48H)" -Value $eventData.Events
    Add-Section -Lines $lines -Title "EVENT QUERY NOTES" -Value $eventData.Notes
    Add-Section -Lines $lines -Title "DIAGNOSTIC FINDINGS" -Value $findings.ToArray()

    Write-StandardSmbReport -Title "SMB_UNC_Share_Troubleshoot" -Lines $lines -Findings $findings.ToArray() -Evidence $evidence
}

function Invoke-SmbEventInvestigator {
    $eventData=Get-SmbEventData
    $events=@($eventData.Events)
    $findings=New-Object System.Collections.Generic.List[object]

    $groups=@($events | Where-Object {$_.Level -in 1,2,3} | Group-Object ProviderName,Id | Where-Object {$_.Count -ge 2} | Sort-Object Count -Descending)
    foreach($g in $groups) {
        $sample=$g.Group|Select-Object -First 1
        $findings.Add((New-ToolkitDiagnosticFinding -Severity "WARNING" -Category "SMB" -Confidence "Likely" `
            -Evidence ("Repeated SMB warning/error event: "+$sample.ProviderName+" Event "+$sample.Id+" occurred "+$g.Count+" times in 48 hours.") `
            -Action "Review the event timeline with transport, authentication, signing, and share-access context." `
            -SourceTool $toolId -Source ([string]$sample.ProviderName) -EventId ([string]$sample.Id)))
    }

    $lines=New-Object System.Collections.Generic.List[string]
    $lines.Add("SMB EVENT INVESTIGATOR")
    $lines.Add("Computer: "+$env:COMPUTERNAME)
    $lines.Add("Generated: "+(Get-Date))
    $lines.Add("")
    $lines.Add("Read-only SMB Client event analysis for the previous 48 hours.")
    Add-Section -Lines $lines -Title "REPEATED SMB WARNING / ERROR GROUPS" -Value ($groups | ForEach-Object {
        $sample=$_.Group|Select-Object -First 1
        [pscustomobject]@{Provider=$sample.ProviderName;EventId=$sample.Id;Count=$_.Count;Newest=($_.Group|Sort-Object TimeCreated -Descending|Select-Object -First 1).TimeCreated}
    })
    Add-Section -Lines $lines -Title "SMB CLIENT EVENT TIMELINE" -Value $events
    Add-Section -Lines $lines -Title "EVENT QUERY NOTES" -Value $eventData.Notes
    Add-Section -Lines $lines -Title "DIAGNOSTIC FINDINGS" -Value $findings.ToArray()

    Write-StandardSmbReport -Title "SMB_Event_Investigator" -Lines $lines -Findings $findings.ToArray() -Evidence (Convert-SmbEventsToEvidence -Events $events)
}

function Get-SanitizedCredentialTestClassification {
    param(
        [string]$Stage,
        [System.Exception]$Exception
    )
    $msg=$(if($Exception){[string]$Exception.Message}else{""})
    $fq=$msg.ToLowerInvariant()

    if($fq -match 'multiple connections|same user.*more than one user name|1219') {
        return "EXISTING_SESSION_CONFLICT"
    }
    if($fq -match 'logon failure|user name or password is incorrect|username or password is incorrect|unknown user name|bad password|1326|0x8007052e') {
        return "CREDENTIALS_REJECTED"
    }
    if($fq -match 'network name cannot be found|network path was not found|specified network name is no longer available|share.*not found|error 67|error 53') {
        return "SHARE_OR_PATH_NOT_FOUND"
    }
    if($fq -match 'access is denied|access denied|unauthorized|permission') {
        if($Stage -eq "POST_CONNECT_ACCESS"){return "AUTH_SUCCESS_SHARE_ACCESS_DENIED"}
        return "AUTHENTICATION_OR_SHARE_ACCESS_REJECTED"
    }
    return "TEST_FAILED_INDETERMINATE"
}

function Write-SanitizedCredentialTestReport {
    param(
        [string]$Result,
        [string]$Stage,
        [bool]$Tcp445Reachable,
        [bool]$TemporaryConnectionCreated,
        [bool]$TemporaryConnectionRemoved
    )

    # PRIVACY CONTRACT:
    # Do not pass the tested server/share, credential username, password,
    # raw exception, UNC path, or session identity into this report or sidecar.
    $stamp=Get-Date -Format "yyyyMMdd_HHmmss"
    $basePath=Join-Path $logs ($env:COMPUTERNAME+"_SMB_Credential_Test_SANITIZED_"+$stamp)

    $lines=New-Object System.Collections.Generic.List[string]
    $lines.Add("SMB CREDENTIALED SHARE ACCESS TEST - SANITIZED")
    $lines.Add("Computer: "+$env:COMPUTERNAME)
    $lines.Add("Generated: "+(Get-Date))
    $lines.Add("")
    $lines.Add("Privacy policy: tested username and server/share identifiers are intentionally not logged.")
    $lines.Add("Credential material is never written to toolkit logs or reports.")
    $lines.Add("")
    $lines.Add("Test attempted: YES")
    $lines.Add("Target identifier logged: NO")
    $lines.Add("Credential username logged: NO")
    $lines.Add("Password logged: NO")
    $lines.Add("Raw authentication error logged: NO")
    $lines.Add("TCP 445 reachable before authentication: "+$Tcp445Reachable)
    $lines.Add("Result: "+$Result)
    $lines.Add("Stage: "+$Stage)
    $lines.Add("Temporary SMB connection created by test: "+$TemporaryConnectionCreated)
    $lines.Add("Temporary SMB connection removed by test: "+$TemporaryConnectionRemoved)

    $finding=New-ToolkitDiagnosticFinding -Severity $(if($Result -eq "SUCCESS"){"INFO"}else{"WARNING"}) `
        -Category "SMB" -Confidence "Confirmed" `
        -Evidence ("Credentialed SMB access test attempted; sanitized result="+$Result+". No target or credential username was logged.") `
        -Action "Use the on-screen result together with passive SMB diagnostics. Do not weaken SMB security controls as a workaround." `
        -SourceTool $toolId -Source "SMBCredentialTest"

    $body=$lines.ToArray() -join [Environment]::NewLine
    & $writer -BasePath $basePath -Title "SMB Credentialed Share Access Test - Sanitized" -Body $body -ToolId $toolId
    if(Get-Command Write-ToolkitDiagnosticSidecar -ErrorAction SilentlyContinue) {
        Write-ToolkitDiagnosticSidecar -BasePath $basePath -ToolkitRoot $toolkitRoot -ToolId $toolId `
            -Title "SMB Credentialed Share Access Test - Sanitized" -Findings @($finding) -Evidence @() -Capabilities @()
    }
    Write-Host ("Sanitized report: "+$basePath+".html")
}

function Initialize-ToolkitCredentialUiInterop {
    if ("ToolkitCredentialUiInterop" -as [type]) { return }

    $source = @"
using System;
using System.Runtime.InteropServices;
using System.Text;

public static class ToolkitCredentialUiInterop
{
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    public struct CREDUI_INFO
    {
        public int cbSize;
        public IntPtr hwndParent;
        [MarshalAs(UnmanagedType.LPWStr)]
        public string pszMessageText;
        [MarshalAs(UnmanagedType.LPWStr)]
        public string pszCaptionText;
        public IntPtr hbmBanner;
    }

    [DllImport("credui.dll", CharSet = CharSet.Unicode)]
    public static extern uint CredUIPromptForWindowsCredentials(
        ref CREDUI_INFO notUsedHere,
        uint authError,
        ref uint authPackage,
        IntPtr inAuthBuffer,
        uint inAuthBufferSize,
        out IntPtr outAuthBuffer,
        out uint outAuthBufferSize,
        ref bool save,
        uint flags);

    [DllImport("credui.dll", CharSet = CharSet.Unicode)]
    public static extern bool CredUnPackAuthenticationBuffer(
        uint flags,
        IntPtr authBuffer,
        uint authBufferSize,
        StringBuilder userName,
        ref uint maxUserName,
        StringBuilder domainName,
        ref uint maxDomainName,
        StringBuilder password,
        ref uint maxPassword);

    [DllImport("ole32.dll")]
    public static extern void CoTaskMemFree(IntPtr ptr);

    [DllImport("user32.dll")]
    public static extern IntPtr GetForegroundWindow();
}
"@

    Add-Type -TypeDefinition $source -ErrorAction Stop
}

function Clear-ToolkitStringBuilder {
    param([Text.StringBuilder]$Builder)
    if (-not $Builder) { return }
    for($i=0; $i -lt $Builder.Length; $i++) { $Builder[$i] = [char]0 }
    $Builder.Clear() | Out-Null
}

function Invoke-NativeWindowsCredentialPrompt {
    Initialize-ToolkitCredentialUiInterop

    $info = New-Object ToolkitCredentialUiInterop+CREDUI_INFO
    $info.cbSize = [Runtime.InteropServices.Marshal]::SizeOf([type][ToolkitCredentialUiInterop+CREDUI_INFO])
    $info.hwndParent = [ToolkitCredentialUiInterop]::GetForegroundWindow()
    $info.pszCaptionText = "Windows Field Tech Toolkit - SMB Credential Test"
    $info.pszMessageText = "Enter credentials for the one-time SMB authentication test. Credentials are not written to toolkit logs or reports."
    $info.hbmBanner = [IntPtr]::Zero

    $authPackage = [uint32]0
    $outBuffer = [IntPtr]::Zero
    $outBufferSize = [uint32]0
    $save = $false
    $flags = [uint32]0x1  # CREDUIWIN_GENERIC; no save checkbox

    $resultCode = [ToolkitCredentialUiInterop]::CredUIPromptForWindowsCredentials(
        [ref]$info,[uint32]0,[ref]$authPackage,[IntPtr]::Zero,[uint32]0,
        [ref]$outBuffer,[ref]$outBufferSize,[ref]$save,$flags
    )

    if($resultCode -eq 1223) {
        return [pscustomobject]@{Credential=$null;Canceled=$true;Failed=$false}
    }
    if($resultCode -ne 0) {
        return [pscustomobject]@{Credential=$null;Canceled=$false;Failed=$true}
    }

    $user = New-Object Text.StringBuilder 513
    $domain = New-Object Text.StringBuilder 256
    $password = New-Object Text.StringBuilder 513
    $userLen = [uint32]$user.Capacity
    $domainLen = [uint32]$domain.Capacity
    $passwordLen = [uint32]$password.Capacity

    try {
        $unpacked = [ToolkitCredentialUiInterop]::CredUnPackAuthenticationBuffer(
            [uint32]0,$outBuffer,$outBufferSize,$user,[ref]$userLen,$domain,[ref]$domainLen,$password,[ref]$passwordLen
        )

        if(-not $unpacked) {
            return [pscustomobject]@{Credential=$null;Canceled=$false;Failed=$true}
        }

        $userText = $user.ToString()
        $domainText = $domain.ToString()
        $qualifiedUser = $(if([string]::IsNullOrWhiteSpace($domainText)){$userText}else{$domainText+"\"+$userText})

        $secure = New-Object Security.SecureString
        for($i=0; $i -lt $password.Length; $i++) { $secure.AppendChar($password[$i]) }
        $secure.MakeReadOnly()

        $credential = New-Object Management.Automation.PSCredential($qualifiedUser,$secure)

        $userText=$null
        $domainText=$null
        $qualifiedUser=$null

        return [pscustomobject]@{Credential=$credential;Canceled=$false;Failed=$false}
    }
    finally {
        if($outBuffer -ne [IntPtr]::Zero) { [ToolkitCredentialUiInterop]::CoTaskMemFree($outBuffer) }
        Clear-ToolkitStringBuilder -Builder $password
        Clear-ToolkitStringBuilder -Builder $user
        Clear-ToolkitStringBuilder -Builder $domain
    }
}

function Invoke-SmbCredentialTest {
    Write-Host ""
    Write-Host "CREDENTIALED SMB SHARE ACCESS TEST"
    Write-Host ""
    Write-Host "This mode validates the submitted credentials against the SMB server, then tests ONE requested UNC share."
    Write-Host "A wrong password can count toward the account's lockout policy. Bad credentials stop before the requested share is tested."
    Write-Host "The toolkit will NOT retry failed credentials, spray credentials, save credentials,"
    Write-Host "use cmdkey, disconnect unrelated SMB sessions, or log the tested username/server/share."
    Write-Host "Only a sanitized result stating that the credential/share workflow was attempted is persisted."
    Write-Host ""

    Write-ToolkitStatus "Waiting for UNC path input."
    $unc=(Read-ToolkitPrompt "UNC path to test, for example \\server\share").Trim()
    $parts=Get-UncParts -Path $unc
    if(-not $parts) {
        Write-ToolkitStatus "Input validation failed."
        Write-Host "Enter a valid UNC share path such as \\server\share."
        return
    }

    Write-ToolkitStatus "Checking TCP 445 reachability before requesting credentials."
    $tcp=$false
    try {$tcp=[bool](Test-NetConnection -ComputerName $parts.Server -Port 445 -InformationLevel Quiet -WarningAction SilentlyContinue)} catch {$tcp=$false}
    if(-not $tcp) {
        Write-ToolkitStatus "Network preflight failed. Authentication was not attempted."
        Write-Host ""
        Write-Host "NETWORK FAILURE BEFORE AUTHENTICATION"
        Write-Host "TCP 445 is not reachable. Credentials were NOT requested and no authentication was attempted."
        Write-SanitizedCredentialTestReport -Result "NETWORK_FAILURE_BEFORE_AUTHENTICATION" -Stage "PRE_AUTH_NETWORK_CHECK" `
            -Tcp445Reachable $false -TemporaryConnectionCreated $false -TemporaryConnectionRemoved $false
        return
    }

    Write-ToolkitStatus "TCP 445 is reachable."
    Write-ToolkitStatus "Checking for existing SMB state that could invalidate the test."

    # Existing sessions can cause Windows to reuse an already-authenticated SMB
    # session and invalidate a credential test. Do not disconnect anything.
    $existing=@(Get-SmbConnection -ErrorAction SilentlyContinue |
        Where-Object { [string]$_.ServerName -ieq [string]$parts.Server })
    $existingMappings=@(Get-SmbMapping -ErrorAction SilentlyContinue |
        Where-Object { ([string]$_.RemotePath).StartsWith(("\\\\"+$parts.Server+"\"),[System.StringComparison]::OrdinalIgnoreCase) })

    if($existing.Count -gt 0 -or $existingMappings.Count -gt 0) {
        Write-ToolkitStatus "Existing SMB state detected. Credential test blocked to avoid reusing or disrupting that session."
        Write-Host ""
        Write-Host "EXISTING SMB SESSION PRESENT"
        Write-Host "Windows already has SMB state for this server."
        Write-Host "The toolkit will not disconnect it or perform a credential test that could reuse that session."
        Write-Host "No credential prompt was shown."
        Write-SanitizedCredentialTestReport -Result "EXISTING_SESSION_PRESENT_TEST_NOT_ATTEMPTED" -Stage "PRE_AUTH_SESSION_CHECK" `
            -Tcp445Reachable $true -TemporaryConnectionCreated $false -TemporaryConnectionRemoved $false
        return
    }

    Write-ToolkitStatus "Preflight complete. No conflicting SMB session was detected."
    $confirm=(Read-ToolkitPrompt "Type AUTH TEST exactly to perform one authentication attempt" -SpellExactPhrase "AUTH TEST").Trim()
    if($confirm -cne "AUTH TEST") {
        Write-ToolkitStatus "Credential test canceled before authentication."
        Write-Host "Credential test canceled. No authentication attempt was made."
        return
    }

Write-ToolkitStatus "Opening the native Windows credential dialog."
Write-ToolkitStatus "Windows will keep the dialog open until you submit credentials or choose Cancel."

$credResult=$null
try {
    $credResult=Invoke-NativeWindowsCredentialPrompt
} catch {
    $credResult=$null
}

if(-not $credResult -or $credResult.Failed) {
    Write-ToolkitStatus "Windows credential dialog could not complete. Authentication was not attempted."
    Write-Host "Credential entry failed before SMB authentication."
    Write-SanitizedCredentialTestReport -Result "CREDENTIAL_DIALOG_FAILED" -Stage "CREDENTIAL_DIALOG" `
        -Tcp445Reachable $true -TemporaryConnectionCreated $false -TemporaryConnectionRemoved $false
    return
}

if($credResult.Canceled) {
    Write-ToolkitStatus "Windows credential dialog was canceled. Authentication was not attempted."
    Write-Host "Credential prompt canceled. No SMB authentication attempt was made."
    return
}

$cred=$credResult.Credential
if(-not $cred) {
    Write-ToolkitStatus "Windows credential dialog returned no credential. Authentication was not attempted."
    return
}

Write-ToolkitStatus "Windows credential dialog returned securely. Starting SMB authentication."
    # The username is held only inside PSCredential memory for this invocation.
    # Never copy it into report strings, evidence, filenames, journals, or errors.
    $driveName=("FTSMB"+(Get-Random -Minimum 10000 -Maximum 99999))
    $created=$false
    $removed=$false
    $result="TEST_FAILED_INDETERMINATE"
    $stage="CONNECT"
    $authTimeoutSeconds=45
    $pollSeconds=3

    Write-ToolkitStatus ("Authentication attempt started. Maximum wait: "+$authTimeoutSeconds+" seconds.")
    Write-ToolkitStatus "The screen will continue to print elapsed-time status while Windows processes the SMB request."



    # Run the SMB credential/share workflow in a disposable background process.
    # Stage 1 validates the submitted credentials against the server's IPC$
    # endpoint. Only if that succeeds does Stage 2 test the requested share.
    # This prevents a hidden/inaccessible share from being misreported as bad
    # credentials, and prevents bad credentials from being misreported as a
    # missing share.
    $job=$null
    try {
        $job=Start-Job -ArgumentList $parts.Server,$parts.Root,$cred -ScriptBlock {
            param($Server,$Root,$Credential)

            $ipcCreated=$false
            $ipcRemoved=$false
            $shareCreated=$false
            $shareRemoved=$false
            $result="TEST_FAILED_INDETERMINATE"
            $stage="IPC_AUTH"
            $ipcCode=-1
            $shareCode=-1
            $ipcCancelCode=$null
            $shareCancelCode=$null
            $username=$null
            $passwordPtr=[IntPtr]::Zero
            $ipcRoot="\\"+$Server+"\IPC$"

            $interop = @"
using System;
using System.Runtime.InteropServices;

public static class ToolkitMprWorkerInterop
{
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    public struct NETRESOURCE
    {
        public int dwScope;
        public int dwType;
        public int dwDisplayType;
        public int dwUsage;
        [MarshalAs(UnmanagedType.LPWStr)]
        public string lpLocalName;
        [MarshalAs(UnmanagedType.LPWStr)]
        public string lpRemoteName;
        [MarshalAs(UnmanagedType.LPWStr)]
        public string lpComment;
        [MarshalAs(UnmanagedType.LPWStr)]
        public string lpProvider;
    }

    [DllImport("mpr.dll", EntryPoint = "WNetAddConnection2W", CharSet = CharSet.Unicode, ExactSpelling = true)]
    public static extern int WNetAddConnection2(
        ref NETRESOURCE lpNetResource,
        IntPtr lpPassword,
        string lpUserName,
        int dwFlags);

    [DllImport("mpr.dll", CharSet = CharSet.Unicode)]
    public static extern int WNetCancelConnection2(
        string lpName,
        int dwFlags,
        bool fForce);
}
"@

            function Classify-IpcCode {
                param([int]$Code)
                switch($Code) {
                    0    { "IPC_AUTH_SUCCESS"; break }
                    5    { "AUTHENTICATION_OR_SERVER_ACCESS_REJECTED"; break }
                    53   { "NETWORK_PATH_NOT_FOUND"; break }
                    67   { "IPC_AUTH_VALIDATION_UNAVAILABLE"; break }
                    86   { "CREDENTIALS_REJECTED"; break }
                    1219 { "EXISTING_SESSION_CONFLICT"; break }
                    1326 { "CREDENTIALS_REJECTED"; break }
                    default { "TEST_FAILED_INDETERMINATE" }
                }
            }

            function Classify-ShareCode {
                param([int]$Code)
                switch($Code) {
                    0    { "SHARE_CONNECT_SUCCESS"; break }
                    5    { "SHARE_ACCESS_DENIED"; break }
                    53   { "NETWORK_PATH_NOT_FOUND"; break }
                    67   { "SHARE_NOT_FOUND"; break }
                    86   { "CREDENTIALS_REJECTED"; break }
                    1219 { "EXISTING_SESSION_CONFLICT"; break }
                    1326 { "CREDENTIALS_REJECTED"; break }
                    default { "TEST_FAILED_INDETERMINATE" }
                }
            }

            try {
                Add-Type -TypeDefinition $interop -ErrorAction Stop

                # WNetAddConnection2W accepts LPCWSTR. Pass the unmanaged Unicode
                # buffer from SecureString directly as IntPtr so no managed
                # System.String copy of the password is materialized. The buffer
                # is zeroed and freed in finally.
                $username=$Credential.UserName
                $passwordPtr=[Runtime.InteropServices.Marshal]::SecureStringToGlobalAllocUnicode($Credential.Password)

                # Stage 1: validate the credentials against IPC$.
                $ipcNr=New-Object ToolkitMprWorkerInterop+NETRESOURCE
                $ipcNr.dwType=1
                $ipcNr.lpRemoteName=$ipcRoot

                $ipcCode=[ToolkitMprWorkerInterop]::WNetAddConnection2([ref]$ipcNr,$passwordPtr,$username,0)
                $ipcClass=Classify-IpcCode -Code $ipcCode

                if($ipcCode -ne 0) {
                    $result=$ipcClass
                }
                else {
                    $ipcCreated=$true

                    # Remove only the IPC$ connection created by this test before
                    # testing the requested share. If cleanup cannot be verified,
                    # do not continue and risk session reuse/credential ambiguity.
                    try {
                        $ipcCancelCode=[ToolkitMprWorkerInterop]::WNetCancelConnection2($ipcRoot,0,$false)
                        $ipcRemoved=($ipcCancelCode -eq 0)
                    }
                    catch {
                        $ipcRemoved=$false
                    }

                    if(-not $ipcRemoved) {
                        $result="IPC_AUTH_SESSION_CLEANUP_FAILED"
                        $stage="IPC_CLEANUP"
                    }
                    else {
                        # Stage 2: credentials were validated; now test the exact
                        # requested share separately.
                        $stage="SHARE_CONNECT"
                        $shareNr=New-Object ToolkitMprWorkerInterop+NETRESOURCE
                        $shareNr.dwType=1
                        $shareNr.lpRemoteName=$Root

                        $shareCode=[ToolkitMprWorkerInterop]::WNetAddConnection2([ref]$shareNr,$passwordPtr,$username,0)
                        $shareClass=Classify-ShareCode -Code $shareCode

                        if($shareCode -ne 0) {
                            $result=$shareClass
                        }
                        else {
                            $shareCreated=$true
                            $stage="POST_CONNECT_ACCESS"
                            try {
                                $null=Get-Item -LiteralPath $Root -ErrorAction Stop
                                $result="SUCCESS"
                            }
                            catch {
                                $result="AUTH_SUCCESS_SHARE_ACCESS_DENIED"
                            }
                        }
                    }
                }
            }
            catch {
                $result="TEST_FAILED_INDETERMINATE"
            }
            finally {
                $username=$null
                if($passwordPtr -ne [IntPtr]::Zero) {
                    [Runtime.InteropServices.Marshal]::ZeroFreeGlobalAllocUnicode($passwordPtr)
                }

                if($shareCreated) {
                    try {
                        $shareCancelCode=[ToolkitMprWorkerInterop]::WNetCancelConnection2($Root,0,$false)
                        $shareRemoved=($shareCancelCode -eq 0)
                    }
                    catch {
                        $shareRemoved=$false
                    }
                }

                # Fallback cleanup only for an IPC$ connection created by this
                # test that was not already confirmed removed.
                if($ipcCreated -and -not $ipcRemoved) {
                    try {
                        $ipcCancelCode=[ToolkitMprWorkerInterop]::WNetCancelConnection2($ipcRoot,0,$false)
                        $ipcRemoved=($ipcCancelCode -eq 0)
                    }
                    catch {
                        $ipcRemoved=$false
                    }
                }

                $Credential=$null
            }

            [pscustomobject]@{
                Result=$result
                Stage=$stage
                TemporaryConnectionCreated=($ipcCreated -or $shareCreated)
                TemporaryConnectionRemoved=(
                    (-not $ipcCreated -or $ipcRemoved) -and
                    (-not $shareCreated -or $shareRemoved)
                )
                IpcConnectionCreated=$ipcCreated
                IpcConnectionRemoved=$ipcRemoved
                ShareConnectionCreated=$shareCreated
                ShareConnectionRemoved=$shareRemoved
            }
        }

        $elapsed=0
        while($job.State -eq "Running" -and $elapsed -lt $authTimeoutSeconds) {
            $wait=[math]::Min($pollSeconds,($authTimeoutSeconds-$elapsed))
            if($wait -le 0){break}
            $null=Wait-Job -Job $job -Timeout $wait
            $elapsed += $wait
            if($job.State -eq "Running" -and $elapsed -lt $authTimeoutSeconds) {
                Write-ToolkitStatus ("SMB credential/share workflow still in progress. Elapsed: "+$elapsed+" seconds.")
            }
        }

        if($job.State -eq "Running") {
            Write-ToolkitStatus "SMB credential/share workflow reached the toolkit timeout. Stopping the background test."
            Stop-Job -Job $job -ErrorAction SilentlyContinue | Out-Null
            $result="AUTHENTICATION_TIMEOUT"
            $stage="WORKFLOW_TIMEOUT"
            $created=$false
            $removed=$false
            Write-Host ""
            Write-Host "SMB TEST TIMED OUT"
            Write-Host "Windows did not return a result within the toolkit timeout."
            Write-Host "The raw target and credential identity remain unlogged."
        }
        else {
            $jobResult=@(Receive-Job -Job $job -ErrorAction SilentlyContinue | Select-Object -Last 1)
            if($jobResult.Count -gt 0) {
                $result=[string]$jobResult[0].Result
                $stage=[string]$jobResult[0].Stage
                $created=[bool]$jobResult[0].TemporaryConnectionCreated
                $removed=[bool]$jobResult[0].TemporaryConnectionRemoved
            }

            Write-ToolkitStatus ("SMB credential/share workflow returned. Sanitized result: "+$result+".")
            Write-Host ""
            switch($result) {
                "SUCCESS" { Write-Host "CREDENTIALS VALID / SHARE ACCESS SUCCESS"; Write-Host "Credentials were validated and the requested share root was accessible." }
                "CREDENTIALS_REJECTED" { Write-Host "CREDENTIALS REJECTED"; Write-Host "Windows rejected the supplied credentials during server authentication." }
                "AUTHENTICATION_OR_SERVER_ACCESS_REJECTED" { Write-Host "AUTHENTICATION / SERVER ACCESS REJECTED"; Write-Host "Windows denied the IPC authentication stage but did not return a definitive bad-password code." }
                "IPC_AUTH_VALIDATION_UNAVAILABLE" { Write-Host "CREDENTIAL VALIDATION UNAVAILABLE"; Write-Host "The server did not expose the IPC authentication endpoint needed to distinguish credentials from share visibility." }
                "IPC_AUTH_SESSION_CLEANUP_FAILED" { Write-Host "TEMPORARY AUTH SESSION CLEANUP FAILED"; Write-Host "The toolkit could not verify removal of its temporary authentication session, so the requested share was not tested." }
                "SHARE_ACCESS_DENIED" { Write-Host "SHARE ACCESS DENIED"; Write-Host "Credentials were validated, but Windows denied connection to the requested share." }
                "AUTH_SUCCESS_SHARE_ACCESS_DENIED" { Write-Host "SHARE ROOT ACCESS DENIED"; Write-Host "Credentials and share connection succeeded, but the minimal read-only root access check was denied." }
                "NETWORK_PATH_NOT_FOUND" { Write-Host "NETWORK PATH NOT FOUND"; Write-Host "Windows could not reach the SMB network path." }
                "SHARE_NOT_FOUND" { Write-Host "SHARE NOT FOUND"; Write-Host "Credentials were validated, but Windows reported that the requested share name was not found." }
                "EXISTING_SESSION_CONFLICT" { Write-Host "EXISTING SMB SESSION CONFLICT"; Write-Host "Windows reported a conflicting existing SMB connection under different credentials." }
                default { Write-Host "SMB TEST FAILED - INDETERMINATE"; Write-Host "The raw native return code is intentionally not displayed or persisted." }
            }
        }
    }
    catch {
        $result="TEST_FAILED_INDETERMINATE"
        $stage="AUTH_JOB_SETUP"
        $created=$false
        $removed=$false
        Write-ToolkitStatus "The SMB credential/share worker could not complete normally."
        Write-Host "SMB TEST FAILED - INDETERMINATE"
        Write-Host "The raw authentication error is intentionally not logged or displayed."
    }
    finally {
        if($job) {
            Remove-Job -Job $job -Force -ErrorAction SilentlyContinue | Out-Null
        }
        $cred=$null
    }

    Write-ToolkitStatus "Writing sanitized credential-test result."
    Write-SanitizedCredentialTestReport -Result $result -Stage $stage -Tcp445Reachable $true `
        -TemporaryConnectionCreated $created -TemporaryConnectionRemoved $removed
    Write-ToolkitStatus "Credential-test workflow complete."
}
Write-Host "SMB CONNECTIVITY / TROUBLESHOOTING INVESTIGATOR"
Write-Host ""
Write-Host "1. Local SMB Client Health"
Write-Host "2. Troubleshoot Server / Host"
Write-Host "3. Troubleshoot UNC Share"
Write-Host "4. SMB Event Investigator"
Write-Host "5. Credentialed SMB Share Access Test"
Write-Host "0. Return"
Write-Host ""
Write-Host "Privacy: mode 5 never logs the tested credential username, password, or server/share identifier."
Write-Host ""

$choice=(Read-ToolkitPrompt "Select an option").Trim()
switch($choice) {
    "1" { Write-ToolkitStatus "Starting Local SMB Client Health."; Invoke-LocalSmbClientHealth; Write-ToolkitStatus "Local SMB Client Health complete." }
    "2" { Write-ToolkitStatus "Starting Server / Host troubleshooting."; Invoke-SmbHostTroubleshoot; Write-ToolkitStatus "Server / Host troubleshooting complete." }
    "3" { Write-ToolkitStatus "Starting UNC Share troubleshooting."; Invoke-UncShareTroubleshoot; Write-ToolkitStatus "UNC Share troubleshooting complete." }
    "4" { Write-ToolkitStatus "Starting SMB Event Investigator."; Invoke-SmbEventInvestigator; Write-ToolkitStatus "SMB Event Investigator complete." }
    "5" { Write-ToolkitStatus "Starting credentialed SMB test workflow."; Invoke-SmbCredentialTest }
    default { }
}

exit 0

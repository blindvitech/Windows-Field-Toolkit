$screenReaderCommon = Join-Path (Split-Path $PSScriptRoot -Parent) "00_Common\ScreenReader-Common.ps1"
if (Test-Path -LiteralPath $screenReaderCommon -PathType Leaf) {
    . $screenReaderCommon
}

$ErrorActionPreference="SilentlyContinue"
$ProgressPreference="SilentlyContinue"
$toolkitRoot=Split-Path $PSScriptRoot -Parent
$foundation=Join-Path $toolkitRoot "00_Common\Foundation-Common.ps1"
if(Test-Path -LiteralPath $foundation -PathType Leaf){. $foundation}
$logs=Join-Path $toolkitRoot "Logs"
if(-not(Test-Path -LiteralPath $logs)){New-Item -ItemType Directory -Path $logs -Force|Out-Null}
$writer=Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"

Write-Host "NETWORK PATH INVESTIGATOR"
$target=(Read-ToolkitPrompt "Hostname or IP address").Trim()
if(-not $target){Write-Host "No target entered.";exit 1}
$portText=(Read-ToolkitPrompt "TCP port to test, default 443").Trim()
$port=443;if($portText -match '^\d+$' -and [int]$portText -ge 1 -and [int]$portText -le 65535){$port=[int]$portText}

$stamp=Get-Date -Format "yyyyMMdd_HHmmss"
$safe=$target-replace'[^A-Za-z0-9._-]','_'
$basePath=Join-Path $logs ($env:COMPUTERNAME+"_Network_Path_Investigator_"+$safe+"_"+$stamp)

$dns=Resolve-DnsName -Name $target -ErrorAction SilentlyContinue|Select-Object Name,Type,IPAddress,NameHost
$tnc=Test-NetConnection -ComputerName $target -Port $port -InformationLevel Detailed -WarningAction SilentlyContinue
$ping=(& ping.exe -n 4 $target 2>&1|Out-String -Width 260).TrimEnd()
$trace=(& tracert.exe -d -h 20 -w 1500 $target 2>&1|Out-String -Width 260).TrimEnd()
$ipconfig=Get-NetIPConfiguration -ErrorAction SilentlyContinue|
 Select-Object InterfaceAlias,InterfaceDescription,@{N="IPv4";E={$_.IPv4Address.IPAddress -join ", "}},@{N="Gateway";E={$_.IPv4DefaultGateway.NextHop -join ", "}},@{N="DNS";E={$_.DNSServer.ServerAddresses -join ", "}}
$routes=Get-NetRoute -AddressFamily IPv4 -ErrorAction SilentlyContinue|Sort-Object RouteMetric,DestinationPrefix|
 Select-Object -First 100 DestinationPrefix,NextHop,InterfaceAlias,RouteMetric,PolicyStore
$arp=(& arp.exe -a 2>&1|Out-String -Width 260).TrimEnd()
$winhttpNative=Invoke-ToolkitNativeCommand -FilePath "netsh.exe" -Arguments @("winhttp","show","proxy") -Label "Network Path WinHTTP Proxy" -Action "Network Path Investigator" -Quiet
$winhttp=(($winhttpNative.Output -join [Environment]::NewLine)|Out-String -Width 260).TrimEnd()
$userProxy=Get-ItemProperty "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings" -ErrorAction SilentlyContinue|
 Select-Object ProxyEnable,ProxyServer,AutoConfigURL
$fw=Get-NetFirewallProfile -ErrorAction SilentlyContinue|Select-Object Name,Enabled,DefaultInboundAction,DefaultOutboundAction

$lines=New-Object System.Collections.Generic.List[string]
$lines.Add("NETWORK PATH INVESTIGATOR");$lines.Add("Computer: "+$env:COMPUTERNAME);$lines.Add("Generated: "+(Get-Date));$lines.Add("Target: "+$target+":"+ $port)
$lines.Add("");$lines.Add("Read-only path investigation: DNS, ping, TCP test, traceroute, local IP/gateway/DNS, route table context, ARP, proxy, and firewall profiles.")
foreach($pair in @(@("DNS RESOLUTION",$dns),@("TEST-NETCONNECTION",$tnc),@("LOCAL IP CONFIGURATION",$ipconfig),@("ROUTE TABLE CONTEXT",$routes),@("USER PROXY",$userProxy),@("FIREWALL PROFILES",$fw))){
 $lines.Add("");$lines.Add(("="*78));$lines.Add($pair[0]);$lines.Add(("="*78));$x=($pair[1]|Out-String -Width 260).TrimEnd();if($x){$lines.Add($x)}else{$lines.Add("(No data returned)")}
}
foreach($pair in @(@("PING",$ping),@("TRACEROUTE",$trace),@("ARP TABLE",$arp),@("WINHTTP PROXY",$winhttp))){
 $lines.Add("");$lines.Add(("="*78));$lines.Add($pair[0]);$lines.Add(("="*78));$lines.Add([string]$pair[1])
}
$body=$lines -join [Environment]::NewLine
& $writer -BasePath $basePath -Title "Network Path Investigator" -Body $body
$html=$basePath+".html";Write-Host("Report: "+$html);try{Start-Process -FilePath $html}catch{}
exit 0

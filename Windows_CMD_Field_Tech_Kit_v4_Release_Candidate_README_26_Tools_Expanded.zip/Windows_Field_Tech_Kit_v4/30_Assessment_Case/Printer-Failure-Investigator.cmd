@echo off
setlocal EnableExtensions
title Printer Failure Investigator

echo Printer Failure Investigator
echo.
echo Read-only diagnostic / assessment tool. Windows system state is not changed.
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Printer-Failure-Investigator.ps1"
set "RC=%errorlevel%"

echo.
if "%SRMODE%"=="1" (
    if "%RC%"=="0" (
        echo Printer Failure Investigator completed.
    ) else (
        echo Printer Failure Investigator returned error code %RC%.
    )
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

exit /b %RC%

@echo off
setlocal EnableExtensions
title Boot / Startup Performance Audit

echo Boot / Startup Performance Audit
echo.
echo Read-only diagnostic / assessment tool. Windows system state is not changed.
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Boot-Startup-Performance-Audit.ps1"
set "RC=%errorlevel%"

echo.
if "%SRMODE%"=="1" (
    if "%RC%"=="0" (
        echo Boot / Startup Performance Audit completed.
    ) else (
        echo Boot / Startup Performance Audit returned error code %RC%.
    )
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

exit /b %RC%

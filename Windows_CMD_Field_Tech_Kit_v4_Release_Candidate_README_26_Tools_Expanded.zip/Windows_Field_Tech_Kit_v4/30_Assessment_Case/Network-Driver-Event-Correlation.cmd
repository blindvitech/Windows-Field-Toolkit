@echo off
setlocal EnableExtensions
title Network Driver / Event Correlation

echo Network Driver / Event Correlation
echo.
echo Read-only network diagnostic / assessment tool. Windows system state is not changed.
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Network-Driver-Event-Correlation.ps1"
set "RC=%errorlevel%"

echo.
if "%SRMODE%"=="1" (
    if "%RC%"=="0" (
        echo Network Driver / Event Correlation completed.
    ) else (
        echo Network Driver / Event Correlation returned error code %RC%.
    )
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

exit /b %RC%

$ErrorActionPreference="SilentlyContinue"
$ProgressPreference="SilentlyContinue"
$toolkitRoot=Split-Path $PSScriptRoot -Parent
$logs=Join-Path $toolkitRoot "Logs"
if(-not(Test-Path -LiteralPath $logs)){New-Item -ItemType Directory -Path $logs -Force|Out-Null}
$writer=Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"
$stamp=Get-Date -Format "yyyyMMdd_HHmmss"
$basePath=Join-Path $logs ($env:COMPUTERNAME+"_Hardware_Error_Investigator_"+$stamp)

$disks=Get-PhysicalDisk -ErrorAction SilentlyContinue|
 Select-Object FriendlyName,SerialNumber,MediaType,BusType,HealthStatus,OperationalStatus,Size
$reliability=@()
foreach($d in Get-PhysicalDisk -ErrorAction SilentlyContinue){
 try{
  $r=$d|Get-StorageReliabilityCounter -ErrorAction Stop
  $reliability+=[pscustomobject]@{
   Disk=$d.FriendlyName;Serial=$d.SerialNumber;Temperature=$r.Temperature;Wear=$r.Wear;
   ReadErrorsTotal=$r.ReadErrorsTotal;WriteErrorsTotal=$r.WriteErrorsTotal;
   PowerOnHours=$r.PowerOnHours;ReadLatencyMax=$r.ReadLatencyMax;WriteLatencyMax=$r.WriteLatencyMax
  }
 }catch{}
}
$memory=Get-CimInstance Win32_PhysicalMemory -ErrorAction SilentlyContinue|
 Select-Object BankLabel,DeviceLocator,Manufacturer,PartNumber,SerialNumber,Speed,ConfiguredClockSpeed,Capacity
$problem=Get-PnpDevice -PresentOnly -ErrorAction SilentlyContinue|Where-Object Status -ne "OK"|
 Select-Object Status,Class,FriendlyName,InstanceId
$gpu=Get-CimInstance Win32_VideoController -ErrorAction SilentlyContinue|
 Select-Object Name,DriverVersion,DriverDate,AdapterRAM,Status
$bios=Get-CimInstance Win32_BIOS -ErrorAction SilentlyContinue|Select-Object Manufacturer,SMBIOSBIOSVersion,ReleaseDate,SerialNumber

$events=@()
try{
 $events=Get-WinEvent -FilterHashtable @{LogName="System";StartTime=(Get-Date).AddDays(-30);Level=1,2,3} -ErrorAction Stop|
  Where-Object{
   $_.ProviderName -match '(?i)(WHEA|disk|ntfs|storahci|stornvme|volmgr|volsnap|Kernel-PnP|Display)' -or
   $_.Message -match '(?i)(hardware error|machine check|corrected hardware|bad block|I/O error|reset to device|thermal)'
  }|
  Sort-Object TimeCreated -Descending|Select-Object -First 250 TimeCreated,Id,ProviderName,LevelDisplayName,@{N="Message";E={($_.Message-replace"[\r\n]+"," "-replace"\s{2,}"," ").Trim()}}
}catch{}

$rel=Get-CimInstance Win32_ReliabilityRecords -ErrorAction SilentlyContinue|
 Where-Object{$_.TimeGenerated -ge (Get-Date).AddDays(-30) -and ($_.SourceName -match '(?i)(Hardware|Windows)' -or $_.Message -match '(?i)(hardware|disk|video|memory|device)')}|
 Sort-Object TimeGenerated -Descending|Select-Object -First 150 TimeGenerated,SourceName,ProductName,EventIdentifier,Message

$lines=New-Object System.Collections.Generic.List[string]
$lines.Add("HARDWARE ERROR INVESTIGATOR");$lines.Add("Computer: "+$env:COMPUTERNAME);$lines.Add("Generated: "+(Get-Date))
$lines.Add("");$lines.Add("Read-only correlation of WHEA/storage/device/display events, physical-disk health/reliability, memory inventory, problem devices, GPU, BIOS, and reliability records.")
$lines.Add("Absence of logged errors does not prove hardware is healthy; this is a triage report, not a hardware certification.")
foreach($pair in @(@("PHYSICAL DISKS",$disks),@("STORAGE RELIABILITY COUNTERS",$reliability),@("MEMORY MODULES",$memory),@("PROBLEM DEVICES",$problem),@("GPU",$gpu),@("BIOS",$bios),@("HARDWARE-ORIENTED EVENTS - 30 DAYS",$events),@("RELIABILITY RECORDS",$rel))){
 $lines.Add("");$lines.Add(("="*78));$lines.Add($pair[0]);$lines.Add(("="*78));$x=($pair[1]|Out-String -Width 260).TrimEnd();if($x){$lines.Add($x)}else{$lines.Add("(No data returned)")}
}
$body=$lines -join [Environment]::NewLine
& $writer -BasePath $basePath -Title "Hardware Error Investigator" -Body $body
$html=$basePath+".html";Write-Host("Report: "+$html);try{Start-Process -FilePath $html}catch{}
exit 0

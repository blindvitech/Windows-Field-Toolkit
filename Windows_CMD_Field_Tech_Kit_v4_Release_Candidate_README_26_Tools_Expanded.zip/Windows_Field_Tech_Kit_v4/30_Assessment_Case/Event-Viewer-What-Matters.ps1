$screenReaderCommon = Join-Path (Split-Path $PSScriptRoot -Parent) "00_Common\ScreenReader-Common.ps1"
if (Test-Path -LiteralPath $screenReaderCommon -PathType Leaf) {
    . $screenReaderCommon
}

$ErrorActionPreference="SilentlyContinue"
$ProgressPreference="SilentlyContinue"
$toolkitRoot=Split-Path $PSScriptRoot -Parent
$logs=Join-Path $toolkitRoot "Logs"
if(-not(Test-Path -LiteralPath $logs)){New-Item -ItemType Directory -Path $logs -Force|Out-Null}
$writer=Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"

Write-Host "EVENT VIEWER: WHAT MATTERS?"
Write-Host "Lookback: 1=24 hours, 2=3 days, 3=7 days, 4=14 days, 5=custom"
$choice=Read-ToolkitPrompt "Select 1 through 5"
$days=7
switch($choice){"1"{$days=1};"2"{$days=3};"3"{$days=7};"4"{$days=14};"5"{$d=Read-ToolkitPrompt "Days, 1 through 90";if($d -match '^\d+$' -and [int]$d -ge 1 -and [int]$d -le 90){$days=[int]$d}}}
$start=(Get-Date).AddDays(-$days)
$stamp=Get-Date -Format "yyyyMMdd_HHmmss"
$basePath=Join-Path $logs ($env:COMPUTERNAME+"_Event_Viewer_What_Matters_"+$days+"days_"+$stamp)

$events=@()
foreach($log in @("System","Application")){
 try{
  $events += Get-WinEvent -FilterHashtable @{LogName=$log;StartTime=$start;Level=1,2,3} -ErrorAction Stop |
   Select-Object TimeCreated,LogName,Id,ProviderName,LevelDisplayName,Message
 }catch{}
}

function Get-Category([object]$e){
 $p=[string]$e.ProviderName;$m=[string]$e.Message;$id=[int]$e.Id
 if($p -match '(?i)WHEA|Kernel-Power|BugCheck' -or $id -in 41,1001){return "CRASH / HARDWARE / POWER"}
 if($p -match '(?i)(disk|ntfs|storahci|stornvme|volmgr|volsnap|partmgr)' -or $m -match '(?i)(bad block|disk error|file system corruption|I/O error)'){return "STORAGE / FILE SYSTEM"}
 if($p -match '(?i)(Kernel-PnP|UserPnp|DeviceSetupManager|DriverFrameworks)' -or $m -match '(?i)(device.*failed|driver.*failed)'){return "DRIVERS / DEVICES"}
 if($p -match '(?i)Service Control Manager' -or $m -match '(?i)(service.*failed|service.*terminated)'){return "SERVICES"}
 if($p -match '(?i)(WindowsUpdateClient|Windows Update)' -or $m -match '(?i)(update.*failed|installation failure)'){return "WINDOWS UPDATE"}
 if($p -match '(?i)(DNS Client|Tcpip|NlaSvc|WLAN|Dhcp)' -or $m -match '(?i)(DNS|network|DHCP|gateway)'){return "NETWORK / DNS"}
 if($p -match '(?i)(Security-SPP|LsaSrv|Kerberos|Netlogon)' -or $m -match '(?i)(logon failure|authentication|credential|Kerberos)'){return "AUTHENTICATION / SECURITY"}
 if($p -match '(?i)(Application Error|Application Hang|Windows Error Reporting|\.NET Runtime)' -or $id -in 1000,1001,1002,1026){return "APPLICATION FAILURES"}
 return "OTHER WARNINGS / ERRORS"
}

$rank=@{
 "CRASH / HARDWARE / POWER"=1;"STORAGE / FILE SYSTEM"=2;"AUTHENTICATION / SECURITY"=3;
 "DRIVERS / DEVICES"=4;"SERVICES"=5;"WINDOWS UPDATE"=6;"NETWORK / DNS"=7;
 "APPLICATION FAILURES"=8;"OTHER WARNINGS / ERRORS"=9
}
$rows=@($events|ForEach-Object{
 $cat=Get-Category $_
 $msg=($_.Message-replace"[\r\n]+"," "-replace"\s{2,}"," ").Trim()
 if($msg.Length -gt 700){$msg=$msg.Substring(0,700)+"..."}
 [pscustomobject]@{Rank=$rank[$cat];Category=$cat;Time=$_.TimeCreated;Log=$_.LogName;Id=$_.Id;Provider=$_.ProviderName;Level=$_.LevelDisplayName;Message=$msg}
}|Sort-Object @{Expression="Rank";Ascending=$true},@{Expression="Time";Descending=$true})

# Common noisy items that are often not individually actionable are still retained,
# but the report emphasizes repeated categories/providers.
$groups=@($rows|Group-Object Category|Sort-Object Count -Descending|ForEach-Object{
 [pscustomobject]@{Category=$_.Name;Count=$_.Count;Newest=($_.Group|Sort-Object Time -Descending|Select-Object -First 1).Time}
})
$providers=@($rows|Group-Object Provider|Sort-Object Count -Descending|Select-Object -First 15|ForEach-Object{
 [pscustomobject]@{Provider=$_.Name;Count=$_.Count;Newest=($_.Group|Sort-Object Time -Descending|Select-Object -First 1).Time}
})

$lines=New-Object System.Collections.Generic.List[string]
$lines.Add("EVENT VIEWER: WHAT MATTERS?")
$lines.Add("Computer: "+$env:COMPUTERNAME);$lines.Add("Generated: "+(Get-Date));$lines.Add("Lookback: "+$days+" days")
$lines.Add("")
$lines.Add("Read-only event triage. Events are grouped into technician-oriented categories and ranked for review.")
$lines.Add("This report does not claim every warning/error is important and does not replace root-cause analysis.")
$lines.Add("")
$lines.Add("CATEGORY SUMMARY")
$lines.Add(($groups|Format-Table -AutoSize|Out-String -Width 260).TrimEnd())
$lines.Add("")
$lines.Add("TOP PROVIDERS")
$lines.Add(($providers|Format-Table -AutoSize|Out-String -Width 260).TrimEnd())
foreach($cat in $rank.Keys|Sort-Object{$rank[$_]}){
 $items=@($rows|Where-Object Category -eq $cat|Select-Object -First 60)
 if($items.Count){
  $lines.Add("");$lines.Add(("="*78));$lines.Add($cat+" ("+$items.Count+" shown)");$lines.Add(("="*78))
  $lines.Add(($items|Select-Object Time,Log,Id,Provider,Level,Message|Format-List|Out-String -Width 260).TrimEnd())
 }
}
$body=$lines -join [Environment]::NewLine
& $writer -BasePath $basePath -Title "Event Viewer - What Matters" -Body $body
$html=$basePath+".html";Write-Host("Report: "+$html)
try{Start-Process -FilePath $html}catch{}
exit 0

$screenReaderCommon = Join-Path (Split-Path $PSScriptRoot -Parent) "00_Common\ScreenReader-Common.ps1"
if(Test-Path -LiteralPath $screenReaderCommon -PathType Leaf){ . $screenReaderCommon }

$ErrorActionPreference = "SilentlyContinue"
$ProgressPreference = "SilentlyContinue"

$toolkitRoot = Split-Path $PSScriptRoot -Parent
$foundation = Join-Path $toolkitRoot "00_Common\Foundation-Common.ps1"
$diagnostic = Join-Path $toolkitRoot "00_Common\Diagnostic-Evidence.ps1"
$assessmentConfidence = Join-Path $toolkitRoot "00_Common\Assessment-Confidence.ps1"
$sectionedHtml = Join-Path $toolkitRoot "00_Common\Sectioned-Html-Report.ps1"
$writer = Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"

foreach($helper in @($foundation,$diagnostic,$assessmentConfidence,$sectionedHtml)){
    if(Test-Path -LiteralPath $helper -PathType Leaf){ . $helper }
}

$logs = $(if(Get-Command Get-ToolkitLogRoot -ErrorAction SilentlyContinue){Get-ToolkitLogRoot}else{Join-Path $toolkitRoot "Logs"})
if(-not(Test-Path -LiteralPath $logs)){ New-Item -ItemType Directory -Path $logs -Force | Out-Null }

$toolId = $(if($env:FIELDTECH_TOOL_ID){$env:FIELDTECH_TOOL_ID}else{"ADV-076"})
$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$basePath = Join-Path $logs ($env:COMPUTERNAME + "_Domain_Trust_AD_Health_" + $stamp)

Write-Host "DOMAIN TRUST / AD HEALTH INVESTIGATOR"
Write-Host ""
Write-Host "Read-only. No domain, secure-channel, DNS, time, credential, or membership change is performed."
Write-Host ""
Write-ToolkitStatus "Collecting domain membership and Active Directory trust evidence."

$assessments = New-Object System.Collections.Generic.List[object]
$recommendations = New-Object System.Collections.Generic.List[string]
$capabilities = New-Object System.Collections.Generic.List[object]

function Add-Assessment {
    param(
        [string]$Area,
        [string]$Status,
        [string]$Finding,
        [string]$Evidence = "",
        [ValidateSet("CONFIRMED","STRONG_EVIDENCE","POSSIBLE","INDETERMINATE","NOT_TESTED")]
        [string]$Confidence = "INDETERMINATE"
    )

    if(Get-Command New-ToolkitAssessment -ErrorAction SilentlyContinue){
        $assessments.Add((New-ToolkitAssessment -Area $Area -Status $Status `
            -Finding $Finding -Evidence $Evidence -Confidence $Confidence))
    }
    else{
        $assessments.Add([pscustomobject]@{
            Area=$Area
            Status=$Status
            Confidence=$Confidence
            Finding=$Finding
            Evidence=$Evidence
            RecommendedAction=""
        })
    }
}

function Add-Recommendation {
    param([string]$Text)
    if(-not [string]::IsNullOrWhiteSpace($Text) -and -not $recommendations.Contains($Text)){
        $recommendations.Add($Text)
    }
}

function Invoke-ReadOnlyNative {
    param(
        [string]$FilePath,
        [string[]]$Arguments,
        [string]$Label
    )

    if(Get-Command Invoke-ToolkitNativeCommand -ErrorAction SilentlyContinue){
        return Invoke-ToolkitNativeCommand -FilePath $FilePath -Arguments $Arguments `
            -Label $Label -Action "Domain Trust / AD Health Investigator" -Quiet
    }

    $output = & $FilePath @Arguments 2>&1
    return [pscustomobject]@{
        ExitCode = $LASTEXITCODE
        Output = @($output)
    }
}

# ---------------------------------------------------------------------------
# Membership / identity
# ---------------------------------------------------------------------------
$cs = Get-CimInstance Win32_ComputerSystem -ErrorAction SilentlyContinue
$domain = [string]$cs.Domain

$membership = [pscustomobject]@{
    Computer = $env:COMPUTERNAME
    PartOfDomain = [bool]$cs.PartOfDomain
    DomainOrWorkgroup = $domain
    UserName = [string]$cs.UserName
    DomainRole = [string]$cs.DomainRole
}

$dnsServers = @(
    Get-DnsClientServerAddress -ErrorAction SilentlyContinue |
        Where-Object { $_.ServerAddresses -and $_.ServerAddresses.Count -gt 0 } |
        Select-Object InterfaceAlias,AddressFamily,
            @{N="ServerAddresses";E={$_.ServerAddresses -join ", "}} |
        Sort-Object InterfaceAlias,AddressFamily
)

$dnsSrv = @()
$dnsSrvError = ""
$dcDiscovery = $null
$dcName = ""
$dcConnectivity = @()
$secureChannel = $null
$secureChannelError = ""
$secureChannelNative = $null
$timeStatus = $null
$timeSource = $null
$domainEvents = @()
$timeEvents = @()
$authEvents = @()

if(-not $cs -or -not $cs.PartOfDomain){
    Add-Assessment -Area "Domain membership" -Status "CONTEXT" `
        -Finding "This computer is not joined to an Active Directory domain." `
        -Evidence ("PartOfDomain=" + [string]$cs.PartOfDomain) -Confidence "CONFIRMED"

    foreach($area in @(
        "AD DNS SRV discovery",
        "Domain controller discovery",
        "Domain controller reachability",
        "Secure channel",
        "Domain time relationship",
        "Authentication / trust event correlation"
    )){
        Add-Assessment -Area $area -Status "NOT_TESTED" `
            -Finding "Not tested because the computer is not Active Directory domain joined." `
            -Confidence "NOT_TESTED"
    }
}
else{
    Add-Assessment -Area "Domain membership" -Status "CLEAR" `
        -Finding ("Computer is joined to Active Directory domain " + $domain + ".") `
        -Evidence ("PartOfDomain=True; Domain=" + $domain) -Confidence "CONFIRMED"

    # -----------------------------------------------------------------------
    # AD DNS SRV discovery
    # -----------------------------------------------------------------------
    Write-ToolkitStatus ("Checking AD DNS SRV discovery for " + $domain + ".")
    try {
        $dnsSrv = @(
            Resolve-DnsName -Name ("_ldap._tcp.dc._msdcs." + $domain) `
                -Type SRV -ErrorAction Stop |
                Select-Object Name,Type,NameTarget,Port,Priority,Weight
        )

        if(Get-Command New-ToolkitCapabilityStatus -ErrorAction SilentlyContinue){
            $capabilities.Add((New-ToolkitCapabilityStatus -Capability "AD DNS SRV discovery" `
                -Available $true -Status "Available" -Detail ("Records=" + $dnsSrv.Count) -SourceTool $toolId))
        }

        if($dnsSrv.Count -gt 0){
            Add-Assessment -Area "AD DNS SRV discovery" -Status "CLEAR" `
                -Finding ("AD domain-controller SRV records were resolved for " + $domain + ".") `
                -Evidence ("Records=" + $dnsSrv.Count) -Confidence "CONFIRMED"
        }
        else{
            Add-Assessment -Area "AD DNS SRV discovery" -Status "ATTENTION" `
                -Finding "The SRV query completed but returned no domain-controller records." `
                -Confidence "STRONG_EVIDENCE"
        }
    }
    catch {
        $dnsSrvError = $_.Exception.Message
        Add-Assessment -Area "AD DNS SRV discovery" -Status "FAILURE" `
            -Finding "AD domain-controller SRV resolution failed." `
            -Evidence $dnsSrvError -Confidence "CONFIRMED"
        Add-Recommendation "Investigate the client's configured DNS servers, VPN/site connectivity, and AD DNS availability before attempting secure-channel repair."

        if(Get-Command New-ToolkitCapabilityStatus -ErrorAction SilentlyContinue){
            $capabilities.Add((New-ToolkitCapabilityStatus -Capability "AD DNS SRV discovery" `
                -Available $false -Status "Query/API Failed" -Detail $dnsSrvError -SourceTool $toolId))
        }
    }

    # -----------------------------------------------------------------------
    # DC discovery
    # -----------------------------------------------------------------------
    Write-ToolkitStatus "Running read-only domain-controller discovery."
    $dcDiscovery = Invoke-ReadOnlyNative -FilePath "nltest.exe" `
        -Arguments @("/dsgetdc:" + $domain) `
        -Label "AD Domain Controller Discovery"

    $dcText = $(if($dcDiscovery){$dcDiscovery.Output -join [Environment]::NewLine}else{""})
    if($dcText -match '(?im)DC:\s*\\\\([^\s]+)'){
        $dcName = $matches[1].Trim()
    }

    if($dcDiscovery -and $dcDiscovery.ExitCode -eq 0){
        Add-Assessment -Area "Domain controller discovery" -Status "CLEAR" `
            -Finding "Windows successfully discovered a domain controller." `
            -Evidence $(if($dcName){"DC=" + $dcName}else{"nltest /dsgetdc completed successfully."}) `
            -Confidence "CONFIRMED"
    }
    elseif($dnsSrv.Count -eq 0){
        Add-Assessment -Area "Domain controller discovery" -Status "FAILURE" `
            -Finding "Domain-controller discovery failed while AD DNS SRV discovery was also unavailable." `
            -Evidence ("nltest exit=" + $(if($dcDiscovery){$dcDiscovery.ExitCode}else{"unavailable"}) + "; SRV records=0") `
            -Confidence "STRONG_EVIDENCE"
        Add-Recommendation "Treat DNS/site connectivity as the first suspect; do not reset the secure channel until DC discovery works."
    }
    else{
        Add-Assessment -Area "Domain controller discovery" -Status "ATTENTION" `
            -Finding "AD DNS records are present, but Windows did not successfully locate a domain controller." `
            -Evidence ("nltest exit=" + $(if($dcDiscovery){$dcDiscovery.ExitCode}else{"unavailable"}) + "; SRV records=" + $dnsSrv.Count) `
            -Confidence "STRONG_EVIDENCE"
        Add-Recommendation "Investigate routing, firewall policy, AD site/DC availability, and Netlogon discovery."
    }

    # -----------------------------------------------------------------------
    # Read-only DC port reachability
    # -----------------------------------------------------------------------
    if($dcName){
        Write-ToolkitStatus ("Checking read-only TCP reachability to " + $dcName + ".")
        foreach($port in @(53,88,135,389,445)){
            $ok = $false
            try {
                $ok = [bool](Test-NetConnection -ComputerName $dcName -Port $port `
                    -InformationLevel Quiet -WarningAction SilentlyContinue)
            }
            catch {}

            $dcConnectivity += [pscustomobject]@{
                DomainController = $dcName
                Port = $port
                Reachable = $ok
                Service = $(switch($port){
                    53 {"DNS"}
                    88 {"Kerberos"}
                    135 {"RPC Endpoint Mapper"}
                    389 {"LDAP"}
                    445 {"SMB"}
                })
            }
        }

        $failedPorts = @($dcConnectivity | Where-Object { -not $_.Reachable })
        if($failedPorts.Count -eq 0){
            Add-Assessment -Area "Domain controller reachability" -Status "CLEAR" `
                -Finding "Selected core AD TCP ports on the discovered domain controller were reachable." `
                -Evidence "Tested TCP 53, 88, 135, 389, and 445." -Confidence "STRONG_EVIDENCE"
        }
        elseif($failedPorts.Count -ge 3){
            Add-Assessment -Area "Domain controller reachability" -Status "FAILURE" `
                -Finding "Multiple core AD TCP ports on the discovered domain controller were not reachable." `
                -Evidence (($failedPorts | Format-Table Port,Service,Reachable -AutoSize | Out-String -Width 180).Trim()) `
                -Confidence "STRONG_EVIDENCE"
            Add-Recommendation "Investigate network path, VPN, firewall, DC health, or site routing before treating this as a machine-account trust failure."
        }
        else{
            Add-Assessment -Area "Domain controller reachability" -Status "ATTENTION" `
                -Finding "One or more selected AD service ports were not reachable." `
                -Evidence (($failedPorts | Format-Table Port,Service,Reachable -AutoSize | Out-String -Width 180).Trim()) `
                -Confidence "POSSIBLE"
        }
    }
    else{
        Add-Assessment -Area "Domain controller reachability" -Status "NOT_TESTED" `
            -Finding "Port reachability was not tested because a domain controller name was not discovered." `
            -Confidence "NOT_TESTED"
    }

    # -----------------------------------------------------------------------
    # Secure channel
    # -----------------------------------------------------------------------
    Write-ToolkitStatus "Querying the computer secure channel without repair."
    try {
        $secureChannel = [bool](Test-ComputerSecureChannel -ErrorAction Stop)

        if($secureChannel){
            Add-Assessment -Area "Secure channel" -Status "CLEAR" `
                -Finding "The computer secure channel reports healthy." `
                -Evidence "Test-ComputerSecureChannel returned True." -Confidence "CONFIRMED"
        }
        else{
            Add-Assessment -Area "Secure channel" -Status "FAILURE" `
                -Finding "The computer secure channel reports broken." `
                -Evidence "Test-ComputerSecureChannel returned False." -Confidence "CONFIRMED"
            Add-Recommendation "Confirm DNS, DC reachability, and time health first. If those are healthy, use a separate explicit secure-channel repair workflow."
        }

        if(Get-Command New-ToolkitCapabilityStatus -ErrorAction SilentlyContinue){
            $capabilities.Add((New-ToolkitCapabilityStatus -Capability "Computer secure-channel query" `
                -Available $true -Status "Available" `
                -Detail "Test-ComputerSecureChannel completed without -Repair." -SourceTool $toolId))
        }
    }
    catch {
        $secureChannelError = $_.Exception.Message
        Add-Assessment -Area "Secure channel" -Status "INDETERMINATE" `
            -Finding "Secure-channel state could not be determined." `
            -Evidence $secureChannelError -Confidence "INDETERMINATE"

        if(Get-Command New-ToolkitCapabilityStatus -ErrorAction SilentlyContinue){
            $capabilities.Add((New-ToolkitCapabilityStatus -Capability "Computer secure-channel query" `
                -Available $false -Status "Query/API Failed" -Detail $secureChannelError -SourceTool $toolId))
        }
    }

    $secureChannelNative = Invoke-ReadOnlyNative -FilePath "nltest.exe" `
        -Arguments @("/sc_query:" + $domain) `
        -Label "AD Secure Channel Native Query"

    # -----------------------------------------------------------------------
    # Windows Time / clock context
    # -----------------------------------------------------------------------
    $timeStatus = Invoke-ReadOnlyNative -FilePath "w32tm.exe" `
        -Arguments @("/query","/status") -Label "Windows Time Status"
    $timeSource = Invoke-ReadOnlyNative -FilePath "w32tm.exe" `
        -Arguments @("/query","/source") -Label "Windows Time Source"

    $timeSourceText = $(if($timeSource){(($timeSource.Output -join " ") -replace '\s+',' ').Trim()}else{""})
    $timeStatusText = $(if($timeStatus){$timeStatus.Output -join [Environment]::NewLine}else{""})

    if($timeSource -and $timeSource.ExitCode -eq 0 -and
       $timeSourceText -and $timeSourceText -notmatch '(?i)local cmos clock|free-running'){
        Add-Assessment -Area "Domain time relationship" -Status "CLEAR" `
            -Finding "Windows reports a non-local time source." `
            -Evidence $timeSourceText -Confidence "STRONG_EVIDENCE"
    }
    elseif($timeSource -and $timeSource.ExitCode -eq 0){
        Add-Assessment -Area "Domain time relationship" -Status "ATTENTION" `
            -Finding "A domain-joined computer appears to be using a local/free-running time source." `
            -Evidence $timeSourceText -Confidence "POSSIBLE"
        Add-Recommendation "Verify Windows Time hierarchy and clock synchronization before interpreting Kerberos/authentication failures as trust failures."
    }
    else{
        Add-Assessment -Area "Domain time relationship" -Status "INDETERMINATE" `
            -Finding "Windows time source could not be determined." `
            -Evidence ("w32tm exit=" + $(if($timeSource){$timeSource.ExitCode}else{"unavailable"})) `
            -Confidence "INDETERMINATE"
    }

    # -----------------------------------------------------------------------
    # Relevant event correlation
    # -----------------------------------------------------------------------
    $start = (Get-Date).AddDays(-7)

    try {
        $domainEvents = @(
            Get-WinEvent -FilterHashtable @{
                LogName = "System"
                StartTime = $start
            } -ErrorAction Stop |
            Where-Object {
                (
                    $_.ProviderName -match '(?i)NETLOGON|GroupPolicy|LsaSrv|Security-Kerberos'
                ) -and (
                    $_.Level -in 1,2,3 -or
                    $_.Id -in 1053,1054,3210,40960,40961,5719,5722,5805
                )
            } |
            Sort-Object TimeCreated -Descending |
            Select-Object -First 180 TimeCreated,Id,ProviderName,LevelDisplayName,
                @{N="Message";E={($_.Message -replace "[\r\n]+"," " -replace "\s{2,}"," ").Trim()}}
        )
    }
    catch {}

    try {
        $timeEvents = @(
            Get-WinEvent -FilterHashtable @{
                LogName = "System"
                StartTime = $start
            } -ErrorAction Stop |
            Where-Object {
                $_.ProviderName -match '(?i)Time-Service' -and
                $_.Level -in 1,2,3
            } |
            Sort-Object TimeCreated -Descending |
            Select-Object -First 100 TimeCreated,Id,ProviderName,LevelDisplayName,
                @{N="Message";E={($_.Message -replace "[\r\n]+"," " -replace "\s{2,}"," ").Trim()}}
        )
    }
    catch {}

    $authEvents = @(
        $domainEvents |
            Where-Object {
                $_.ProviderName -match '(?i)Kerberos|LsaSrv|NETLOGON' -or
                $_.Id -in 3210,40960,40961,5719,5722,5805
            }
    )

    if($authEvents.Count -gt 0){
        $authConfidence = $(if($secureChannel -eq $false){"STRONG_EVIDENCE"}else{"POSSIBLE"})
        Add-Assessment -Area "Authentication / trust event correlation" -Status "ATTENTION" `
            -Finding ("Recent System log contains " + $authEvents.Count + " authentication/trust-oriented warning or error event(s).") `
            -Evidence ("Most recent: " + $authEvents[0].ProviderName + " event " + $authEvents[0].Id + " at " + $authEvents[0].TimeCreated) `
            -Confidence $authConfidence
        Add-Recommendation "Correlate event timestamps with logon failures, VPN/network changes, DC reachability, and time state."
    }
    else{
        Add-Assessment -Area "Authentication / trust event correlation" -Status "CLEAR" `
            -Finding "No matching recent System log authentication/trust warning or error events were returned." `
            -Confidence "STRONG_EVIDENCE"
    }
}

# ---------------------------------------------------------------------------
# Cause-oriented summary
# ---------------------------------------------------------------------------
$causeRows = New-Object System.Collections.Generic.List[object]

$dnsAssessment = @($assessments.ToArray() | Where-Object { $_.Area -eq "AD DNS SRV discovery" } | Select-Object -First 1)
$dcAssessment = @($assessments.ToArray() | Where-Object { $_.Area -eq "Domain controller reachability" } | Select-Object -First 1)
$scAssessment = @($assessments.ToArray() | Where-Object { $_.Area -eq "Secure channel" } | Select-Object -First 1)
$timeAssessment = @($assessments.ToArray() | Where-Object { $_.Area -eq "Domain time relationship" } | Select-Object -First 1)
$authAssessment = @($assessments.ToArray() | Where-Object { $_.Area -eq "Authentication / trust event correlation" } | Select-Object -First 1)

function Add-CauseRow {
    param([string]$Cause,[string]$Assessment,[string]$Confidence,[string]$Basis)
    $causeRows.Add([pscustomobject]@{
        PossibleCause = $Cause
        Assessment = $Assessment
        Confidence = $Confidence
        Basis = $Basis
    })
}

if($cs -and $cs.PartOfDomain){
    if($dnsAssessment -and $dnsAssessment.Status -in @("FAILURE","ATTENTION")){
        Add-CauseRow "DNS / AD discovery" "SUPPORTED" $dnsAssessment.Confidence $dnsAssessment.Finding
    }else{
        Add-CauseRow "DNS / AD discovery" "NOT ESTABLISHED" "STRONG_EVIDENCE" "AD SRV discovery did not produce a failure finding."
    }

    if($dcAssessment -and $dcAssessment.Status -in @("FAILURE","ATTENTION")){
        Add-CauseRow "DC reachability / network path" "SUPPORTED" $dcAssessment.Confidence $dcAssessment.Finding
    }else{
        Add-CauseRow "DC reachability / network path" "NOT ESTABLISHED" $(if($dcAssessment){$dcAssessment.Confidence}else{"NOT_TESTED"}) $(if($dcAssessment){$dcAssessment.Finding}else{"DC reachability was not tested."})
    }

    if($scAssessment -and $scAssessment.Status -eq "FAILURE"){
        Add-CauseRow "Machine secure-channel trust" "SUPPORTED" "CONFIRMED" $scAssessment.Finding
    }elseif($scAssessment -and $scAssessment.Status -eq "CLEAR"){
        Add-CauseRow "Machine secure-channel trust" "NOT ESTABLISHED" "CONFIRMED" $scAssessment.Finding
    }else{
        Add-CauseRow "Machine secure-channel trust" "INDETERMINATE" "INDETERMINATE" $(if($scAssessment){$scAssessment.Finding}else{"Secure channel was not tested."})
    }

    if($timeAssessment -and $timeAssessment.Status -eq "ATTENTION"){
        Add-CauseRow "Windows Time / Kerberos clock context" "POSSIBLE" $timeAssessment.Confidence $timeAssessment.Finding
    }else{
        Add-CauseRow "Windows Time / Kerberos clock context" "NOT ESTABLISHED" $(if($timeAssessment){$timeAssessment.Confidence}else{"NOT_TESTED"}) $(if($timeAssessment){$timeAssessment.Finding}else{"Time state was not tested."})
    }

    if($authAssessment -and $authAssessment.Status -eq "ATTENTION"){
        Add-CauseRow "Authentication / logon path" "SUPPORTED BY EVENTS" $authAssessment.Confidence $authAssessment.Finding
    }else{
        Add-CauseRow "Authentication / logon path" "NOT ESTABLISHED" $(if($authAssessment){$authAssessment.Confidence}else{"NOT_TESTED"}) $(if($authAssessment){$authAssessment.Finding}else{"Authentication events were not tested."})
    }
}
else{
    foreach($cause in @(
        "DNS / AD discovery",
        "DC reachability / network path",
        "Machine secure-channel trust",
        "Windows Time / Kerberos clock context",
        "Authentication / logon path"
    )){
        Add-CauseRow $cause "NOT TESTED" "NOT_TESTED" "Computer is not Active Directory domain joined."
    }
}

if($recommendations.Count -eq 0){
    Add-Recommendation "No repair action is indicated by the collected evidence. Preserve the report if symptoms are intermittent."
}

# ---------------------------------------------------------------------------
# Sectioned report
# ---------------------------------------------------------------------------
$summary = @($assessments.ToArray() | Select-Object Area,Status,Confidence,Finding)
$warnings = @(
    $assessments.ToArray() |
        Where-Object { $_.Status -in @("ATTENTION","FAILURE","PARTIAL","INDETERMINATE","NOT_TESTED") }
)
$confidenceDefinitions = Get-ToolkitAssessmentConfidenceDefinition

$report = New-ToolkitSectionedReport -Title "Domain Trust / AD Health Investigator" `
    -Subtitle "Read-only correlation of AD membership, DNS, DC discovery/reachability, secure channel, Windows Time, and trust/authentication events." `
    -Footer "No domain membership, secure-channel, DNS, Windows Time, or credential configuration was changed."

Add-ToolkitSectionedReportSection -Report $report -Title "Technician Summary" `
    -Data $summary -Kind "SUMMARY" -OpenByDefault:$true

Add-ToolkitSectionedReportSection -Report $report -Title "Likely Cause Matrix" `
    -Data $causeRows.ToArray() -Kind "SUMMARY" -OpenByDefault:$true

Add-ToolkitSectionedReportSection -Report $report -Title "Warnings / Incomplete Coverage" `
    -Data $(if($warnings.Count){$warnings}else{"No warning/failure/incomplete assessment was produced."}) `
    -Kind $(if($warnings.Count){"WARNING"}else{"SUMMARY"}) -OpenByDefault:$true

Add-ToolkitSectionedReportSection -Report $report -Title "Recommended Next Actions" `
    -Data ($recommendations -join [Environment]::NewLine) `
    -Kind "RECOMMENDATION" -OpenByDefault:$true

Add-ToolkitSectionedReportSection -Report $report -Title "Assessment Confidence Vocabulary" `
    -Data $confidenceDefinitions -Kind "NORMAL" -OpenByDefault:$false `
    -Note "Qualitative evidence labels; the toolkit does not invent numeric certainty."

Add-ToolkitSectionedReportSection -Report $report -Title "Domain Membership / Identity" `
    -Data $membership -Kind "NORMAL" -OpenByDefault:$true

Add-ToolkitSectionedReportSection -Report $report -Title "Configured DNS Servers" `
    -Data $dnsServers -Kind "EVIDENCE" -OpenByDefault:$false

Add-ToolkitSectionedReportSection -Report $report -Title "AD DNS SRV Records" `
    -Data $(if($dnsSrv.Count){$dnsSrv}else{$dnsSrvError}) `
    -Kind "EVIDENCE" -OpenByDefault:$false

Add-ToolkitSectionedReportSection -Report $report -Title "Domain Controller Discovery" `
    -Data $(if($dcDiscovery){$dcDiscovery.Output -join [Environment]::NewLine}else{"Not tested."}) `
    -Kind "EVIDENCE" -OpenByDefault:$false

Add-ToolkitSectionedReportSection -Report $report -Title "Domain Controller Port Reachability" `
    -Data $(if($dcConnectivity.Count){$dcConnectivity}else{"Not tested."}) `
    -Kind "EVIDENCE" -OpenByDefault:$false

Add-ToolkitSectionedReportSection -Report $report -Title "Secure Channel Evidence" `
    -Data ([pscustomobject]@{
        TestComputerSecureChannel = $secureChannel
        Error = $secureChannelError
        NltestScQuery = $(if($secureChannelNative){$secureChannelNative.Output -join " | "}else{"Not tested."})
    }) `
    -Kind "EVIDENCE" -OpenByDefault:$false

Add-ToolkitSectionedReportSection -Report $report -Title "Windows Time Evidence" `
    -Data ([pscustomobject]@{
        Source = $(if($timeSource){$timeSource.Output -join " | "}else{"Not tested."})
        Status = $(if($timeStatus){$timeStatus.Output -join " | "}else{"Not tested."})
    }) `
    -Kind "EVIDENCE" -OpenByDefault:$false

Add-ToolkitSectionedReportSection -Report $report -Title "Recent AD / Trust / Authentication Events - 7 Days" `
    -Data $domainEvents -Kind "EVIDENCE" -OpenByDefault:$false

Add-ToolkitSectionedReportSection -Report $report -Title "Recent Windows Time Events - 7 Days" `
    -Data $timeEvents -Kind "EVIDENCE" -OpenByDefault:$false

# TXT / MD / meta through shared writer.
$lines = New-Object System.Collections.Generic.List[string]
$lines.Add("DOMAIN TRUST / AD HEALTH INVESTIGATOR")
$lines.Add("Computer: " + $env:COMPUTERNAME)
$lines.Add("Generated: " + (Get-Date))
$lines.Add("Read-only: Yes")

foreach($section in @($report.Sections)){
    $lines.Add("")
    $lines.Add(("=" * 78))
    $lines.Add([string]$section.Title)
    $lines.Add(("=" * 78))
    if(-not [string]::IsNullOrWhiteSpace([string]$section.Note)){
        $lines.Add("NOTE: " + [string]$section.Note)
    }
    $lines.Add([string]$section.Body)
}

$body = $lines -join [Environment]::NewLine
& $writer -BasePath $basePath -Title "Domain Trust / AD Health Investigator" -Body $body -ToolId $toolId

# Explicit section ordering replaces generic long-report presentation.
[void](Write-ToolkitSectionedHtmlReport -Report $report -Path ($basePath + ".html") `
    -Computer $env:COMPUTERNAME -Generated ([string](Get-Date)) -ToolId $toolId)

$payload = [pscustomobject]@{
    Report = [pscustomobject]@{
        Title = "Domain Trust / AD Health Investigator"
        ToolId = $toolId
        Computer = $env:COMPUTERNAME
        GeneratedAt = (Get-Date)
        ReadOnly = $true
    }
    AssessmentConfidenceVocabulary = @(
        "CONFIRMED",
        "STRONG_EVIDENCE",
        "POSSIBLE",
        "INDETERMINATE",
        "NOT_TESTED"
    )
    Assessments = $assessments.ToArray()
    CauseMatrix = $causeRows.ToArray()
    Recommendations = $recommendations.ToArray()
    Membership = $membership
    ConfiguredDnsServers = $dnsServers
    DnsSrv = $dnsSrv
    DcDiscovery = $(if($dcDiscovery){$dcDiscovery.Output}else{@()})
    DcConnectivity = $dcConnectivity
    SecureChannel = [pscustomobject]@{
        Result = $secureChannel
        Error = $secureChannelError
        NativeQuery = $(if($secureChannelNative){$secureChannelNative.Output}else{@()})
    }
    WindowsTime = [pscustomobject]@{
        Source = $(if($timeSource){$timeSource.Output}else{@()})
        Status = $(if($timeStatus){$timeStatus.Output}else{@()})
    }
    DomainEvents = $domainEvents
    TimeEvents = $timeEvents
}

$payload | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath ($basePath + ".json") -Encoding UTF8

if(Get-Command Write-ToolkitDiagnosticSidecar -ErrorAction SilentlyContinue){
    Write-ToolkitDiagnosticSidecar -BasePath $basePath -ToolkitRoot $toolkitRoot `
        -ToolId $toolId -Title "Domain Trust / AD Health Investigator" `
        -Capabilities $capabilities.ToArray()
}

Write-ToolkitStatus "Domain Trust / AD Health Investigator complete."
Write-Host ""
Write-Host ("HTML: " + $basePath + ".html")
Write-Host ("Text: " + $basePath + ".txt")
Write-Host ("Markdown: " + $basePath + ".md")
Write-Host ("JSON: " + $basePath + ".json")
Write-Host ""

try { Start-Process -FilePath ($basePath + ".html") } catch {}

exit 0

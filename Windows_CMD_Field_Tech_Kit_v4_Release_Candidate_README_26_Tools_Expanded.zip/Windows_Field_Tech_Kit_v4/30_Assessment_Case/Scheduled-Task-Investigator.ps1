$screenReaderCommon = Join-Path (Split-Path $PSScriptRoot -Parent) "00_Common\ScreenReader-Common.ps1"
if (Test-Path -LiteralPath $screenReaderCommon -PathType Leaf) {
    . $screenReaderCommon
}

$ErrorActionPreference="SilentlyContinue"
$ProgressPreference="SilentlyContinue"
$toolkitRoot=Split-Path $PSScriptRoot -Parent
$logs=Join-Path $toolkitRoot "Logs"
if(-not(Test-Path -LiteralPath $logs)){New-Item -ItemType Directory -Path $logs -Force|Out-Null}
$writer=Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"

Write-Host "SCHEDULED TASK INVESTIGATOR"
$filter=(Read-ToolkitPrompt "Task name/path filter, or Enter for all tasks").Trim()
$stamp=Get-Date -Format "yyyyMMdd_HHmmss"
$safe=if($filter){$filter-replace'[^A-Za-z0-9._-]','_'}else{"ALL"}
$basePath=Join-Path $logs ($env:COMPUTERNAME+"_Scheduled_Task_Investigator_"+$safe+"_"+$stamp)

$rows=New-Object System.Collections.Generic.List[object]
$tasks=Get-ScheduledTask -ErrorAction SilentlyContinue
if($filter){$tasks=@($tasks|Where-Object{$_.TaskName -like "*$filter*" -or $_.TaskPath -like "*$filter*"})}
foreach($task in $tasks){
 $info=Get-ScheduledTaskInfo -TaskName $task.TaskName -TaskPath $task.TaskPath -ErrorAction SilentlyContinue
 $actions=@()
 foreach($a in $task.Actions){
  $exe=[string]$a.Execute;$sigStatus="";$signer=""
  if($exe){
   $expanded=[Environment]::ExpandEnvironmentVariables($exe.Trim('"'))
   if(Test-Path -LiteralPath $expanded -PathType Leaf){
    $sig=Get-AuthenticodeSignature -FilePath $expanded -ErrorAction SilentlyContinue
    $sigStatus=[string]$sig.Status
    if($sig.SignerCertificate){$signer=$sig.SignerCertificate.Subject}
   }
  }
  $actions+=("Execute="+$exe+" Args="+$a.Arguments+" Signature="+$sigStatus+" Signer="+$signer)
 }
 $result=if($info){$info.LastTaskResult}else{$null}
 $assessment=if($null -eq $result){"UNKNOWN"}elseif($result -eq 0){"OK"}elseif($result -in 267009,267010,267011){"INFO"}else{"REVIEW"}
 $rows.Add([pscustomobject]@{
  Assessment=$assessment;TaskPath=$task.TaskPath;TaskName=$task.TaskName;State=$task.State;LastRun=$info.LastRunTime;
  LastResult=$result;NextRun=$info.NextRunTime;Author=$task.Author;Actions=($actions -join " | ")
 })
}

$events=@()
try{
 $events=Get-WinEvent -FilterHashtable @{LogName="Microsoft-Windows-TaskScheduler/Operational";StartTime=(Get-Date).AddDays(-14)} -ErrorAction Stop|
  Where-Object{(-not $filter) -or $_.Message -like "*$filter*"}|
  Sort-Object TimeCreated -Descending|Select-Object -First 200 TimeCreated,Id,LevelDisplayName,@{N="Message";E={($_.Message-replace"[\r\n]+"," "-replace"\s{2,}"," ").Trim()}}
}catch{}

$review=@($rows|Where-Object Assessment -eq "REVIEW")
$lines=New-Object System.Collections.Generic.List[string]
$lines.Add("SCHEDULED TASK INVESTIGATOR");$lines.Add("Computer: "+$env:COMPUTERNAME);$lines.Add("Generated: "+(Get-Date));$lines.Add("Filter: "+$(if($filter){$filter}else{"All tasks"}))
$lines.Add("");$lines.Add("Read-only task state, last-result, next-run, action/signature, author, and TaskScheduler event review.")
$lines.Add("Tasks flagged REVIEW: "+$review.Count+". Nonzero LastTaskResult is a clue and must be interpreted in task context.")
$lines.Add("");$lines.Add(("="*78));$lines.Add("TASK INVENTORY");$lines.Add(("="*78));$lines.Add(($rows|Sort-Object Assessment,TaskPath,TaskName|Format-Table Assessment,State,LastResult,LastRun,TaskPath,TaskName -Wrap -AutoSize|Out-String -Width 260).TrimEnd())
$lines.Add("");$lines.Add(("="*78));$lines.Add("TASK DETAILS");$lines.Add(("="*78));$lines.Add(($rows|Format-List|Out-String -Width 260).TrimEnd())
$lines.Add("");$lines.Add(("="*78));$lines.Add("TASKSCHEDULER EVENTS - 14 DAYS");$lines.Add(("="*78));$x=($events|Format-List|Out-String -Width 260).TrimEnd();if($x){$lines.Add($x)}else{$lines.Add("(No matching events returned.)")}
$body=$lines -join [Environment]::NewLine
& $writer -BasePath $basePath -Title "Scheduled Task Investigator" -Body $body
$html=$basePath+".html";Write-Host("Report: "+$html);try{Start-Process -FilePath $html}catch{}
exit 0

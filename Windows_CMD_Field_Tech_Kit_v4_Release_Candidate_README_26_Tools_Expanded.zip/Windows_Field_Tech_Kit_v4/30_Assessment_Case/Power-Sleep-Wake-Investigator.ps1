$ErrorActionPreference="SilentlyContinue"
$ProgressPreference="SilentlyContinue"
$toolkitRoot=Split-Path $PSScriptRoot -Parent
$foundation=Join-Path $toolkitRoot "00_Common\Foundation-Common.ps1"
if(Test-Path -LiteralPath $foundation -PathType Leaf){. $foundation}
$logs=Join-Path $toolkitRoot "Logs"
if(-not(Test-Path -LiteralPath $logs)){New-Item -ItemType Directory -Path $logs -Force|Out-Null}
$writer=Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"
$stamp=Get-Date -Format "yyyyMMdd_HHmmss"
$basePath=Join-Path $logs ($env:COMPUTERNAME+"_Power_Sleep_Wake_Investigator_"+$stamp)

$cmds=[ordered]@{}
foreach($entry in @(
 @("POWERCFG /A",@("/a")),
 @("POWERCFG /LASTWAKE",@("/lastwake")),
 @("POWERCFG /WAKETIMERS",@("/waketimers")),
 @("POWERCFG /REQUESTS",@("/requests")),
 @("ACTIVE POWER SCHEME",@("/getactivescheme"))
)){
 $name=$entry[0];$powerArgs=$entry[1]
 $powerNative=Invoke-ToolkitNativeCommand -FilePath "powercfg.exe" -Arguments @($powerArgs) -Label $name -Action "Power Sleep Wake Investigator" -Quiet
 $cmds[$name]=(($powerNative.Output -join [Environment]::NewLine)|Out-String -Width 260).TrimEnd()
}

$fast=Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power" -ErrorAction SilentlyContinue
$events=@()
try{
 $events=Get-WinEvent -FilterHashtable @{LogName="System";StartTime=(Get-Date).AddDays(-14)} -ErrorAction Stop|
  Where-Object{
   ($_.ProviderName -match '(?i)(Kernel-Power|Power-Troubleshooter|Kernel-General)' -and $_.Id -in 1,41,42,107,109,506,507) -or
   $_.Message -match '(?i)(wake source|sleep|resume|standby)'
  }|
  Sort-Object TimeCreated -Descending|Select-Object -First 180 TimeCreated,Id,ProviderName,LevelDisplayName,@{N="Message";E={($_.Message-replace"[\r\n]+"," "-replace"\s{2,}"," ").Trim()}}
}catch{}

$battery=Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue|
 Select-Object Name,BatteryStatus,EstimatedChargeRemaining,EstimatedRunTime,DesignVoltage

$lines=New-Object System.Collections.Generic.List[string]
$lines.Add("POWER / SLEEP / WAKE INVESTIGATOR");$lines.Add("Computer: "+$env:COMPUTERNAME);$lines.Add("Generated: "+(Get-Date))
$lines.Add("Fast Startup HiberbootEnabled: "+$fast.HiberbootEnabled)
$lines.Add("");$lines.Add("Read-only collection of sleep-state capability, wake source/timers, active power requests, power scheme, battery state, and recent power events.")
foreach($key in $cmds.Keys){
 $lines.Add("");$lines.Add(("="*78));$lines.Add($key);$lines.Add(("="*78));$lines.Add($cmds[$key])
}
$lines.Add("");$lines.Add(("="*78));$lines.Add("BATTERY STATE");$lines.Add(("="*78));$x=($battery|Out-String -Width 260).TrimEnd();if($x){$lines.Add($x)}else{$lines.Add("(No battery object returned.)")}
$lines.Add("");$lines.Add(("="*78));$lines.Add("RECENT POWER / SLEEP / WAKE EVENTS - 14 DAYS");$lines.Add(("="*78));$x=($events|Format-List|Out-String -Width 260).TrimEnd();if($x){$lines.Add($x)}else{$lines.Add("(No matching events returned.)")}
$body=$lines -join [Environment]::NewLine
& $writer -BasePath $basePath -Title "Power Sleep Wake Investigator" -Body $body
$html=$basePath+".html";Write-Host("Report: "+$html);try{Start-Process -FilePath $html}catch{}
exit 0

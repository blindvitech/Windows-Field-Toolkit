$screenReaderCommon = Join-Path (Split-Path $PSScriptRoot -Parent) "00_Common\ScreenReader-Common.ps1"
if (Test-Path -LiteralPath $screenReaderCommon -PathType Leaf) { . $screenReaderCommon }

$ErrorActionPreference = "SilentlyContinue"
$ProgressPreference = "SilentlyContinue"

$toolkitRoot = Split-Path $PSScriptRoot -Parent
$foundation = Join-Path $toolkitRoot "00_Common\Foundation-Common.ps1"
$diagnostic = Join-Path $toolkitRoot "00_Common\Diagnostic-Evidence.ps1"
$writer = Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"
if (Test-Path -LiteralPath $foundation -PathType Leaf) { . $foundation }
if (Test-Path -LiteralPath $diagnostic -PathType Leaf) { . $diagnostic }

$logs = Get-ToolkitLogRoot
$toolId = $(if($env:FIELDTECH_TOOL_ID){$env:FIELDTECH_TOOL_ID}else{"ADV-071"})

Write-Host "DNS RESOLUTION CHAIN INVESTIGATOR"
Write-Host ""
$target = (Read-ToolkitPrompt "Hostname to investigate, default www.microsoft.com").Trim()
if ([string]::IsNullOrWhiteSpace($target)) { $target = "www.microsoft.com" }

$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$safeTarget = $target -replace '[^A-Za-z0-9._-]','_'
$basePath = Join-Path $logs ($env:COMPUTERNAME + "_DNS_Resolution_Chain_" + $safeTarget + "_" + $stamp)

$findings = New-Object System.Collections.Generic.List[object]
$evidence = New-Object System.Collections.Generic.List[object]
$capabilities = New-Object System.Collections.Generic.List[object]

function Add-Section {
    param(
        [System.Collections.Generic.List[string]]$Lines,
        [string]$Title,
        $Value
    )
    $Lines.Add("")
    $Lines.Add(("=" * 78))
    $Lines.Add($Title)
    $Lines.Add(("=" * 78))
    $text = ($Value | Out-String -Width 260).TrimEnd()
    if ($text) { $Lines.Add($text) } else { $Lines.Add("(No data returned)") }
}

$activeAdapters = @(Get-NetAdapter -ErrorAction SilentlyContinue | Where-Object Status -eq "Up")
$dnsServers = @(Get-DnsClientServerAddress -ErrorAction SilentlyContinue |
    Where-Object { $_.ServerAddresses -and $_.ServerAddresses.Count -gt 0 } |
    Select-Object InterfaceAlias,InterfaceIndex,AddressFamily,@{N="ServerAddresses";E={$_.ServerAddresses -join ", "}} |
    Sort-Object InterfaceIndex,AddressFamily)
$globalDns = Get-DnsClientGlobalSetting -ErrorAction SilentlyContinue
$dnsClient = @(Get-DnsClient -ErrorAction SilentlyContinue |
    Select-Object InterfaceAlias,InterfaceIndex,ConnectionSpecificSuffix,RegisterThisConnectionsAddress,UseSuffixWhenRegistering |
    Sort-Object InterfaceIndex)
$nrpt = @(Get-DnsClientNrptPolicy -ErrorAction SilentlyContinue |
    Select-Object Namespace,NameServers,DirectAccessDnsServers,QueryPolicy,Fqdn,Comment)

$hostsPath = Join-Path $env:SystemRoot "System32\drivers\etc\hosts"
$hostsMatches = @()
if (Test-Path -LiteralPath $hostsPath -PathType Leaf) {
    $escapedTarget = [regex]::Escape($target)
    $hostsMatches = @(Get-Content -LiteralPath $hostsPath -ErrorAction SilentlyContinue |
        Where-Object { $_ -notmatch '^\s*#' -and $_ -match ('(?i)(^|\s)' + $escapedTarget + '(\s|$)') })
}

$cacheMatches = @(Get-DnsClientCache -ErrorAction SilentlyContinue |
    Where-Object { [string]$_.Entry -ieq $target -or [string]$_.Name -ieq $target } |
    Select-Object Entry,Name,RecordName,RecordType,Data,Status,TimeToLive)

$systemResolution = $null
$systemResolutionError = ""
try {
    $systemResolution = @(Resolve-DnsName -Name $target -ErrorAction Stop |
        Select-Object Name,Type,IPAddress,NameHost,QueryType,Server)
    $capabilities.Add((New-ToolkitCapabilityStatus -Capability "System DNS resolution" -Available $true -Status "Available" -Detail "Resolve-DnsName returned data." -SourceTool $toolId))
}
catch {
    $systemResolutionError = $_.Exception.Message
    $class = Get-ToolkitCapabilityFailureClassification -ExceptionMessage $systemResolutionError -Context "Resolve-DnsName system resolver"
    $capabilities.Add((New-ToolkitCapabilityStatus -Capability "System DNS resolution" -Available $false -Status $class.Label -Detail $class.Detail -SourceTool $toolId))
}

$configuredServerResults = New-Object System.Collections.Generic.List[object]
$configuredServerAddresses = New-Object System.Collections.Generic.List[string]
foreach ($row in $dnsServers) {
    foreach ($server in @(([string]$row.ServerAddresses) -split ',\s*')) {
        if (-not [string]::IsNullOrWhiteSpace($server) -and -not $configuredServerAddresses.Contains($server)) {
            $configuredServerAddresses.Add($server)
        }
    }
}

foreach ($server in $configuredServerAddresses.ToArray()) {
    try {
        $r = @(Resolve-DnsName -Name $target -Server $server -DnsOnly -ErrorAction Stop |
            Select-Object Name,Type,IPAddress,NameHost)
        $configuredServerResults.Add([pscustomobject]@{
            Server=$server
            Result="SUCCESS"
            Answers=(($r | ForEach-Object {
                if($_.IPAddress){[string]$_.IPAddress}
                elseif($_.NameHost){[string]$_.NameHost}
                else{[string]$_.Name}
            }) -join ", ")
            Error=""
        })
    }
    catch {
        $configuredServerResults.Add([pscustomobject]@{
            Server=$server
            Result="FAILED"
            Answers=""
            Error=$_.Exception.Message
        })
    }
}

$publicResults = New-Object System.Collections.Generic.List[object]
foreach($serverSpec in @(
    [pscustomobject]@{Name="Cloudflare";Address="1.1.1.1"},
    [pscustomobject]@{Name="Google";Address="8.8.8.8"}
)) {
    try {
        $r = @(Resolve-DnsName -Name $target -Server $serverSpec.Address -DnsOnly -ErrorAction Stop |
            Select-Object Name,Type,IPAddress,NameHost)
        $publicResults.Add([pscustomobject]@{
            Resolver=$serverSpec.Name
            Server=$serverSpec.Address
            Result="SUCCESS"
            Answers=(($r | ForEach-Object {
                if($_.IPAddress){[string]$_.IPAddress}
                elseif($_.NameHost){[string]$_.NameHost}
                else{[string]$_.Name}
            }) -join ", ")
            Error=""
        })
    }
    catch {
        $publicResults.Add([pscustomobject]@{
            Resolver=$serverSpec.Name
            Server=$serverSpec.Address
            Result="FAILED"
            Answers=""
            Error=$_.Exception.Message
        })
    }
}

$dnsEvents = @()
$eventError = ""
try {
    $start = (Get-Date).AddHours(-24)
    $dnsEvents = @(Get-WinEvent -FilterHashtable @{
        LogName="Microsoft-Windows-DNS-Client/Operational"
        StartTime=$start
    } -ErrorAction Stop | Where-Object { $_.Level -in 1,2,3 } |
        Select-Object -First 80 TimeCreated,Id,LevelDisplayName,ProviderName,Message)
    $capabilities.Add((New-ToolkitCapabilityStatus -Capability "DNS Client Operational event log" -Available $true -Status "Available" -Detail ("Events read: " + $dnsEvents.Count) -SourceTool $toolId))
}
catch {
    $eventError = $_.Exception.Message
    $class = Get-ToolkitCapabilityFailureClassification -ExceptionMessage $eventError -Context "DNS Client Operational event log"
    $capabilities.Add((New-ToolkitCapabilityStatus -Capability "DNS Client Operational event log" -Available $false -Status $class.Label -Detail $class.Detail -SourceTool $toolId))
}

if ($hostsMatches.Count -gt 0) {
    $findings.Add((New-ToolkitDiagnosticFinding -Severity "INFO" -Category "DNS" -Confidence "Confirmed" `
        -Evidence ("HOSTS file contains " + $hostsMatches.Count + " active matching line(s) for " + $target + ".") `
        -Action "Treat HOSTS-file entries as an intentional local override until verified." -SourceTool $toolId -Source "HOSTS"))
}

if ($configuredServerAddresses.Count -eq 0) {
    $findings.Add((New-ToolkitDiagnosticFinding -Severity "WARNING" -Category "DNS" -Confidence "Likely" `
        -Evidence "No configured DNS server addresses were returned for Windows interfaces." `
        -Action "Inspect adapter DHCP/static DNS configuration and current link state." -SourceTool $toolId -Source "DnsClientServerAddress"))
}

$configuredSuccess = @($configuredServerResults.ToArray() | Where-Object Result -eq "SUCCESS").Count
$configuredFailure = @($configuredServerResults.ToArray() | Where-Object Result -eq "FAILED").Count
$publicSuccess = @($publicResults.ToArray() | Where-Object Result -eq "SUCCESS").Count

if (-not $systemResolution -and $publicSuccess -gt 0) {
    $findings.Add((New-ToolkitDiagnosticFinding -Severity "WARNING" -Category "DNS" -Confidence "Likely" `
        -Evidence ("System-configured DNS failed for " + $target + " while at least one public comparison resolver succeeded.") `
        -Action "Focus on configured DNS server reachability, DHCP-provided DNS, NRPT, VPN/security filtering, or local DNS-client state." `
        -SourceTool $toolId -Source "Resolve-DnsName"))
}
elseif ($systemResolution -and $configuredFailure -gt 0 -and $configuredSuccess -gt 0) {
    $findings.Add((New-ToolkitDiagnosticFinding -Severity "WARNING" -Category "DNS" -Confidence "Likely" `
        -Evidence "Configured DNS servers produced mixed success/failure results." `
        -Action "Investigate the failing resolver address and adapter DNS ordering." -SourceTool $toolId -Source "Resolve-DnsName"))
}
elseif (-not $systemResolution -and $publicSuccess -eq 0) {
    $findings.Add((New-ToolkitDiagnosticFinding -Severity "WARNING" -Category "DNS" -Confidence "Possible" `
        -Evidence ("Neither the system resolver nor public comparison resolvers returned a successful answer for " + $target + ".") `
        -Action "Confirm the hostname is valid and verify general network reachability before concluding the local DNS configuration is at fault." `
        -SourceTool $toolId -Source "Resolve-DnsName"))
}

foreach($evt in $dnsEvents) {
    $msg = ([string]$evt.Message).Trim()
    $ev = [pscustomobject]@{
        EvidenceId = Get-ToolkitEvidenceId -Category "WindowsEvent" -Source ([string]$evt.ProviderName) `
            -EventId ([string]$evt.Id) -Timestamp $evt.TimeCreated -Device "" -Evidence $msg
        Class = "DNS Client Event"
        DeviceContext = ""
        Timestamp = $evt.TimeCreated
        Source = [string]$evt.ProviderName
        EventId = [string]$evt.Id
        Evidence = $msg
    }
    $evidence.Add($ev)
}

$lines = New-Object System.Collections.Generic.List[string]
$lines.Add("DNS RESOLUTION CHAIN INVESTIGATOR")
$lines.Add("Computer: " + $env:COMPUTERNAME)
$lines.Add("Generated: " + (Get-Date))
$lines.Add("Target: " + $target)
$lines.Add("")
$lines.Add("Read-only investigation of local overrides, suffix/NRPT policy, configured resolvers,")
$lines.Add("system resolution, per-server resolution, public comparison resolution, cache, and")
$lines.Add("recent DNS Client warning/error events. Public resolvers are comparison probes only.")

Add-Section -Lines $lines -Title "ACTIVE ADAPTERS" -Value ($activeAdapters | Select-Object Name,InterfaceDescription,Status,LinkSpeed,ifIndex)
Add-Section -Lines $lines -Title "DNS SERVER CONFIGURATION" -Value $dnsServers
Add-Section -Lines $lines -Title "DNS CLIENT / SUFFIX STATE" -Value $dnsClient
Add-Section -Lines $lines -Title "GLOBAL DNS CLIENT SETTINGS" -Value $globalDns
Add-Section -Lines $lines -Title "NRPT POLICY" -Value $nrpt
Add-Section -Lines $lines -Title "HOSTS FILE MATCHES" -Value $hostsMatches
Add-Section -Lines $lines -Title "SYSTEM RESOLUTION" -Value $(if($systemResolution){$systemResolution}else{$systemResolutionError})
Add-Section -Lines $lines -Title "CONFIGURED RESOLVER TESTS" -Value $configuredServerResults.ToArray()
Add-Section -Lines $lines -Title "PUBLIC COMPARISON RESOLVERS" -Value $publicResults.ToArray()
Add-Section -Lines $lines -Title "DNS CACHE MATCHES" -Value $cacheMatches
Add-Section -Lines $lines -Title "RECENT DNS CLIENT WARNING / ERROR EVENTS (24H)" -Value $(if($dnsEvents.Count -gt 0){$dnsEvents}else{$eventError})
Add-Section -Lines $lines -Title "DIAGNOSTIC FINDINGS" -Value $findings.ToArray()
Add-Section -Lines $lines -Title "CAPABILITY / QUERY STATUS" -Value $capabilities.ToArray()

$body = $lines.ToArray() -join [Environment]::NewLine
& $writer -BasePath $basePath -Title "DNS Resolution Chain Investigator" -Body $body -ToolId $toolId
if (Get-Command Write-ToolkitDiagnosticSidecar -ErrorAction SilentlyContinue) {
    Write-ToolkitDiagnosticSidecar -BasePath $basePath -ToolkitRoot $toolkitRoot -ToolId $toolId `
        -Title "DNS Resolution Chain Investigator" -Findings $findings.ToArray() `
        -Evidence $evidence.ToArray() -Capabilities $capabilities.ToArray()
}
Write-Host ("Report: " + $basePath + ".html")
try { Start-Process -FilePath ($basePath + ".html") } catch {}
exit 0

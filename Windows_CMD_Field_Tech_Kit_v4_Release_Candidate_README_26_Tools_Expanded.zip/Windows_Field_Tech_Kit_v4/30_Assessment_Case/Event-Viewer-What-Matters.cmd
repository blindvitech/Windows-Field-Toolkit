@echo off
setlocal EnableExtensions
title Event Viewer - What Matters?

echo Event Viewer - What Matters?
echo.
echo Read-only assessment tool. Windows system state is not changed.
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Event-Viewer-What-Matters.ps1"
set "RC=%errorlevel%"

echo.
if "%SRMODE%"=="1" (
    if "%RC%"=="0" (
        echo Event Viewer - What Matters? completed.
    ) else (
        echo Event Viewer - What Matters? returned error code %RC%.
    )
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

exit /b %RC%

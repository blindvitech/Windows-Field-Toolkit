$screenReaderCommon = Join-Path (Split-Path $PSScriptRoot -Parent) "00_Common\ScreenReader-Common.ps1"
if (Test-Path -LiteralPath $screenReaderCommon -PathType Leaf) {
    . $screenReaderCommon
}

$ErrorActionPreference="SilentlyContinue"
$ProgressPreference="SilentlyContinue"
$toolkitRoot=Split-Path $PSScriptRoot -Parent
$logs=Join-Path $toolkitRoot "Logs"
if(-not(Test-Path -LiteralPath $logs)){New-Item -ItemType Directory -Path $logs -Force|Out-Null}
$writer=Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"

Write-Host "PRINTER FAILURE INVESTIGATOR"
Write-Host "Enter a printer name, or press Enter to investigate all installed printers."
$filter=(Read-ToolkitPrompt "Printer").Trim()
$stamp=Get-Date -Format "yyyyMMdd_HHmmss"
$safe=if($filter){$filter-replace'[^A-Za-z0-9._-]','_'}else{"ALL"}
$basePath=Join-Path $logs ($env:COMPUTERNAME+"_Printer_Failure_Investigator_"+$safe+"_"+$stamp)

$printers=@(Get-Printer -ErrorAction SilentlyContinue)
if($filter){$printers=@($printers|Where-Object{$_.Name -like "*$filter*"})}
$printerRows=$printers|Select-Object Name,Type,DriverName,PortName,Shared,Published,PrinterStatus
$driverNames=@($printers.DriverName|Where-Object{$_}|Sort-Object -Unique)
$drivers=Get-PrinterDriver -ErrorAction SilentlyContinue|Where-Object{$driverNames -contains $_.Name}|
 Select-Object Name,Manufacturer,MajorVersion,DriverVersion,InfPath
$portNames=@($printers.PortName|Where-Object{$_}|Sort-Object -Unique)
$ports=Get-PrinterPort -ErrorAction SilentlyContinue|Where-Object{$portNames -contains $_.Name}|
 Select-Object Name,Description,PrinterHostAddress,PortNumber,Protocol,SNMPEnabled

$jobs=@()
foreach($p in $printers){try{$jobs+=Get-PrintJob -PrinterName $p.Name -ErrorAction Stop|Select-Object @{N="Printer";E={$p.Name}},ID,DocumentName,JobStatus,Submitter,SubmittedTime,TotalPages}catch{}}

$networkTests=@()
foreach($port in $ports|Where-Object PrinterHostAddress){
 $target=[string]$port.PrinterHostAddress
 $testPort=if($port.PortNumber){[int]$port.PortNumber}else{9100}
 $t=Test-NetConnection -ComputerName $target -Port $testPort -WarningAction SilentlyContinue -InformationLevel Detailed
 $networkTests+=[pscustomobject]@{PrinterPort=$port.Name;Target=$target;Port=$testPort;RemoteAddress=$t.RemoteAddress;TcpTestSucceeded=$t.TcpTestSucceeded;InterfaceAlias=$t.InterfaceAlias;SourceAddress=$t.SourceAddress}
}

$svc=Get-Service Spooler -ErrorAction SilentlyContinue|Select-Object Name,Status,StartType
$events=@()
foreach($log in @("Microsoft-Windows-PrintService/Admin","Microsoft-Windows-PrintService/Operational")){
 try{
  $events+=Get-WinEvent -FilterHashtable @{LogName=$log;StartTime=(Get-Date).AddDays(-14);Level=1,2,3} -ErrorAction Stop|
   Where-Object{(-not $filter) -or $_.Message -like "*$filter*"}|
   Sort-Object TimeCreated -Descending|Select-Object -First 100 TimeCreated,LogName,Id,LevelDisplayName,@{N="Message";E={($_.Message-replace"[\r\n]+"," "-replace"\s{2,}"," ").Trim()}}
 }catch{}
}

$lines=New-Object System.Collections.Generic.List[string]
$lines.Add("PRINTER FAILURE INVESTIGATOR");$lines.Add("Computer: "+$env:COMPUTERNAME);$lines.Add("Generated: "+(Get-Date));$lines.Add("Filter: "+$(if($filter){$filter}else{"All printers"}))
$lines.Add("");$lines.Add("Read-only correlation of printer, driver, port, queued-job, spooler, PrintService event, and network-port state.")
foreach($pair in @(@("PRINTERS",$printerRows),@("DRIVERS",$drivers),@("PORTS",$ports),@("QUEUED JOBS",$jobs),@("NETWORK PORT TESTS",$networkTests),@("SPOOLER SERVICE",$svc),@("PRINTSERVICE EVENTS - 14 DAYS",$events))){
 $lines.Add("");$lines.Add(("="*78));$lines.Add($pair[0]);$lines.Add(("="*78));$x=($pair[1]|Out-String -Width 260).TrimEnd();if($x){$lines.Add($x)}else{$lines.Add("(No data returned)")}
}
$body=$lines -join [Environment]::NewLine
& $writer -BasePath $basePath -Title "Printer Failure Investigator" -Body $body
$html=$basePath+".html";Write-Host("Report: "+$html);try{Start-Process -FilePath $html}catch{}
exit 0

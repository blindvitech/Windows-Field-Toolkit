$ErrorActionPreference="SilentlyContinue"
$ProgressPreference="SilentlyContinue"
$toolkitRoot=Split-Path $PSScriptRoot -Parent
$foundation=Join-Path $toolkitRoot "00_Common\Foundation-Common.ps1"
if(Test-Path -LiteralPath $foundation -PathType Leaf){. $foundation}
$logs=if(Get-Command Get-ToolkitLogRoot -ErrorAction SilentlyContinue){Get-ToolkitLogRoot}else{Join-Path $toolkitRoot "Logs"}
$toolkitVersion="v4"
$versionPath=Join-Path $toolkitRoot "00_Common\Toolkit-Version.json"
try{$toolkitVersion=[string](Get-Content -LiteralPath $versionPath -Raw -ErrorAction Stop|ConvertFrom-Json -ErrorAction Stop).DisplayVersion}catch{}
$toolkitBuildId=""
if(Get-Command Get-ToolkitBuildIdentity -ErrorAction SilentlyContinue){
 try{$toolkitBuildId=[string](Get-ToolkitBuildIdentity).BuildId}catch{}
}
if(-not(Test-Path -LiteralPath $logs)){New-Item -ItemType Directory -Path $logs -Force|Out-Null}

$stamp=Get-Date -Format "yyyyMMdd_HHmmss"
$caseName="CASE_"+$env:COMPUTERNAME+"_"+$stamp
$caseDir=Join-Path $logs $caseName
New-Item -ItemType Directory -Path $caseDir -Force|Out-Null
New-Item -ItemType Directory -Path (Join-Path $caseDir "Artifacts\LogsMirror") -Force|Out-Null
New-Item -ItemType Directory -Path (Join-Path $caseDir "Activity") -Force|Out-Null
if(Get-Command Set-ToolkitActiveCaseState -ErrorAction SilentlyContinue){
 [void](Set-ToolkitActiveCaseState -CaseId $caseName -CasePath $caseDir -Status "ACTIVE")
}else{
 $caseName | Set-Content -LiteralPath (Join-Path $logs "ACTIVE_CASE.txt") -Encoding ASCII
}

$caseState=[ordered]@{
 SchemaVersion=2
 CaseId=$caseName
 Status="ACTIVE"
 Computer=$env:COMPUTERNAME
 User=$env:USERDOMAIN+"\"+$env:USERNAME
 SessionId=$env:FIELDTECH_SESSION_ID
 ToolkitVersion=$toolkitVersion
 ToolkitBuildId=$toolkitBuildId
 ArtifactCaptureEnabled=$true
 ArtifactCaptureMode="ACTIVE_CASE_ONLY"
 Created=(Get-Date -Format "o")
 Updated=(Get-Date -Format "o")
 Closed=$null
}
if(Get-Command Set-ToolkitAtomicJson -ErrorAction SilentlyContinue){
 [void](Set-ToolkitAtomicJson -Path (Join-Path $caseDir "CASE_STATE.json") -Object $caseState)
}else{
 $caseState|ConvertTo-Json -Depth 4|Set-Content -LiteralPath (Join-Path $caseDir "CASE_STATE.json") -Encoding UTF8
}

$metadata = @(
    "Case=" + $caseName,
    "Computer=" + $env:COMPUTERNAME,
    "StartTimeISO=" + (Get-Date -Format "o"),
    "User=" + $env:USERDOMAIN + "\" + $env:USERNAME,
    "ToolkitRoot=" + $toolkitRoot,
    "ToolkitVersion=" + $toolkitVersion,
    "ToolkitBuildId=" + $toolkitBuildId,
    "ArtifactCapture=ACTIVE_CASE_ONLY"
)
$metadata | Set-Content -LiteralPath (Join-Path $caseDir "CASE_METADATA.txt") -Encoding UTF8

@(
 "CASE ARTIFACT CAPTURE POLICY",
 "Mode: ACTIVE_CASE_ONLY",
 "While this case remains ACTIVE, toolkit tools launched from the main menu or Menu Search automatically mirror newly created or updated files from the toolkit Logs tree into Artifacts\LogsMirror.",
 "Shared global ledgers are not copied raw because they may contain other cases. Case-filtered operation/mutation ledger snapshots and repair-journal evidence are written under Activity.",
 "When no case is ACTIVE, normal toolkit report/log behavior is unchanged and no case mirroring occurs.",
 "Case Closeout performs one final Logs sweep before closing the case."
) | Set-Content -LiteralPath (Join-Path $caseDir "CASE_CAPTURE_POLICY.txt") -Encoding UTF8

function Save-Text {
 param([string]$Name,$Data)
 $path=Join-Path $caseDir $Name
 ($Data|Out-String -Width 260).TrimEnd()|Set-Content -LiteralPath $path -Encoding UTF8
 return $path
}

Write-Host "COLLECT CASE MODE"
Write-Host ("Case folder: "+$caseDir)
Write-Host "Collecting a curated read-only evidence package. No repair actions are run."
Write-Host "Live case capture is now ACTIVE: subsequent toolkit Logs/reports are mirrored into this case until Case Closeout."

$os=Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
$cs=Get-CimInstance Win32_ComputerSystem -ErrorAction SilentlyContinue
$bios=Get-CimInstance Win32_BIOS -ErrorAction SilentlyContinue
Save-Text "01_MACHINE_SUMMARY.txt" ([pscustomobject]@{
 Computer=$env:COMPUTERNAME;Manufacturer=$cs.Manufacturer;Model=$cs.Model;Serial=$bios.SerialNumber;
 Windows=$os.Caption;Version=$os.Version;Build=$os.BuildNumber;Architecture=$os.OSArchitecture;
 LastBoot=$os.LastBootUpTime;User=$env:USERDOMAIN+"\"+$env:USERNAME
}|Format-List)|Out-Null

Save-Text "02_NETWORK.txt" (& ipconfig.exe /all 2>&1)|Out-Null
Save-Text "03_ROUTES.txt" (& route.exe print 2>&1)|Out-Null
Save-Text "04_ADAPTERS.txt" (Get-NetAdapter -ErrorAction SilentlyContinue|Format-Table Name,InterfaceDescription,Status,LinkSpeed,MacAddress -AutoSize)|Out-Null
Save-Text "05_DNS.txt" (Get-DnsClientServerAddress -ErrorAction SilentlyContinue|Format-Table InterfaceAlias,AddressFamily,ServerAddresses -AutoSize)|Out-Null

$mp=Get-MpComputerStatus -ErrorAction SilentlyContinue
Save-Text "06_DEFENDER_STATUS.txt" ($mp|Format-List *)|Out-Null
Save-Text "07_FIREWALL.txt" (Get-NetFirewallProfile -ErrorAction SilentlyContinue|Format-Table Name,Enabled,DefaultInboundAction,DefaultOutboundAction -AutoSize)|Out-Null
Save-Text "08_PROBLEM_DEVICES.txt" (Get-PnpDevice -PresentOnly -ErrorAction SilentlyContinue|Where-Object Status -ne "OK"|Format-Table Status,Class,FriendlyName,InstanceId -Wrap -AutoSize)|Out-Null
Save-Text "09_STORAGE.txt" (Get-Volume -ErrorAction SilentlyContinue|Format-Table DriveLetter,FileSystemLabel,FileSystem,HealthStatus,Size,SizeRemaining -AutoSize)|Out-Null
Save-Text "10_SERVICES.txt" (Get-Service|Sort-Object Status,Name|Format-Table Status,Name,DisplayName -AutoSize)|Out-Null

$apps=@()
foreach($p in @("HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*","HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*","HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*")){
 $apps+=Get-ItemProperty $p -ErrorAction SilentlyContinue|Where-Object DisplayName|Select-Object DisplayName,DisplayVersion,Publisher,InstallDate
}
$apps|Sort-Object DisplayName,DisplayVersion -Unique|Export-Csv -LiteralPath (Join-Path $caseDir "11_INSTALLED_APPS.csv") -NoTypeInformation -Encoding UTF8

Get-CimInstance Win32_UserProfile -ErrorAction SilentlyContinue|Where-Object{-not $_.Special}|Select-Object SID,LocalPath,Loaded,RoamingConfigured,LastUseTime|
 Export-Csv -LiteralPath (Join-Path $caseDir "12_USER_PROFILES.csv") -NoTypeInformation -Encoding UTF8

$start=(Get-Date).AddDays(-14)
$important=@()
foreach($log in @("System","Application")){
 try{
  $important+=Get-WinEvent -FilterHashtable @{LogName=$log;StartTime=$start;Level=1,2,3} -ErrorAction Stop|
   Select-Object TimeCreated,LogName,Id,ProviderName,LevelDisplayName,@{N="Message";E={($_.Message-replace"[\r\n]+"," "-replace"\s{2,}"," ").Trim()}}
 }catch{}
}
$important|Sort-Object TimeCreated -Descending|Select-Object -First 500|
 Export-Csv -LiteralPath (Join-Path $caseDir "13_RECENT_WARNINGS_ERRORS.csv") -NoTypeInformation -Encoding UTF8

try{
 Get-WinEvent -FilterHashtable @{LogName="System";StartTime=$start;Id=12,13,41,1001,1074,1076,6005,6006,6008} -ErrorAction Stop|
  Select-Object TimeCreated,Id,ProviderName,@{N="Message";E={($_.Message-replace"[\r\n]+"," "-replace"\s{2,}"," ").Trim()}}|
  Export-Csv -LiteralPath (Join-Path $caseDir "14_REBOOT_SHUTDOWN.csv") -NoTypeInformation -Encoding UTF8
}catch{}

$certs=@()
foreach($store in @("Cert:\CurrentUser\My","Cert:\LocalMachine\My")){
 if(Test-Path -LiteralPath $store){
  $certs+=Get-ChildItem -LiteralPath $store -ErrorAction SilentlyContinue|Select-Object @{N="Store";E={$store}},Subject,Issuer,Thumbprint,NotBefore,NotAfter,HasPrivateKey
 }
}
$certs|Export-Csv -LiteralPath (Join-Path $caseDir "15_CERTIFICATES.csv") -NoTypeInformation -Encoding UTF8

$index=Join-Path $caseDir "CASE_INDEX.html"
$files=Get-ChildItem -LiteralPath $caseDir -File|Sort-Object Name
$html=New-Object System.Text.StringBuilder
[void]$html.AppendLine('<!doctype html><html><head><meta charset="utf-8"><title>' + $caseName + '</title><style>body{font-family:Segoe UI,Arial,sans-serif;margin:24px}li{margin:7px 0}</style></head><body>')
[void]$html.AppendLine("<h1>"+[System.Net.WebUtility]::HtmlEncode($caseName)+"</h1>")
[void]$html.AppendLine("<p>Generated: "+[System.Net.WebUtility]::HtmlEncode([string](Get-Date))+"</p><ul>")
foreach($f in $files){
 $href=[uri]::EscapeDataString($f.Name)
 [void]$html.AppendLine('<li><a href="' + $href + '">' + [System.Net.WebUtility]::HtmlEncode($f.Name) + '</a></li>')
}
[void]$html.AppendLine("</ul><p>Read-only baseline collection. Live artifact capture remains active until Case Closeout; subsequent toolkit-generated Logs/reports are mirrored into the case.</p></body></html>")
$html.ToString()|Set-Content -LiteralPath $index -Encoding UTF8

$zip=Join-Path $logs ($caseName+".zip")
try{
 Compress-Archive -Path (Join-Path $caseDir "*") -DestinationPath $zip -Force
}catch{}

Write-Host ""
Write-Host "Collect Case complete."
Write-Host ("Case folder: "+$caseDir)
Write-Host ("Index: "+$index)
if(Test-Path -LiteralPath $zip){Write-Host("ZIP: "+$zip)}
try{Start-Process -FilePath $index}catch{}
exit 0

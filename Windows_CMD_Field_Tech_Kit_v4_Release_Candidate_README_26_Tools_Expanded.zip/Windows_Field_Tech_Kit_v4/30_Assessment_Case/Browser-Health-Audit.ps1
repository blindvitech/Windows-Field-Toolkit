$ErrorActionPreference="SilentlyContinue"
$ProgressPreference="SilentlyContinue"
$toolkitRoot=Split-Path $PSScriptRoot -Parent
$foundation=Join-Path $toolkitRoot "00_Common\Foundation-Common.ps1"
if(Test-Path -LiteralPath $foundation -PathType Leaf){. $foundation}
$logs=Join-Path $toolkitRoot "Logs"
if(-not(Test-Path -LiteralPath $logs)){New-Item -ItemType Directory -Path $logs -Force|Out-Null}
$writer=Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"
$stamp=Get-Date -Format "yyyyMMdd_HHmmss"
$basePath=Join-Path $logs ($env:COMPUTERNAME+"_Browser_Health_Audit_"+$stamp)

$browserPaths=@(
 [pscustomobject]@{Name="Microsoft Edge";Path="${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe";Profile="$env:LOCALAPPDATA\Microsoft\Edge\User Data"},
 [pscustomobject]@{Name="Google Chrome";Path="$env:ProgramFiles\Google\Chrome\Application\chrome.exe";Profile="$env:LOCALAPPDATA\Google\Chrome\User Data"},
 [pscustomobject]@{Name="Google Chrome x86";Path="${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe";Profile="$env:LOCALAPPDATA\Google\Chrome\User Data"},
 [pscustomobject]@{Name="Mozilla Firefox";Path="$env:ProgramFiles\Mozilla Firefox\firefox.exe";Profile="$env:APPDATA\Mozilla\Firefox\Profiles"},
 [pscustomobject]@{Name="Mozilla Firefox x86";Path="${env:ProgramFiles(x86)}\Mozilla Firefox\firefox.exe";Profile="$env:APPDATA\Mozilla\Firefox\Profiles"},
 [pscustomobject]@{Name="Brave";Path="$env:ProgramFiles\BraveSoftware\Brave-Browser\Application\brave.exe";Profile="$env:LOCALAPPDATA\BraveSoftware\Brave-Browser\User Data"}
)
$browsers=@()
foreach($b in $browserPaths){
 if(Test-Path -LiteralPath $b.Path){
  $f=Get-Item -LiteralPath $b.Path -ErrorAction SilentlyContinue
  $sig=Get-AuthenticodeSignature -FilePath $b.Path -ErrorAction SilentlyContinue
  $browsers+=[pscustomobject]@{Name=$b.Name;Version=$f.VersionInfo.ProductVersion;Path=$b.Path;ProfilePath=$b.Profile;ProfileExists=Test-Path -LiteralPath $b.Profile;Signature=$sig.Status}
 }
}
$browsers=@($browsers|Sort-Object Path -Unique)

$userChoice=Get-ItemProperty "HKCU:\Software\Microsoft\Windows\Shell\Associations\UrlAssociations\http\UserChoice" -ErrorAction SilentlyContinue
$userChoiceHttps=Get-ItemProperty "HKCU:\Software\Microsoft\Windows\Shell\Associations\UrlAssociations\https\UserChoice" -ErrorAction SilentlyContinue
$proxy=Get-ItemProperty "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings" -ErrorAction SilentlyContinue
$winhttpNative=Invoke-ToolkitNativeCommand -FilePath "netsh.exe" -Arguments @("winhttp","show","proxy") -Label "Browser Health WinHTTP Proxy" -Action "Browser Health Audit" -Quiet
$winhttp=(($winhttpNative.Output -join [Environment]::NewLine)|Out-String -Width 260).TrimEnd()

$policyRows=@()
foreach($path in @(
 "HKLM:\SOFTWARE\Policies\Microsoft\Edge","HKCU:\SOFTWARE\Policies\Microsoft\Edge",
 "HKLM:\SOFTWARE\Policies\Google\Chrome","HKCU:\SOFTWARE\Policies\Google\Chrome",
 "HKLM:\SOFTWARE\Policies\Mozilla\Firefox","HKCU:\SOFTWARE\Policies\Mozilla\Firefox"
)){
 if(Test-Path -LiteralPath $path){
  $vals=Get-ItemProperty -LiteralPath $path -ErrorAction SilentlyContinue
  foreach($prop in $vals.PSObject.Properties|Where-Object{$_.Name -notmatch '^PS'}){
   $policyRows+=[pscustomobject]@{Path=$path;Name=$prop.Name;Value=[string]$prop.Value}
  }
 }
}

$extensions=@()
foreach($root in @(
 "$env:LOCALAPPDATA\Microsoft\Edge\User Data",
 "$env:LOCALAPPDATA\Google\Chrome\User Data",
 "$env:LOCALAPPDATA\BraveSoftware\Brave-Browser\User Data"
)){
 if(Test-Path -LiteralPath $root){
  foreach($profile in Get-ChildItem -LiteralPath $root -Directory -ErrorAction SilentlyContinue|Where-Object{$_.Name -eq "Default" -or $_.Name -match '^Profile \d+$'}){
   $extRoot=Join-Path $profile.FullName "Extensions"
   if(Test-Path -LiteralPath $extRoot){
    foreach($ext in Get-ChildItem -LiteralPath $extRoot -Directory -ErrorAction SilentlyContinue){
     $latest=Get-ChildItem -LiteralPath $ext.FullName -Directory -ErrorAction SilentlyContinue|Sort-Object Name -Descending|Select-Object -First 1
     $manifest=$null;$display=""
     if($latest){$manifest=Join-Path $latest.FullName "manifest.json"}
     if($manifest -and (Test-Path -LiteralPath $manifest)){
      try{$j=Get-Content -LiteralPath $manifest -Raw -ErrorAction Stop|ConvertFrom-Json;$display=$j.name}catch{}
     }
     $extensions+=[pscustomobject]@{BrowserRoot=$root;Profile=$profile.Name;ExtensionId=$ext.Name;Version=$(if($latest){$latest.Name}else{""});ManifestName=$display}
    }
   }
  }
 }
}

$crashes=@()
try{
 $crashes=Get-WinEvent -FilterHashtable @{LogName="Application";StartTime=(Get-Date).AddDays(-14);Id=1000,1001,1002} -ErrorAction Stop |
  Where-Object{$_.Message -match '(?i)(msedge\.exe|chrome\.exe|firefox\.exe|brave\.exe)'} |
  Sort-Object TimeCreated -Descending|Select-Object -First 100 TimeCreated,Id,ProviderName,@{N="Message";E={($_.Message-replace"[\r\n]+"," "-replace"\s{2,}"," ").Trim()}}
}catch{}

$lines=New-Object System.Collections.Generic.List[string]
$lines.Add("BROWSER HEALTH AUDIT");$lines.Add("Computer: "+$env:COMPUTERNAME);$lines.Add("Generated: "+(Get-Date))
$lines.Add("");$lines.Add("Read-only inventory of installed browser executables, profiles, extensions, policy, proxy/default-browser state, and recent browser crash events.")
$lines.Add("HTTP default ProgId: "+$userChoice.ProgId);$lines.Add("HTTPS default ProgId: "+$userChoiceHttps.ProgId)
$lines.Add("User proxy enabled: "+$proxy.ProxyEnable+"; ProxyServer: "+$proxy.ProxyServer+"; AutoConfigURL: "+$proxy.AutoConfigURL)
foreach($pair in @(@("BROWSER EXECUTABLES",$browsers),@("CHROMIUM EXTENSION INVENTORY",$extensions),@("BROWSER POLICY VALUES",$policyRows),@("RECENT BROWSER CRASH/HANG EVENTS",$crashes))){
 $lines.Add("");$lines.Add(("="*78));$lines.Add($pair[0]);$lines.Add(("="*78));$x=($pair[1]|Out-String -Width 260).TrimEnd();if($x){$lines.Add($x)}else{$lines.Add("(No data returned)")}
}
$lines.Add("");$lines.Add(("="*78));$lines.Add("WINHTTP PROXY");$lines.Add(("="*78));$lines.Add($winhttp)
$body=$lines -join [Environment]::NewLine
& $writer -BasePath $basePath -Title "Browser Health Audit" -Body $body
$html=$basePath+".html";Write-Host("Report: "+$html);try{Start-Process -FilePath $html}catch{}
exit 0

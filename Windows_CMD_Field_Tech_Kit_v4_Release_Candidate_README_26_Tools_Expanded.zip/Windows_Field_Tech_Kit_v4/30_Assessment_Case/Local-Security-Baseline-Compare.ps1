$ErrorActionPreference="SilentlyContinue"
$ProgressPreference="SilentlyContinue"
$toolkitRoot=Split-Path $PSScriptRoot -Parent
$logs=Join-Path $toolkitRoot "Logs"
if(-not(Test-Path -LiteralPath $logs)){New-Item -ItemType Directory -Path $logs -Force|Out-Null}
$writer=Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"
$stamp=Get-Date -Format "yyyyMMdd_HHmmss"
$basePath=Join-Path $logs ($env:COMPUTERNAME+"_Local_Security_Baseline_Compare_"+$stamp)

$rows=New-Object System.Collections.Generic.List[object]
function Add-Check {
 param([string]$Check,[string]$Status,[string]$Current,[string]$Expected,[string]$Reason)
 $rows.Add([pscustomobject]@{Check=$Check;Status=$Status;Current=$Current;Expected=$Expected;Reason=$Reason})
}

$uac=Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -ErrorAction SilentlyContinue
if($null -ne $uac.EnableLUA){
 Add-Check "UAC enabled" $(if([int]$uac.EnableLUA -eq 1){"PASS"}else{"REVIEW"}) ([string]$uac.EnableLUA) "1" "UAC should normally remain enabled."
}else{Add-Check "UAC enabled" "UNKNOWN" "Not collected" "1" "Registry value unavailable."}

$firewall=Get-NetFirewallProfile -ErrorAction SilentlyContinue
if($firewall){
 foreach($f in $firewall){
  Add-Check ("Firewall profile "+$f.Name) $(if($f.Enabled){"PASS"}else{"REVIEW"}) ([string]$f.Enabled) "True" "Windows Firewall is normally expected to remain enabled."
 }
}else{Add-Check "Windows Firewall profiles" "UNKNOWN" "Not collected" "Enabled" "Firewall cmdlet unavailable or access failed."}

$mp=Get-MpComputerStatus -ErrorAction SilentlyContinue
if($mp){
 Add-Check "Defender antivirus enabled" $(if($mp.AntivirusEnabled){"PASS"}else{"REVIEW"}) ([string]$mp.AntivirusEnabled) "True" "Built-in Defender should normally be active unless another managed antivirus replaces it."
 Add-Check "Defender real-time protection" $(if($mp.RealTimeProtectionEnabled){"PASS"}else{"REVIEW"}) ([string]$mp.RealTimeProtectionEnabled) "True" "Real-time protection should normally be enabled."
}else{
 Add-Check "Defender antivirus enabled" "INFO" "Defender status unavailable" "Context dependent" "Another antivirus product may be active."
}

$guest=Get-LocalUser -Name "Guest" -ErrorAction SilentlyContinue
if($guest){
 Add-Check "Built-in Guest account" $(if(-not $guest.Enabled){"PASS"}else{"REVIEW"}) ([string]$guest.Enabled) "False" "Built-in Guest should normally be disabled."
}

$smb1=Get-WindowsOptionalFeature -Online -FeatureName SMB1Protocol -ErrorAction SilentlyContinue
if($smb1){
 Add-Check "SMB1 optional feature" $(if($smb1.State -eq "Disabled"){"PASS"}else{"REVIEW"}) ([string]$smb1.State) "Disabled" "SMB1 is obsolete and should generally remain disabled unless a documented legacy dependency exists."
}

$rdp=Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server" -ErrorAction SilentlyContinue
if($null -ne $rdp.fDenyTSConnections){
 Add-Check "Remote Desktop inbound access" $(if([int]$rdp.fDenyTSConnections -eq 1){"PASS"}else{"INFO"}) $(if([int]$rdp.fDenyTSConnections -eq 1){"Disabled"}else{"Enabled"}) "Disabled unless intentionally required" "Enabled RDP is not automatically unsafe, but should be intentional and protected."
}

$wu=Get-Service wuauserv -ErrorAction SilentlyContinue
if($wu){
 Add-Check "Windows Update service startup" $(if($wu.StartType -eq "Disabled"){"REVIEW"}else{"PASS"}) ([string]$wu.StartType) "Not Disabled" "A disabled Windows Update service can prevent normal patching."
}

$secureBoot="Unavailable"
try{$secureBoot=[string](Confirm-SecureBootUEFI -ErrorAction Stop)}catch{}
if($secureBoot -ne "Unavailable"){
 Add-Check "Secure Boot" $(if($secureBoot -eq "True"){"PASS"}else{"INFO"}) $secureBoot "True where supported" "Secure Boot availability depends on firmware/platform and boot mode."
}else{Add-Check "Secure Boot" "INFO" "Unavailable or access denied" "True where supported" "May require elevation or unsupported firmware."}

$tpm=Get-Tpm -ErrorAction SilentlyContinue
if($tpm){
 Add-Check "TPM present/ready" $(if($tpm.TpmPresent -and $tpm.TpmReady){"PASS"}else{"INFO"}) ("Present="+$tpm.TpmPresent+"; Ready="+$tpm.TpmReady) "Present and Ready where supported" "TPM state depends on hardware and deployment requirements."
}

$bit=Get-BitLockerVolume -MountPoint $env:SystemDrive -ErrorAction SilentlyContinue
if($bit){
 Add-Check "System-drive BitLocker" $(if($bit.ProtectionStatus -eq "On"){"PASS"}else{"INFO"}) ("ProtectionStatus="+$bit.ProtectionStatus+"; VolumeStatus="+$bit.VolumeStatus) "On where organizational policy requires" "Encryption requirements vary by organization and device role."
}else{Add-Check "System-drive BitLocker" "INFO" "Not collected / unavailable" "Policy dependent" "BitLocker status may require elevation or may not apply."}

$admins=@()
try{$admins=@(Get-LocalGroupMember -Group "Administrators" -ErrorAction Stop)}catch{}
if($admins.Count){
 Add-Check "Local Administrators membership" "INFO" ($admins.Name -join ", ") "Review for least privilege" "This is inventory-only; legitimate admin membership varies by environment."
}

$lsa=Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -ErrorAction SilentlyContinue
if($null -ne $lsa.RunAsPPL){
 Add-Check "LSA protection RunAsPPL" $(if([int]$lsa.RunAsPPL -ge 1){"PASS"}else{"INFO"}) ([string]$lsa.RunAsPPL) "1 or 2 on supported managed systems" "Support varies by Windows version and deployment."
}

$counts=$rows|Group-Object Status|Sort-Object Name
$lines=New-Object System.Collections.Generic.List[string]
$lines.Add("LOCAL SECURITY BASELINE COMPARE")
$lines.Add("Computer: "+$env:COMPUTERNAME);$lines.Add("Generated: "+(Get-Date))
$lines.Add("")
$lines.Add("Read-only comparison against a conservative technician baseline.")
$lines.Add("This is NOT a compliance certification and does not replace organization-specific policy.")
$lines.Add("PASS = aligned with the conservative default; REVIEW = worth technician review; INFO = context dependent; UNKNOWN = not collected.")
$lines.Add("")
$lines.Add("Summary: "+(($counts|ForEach-Object{$_.Name+"="+$_.Count}) -join "; "))
$lines.Add("")
$lines.Add(($rows|Format-Table Status,Check,Current,Expected -Wrap -AutoSize|Out-String -Width 260).TrimEnd())
$lines.Add("")
$lines.Add("DETAILS")
$lines.Add(($rows|Format-List Check,Status,Current,Expected,Reason|Out-String -Width 260).TrimEnd())
$body=$lines -join [Environment]::NewLine
& $writer -BasePath $basePath -Title "Local Security Baseline Compare" -Body $body
$html=$basePath+".html";Write-Host("Report: "+$html)
try{Start-Process -FilePath $html}catch{}
exit 0

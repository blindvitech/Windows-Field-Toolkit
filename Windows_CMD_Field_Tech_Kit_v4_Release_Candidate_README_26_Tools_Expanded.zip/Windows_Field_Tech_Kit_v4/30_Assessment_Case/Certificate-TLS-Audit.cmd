@echo off
setlocal EnableExtensions
title Certificate / TLS Audit

echo Certificate / TLS Audit
echo.
echo Read-only assessment tool. Windows system state is not changed.
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Certificate-TLS-Audit.ps1"
set "RC=%errorlevel%"

echo.
if "%SRMODE%"=="1" (
    if "%RC%"=="0" (
        echo Certificate / TLS Audit completed.
    ) else (
        echo Certificate / TLS Audit returned error code %RC%.
    )
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

exit /b %RC%

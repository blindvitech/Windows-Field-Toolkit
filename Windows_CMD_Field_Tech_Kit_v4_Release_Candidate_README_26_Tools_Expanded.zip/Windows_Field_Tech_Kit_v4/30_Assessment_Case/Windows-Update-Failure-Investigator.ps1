$screenReaderCommon = Join-Path (Split-Path $PSScriptRoot -Parent) "00_Common\ScreenReader-Common.ps1"
if (Test-Path -LiteralPath $screenReaderCommon -PathType Leaf) {
    . $screenReaderCommon
}

$ErrorActionPreference="SilentlyContinue"
$ProgressPreference="SilentlyContinue"
$toolkitRoot=Split-Path $PSScriptRoot -Parent
$foundation=Join-Path $toolkitRoot "00_Common\Foundation-Common.ps1"
if(Test-Path -LiteralPath $foundation -PathType Leaf){. $foundation}
$logs=Join-Path $toolkitRoot "Logs"
if(-not(Test-Path -LiteralPath $logs)){New-Item -ItemType Directory -Path $logs -Force|Out-Null}
$writer=Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"

Write-Host "WINDOWS UPDATE FAILURE INVESTIGATOR"
Write-Host "Lookback: 1=7 days, 2=14 days, 3=30 days, 4=custom"
$c=Read-ToolkitPrompt "Select 1 through 4";$days=14
switch($c){"1"{$days=7};"2"{$days=14};"3"{$days=30};"4"{$d=Read-ToolkitPrompt "Days, 1 through 90";if($d -match '^\d+$' -and [int]$d -ge 1 -and [int]$d -le 90){$days=[int]$d}}}
$start=(Get-Date).AddDays(-$days)
$stamp=Get-Date -Format "yyyyMMdd_HHmmss"
$basePath=Join-Path $logs ($env:COMPUTERNAME+"_Windows_Update_Failure_Investigator_"+$stamp)

$services=Get-Service wuauserv,bits,cryptsvc,msiserver -ErrorAction SilentlyContinue|Select-Object Name,Status,StartType
$pending=[pscustomobject]@{
 CBS=Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending"
 WindowsUpdate=Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired"
 PendingFileRename=$null -ne (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager" -Name PendingFileRenameOperations -ErrorAction SilentlyContinue).PendingFileRenameOperations
}

$wuEvents=@()
try{
 $wuEvents=Get-WinEvent -FilterHashtable @{LogName="Microsoft-Windows-WindowsUpdateClient/Operational";StartTime=$start} -ErrorAction Stop|
  Where-Object{$_.Id -in 19,20,21,25,31,34,41,43,44 -or $_.Level -in 1,2,3}|
  Sort-Object TimeCreated -Descending|Select-Object -First 200 TimeCreated,Id,LevelDisplayName,@{N="Message";E={($_.Message-replace"[\r\n]+"," "-replace"\s{2,}"," ").Trim()}}
}catch{}

$setupEvents=@()
try{
 $setupEvents=Get-WinEvent -FilterHashtable @{LogName="Setup";StartTime=$start;Level=1,2,3} -ErrorAction Stop|
  Sort-Object TimeCreated -Descending|Select-Object -First 150 TimeCreated,Id,ProviderName,LevelDisplayName,@{N="Message";E={($_.Message-replace"[\r\n]+"," "-replace"\s{2,}"," ").Trim()}}
}catch{}

$history=@()
try{
 $session=New-Object -ComObject Microsoft.Update.Session
 $searcher=$session.CreateUpdateSearcher()
 $count=$searcher.GetTotalHistoryCount()
 if($count -gt 0){
  $history=$searcher.QueryHistory(0,[Math]::Min($count,200))|
   Where-Object{$_.Date -ge $start}|
   Select-Object Date,Title,Operation,ResultCode,HResult
 }
}catch{}

$hotfixes=Get-CimInstance Win32_QuickFixEngineering -ErrorAction SilentlyContinue|
 Sort-Object InstalledOn -Descending|Select-Object -First 100 HotFixID,Description,InstalledOn

$dismNative=Invoke-ToolkitNativeCommand -FilePath "dism.exe" -Arguments @("/Online","/Cleanup-Image","/CheckHealth") -Label "Windows Update Failure DISM CheckHealth" -Action "Windows Update Failure Investigator" -Quiet
$dism=(($dismNative.Output -join [Environment]::NewLine)|Out-String -Width 260).TrimEnd()

$lines=New-Object System.Collections.Generic.List[string]
$lines.Add("WINDOWS UPDATE FAILURE INVESTIGATOR");$lines.Add("Computer: "+$env:COMPUTERNAME);$lines.Add("Generated: "+(Get-Date));$lines.Add("Lookback: "+$days+" days")
$lines.Add("");$lines.Add("Read-only correlation of Windows Update history/events, servicing events, pending-reboot state, service state, installed hotfixes, and DISM CheckHealth.")
foreach($pair in @(@("UPDATE SERVICES",$services),@("PENDING REBOOT STATE",$pending),@("WINDOWS UPDATE OPERATIONAL EVENTS",$wuEvents),@("SETUP / SERVICING EVENTS",$setupEvents),@("UPDATE HISTORY",$history),@("INSTALLED HOTFIXES",$hotfixes))){
 $lines.Add("");$lines.Add(("="*78));$lines.Add($pair[0]);$lines.Add(("="*78));$x=($pair[1]|Out-String -Width 260).TrimEnd();if($x){$lines.Add($x)}else{$lines.Add("(No data returned)")}
}
$lines.Add("");$lines.Add(("="*78));$lines.Add("DISM CHECKHEALTH");$lines.Add(("="*78));$lines.Add($dism)
$body=$lines -join [Environment]::NewLine
& $writer -BasePath $basePath -Title "Windows Update Failure Investigator" -Body $body
$html=$basePath+".html";Write-Host("Report: "+$html);try{Start-Process -FilePath $html}catch{}
exit 0

@echo off
setlocal EnableExtensions
title DHCP Lease / State Deep Dive

echo DHCP Lease / State Deep Dive
echo.
echo Read-only network diagnostic / assessment tool. Windows system state is not changed.
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0DHCP-Lease-State-Deep-Dive.ps1"
set "RC=%errorlevel%"

echo.
if "%SRMODE%"=="1" (
    if "%RC%"=="0" (
        echo DHCP Lease / State Deep Dive completed.
    ) else (
        echo DHCP Lease / State Deep Dive returned error code %RC%.
    )
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

exit /b %RC%

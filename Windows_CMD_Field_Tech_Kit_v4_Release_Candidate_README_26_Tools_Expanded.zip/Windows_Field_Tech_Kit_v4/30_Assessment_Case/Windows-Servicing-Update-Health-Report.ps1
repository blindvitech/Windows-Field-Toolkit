$screenReaderCommon = Join-Path (Split-Path $PSScriptRoot -Parent) "00_Common\ScreenReader-Common.ps1"
if (Test-Path -LiteralPath $screenReaderCommon -PathType Leaf) { . $screenReaderCommon }

$ErrorActionPreference = "SilentlyContinue"
$ProgressPreference = "SilentlyContinue"

$toolkitRoot = Split-Path $PSScriptRoot -Parent
$foundation = Join-Path $toolkitRoot "00_Common\Foundation-Common.ps1"
$diagnostic = Join-Path $toolkitRoot "00_Common\Diagnostic-Evidence.ps1"
$assessmentConfidence = Join-Path $toolkitRoot "00_Common\Assessment-Confidence.ps1"
$sectionedHtml = Join-Path $toolkitRoot "00_Common\Sectioned-Html-Report.ps1"
$writer = Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"

foreach($helper in @($foundation,$diagnostic,$assessmentConfidence,$sectionedHtml)){
    if(Test-Path -LiteralPath $helper -PathType Leaf){ . $helper }
}

$logs = $(if(Get-Command Get-ToolkitLogRoot -ErrorAction SilentlyContinue){Get-ToolkitLogRoot}else{Join-Path $toolkitRoot "Logs"})
if(-not(Test-Path -LiteralPath $logs)){ New-Item -ItemType Directory -Path $logs -Force | Out-Null }

$toolId = $(if($env:FIELDTECH_TOOL_ID){$env:FIELDTECH_TOOL_ID}else{"ADV-075"})
$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$basePath = Join-Path $logs ($env:COMPUTERNAME + "_Windows_Servicing_Update_Health_" + $stamp)

$isAdmin = $false
try {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($id)
    $isAdmin = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}
catch {}

Write-Host "WINDOWS SERVICING / UPDATE HEALTH REPORT"
Write-Host ""
Write-Host "Read-only umbrella assessment."
Write-Host "No cleanup, ResetBase, RestoreHealth, update reset, update install, or servicing mutation is performed."
Write-Host ("Administrator: " + $isAdmin)
Write-Host ""
Write-ToolkitStatus "Collecting Windows servicing and update evidence."

$capabilities = New-Object System.Collections.Generic.List[object]
$assessmentRows = New-Object System.Collections.Generic.List[object]
$recommendations = New-Object System.Collections.Generic.List[string]

function Add-Assessment {
    param(
        [string]$Area,
        [string]$Status,
        [string]$Finding,
        [string]$Evidence = "",
        [ValidateSet("CONFIRMED","STRONG_EVIDENCE","POSSIBLE","INDETERMINATE","NOT_TESTED")]
        [string]$Confidence = "INDETERMINATE"
    )

    if(Get-Command New-ToolkitAssessment -ErrorAction SilentlyContinue){
        $assessmentRows.Add((New-ToolkitAssessment -Area $Area -Status $Status `
            -Finding $Finding -Evidence $Evidence -Confidence $Confidence))
    }
    else{
        $assessmentRows.Add([pscustomobject]@{
            Area = $Area
            Status = $Status
            Confidence = $Confidence
            Finding = $Finding
            Evidence = $Evidence
            RecommendedAction = ""
        })
    }
}

function Add-Recommendation {
    param([string]$Text)
    if(-not [string]::IsNullOrWhiteSpace($Text) -and -not $recommendations.Contains($Text)){
        $recommendations.Add($Text)
    }
}

function Invoke-ReadOnlyNative {
    param(
        [string]$FilePath,
        [string[]]$Arguments,
        [string]$Label
    )
    if(Get-Command Invoke-ToolkitNativeCommand -ErrorAction SilentlyContinue){
        return Invoke-ToolkitNativeCommand -FilePath $FilePath -Arguments $Arguments `
            -Label $Label -Action "Windows Servicing / Update Health Report" -Quiet
    }

    $output = & $FilePath @Arguments 2>&1
    return [pscustomobject]@{
        ExitCode = $LASTEXITCODE
        Output = @($output)
    }
}

# ---------------------------------------------------------------------------
# System / servicing identity
# ---------------------------------------------------------------------------
$os = Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
$cv = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion" -ErrorAction SilentlyContinue
$identity = [pscustomobject]@{
    Computer = $env:COMPUTERNAME
    Windows = [string]$os.Caption
    Version = [string]$os.Version
    Build = [string]$os.BuildNumber
    DisplayVersion = [string]$cv.DisplayVersion
    UBR = [string]$cv.UBR
    InstallDate = $os.InstallDate
    LastBootUpTime = $os.LastBootUpTime
    Administrator = $isAdmin
}

# ---------------------------------------------------------------------------
# Reboot / servicing state
# ---------------------------------------------------------------------------
$pending = [pscustomobject]@{
    ComponentBasedServicing = Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending"
    WindowsUpdate = Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired"
    PendingFileRenameOperations = $null -ne (
        Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager" `
            -Name PendingFileRenameOperations -ErrorAction SilentlyContinue
    ).PendingFileRenameOperations
    UpdateExeVolatile = [string](
        Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Updates" `
            -Name UpdateExeVolatile -ErrorAction SilentlyContinue
    ).UpdateExeVolatile
}

$pendingAny = (
    $pending.ComponentBasedServicing -or
    $pending.WindowsUpdate -or
    $pending.PendingFileRenameOperations -or
    ($pending.UpdateExeVolatile -and $pending.UpdateExeVolatile -ne "0")
)

if($pendingAny){
    Add-Assessment -Area "Pending reboot" -Status "ATTENTION" `
        -Finding "One or more standard pending-reboot indicators are set." `
        -Evidence (($pending | Out-String -Width 220).Trim()) -Confidence "CONFIRMED"
    Add-Recommendation "Schedule a normal reboot before escalating servicing failures, then rerun this report."
}
else{
    Add-Assessment -Area "Pending reboot" -Status "CLEAR" `
        -Finding "No standard pending-reboot indicators were detected." -Confidence "CONFIRMED"
}

# ---------------------------------------------------------------------------
# Update / servicing service state
# ---------------------------------------------------------------------------
$services = @(
    Get-Service wuauserv,bits,cryptsvc,msiserver,TrustedInstaller -ErrorAction SilentlyContinue |
        Select-Object Name,Status,StartType
)

# Service stopped state is intentionally not treated as a failure by itself.
Add-Assessment -Area "Update services" -Status "CONTEXT" `
    -Finding "Core update/servicing service states were collected. Stopped trigger-start services are not automatically classified as failures." -Confidence "CONFIRMED"

# ---------------------------------------------------------------------------
# Windows Update history
# ---------------------------------------------------------------------------
$history = @()
$historyError = ""
try {
    $session = New-Object -ComObject Microsoft.Update.Session
    $searcher = $session.CreateUpdateSearcher()
    $count = $searcher.GetTotalHistoryCount()
    if($count -gt 0){
        $history = @(
            $searcher.QueryHistory(0,[Math]::Min($count,300)) |
                Select-Object Date,Title,Operation,ResultCode,HResult
        )
    }
    if(Get-Command New-ToolkitCapabilityStatus -ErrorAction SilentlyContinue){
        $capabilities.Add((New-ToolkitCapabilityStatus -Capability "Windows Update COM history" `
            -Available $true -Status "Available" -Detail ("Entries=" + $history.Count) -SourceTool $toolId))
    }
}
catch {
    $historyError = $_.Exception.Message
    if(Get-Command New-ToolkitCapabilityStatus -ErrorAction SilentlyContinue){
        $capabilities.Add((New-ToolkitCapabilityStatus -Capability "Windows Update COM history" `
            -Available $false -Status "Query/API Failed" -Detail $historyError -SourceTool $toolId))
    }
}

$recentHistory = @($history | Where-Object { $_.Date -ge (Get-Date).AddDays(-30) })
$failedHistory = @(
    $recentHistory |
        Where-Object { [int]$_.ResultCode -in 3,4,5 } |
        Sort-Object Date -Descending
)

if($failedHistory.Count -gt 0){
    Add-Assessment -Area "Update history" -Status "ATTENTION" `
        -Finding ("Windows Update history shows " + $failedHistory.Count + " failed, aborted, or succeeded-with-errors operation(s) in the last 30 days.") `
        -Evidence ("Most recent: " + $failedHistory[0].Title) -Confidence "CONFIRMED"
    Add-Recommendation "Correlate the most recent failed update title and HResult with the Windows Update and Setup event sections before resetting update components."
}
elseif($historyError){
    Add-Assessment -Area "Update history" -Status "NOT_TESTED" `
        -Finding "Windows Update history could not be queried." -Evidence $historyError -Confidence "NOT_TESTED"
}
else{
    Add-Assessment -Area "Update history" -Status "CLEAR" `
        -Finding "No failed/aborted/succeeded-with-errors update-history entries were found in the last 30 days." -Confidence "STRONG_EVIDENCE"
}

# ---------------------------------------------------------------------------
# Event correlation
# ---------------------------------------------------------------------------
$start = (Get-Date).AddDays(-30)
$wuEvents = @()
$setupEvents = @()

try {
    $wuEvents = @(
        Get-WinEvent -FilterHashtable @{
            LogName = "Microsoft-Windows-WindowsUpdateClient/Operational"
            StartTime = $start
        } -ErrorAction Stop |
        Where-Object {
            $_.Level -in 1,2,3 -or
            $_.Id -in 20,21,25,31,34,41,43,44
        } |
        Sort-Object TimeCreated -Descending |
        Select-Object -First 250 TimeCreated,Id,LevelDisplayName,ProviderName,
            @{N="Message";E={($_.Message -replace "[\r\n]+"," " -replace "\s{2,}"," ").Trim()}}
    )
}
catch {}

try {
    $setupEvents = @(
        Get-WinEvent -FilterHashtable @{
            LogName = "Setup"
            StartTime = $start
        } -ErrorAction Stop |
        Where-Object { $_.Level -in 1,2,3 } |
        Sort-Object TimeCreated -Descending |
        Select-Object -First 200 TimeCreated,Id,LevelDisplayName,ProviderName,
            @{N="Message";E={($_.Message -replace "[\r\n]+"," " -replace "\s{2,}"," ").Trim()}}
    )
}
catch {}

if($wuEvents.Count -gt 0){
    Add-Assessment -Area "Windows Update events" -Status "ATTENTION" `
        -Finding ("Windows Update Operational contains " + $wuEvents.Count + " warning/error/failure-oriented event(s) in the last 30 days.") `
        -Evidence ("Most recent: event " + $wuEvents[0].Id + " at " + $wuEvents[0].TimeCreated) -Confidence "CONFIRMED"
}
else{
    Add-Assessment -Area "Windows Update events" -Status "CLEAR" `
        -Finding "No matching warning/error/failure-oriented Windows Update events were returned for the last 30 days." -Confidence "STRONG_EVIDENCE"
}

if($setupEvents.Count -gt 0){
    Add-Assessment -Area "Setup / servicing events" -Status "ATTENTION" `
        -Finding ("Setup log contains " + $setupEvents.Count + " warning/error servicing event(s) in the last 30 days.") `
        -Evidence ("Most recent: " + $setupEvents[0].ProviderName + " event " + $setupEvents[0].Id) -Confidence "CONFIRMED"
}

# ---------------------------------------------------------------------------
# DISM health / component store
# ---------------------------------------------------------------------------
$dismCheck = $null
$dismAnalyze = $null

Write-ToolkitStatus "Running read-only DISM CheckHealth."
$dismCheck = Invoke-ReadOnlyNative -FilePath "dism.exe" `
    -Arguments @("/Online","/Cleanup-Image","/CheckHealth") `
    -Label "Servicing Report DISM CheckHealth"

if($isAdmin){
    Write-ToolkitStatus "Running read-only DISM AnalyzeComponentStore. This can take several minutes."
    $dismAnalyze = Invoke-ReadOnlyNative -FilePath "dism.exe" `
        -Arguments @("/Online","/Cleanup-Image","/AnalyzeComponentStore") `
        -Label "Servicing Report AnalyzeComponentStore"
}

$dismCheckText = $(if($dismCheck){$dismCheck.Output -join [Environment]::NewLine}else{""})
$dismAnalyzeText = $(if($dismAnalyze){$dismAnalyze.Output -join [Environment]::NewLine}else{""})

if($dismCheckText -match '(?i)component store is repairable'){
    Add-Assessment -Area "Component store" -Status "FAILURE" `
        -Finding "DISM reports the component store is repairable." `
        -Evidence "DISM /CheckHealth indicates repairable component-store corruption." -Confidence "CONFIRMED"
    Add-Recommendation "Use the toolkit DISM Service Center RestoreHealth workflow only after reviewing source/connectivity requirements; rerun servicing health checks afterward."
}
elseif($dismCheckText -match '(?i)component store cannot be repaired|non-repairable'){
    Add-Assessment -Area "Component store" -Status "FAILURE" `
        -Finding "DISM reports non-repairable component-store corruption." `
        -Evidence "DISM /CheckHealth indicates a non-repairable state." -Confidence "CONFIRMED"
    Add-Recommendation "Preserve servicing evidence and consider repair-install/recovery planning instead of repeated cleanup/reset attempts."
}
elseif($dismCheckText -match '(?i)no component store corruption detected'){
    Add-Assessment -Area "Component store" -Status "CLEAR" `
        -Finding "DISM CheckHealth reports no component-store corruption." -Confidence "CONFIRMED"
}
else{
    Add-Assessment -Area "Component store" -Status "INDETERMINATE" `
        -Finding "DISM component-store health could not be conclusively classified from CheckHealth output." `
        -Evidence $(if($dismCheck){"Exit code=" + $dismCheck.ExitCode}else{"DISM result unavailable."}) -Confidence "INDETERMINATE"
}

$cleanupRecommended = $false
if($dismAnalyzeText -match '(?im)Component Store Cleanup Recommended\s*:\s*Yes'){
    $cleanupRecommended = $true
    Add-Assessment -Area "Component store cleanup" -Status "CONTEXT" `
        -Finding "DISM AnalyzeComponentStore reports component-store cleanup is recommended." `
        -Evidence "This is a servicing recommendation, not evidence of corruption." -Confidence "CONFIRMED"
    Add-Recommendation "If cleanup is desired, use the normal StartComponentCleanup path. Do not use ResetBase merely because cleanup is recommended."
}
elseif($dismAnalyzeText){
    Add-Assessment -Area "Component store cleanup" -Status "CONTEXT" `
        -Finding "AnalyzeComponentStore completed; no cleanup recommendation was detected in the parsed output." -Confidence "STRONG_EVIDENCE"
}

# ---------------------------------------------------------------------------
# Package inventory
# ---------------------------------------------------------------------------
$packages = @()
$servicingPackages = @()

if($isAdmin){
    try {
        Write-ToolkitStatus "Collecting read-only Windows package inventory."
        $packages = @(
            Get-WindowsPackage -Online -ErrorAction Stop |
                Select-Object PackageName,PackageState,ReleaseType,InstallTime |
                Sort-Object InstallTime -Descending
        )
        $servicingPackages = @(
            $packages |
                Where-Object { $_.PackageName -match '(?i)ServicingStack|RollupFix' } |
                Select-Object -First 60
        )
        if(Get-Command New-ToolkitCapabilityStatus -ErrorAction SilentlyContinue){
            $capabilities.Add((New-ToolkitCapabilityStatus -Capability "Windows servicing package inventory" `
                -Available $true -Status "Available" -Detail ("Packages=" + $packages.Count) -SourceTool $toolId))
        }
    }
    catch {
        if(Get-Command New-ToolkitCapabilityStatus -ErrorAction SilentlyContinue){
            $capabilities.Add((New-ToolkitCapabilityStatus -Capability "Windows servicing package inventory" `
                -Available $false -Status "Query/API Failed" -Detail $_.Exception.Message -SourceTool $toolId))
        }
    }
}
else{
    Add-Assessment -Area "Elevation coverage" -Status "NOT_TESTED" `
        -Finding "Report is not elevated; package inventory and AnalyzeComponentStore were not collected." `
        -Evidence "Basic update history, event, pending-reboot, service, hotfix, and CheckHealth evidence is still included." -Confidence "NOT_TESTED"
    Add-Recommendation "Rerun as Administrator if deep component-store/package evidence is required."
    if(Get-Command New-ToolkitCapabilityStatus -ErrorAction SilentlyContinue){
        $capabilities.Add((New-ToolkitCapabilityStatus -Capability "Windows servicing package inventory" `
            -Available $false -Status "Requires Elevation" `
            -Detail "Run as Administrator for Get-WindowsPackage and AnalyzeComponentStore." -SourceTool $toolId))
    }
}

$hotfixes = @(
    Get-CimInstance Win32_QuickFixEngineering -ErrorAction SilentlyContinue |
        Sort-Object InstalledOn -Descending |
        Select-Object -First 150 HotFixID,Description,InstalledOn
)

# ---------------------------------------------------------------------------
# Policy / configuration context
# ---------------------------------------------------------------------------
$auPolicy = Get-ItemProperty "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" -ErrorAction SilentlyContinue
$wuPolicy = Get-ItemProperty "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" -ErrorAction SilentlyContinue
$policy = [pscustomobject]@{
    WUServer = [string]$wuPolicy.WUServer
    WUStatusServer = [string]$wuPolicy.WUStatusServer
    DoNotConnectToWindowsUpdateInternetLocations = [string]$wuPolicy.DoNotConnectToWindowsUpdateInternetLocations
    DisableWindowsUpdateAccess = [string]$wuPolicy.DisableWindowsUpdateAccess
    UseWUServer = [string]$auPolicy.UseWUServer
    NoAutoUpdate = [string]$auPolicy.NoAutoUpdate
    AUOptions = [string]$auPolicy.AUOptions
}

# ---------------------------------------------------------------------------
# Filtered recent CBS / DISM evidence
# ---------------------------------------------------------------------------
function Get-FilteredLogTail {
    param(
        [string]$Path,
        [int]$Tail = 1200,
        [int]$Max = 220
    )

    if(-not(Test-Path -LiteralPath $Path -PathType Leaf)){ return @() }

    try {
        return @(
            Get-Content -LiteralPath $Path -Tail $Tail -ErrorAction Stop |
                Where-Object {
                    $_ -match '(?i)\berror\b|\bfail(ed|ure)?\b|0x[0-9a-f]{8}|corrupt|repair|reboot|pending'
                } |
                Select-Object -Last $Max
        )
    }
    catch {
        return @()
    }
}

$cbsEvidence = Get-FilteredLogTail -Path (Join-Path $env:SystemRoot "Logs\CBS\CBS.log")
$dismLogEvidence = Get-FilteredLogTail -Path (Join-Path $env:SystemRoot "Logs\DISM\dism.log")

# ---------------------------------------------------------------------------
# Overall correlation
# ---------------------------------------------------------------------------
$signalGroups = New-Object System.Collections.Generic.List[string]

if($pendingAny){ $signalGroups.Add("Pending reboot") }
if($failedHistory.Count -gt 0){ $signalGroups.Add("Failed update history") }
if($wuEvents.Count -gt 0){ $signalGroups.Add("Windows Update events") }
if($setupEvents.Count -gt 0){ $signalGroups.Add("Setup/servicing events") }

$dismCorrupt = (
    $dismCheckText -match '(?i)component store is repairable|component store cannot be repaired|non-repairable'
)
if($dismCorrupt){ $signalGroups.Add("Component-store health") }

$overall = "No major servicing failure signal was established."
$overallState = "CLEAR"

if($dismCorrupt){
    $overallState = "FAILURE"
    $overall = "Component-store health is the highest-priority servicing finding."
}
elseif($pendingAny -and ($failedHistory.Count -gt 0 -or $wuEvents.Count -gt 0)){
    $overallState = "ATTENTION"
    $overall = "Pending reboot state overlaps with update-failure evidence and should be cleared before deeper repair decisions."
}
elseif($signalGroups.Count -ge 3){
    $overallState = "ATTENTION"
    $overall = "Multiple independent servicing/update warning groups are present and should be correlated by timestamp."
}
elseif($signalGroups.Count -gt 0){
    $overallState = "ATTENTION"
    $overall = "Some servicing/update warning evidence is present, but this report does not establish one root cause."
}

$overallConfidence = "POSSIBLE"
if($dismCorrupt){ $overallConfidence = "CONFIRMED" }
elseif($signalGroups.Count -ge 3){ $overallConfidence = "STRONG_EVIDENCE" }
elseif($signalGroups.Count -eq 0){ $overallConfidence = "STRONG_EVIDENCE" }

Add-Assessment -Area "Overall servicing correlation" -Status $overallState `
    -Finding $overall -Evidence ("Signal groups: " + $(if($signalGroups.Count){$signalGroups -join ", "}else{"none"})) `
    -Confidence $overallConfidence

if($recommendations.Count -eq 0){
    Add-Recommendation "No servicing repair is indicated by this report alone. Continue with symptom-specific diagnosis if the machine still has a problem."
}

# ---------------------------------------------------------------------------
# Report presentation
# ---------------------------------------------------------------------------
$summary = @($assessmentRows.ToArray() | Select-Object Area,Status,Confidence,Finding)
$confidenceDefinitions = Get-ToolkitAssessmentConfidenceDefinition
$warnings = @(
    $assessmentRows.ToArray() |
        Where-Object { $_.Status -in @("ATTENTION","FAILURE","PARTIAL","INDETERMINATE") }
)

$report = New-ToolkitSectionedReport -Title "Windows Servicing / Update Health Report" `
    -Subtitle "Read-only servicing umbrella report. Summary and recommendations open first; inventories and raw evidence stay collapsed." `
    -Footer "No cleanup, ResetBase, RestoreHealth, update reset, update installation, or servicing mutation was performed."

Add-ToolkitSectionedReportSection -Report $report -Title "Technician Summary" `
    -Data $summary -Kind "SUMMARY" -OpenByDefault:$true

Add-ToolkitSectionedReportSection -Report $report -Title "Warnings / Incomplete Coverage" `
    -Data $(if($warnings.Count){$warnings}else{"No warning/failure/incomplete assessment was produced."}) `
    -Kind $(if($warnings.Count){"WARNING"}else{"SUMMARY"}) -OpenByDefault:$true

Add-ToolkitSectionedReportSection -Report $report -Title "Recommended Next Actions" `
    -Data ($recommendations -join [Environment]::NewLine) `
    -Kind "RECOMMENDATION" -OpenByDefault:$true

Add-ToolkitSectionedReportSection -Report $report -Title "Assessment Confidence Vocabulary" `
    -Data $confidenceDefinitions -Kind "NORMAL" -OpenByDefault:$false `
    -Note "Qualitative evidence labels; the toolkit does not invent numeric certainty."

Add-ToolkitSectionedReportSection -Report $report -Title "Windows / Servicing Identity" `
    -Data $identity -Kind "NORMAL" -OpenByDefault:$true

Add-ToolkitSectionedReportSection -Report $report -Title "Pending Reboot State" `
    -Data $pending -Kind $(if($pendingAny){"WARNING"}else{"NORMAL"}) `
    -OpenByDefault:$pendingAny

Add-ToolkitSectionedReportSection -Report $report -Title "Windows Update / Servicing Services" `
    -Data $services -Kind "NORMAL" -OpenByDefault:$false `
    -Note "Stopped trigger-start services are context, not automatically a failure."

Add-ToolkitSectionedReportSection -Report $report -Title "Windows Update Policy Context" `
    -Data $policy -Kind "EVIDENCE" -OpenByDefault:$false

Add-ToolkitSectionedReportSection -Report $report -Title "DISM CheckHealth" `
    -Data $dismCheckText -Kind "EVIDENCE" -OpenByDefault:$false

Add-ToolkitSectionedReportSection -Report $report -Title "DISM AnalyzeComponentStore" `
    -Data $(if($dismAnalyze){$dismAnalyzeText}else{"Not collected. Administrator elevation is required for this deep section."}) `
    -Kind "EVIDENCE" -OpenByDefault:$false

Add-ToolkitSectionedReportSection -Report $report -Title "Failed / Aborted Update History - 30 Days" `
    -Data $(if($failedHistory.Count){$failedHistory}else{"No failed/aborted/succeeded-with-errors history entries found in the last 30 days."}) `
    -Kind $(if($failedHistory.Count){"WARNING"}else{"NORMAL"}) `
    -OpenByDefault:($failedHistory.Count -gt 0)

Add-ToolkitSectionedReportSection -Report $report -Title "Windows Update History - 30 Days" `
    -Data $(if($recentHistory.Count){$recentHistory}else{$historyError}) `
    -Kind "EVIDENCE" -OpenByDefault:$false

Add-ToolkitSectionedReportSection -Report $report -Title "Windows Update Operational Events - 30 Days" `
    -Data $wuEvents -Kind "EVIDENCE" -OpenByDefault:$false

Add-ToolkitSectionedReportSection -Report $report -Title "Setup / Servicing Events - 30 Days" `
    -Data $setupEvents -Kind "EVIDENCE" -OpenByDefault:$false

Add-ToolkitSectionedReportSection -Report $report -Title "Servicing Stack / Rollup Packages" `
    -Data $(if($servicingPackages.Count){$servicingPackages}else{"No servicing-stack/rollup package inventory was collected or matched."}) `
    -Kind "INVENTORY" -OpenByDefault:$false

Add-ToolkitSectionedReportSection -Report $report -Title "Installed Windows Packages" `
    -Data $(if($packages.Count){$packages}else{"Package inventory not collected."}) `
    -Kind "INVENTORY" -OpenByDefault:$false

Add-ToolkitSectionedReportSection -Report $report -Title "Installed Hotfixes" `
    -Data $hotfixes -Kind "INVENTORY" -OpenByDefault:$false

Add-ToolkitSectionedReportSection -Report $report -Title "CBS Log - Filtered Recent Evidence" `
    -Data $cbsEvidence -Kind "EVIDENCE" -OpenByDefault:$false `
    -Note "Filtered tail only; this is not the complete CBS.log."

Add-ToolkitSectionedReportSection -Report $report -Title "DISM Log - Filtered Recent Evidence" `
    -Data $dismLogEvidence -Kind "EVIDENCE" -OpenByDefault:$false `
    -Note "Filtered tail only; this is not the complete DISM log."

# TXT / MD / meta remain on the shared writer path.
$lines = New-Object System.Collections.Generic.List[string]
$lines.Add("WINDOWS SERVICING / UPDATE HEALTH REPORT")
$lines.Add("Computer: " + $env:COMPUTERNAME)
$lines.Add("Generated: " + (Get-Date))
$lines.Add("Administrator: " + $isAdmin)
$lines.Add("Read-only: Yes")

foreach($section in @($report.Sections)){
    $lines.Add("")
    $lines.Add(("=" * 78))
    $lines.Add([string]$section.Title)
    $lines.Add(("=" * 78))
    if(-not [string]::IsNullOrWhiteSpace([string]$section.Note)){
        $lines.Add("NOTE: " + [string]$section.Note)
    }
    $lines.Add([string]$section.Body)
}

$body = $lines -join [Environment]::NewLine
& $writer -BasePath $basePath -Title "Windows Servicing / Update Health Report" -Body $body -ToolId $toolId

# Replace the generic auto-rendered HTML with the explicit report ordering above.
[void](Write-ToolkitSectionedHtmlReport -Report $report -Path ($basePath + ".html") `
    -Computer $env:COMPUTERNAME -Generated ([string](Get-Date)) -ToolId $toolId)

$payload = [pscustomobject]@{
    Report = [pscustomobject]@{
        Title = "Windows Servicing / Update Health Report"
        ToolId = $toolId
        Computer = $env:COMPUTERNAME
        GeneratedAt = (Get-Date)
        Administrator = $isAdmin
        ReadOnly = $true
    }
    AssessmentConfidenceVocabulary = @("CONFIRMED","STRONG_EVIDENCE","POSSIBLE","INDETERMINATE","NOT_TESTED")
    Assessment = $assessmentRows.ToArray()
    Recommendations = $recommendations.ToArray()
    PendingReboot = $pending
    Services = $services
    Policy = $policy
    Dism = [pscustomobject]@{
        CheckHealth = $dismCheckText
        AnalyzeComponentStore = $dismAnalyzeText
        CleanupRecommended = $cleanupRecommended
    }
    UpdateHistory = $recentHistory
    FailedUpdateHistory = $failedHistory
    WindowsUpdateEvents = $wuEvents
    SetupEvents = $setupEvents
    ServicingPackages = $servicingPackages
    Packages = $packages
    Hotfixes = $hotfixes
    CbsFilteredEvidence = $cbsEvidence
    DismFilteredEvidence = $dismLogEvidence
}

$payload | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath ($basePath + ".json") -Encoding UTF8

if(Get-Command Write-ToolkitDiagnosticSidecar -ErrorAction SilentlyContinue){
    Write-ToolkitDiagnosticSidecar -BasePath $basePath -ToolkitRoot $toolkitRoot `
        -ToolId $toolId -Title "Windows Servicing / Update Health Report" `
        -Capabilities $capabilities.ToArray()
}

Write-ToolkitStatus "Windows servicing / update health report complete."
Write-Host ""
Write-Host ("HTML: " + $basePath + ".html")
Write-Host ("Text: " + $basePath + ".txt")
Write-Host ("Markdown: " + $basePath + ".md")
Write-Host ("JSON: " + $basePath + ".json")
Write-Host ""

try { Start-Process -FilePath ($basePath + ".html") } catch {}

exit 0

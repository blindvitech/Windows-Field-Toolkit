$screenReaderCommon = Join-Path (Split-Path $PSScriptRoot -Parent) "00_Common\ScreenReader-Common.ps1"
if (Test-Path -LiteralPath $screenReaderCommon -PathType Leaf) {
    . $screenReaderCommon
}

$ErrorActionPreference="SilentlyContinue"
$ProgressPreference="SilentlyContinue"
$toolkitRoot=Split-Path $PSScriptRoot -Parent
$logs=Join-Path $toolkitRoot "Logs"
if(-not(Test-Path -LiteralPath $logs)){Write-Host "Logs folder not found.";exit 1}

$cases=@(Get-ChildItem -LiteralPath $logs -Directory -ErrorAction SilentlyContinue|Where-Object{$_.Name -like "CASE_*"}|Sort-Object LastWriteTime -Descending|Select-Object -First 10)
if(-not $cases.Count){Write-Host "No CASE_ folders were found. Run Collect Case Mode first.";exit 1}
Write-Host "CASE NOTES / TECHNICIAN NOTES"
for($i=0;$i -lt $cases.Count;$i++){Write-Host(("{0}. {1}" -f ($i+1),$cases[$i].FullName))}
$choice=(Read-ToolkitPrompt "Case number, or press Enter for newest").Trim()
$case=$cases[0]
if($choice -match '^\d+$' -and [int]$choice -ge 1 -and [int]$choice -le $cases.Count){$case=$cases[[int]$choice-1]}

$ticket=(Read-ToolkitPrompt "Ticket / reference number").Trim()
$issue=(Read-ToolkitPrompt "Issue / request summary").Trim()
$symptoms=(Read-ToolkitPrompt "Symptoms / observations").Trim()
$work=(Read-ToolkitPrompt "Work performed").Trim()
$result=(Read-ToolkitPrompt "Result / current state").Trim()
$next=(Read-ToolkitPrompt "Next steps / follow-up").Trim()
$tech=(Read-ToolkitPrompt ("Technician name, Enter for "+$env:USERNAME)).Trim()
if(-not $tech){$tech=$env:USERNAME}

$stamp=Get-Date -Format "yyyyMMdd_HHmmss"
$txt=Join-Path $case.FullName ("CASE_NOTES_"+$stamp+".txt")
$md=Join-Path $case.FullName ("CASE_NOTES_"+$stamp+".md")
$lines=@(
 "CASE / TECHNICIAN NOTES",
 "Case: "+$case.Name,
 "Generated: "+(Get-Date),
 "Technician: "+$tech,
 "Ticket / Reference: "+$ticket,
 "",
 "ISSUE / REQUEST",
 $issue,
 "",
 "SYMPTOMS / OBSERVATIONS",
 $symptoms,
 "",
 "WORK PERFORMED",
 $work,
 "",
 "RESULT / CURRENT STATE",
 $result,
 "",
 "NEXT STEPS / FOLLOW-UP",
 $next
)
$lines|Set-Content -LiteralPath $txt -Encoding UTF8
$mdLines=@(
 "# Case / Technician Notes",
 "",
 "**Case:** "+$case.Name,
 "**Generated:** "+(Get-Date),
 "**Technician:** "+$tech,
 "**Ticket / Reference:** "+$ticket,
 "",
 "## Issue / Request","",$issue,"",
 "## Symptoms / Observations","",$symptoms,"",
 "## Work Performed","",$work,"",
 "## Result / Current State","",$result,"",
 "## Next Steps / Follow-up","",$next
)
$mdLines|Set-Content -LiteralPath $md -Encoding UTF8

$zip=Join-Path $logs ($case.Name+".zip")
try{if(Test-Path -LiteralPath $zip){Remove-Item -LiteralPath $zip -Force};Compress-Archive -Path (Join-Path $case.FullName "*") -DestinationPath $zip -Force}catch{}
Write-Host ("Notes saved: "+$txt)
if(Test-Path -LiteralPath $zip){Write-Host("Case ZIP refreshed: "+$zip)}
exit 0

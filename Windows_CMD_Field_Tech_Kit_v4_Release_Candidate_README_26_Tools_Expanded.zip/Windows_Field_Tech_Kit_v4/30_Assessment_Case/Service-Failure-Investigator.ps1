$screenReaderCommon = Join-Path (Split-Path $PSScriptRoot -Parent) "00_Common\ScreenReader-Common.ps1"
if (Test-Path -LiteralPath $screenReaderCommon -PathType Leaf) {
    . $screenReaderCommon
}

$ErrorActionPreference="SilentlyContinue"
$ProgressPreference="SilentlyContinue"
$toolkitRoot=Split-Path $PSScriptRoot -Parent
$logs=Join-Path $toolkitRoot "Logs"
if(-not(Test-Path -LiteralPath $logs)){New-Item -ItemType Directory -Path $logs -Force|Out-Null}
$writer=Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"

Write-Host "SERVICE FAILURE INVESTIGATOR"
$name=(Read-ToolkitPrompt "Service name, not display name").Trim()
if(-not $name){Write-Host "No service entered.";exit 1}
$svc=Get-Service -Name $name -ErrorAction SilentlyContinue
if(-not $svc){Write-Host "Service not found.";exit 2}
$name=$svc.Name
$stamp=Get-Date -Format "yyyyMMdd_HHmmss"
$safe=$name-replace'[^A-Za-z0-9._-]','_'
$basePath=Join-Path $logs ($env:COMPUTERNAME+"_Service_Failure_Investigator_"+$safe+"_"+$stamp)

$cim=Get-CimInstance Win32_Service -Filter ("Name='"+$name.Replace("'","''")+"'") -ErrorAction SilentlyContinue
$qc=(& sc.exe qc $name 2>&1|Out-String -Width 260).TrimEnd()
$qfailure=(& sc.exe qfailure $name 2>&1|Out-String -Width 260).TrimEnd()
$deps=$svc.ServicesDependedOn|Select-Object Name,DisplayName,Status
$dependents=$svc.DependentServices|Select-Object Name,DisplayName,Status

$binary=""
if($cim.PathName){
 $raw=[Environment]::ExpandEnvironmentVariables([string]$cim.PathName)
 if($raw.StartsWith('"')){
  $end=$raw.IndexOf('"',1);if($end -gt 1){$binary=$raw.Substring(1,$end-1)}
 }else{
  $exeMatch=[regex]::Match($raw,'^(.*?\.exe)\b',[System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
  if($exeMatch.Success){$binary=$exeMatch.Groups[1].Value}else{$binary=($raw -split '\s+')[0]}
 }
}
$file=$null
if($binary -and (Test-Path -LiteralPath $binary -PathType Leaf)){
 $f=Get-Item -LiteralPath $binary -ErrorAction SilentlyContinue
 $sig=Get-AuthenticodeSignature -FilePath $binary -ErrorAction SilentlyContinue
 $hash=Get-FileHash -LiteralPath $binary -Algorithm SHA256 -ErrorAction SilentlyContinue
 $file=[pscustomobject]@{Path=$binary;FileVersion=$f.VersionInfo.FileVersion;ProductVersion=$f.VersionInfo.ProductVersion;CompanyName=$f.VersionInfo.CompanyName;Signature=$sig.Status;Signer=$(if($sig.SignerCertificate){$sig.SignerCertificate.Subject}else{$null});SHA256=$hash.Hash}
}

$events=@()
try{
 $events=Get-WinEvent -FilterHashtable @{LogName="System";ProviderName="Service Control Manager";StartTime=(Get-Date).AddDays(-14)} -ErrorAction Stop|
  Where-Object{$_.Message -match [regex]::Escape($name) -or $_.Message -match [regex]::Escape($svc.DisplayName)}|
  Sort-Object TimeCreated -Descending|Select-Object -First 150 TimeCreated,Id,LevelDisplayName,@{N="Message";E={($_.Message-replace"[\r\n]+"," "-replace"\s{2,}"," ").Trim()}}
}catch{}

$lines=New-Object System.Collections.Generic.List[string]
$lines.Add("SERVICE FAILURE INVESTIGATOR");$lines.Add("Computer: "+$env:COMPUTERNAME);$lines.Add("Generated: "+(Get-Date));$lines.Add("Service: "+$name+" - "+$svc.DisplayName)
$lines.Add("");$lines.Add("Read-only service configuration, binary/signature, dependencies, recovery policy, and recent Service Control Manager event review.")
foreach($pair in @(@("SERVICE CONFIGURATION",$cim),@("SERVICE BINARY",$file),@("DEPENDENCIES",$deps),@("DEPENDENT SERVICES",$dependents),@("SERVICE CONTROL MANAGER EVENTS - 14 DAYS",$events))){
 $lines.Add("");$lines.Add(("="*78));$lines.Add($pair[0]);$lines.Add(("="*78));$x=($pair[1]|Out-String -Width 260).TrimEnd();if($x){$lines.Add($x)}else{$lines.Add("(No data returned)")}
}
$lines.Add("");$lines.Add(("="*78));$lines.Add("SC QC");$lines.Add(("="*78));$lines.Add($qc)
$lines.Add("");$lines.Add(("="*78));$lines.Add("SC QFAILURE");$lines.Add(("="*78));$lines.Add($qfailure)
$body=$lines -join [Environment]::NewLine
& $writer -BasePath $basePath -Title "Service Failure Investigator" -Body $body
$html=$basePath+".html";Write-Host("Report: "+$html);try{Start-Process -FilePath $html}catch{}
exit 0

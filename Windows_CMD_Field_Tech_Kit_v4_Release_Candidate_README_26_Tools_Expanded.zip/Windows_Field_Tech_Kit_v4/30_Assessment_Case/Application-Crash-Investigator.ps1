$screenReaderCommon = Join-Path (Split-Path $PSScriptRoot -Parent) "00_Common\ScreenReader-Common.ps1"
if (Test-Path -LiteralPath $screenReaderCommon -PathType Leaf) {
    . $screenReaderCommon
}

$ErrorActionPreference = "SilentlyContinue"
$ProgressPreference = "SilentlyContinue"
$toolkitRoot=Split-Path $PSScriptRoot -Parent
$logs=Join-Path $toolkitRoot "Logs"
if (-not (Test-Path -LiteralPath $logs)) { New-Item -ItemType Directory -Path $logs -Force | Out-Null }
$writer=Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"

Write-Host "APPLICATION CRASH INVESTIGATOR"
Write-Host "Enter an application name, executable name, or full executable path."
$target=(Read-ToolkitPrompt "Application").Trim().Trim('"')
if ([string]::IsNullOrWhiteSpace($target)) { Write-Host "No application entered."; exit 1 }

Write-Host "Lookback: 1=7 days, 2=14 days, 3=30 days, 4=custom"
$choice=Read-ToolkitPrompt "Select 1 through 4"
$days=14
switch($choice) {
    "1" {$days=7}; "2" {$days=14}; "3" {$days=30}
    "4" {
        $d=Read-ToolkitPrompt "Days, 1 through 365"
        if ($d -match '^\d+$' -and [int]$d -ge 1 -and [int]$d -le 365) { $days=[int]$d }
    }
}
$start=(Get-Date).AddDays(-$days)
$leaf=Split-Path $target -Leaf
if ([string]::IsNullOrWhiteSpace($leaf)) { $leaf=$target }
$stem=[IO.Path]::GetFileNameWithoutExtension($leaf)
$patterns=@($target,$leaf,$stem) | Where-Object { $_ } | ForEach-Object { [regex]::Escape($_) }
$matchPattern='(?i)(' + ($patterns -join '|') + ')'
$safe=($stem -replace '[^A-Za-z0-9._-]','_')
if (-not $safe) { $safe="Application" }
$stamp=Get-Date -Format "yyyyMMdd_HHmmss"
$basePath=Join-Path $logs ($env:COMPUTERNAME+"_Application_Crash_Investigator_"+$safe+"_"+$stamp)

$running=@(Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.Name -match $matchPattern -or $_.Path -match $matchPattern } |
    ForEach-Object {
        $sig=$null
        if ($_.Path) { $sig=Get-AuthenticodeSignature -FilePath $_.Path -ErrorAction SilentlyContinue }
        [pscustomobject]@{
            ProcessName=$_.Name; Id=$_.Id; Path=$_.Path; ProductVersion=$_.ProductVersion; FileVersion=$_.FileVersion;
            StartTime=$_.StartTime; SignatureStatus=$(if($sig){$sig.Status}else{$null});
            Signer=$(if($sig -and $sig.SignerCertificate){$sig.SignerCertificate.Subject}else{$null})
        }
    })

$fileInfo=$null
if (Test-Path -LiteralPath $target -PathType Leaf) {
    $f=Get-Item -LiteralPath $target -Force -ErrorAction SilentlyContinue
    $sig=Get-AuthenticodeSignature -FilePath $target -ErrorAction SilentlyContinue
    $hash=Get-FileHash -LiteralPath $target -Algorithm SHA256 -ErrorAction SilentlyContinue
    $fileInfo=[pscustomobject]@{
        FullName=$f.FullName; Length=$f.Length; LastWriteTime=$f.LastWriteTime;
        FileVersion=$f.VersionInfo.FileVersion; ProductVersion=$f.VersionInfo.ProductVersion;
        CompanyName=$f.VersionInfo.CompanyName; ProductName=$f.VersionInfo.ProductName;
        SignatureStatus=$sig.Status; Signer=$(if($sig.SignerCertificate){$sig.SignerCertificate.Subject}else{$null}); SHA256=$hash.Hash
    }
}

$installed=@()
foreach($path in @("HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*","HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*","HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*")) {
    $installed += Get-ItemProperty $path -ErrorAction SilentlyContinue |
        Where-Object { $_.DisplayName -match $matchPattern -or $_.DisplayIcon -match $matchPattern -or $_.InstallLocation -match $matchPattern } |
        Select-Object DisplayName,DisplayVersion,Publisher,InstallDate,InstallLocation,DisplayIcon
}
$installed=@($installed | Sort-Object DisplayName,DisplayVersion -Unique)

$events=@()
try {
    $events=Get-WinEvent -FilterHashtable @{LogName="Application";StartTime=$start;Id=1000,1001,1002} -ErrorAction Stop |
        Where-Object { $_.Message -match $matchPattern } |
        Select-Object -First 150 TimeCreated,Id,ProviderName,LevelDisplayName,
            @{N="Message";E={($_.Message -replace "[\r\n]+"," " -replace "\s{2,}"," ").Trim()}}
} catch {}
$reliability=@(Get-CimInstance Win32_ReliabilityRecords -ErrorAction SilentlyContinue |
    Where-Object { $_.TimeGenerated -ge $start -and ($_.ProductName -match $matchPattern -or $_.Message -match $matchPattern -or $_.SourceName -match $matchPattern) } |
    Sort-Object TimeGenerated -Descending | Select-Object -First 100 TimeGenerated,SourceName,ProductName,EventIdentifier,Message)

$wer=@()
$werRoot=Join-Path $env:ProgramData "Microsoft\Windows\WER"
if (Test-Path -LiteralPath $werRoot) {
    $wer=@(Get-ChildItem -LiteralPath $werRoot -File -Recurse -ErrorAction SilentlyContinue |
        Where-Object { $_.LastWriteTime -ge $start -and ($_.Name -match $matchPattern -or $_.DirectoryName -match $matchPattern) } |
        Sort-Object LastWriteTime -Descending | Select-Object -First 75 FullName,Length,LastWriteTime)
}

$lines=New-Object System.Collections.Generic.List[string]
$lines.Add("APPLICATION CRASH INVESTIGATOR")
$lines.Add("Computer: "+$env:COMPUTERNAME); $lines.Add("Generated: "+(Get-Date))
$lines.Add("Target: "+$target); $lines.Add("Lookback: "+$days+" days")
$lines.Add("")
$lines.Add("Read-only investigation of Application Error/Hang/WER events, reliability records,")
$lines.Add("installed-app metadata, running process details, signatures, and matching WER files.")
foreach($pair in @(
    @("RUNNING PROCESS MATCHES",$running),
    @("EXPLICIT EXECUTABLE FILE DETAILS",$fileInfo),
    @("INSTALLED APPLICATION MATCHES",$installed),
    @("APPLICATION CRASH / HANG EVENTS",$events),
    @("RELIABILITY RECORDS",$reliability),
    @("MATCHING WINDOWS ERROR REPORTING FILES",$wer)
)) {
    $lines.Add("");$lines.Add(("="*78));$lines.Add($pair[0]);$lines.Add(("="*78))
    $x=($pair[1]|Out-String -Width 260).TrimEnd()
    if($x){$lines.Add($x)}else{$lines.Add("(No matching data returned)")}
}
$body=$lines -join [Environment]::NewLine
& $writer -BasePath $basePath -Title "Application Crash Investigator" -Body $body
$html=$basePath+".html"; Write-Host ("Report: "+$html)
try{Start-Process -FilePath $html}catch{}
exit 0

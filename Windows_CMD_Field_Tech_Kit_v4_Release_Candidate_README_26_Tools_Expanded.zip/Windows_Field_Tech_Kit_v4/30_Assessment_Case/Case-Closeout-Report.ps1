$screenReaderCommon = Join-Path (Split-Path $PSScriptRoot -Parent) "00_Common\ScreenReader-Common.ps1"
if (Test-Path -LiteralPath $screenReaderCommon -PathType Leaf) {
    . $screenReaderCommon
}

$ErrorActionPreference="SilentlyContinue"
$ProgressPreference="SilentlyContinue"
$toolkitRoot=Split-Path $PSScriptRoot -Parent
$foundation=Join-Path $toolkitRoot "00_Common\Foundation-Common.ps1"
if(Test-Path -LiteralPath $foundation -PathType Leaf){. $foundation}
$logs=if(Get-Command Get-ToolkitLogRoot -ErrorAction SilentlyContinue){Get-ToolkitLogRoot}else{Join-Path $toolkitRoot "Logs"}
$writer=Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"
$sectionedHtml=Join-Path $toolkitRoot "00_Common\Sectioned-Html-Report.ps1"
if(Test-Path -LiteralPath $sectionedHtml -PathType Leaf){. $sectionedHtml}
$cases=@(Get-ChildItem -LiteralPath $logs -Directory -ErrorAction SilentlyContinue|Where-Object{$_.Name -like "CASE_*"}|Sort-Object LastWriteTime -Descending|Select-Object -First 10)
if(-not $cases.Count){Write-Host "No CASE_ folders were found.";exit 1}
Write-Host "CASE CLOSEOUT REPORT"
for($i=0;$i -lt $cases.Count;$i++){Write-Host(("{0}. {1}" -f ($i+1),$cases[$i].FullName))}
$choice=(Read-ToolkitPrompt "Case number, or press Enter for newest").Trim()
$case=$cases[0]
if($choice -match '^\d+$' -and [int]$choice -ge 1 -and [int]$choice -le $cases.Count){$case=$cases[[int]$choice-1]}

$metadataPath=Join-Path $case.FullName "CASE_METADATA.txt"
$metadata=if(Test-Path -LiteralPath $metadataPath){Get-Content -LiteralPath $metadataPath -ErrorAction SilentlyContinue}else{@("Case="+$case.Name)}
$machineSummaryPath=Join-Path $case.FullName "01_MACHINE_SUMMARY.txt"
$machineSummary=if(Test-Path -LiteralPath $machineSummaryPath){Get-Content -LiteralPath $machineSummaryPath -ErrorAction SilentlyContinue}else{@("(Machine summary unavailable)")}
$notes=@(Get-ChildItem -LiteralPath $case.FullName -Filter "CASE_NOTES_*.txt" -File -ErrorAction SilentlyContinue|Sort-Object LastWriteTime)

$caseStart=$null
$caseComputer=$env:COMPUTERNAME
foreach($line in $metadata){
 if($line -like "StartTimeISO=*"){
  try{$caseStart=[datetime]::Parse($line.Substring(13))}catch{}
 }
 if($line -like "Computer=*"){
  $value=$line.Substring(9).Trim()
  if($value){$caseComputer=$value}
 }
}

$caseIsActive=$false
if(Get-Command Get-ToolkitCaseContext -ErrorAction SilentlyContinue){
 try{
  $activeCtx=Get-ToolkitCaseContext
  $caseIsActive=([string]$activeCtx.CaseId -ieq $case.Name -and [bool]$activeCtx.ExplicitActiveCase)
 }catch{}
}
$captureHelper=Join-Path $toolkitRoot "00_Common\Capture-Active-Case-Artifacts.ps1"
if($caseIsActive -and (Test-Path -LiteralPath $captureHelper -PathType Leaf)){
 try{
  & $captureHelper -FinalSweep -ToolId "TOOL-041" -ToolName "Case Closeout Final Sweep" -ReturnCode 0 -Quiet
 }catch{}
}

$files=@(Get-ChildItem -LiteralPath $case.FullName -File -Recurse -ErrorAction SilentlyContinue|
 Sort-Object FullName|
 Select-Object @{N="RelativePath";E={$_.FullName.Substring($case.FullName.Length).TrimStart("\")}},Length,LastWriteTime)
$capturedArtifacts=@(Get-ChildItem -LiteralPath (Join-Path $case.FullName "Artifacts\LogsMirror") -File -Recurse -ErrorAction SilentlyContinue|
 Sort-Object FullName|
 Select-Object @{N="RelativePath";E={$_.FullName.Substring($case.FullName.Length).TrimStart("\")}},Length,LastWriteTime)
$activityFiles=@(Get-ChildItem -LiteralPath (Join-Path $case.FullName "Activity") -File -Recurse -ErrorAction SilentlyContinue|
 Sort-Object FullName|
 Select-Object @{N="RelativePath";E={$_.FullName.Substring($case.FullName.Length).TrimStart("\")}},Length,LastWriteTime)

$journalMatches=@()
$journal=Join-Path $logs "REPAIR_SESSION_JOURNAL.txt"
if(Test-Path -LiteralPath $journal){
 $candidate=@(Get-Content -LiteralPath $journal -ErrorAction SilentlyContinue|Where-Object{$_ -match ("Computer="+[regex]::Escape($caseComputer)+"\s*\|")})
 foreach($line in $candidate){
  $include=$true
  if($caseStart -and $line.Length -ge 19){
   [datetime]$ts=[datetime]::MinValue
   if([datetime]::TryParse($line.Substring(0,19),[ref]$ts)){$include=($ts -ge $caseStart)}
  }
  if($include){$journalMatches+=$line}
 }
 $journalMatches=@($journalMatches|Select-Object -Last 100)
}

$sectionedReport=New-ToolkitSectionedReport -Title "Case Closeout Report" `
 -Subtitle "Consolidated baseline evidence, automatically captured toolkit artifacts, case activity, technician notes, repair journal entries, and case-file inventory." `
 -Footer "This report summarizes existing case material. It does not invent a diagnosis or claim a successful repair."
Add-ToolkitSectionedReportSection -Report $sectionedReport -Title "Closeout Summary" `
 -Data ("Case: "+$case.Name+[Environment]::NewLine+"Computer: "+$caseComputer+[Environment]::NewLine+"Generated: "+(Get-Date)+[Environment]::NewLine+"Active-case final sweep: "+$caseIsActive+[Environment]::NewLine+"Captured toolkit artifacts: "+$capturedArtifacts.Count) `
 -Kind "SUMMARY" -OpenByDefault:$true
Add-ToolkitSectionedReportSection -Report $sectionedReport -Title "Case Metadata" `
 -Data ($metadata -join [Environment]::NewLine) -Kind "SUMMARY" -OpenByDefault:$true
Add-ToolkitSectionedReportSection -Report $sectionedReport -Title "Machine Summary" `
 -Data ($machineSummary -join [Environment]::NewLine) -Kind "NORMAL" -OpenByDefault:$true
$noteText=if($notes.Count){(@(foreach($n in $notes){"--- "+$n.Name+" ---";Get-Content -LiteralPath $n.FullName -ErrorAction SilentlyContinue}) -join [Environment]::NewLine)}else{"(No technician-note files found.)"}
Add-ToolkitSectionedReportSection -Report $sectionedReport -Title "Technician Notes" `
 -Data $noteText -Kind "NORMAL" -OpenByDefault:$true
$artifactText=if($capturedArtifacts.Count){(($capturedArtifacts|Format-Table -AutoSize|Out-String -Width 260).TrimEnd())}else{"(No mirrored toolkit artifacts were captured.)"}
Add-ToolkitSectionedReportSection -Report $sectionedReport -Title "Captured Toolkit Artifacts" `
 -Data $artifactText -Kind "EVIDENCE" -OpenByDefault:$true
$activityText=if($activityFiles.Count){(($activityFiles|Format-Table -AutoSize|Out-String -Width 260).TrimEnd())}else{"(No case activity snapshot files found.)"}
Add-ToolkitSectionedReportSection -Report $sectionedReport -Title "Case Activity Evidence" `
 -Data $activityText -Kind "EVIDENCE" -OpenByDefault:$false
$journalText=if($journalMatches.Count){$journalMatches -join [Environment]::NewLine}else{"(No matching repair-journal entries found.)"}
Add-ToolkitSectionedReportSection -Report $sectionedReport -Title "Recent Repair Journal Entries" `
 -Data $journalText -Kind "EVIDENCE" -OpenByDefault:$false
Add-ToolkitSectionedReportSection -Report $sectionedReport -Title "Case File Inventory" `
 -Data (($files|Format-Table -AutoSize|Out-String -Width 260).TrimEnd()) `
 -Kind "INVENTORY" -OpenByDefault:$false

$lines=New-Object System.Collections.Generic.List[string]
$lines.Add("CASE CLOSEOUT REPORT");$lines.Add("Case: "+$case.Name);$lines.Add("Generated: "+(Get-Date))
$lines.Add("");$lines.Add("This report consolidates existing case evidence, technician notes, and recent repair-journal entries. It does not invent a diagnosis or successful outcome.")
$lines.Add("");$lines.Add(("="*78));$lines.Add("CASE METADATA");$lines.Add(("="*78));foreach($x in $metadata){$lines.Add($x)}
$lines.Add("");$lines.Add(("="*78));$lines.Add("MACHINE SUMMARY");$lines.Add(("="*78));foreach($x in $machineSummary){$lines.Add($x)}
$lines.Add("");$lines.Add(("="*78));$lines.Add("TECHNICIAN NOTES");$lines.Add(("="*78))
if($notes.Count){foreach($n in $notes){$lines.Add("");$lines.Add("--- "+$n.Name+" ---");foreach($x in Get-Content -LiteralPath $n.FullName -ErrorAction SilentlyContinue){$lines.Add($x)}}}else{$lines.Add("(No technician-note files found.)")}
$lines.Add("");$lines.Add(("="*78));$lines.Add("CAPTURED TOOLKIT ARTIFACTS");$lines.Add(("="*78))
if($capturedArtifacts.Count){$lines.Add(($capturedArtifacts|Format-Table -AutoSize|Out-String -Width 260).TrimEnd())}else{$lines.Add("(No mirrored toolkit artifacts were captured.)")}
$lines.Add("");$lines.Add(("="*78));$lines.Add("CASE ACTIVITY EVIDENCE");$lines.Add(("="*78))
if($activityFiles.Count){$lines.Add(($activityFiles|Format-Table -AutoSize|Out-String -Width 260).TrimEnd())}else{$lines.Add("(No case activity snapshot files found.)")}
$lines.Add("");$lines.Add(("="*78));$lines.Add("RECENT REPAIR JOURNAL ENTRIES FOR THIS COMPUTER");$lines.Add(("="*78))
if($journalMatches.Count){foreach($x in $journalMatches){$lines.Add($x)}}else{$lines.Add("(No matching repair-journal entries found.)")}
$lines.Add("");$lines.Add(("="*78));$lines.Add("CASE FILE INVENTORY");$lines.Add(("="*78));$lines.Add(($files|Format-Table -AutoSize|Out-String -Width 260).TrimEnd())

$stamp=Get-Date -Format "yyyyMMdd_HHmmss"
$reportBase=Join-Path $case.FullName ("CASE_CLOSEOUT_"+$stamp)
$body=$lines -join [Environment]::NewLine
& $writer -BasePath $reportBase -Title "Case Closeout Report" -Body $body

$html=$reportBase+".html"
[void](Write-ToolkitSectionedHtmlReport -Report $sectionedReport -Path $html `
 -Computer $caseComputer -Generated ([string](Get-Date)) `
 -ToolId $(if($env:FIELDTECH_TOOL_ID){$env:FIELDTECH_TOOL_ID}else{"TOOL-041"}))
$caseStatePath=Join-Path $case.FullName "CASE_STATE.json"
$closedState=[ordered]@{
 SchemaVersion=2
 CaseId=$case.Name
 Status="CLOSED"
 Computer=$caseComputer
 SessionId=$env:FIELDTECH_SESSION_ID
 ArtifactCaptureEnabled=$true
 ArtifactCaptureMode="ACTIVE_CASE_ONLY"
 CapturedArtifactCount=$capturedArtifacts.Count
 Updated=(Get-Date -Format "o")
 Closed=(Get-Date -Format "o")
}
if(Get-Command Set-ToolkitAtomicJson -ErrorAction SilentlyContinue){
 [void](Set-ToolkitAtomicJson -Path $caseStatePath -Object $closedState)
}else{
 $closedState|ConvertTo-Json -Depth 4|Set-Content -LiteralPath $caseStatePath -Encoding UTF8
}
$zip=Join-Path $logs ($case.Name+".zip")
try{if(Test-Path -LiteralPath $zip){Remove-Item -LiteralPath $zip -Force};Compress-Archive -Path (Join-Path $case.FullName "*") -DestinationPath $zip -Force}catch{}
Write-Host("Closeout report: "+$html)
if(Test-Path -LiteralPath $zip){Write-Host("Case ZIP refreshed: "+$zip)}

if(Get-Command Clear-ToolkitActiveCaseState -ErrorAction SilentlyContinue){
 if(Clear-ToolkitActiveCaseState -ExpectedCaseId $case.Name){Write-Host("Active case cleared: "+$case.Name)}
}else{
 $activeCaseMarker=Join-Path $logs "ACTIVE_CASE.txt"
 if(Test-Path -LiteralPath $activeCaseMarker){
  $activeCase=(Get-Content -LiteralPath $activeCaseMarker -Raw -ErrorAction SilentlyContinue).Trim()
  if($activeCase -eq $case.Name){Remove-Item -LiteralPath $activeCaseMarker -Force -ErrorAction SilentlyContinue}
 }
}
try{Start-Process -FilePath $html}catch{}
exit 0

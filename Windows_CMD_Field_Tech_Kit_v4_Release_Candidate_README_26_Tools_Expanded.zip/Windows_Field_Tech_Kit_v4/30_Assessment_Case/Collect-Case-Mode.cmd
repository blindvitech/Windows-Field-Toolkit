@echo off
setlocal EnableExtensions
title Collect Case Mode

echo Collect Case Mode
echo.
echo Read-only case collection. It creates report files under Logs but does not change Windows configuration.
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Collect-Case-Mode.ps1"
set "RC=%errorlevel%"

echo.
if "%SRMODE%"=="1" (
    if "%RC%"=="0" (
        echo Collect Case Mode completed.
    ) else (
        echo Collect Case Mode returned error code %RC%.
    )
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

exit /b %RC%

@echo off
setlocal EnableExtensions
title Power / Sleep / Wake Investigator

echo Power / Sleep / Wake Investigator
echo.
echo Read-only diagnostic / assessment tool. Windows system state is not changed.
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Power-Sleep-Wake-Investigator.ps1"
set "RC=%errorlevel%"

echo.
if "%SRMODE%"=="1" (
    if "%RC%"=="0" (
        echo Power / Sleep / Wake Investigator completed.
    ) else (
        echo Power / Sleep / Wake Investigator returned error code %RC%.
    )
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

exit /b %RC%

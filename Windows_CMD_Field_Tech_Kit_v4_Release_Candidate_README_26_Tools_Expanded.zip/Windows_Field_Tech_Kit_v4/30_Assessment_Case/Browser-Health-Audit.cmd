@echo off
setlocal EnableExtensions
title Browser Health Audit

echo Browser Health Audit
echo.
echo Read-only diagnostic / assessment tool. Windows system state is not changed.
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Browser-Health-Audit.ps1"
set "RC=%errorlevel%"

echo.
if "%SRMODE%"=="1" (
    if "%RC%"=="0" (
        echo Browser Health Audit completed.
    ) else (
        echo Browser Health Audit returned error code %RC%.
    )
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

exit /b %RC%

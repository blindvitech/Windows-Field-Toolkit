@echo off
setlocal EnableExtensions
title Change Comparison Dashboard

echo Change Comparison Dashboard
echo.
echo Read-only comparison of existing files/folders. It creates a new comparison report under Logs.
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Change-Comparison-Dashboard.ps1"
set "RC=%errorlevel%"

echo.
if "%SRMODE%"=="1" (
    if "%RC%"=="0" (
        echo Change Comparison Dashboard completed.
    ) else (
        echo Change Comparison Dashboard returned error code %RC%.
    )
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

exit /b %RC%

@echo off
setlocal EnableExtensions
title USB / Removable Device History

echo USB / Removable Device History
echo.
echo Read-only diagnostic / assessment tool. Windows system state is not changed.
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0USB-Removable-Device-History.ps1"
set "RC=%errorlevel%"

echo.
if "%SRMODE%"=="1" (
    if "%RC%"=="0" (
        echo USB / Removable Device History completed.
    ) else (
        echo USB / Removable Device History returned error code %RC%.
    )
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

exit /b %RC%

@echo off
setlocal EnableExtensions
title Windows Servicing / Update Health Report

echo Windows Servicing / Update Health Report
echo.
echo Read-only umbrella report. No cleanup, repair, reset, update install,
echo or other Windows servicing change is performed.
echo.
echo Administrator rights are recommended for the deepest DISM/package data.
echo The report still runs without elevation and marks unavailable sections.
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Windows-Servicing-Update-Health-Report.ps1"
set "RC=%errorlevel%"

echo.
if "%SRMODE%"=="1" (
    if "%RC%"=="0" (
        echo Windows Servicing / Update Health Report completed.
    ) else (
        echo Windows Servicing / Update Health Report returned error code %RC%.
    )
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

exit /b %RC%

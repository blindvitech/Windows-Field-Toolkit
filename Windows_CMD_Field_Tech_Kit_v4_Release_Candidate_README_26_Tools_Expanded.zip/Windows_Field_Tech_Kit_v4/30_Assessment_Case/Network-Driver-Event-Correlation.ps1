$ErrorActionPreference = "SilentlyContinue"
$ProgressPreference = "SilentlyContinue"

$toolkitRoot = Split-Path $PSScriptRoot -Parent
$foundation = Join-Path $toolkitRoot "00_Common\Foundation-Common.ps1"
$diagnostic = Join-Path $toolkitRoot "00_Common\Diagnostic-Evidence.ps1"
$writer = Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"
if (Test-Path -LiteralPath $foundation -PathType Leaf) { . $foundation }
if (Test-Path -LiteralPath $diagnostic -PathType Leaf) { . $diagnostic }

$logs = Get-ToolkitLogRoot
$toolId = $(if($env:FIELDTECH_TOOL_ID){$env:FIELDTECH_TOOL_ID}else{"ADV-073"})
$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$basePath = Join-Path $logs ($env:COMPUTERNAME + "_Network_Driver_Event_Correlation_" + $stamp)

$findings = New-Object System.Collections.Generic.List[object]
$evidence = New-Object System.Collections.Generic.List[object]
$capabilities = New-Object System.Collections.Generic.List[object]

function Add-Section {
    param([System.Collections.Generic.List[string]]$Lines,[string]$Title,$Value)
    $Lines.Add("")
    $Lines.Add(("=" * 78))
    $Lines.Add($Title)
    $Lines.Add(("=" * 78))
    $text = ($Value | Out-String -Width 300).TrimEnd()
    if($text){$Lines.Add($text)}else{$Lines.Add("(No data returned)")}
}

$adapters = @(Get-NetAdapter -IncludeHidden -ErrorAction SilentlyContinue |
    Select-Object Name,InterfaceDescription,Status,LinkSpeed,MacAddress,ifIndex,DriverInformation,DriverFileName,DriverVersion,DriverDate,PnPDeviceID |
    Sort-Object ifIndex)
$activeAdapters = @($adapters | Where-Object { $_.Status -in @("Up","Disconnected") })

$driverInventory = @()
try {
    $driverInventory = @(Get-CimInstance Win32_PnPSignedDriver -ErrorAction Stop |
        Where-Object { $_.DeviceClass -eq "NET" } |
        Select-Object DeviceName,Manufacturer,DriverProviderName,DriverVersion,DriverDate,InfName,DeviceID,IsSigned,Signer |
        Sort-Object DeviceName)
    $capabilities.Add((New-ToolkitCapabilityStatus -Capability "Network driver inventory" -Available $true -Status "Available" -Detail ("Drivers: " + $driverInventory.Count) -SourceTool $toolId))
}
catch {
    $class=Get-ToolkitCapabilityFailureClassification -ExceptionMessage $_.Exception.Message -Context "Win32_PnPSignedDriver NET"
    $capabilities.Add((New-ToolkitCapabilityStatus -Capability "Network driver inventory" -Available $false -Status $class.Label -Detail $class.Detail -SourceTool $toolId))
}

$powerRows=New-Object System.Collections.Generic.List[object]
foreach($adapter in $activeAdapters) {
    try {
        $p=Get-NetAdapterPowerManagement -Name $adapter.Name -ErrorAction Stop
        $powerRows.Add([pscustomobject]@{
            Name=$adapter.Name
            AllowComputerToTurnOffDevice=$p.AllowComputerToTurnOffDevice
            WakeOnMagicPacket=$p.WakeOnMagicPacket
            WakeOnPattern=$p.WakeOnPattern
            DeviceSleepOnDisconnect=$p.DeviceSleepOnDisconnect
            ArpOffload=$p.ArpOffload
            NSOffload=$p.NSOffload
        })
    } catch {}
}

$stats=@(Get-NetAdapterStatistics -ErrorAction SilentlyContinue |
    Select-Object Name,ReceivedBytes,SentBytes,ReceivedUnicastPackets,SentUnicastPackets,
        ReceivedDiscardedPackets,OutboundDiscardedPackets,ReceivedPacketErrors,OutboundPacketErrors |
    Sort-Object Name)

$events=New-Object System.Collections.Generic.List[object]
$eventErrors=New-Object System.Collections.Generic.List[string]
$start=(Get-Date).AddHours(-48)

# System log: capture providers commonly associated with adapter, TCP/IP, DHCP,
# DNS and network stack behavior. Keep warning/error plus selected link lifecycle
# messages without hard-coding a single OEM driver.
try {
    $rows=@(Get-WinEvent -FilterHashtable @{LogName="System";StartTime=$start} -ErrorAction Stop |
        Where-Object {
            $_.ProviderName -match '(?i)(NDIS|NetAdapter|Netwtw|Tcpip|TcpIpReg|Dhcp|DNS|WLAN|e1[a-z0-9]*|e2[a-z0-9]*|rt[0-9a-z]+|Realtek|Killer|BTHUSB|USBXHCI)' -and
            ($_.Level -in 1,2,3 -or $_.Message -match '(?i)disconnect|connected|link|reset|timed out|timeout|failed|media')
        } |
        Select-Object -First 300 TimeCreated,Id,Level,LevelDisplayName,ProviderName,LogName,Message)
    foreach($row in $rows){$events.Add($row)}
}
catch {$eventErrors.Add(("System: "+$_.Exception.Message))}

try {
    $rows=@(Get-WinEvent -FilterHashtable @{LogName="Microsoft-Windows-WLAN-AutoConfig/Operational";StartTime=$start} -ErrorAction Stop |
        Where-Object { $_.Level -in 1,2,3 -or $_.Id -in 8000,8001,8002,8003,11000,11001,11002,11004 } |
        Select-Object -First 250 TimeCreated,Id,Level,LevelDisplayName,ProviderName,LogName,Message)
    foreach($row in $rows){$events.Add($row)}
}
catch {$eventErrors.Add(("WLAN-AutoConfig/Operational: "+$_.Exception.Message))}

try {
    $rows=@(Get-WinEvent -FilterHashtable @{LogName="Microsoft-Windows-Dhcp-Client/Operational";StartTime=$start} -ErrorAction Stop |
        Where-Object { $_.Level -in 1,2,3 } |
        Select-Object -First 150 TimeCreated,Id,Level,LevelDisplayName,ProviderName,LogName,Message)
    foreach($row in $rows){$events.Add($row)}
}
catch {$eventErrors.Add(("Dhcp-Client/Operational: "+$_.Exception.Message))}

$eventsSorted=@($events.ToArray() | Sort-Object TimeCreated -Descending)
if($eventsSorted.Count -gt 0) {
    $capabilities.Add((New-ToolkitCapabilityStatus -Capability "Network-related Windows event logs" -Available $true -Status "Available" -Detail ("Events collected: " + $eventsSorted.Count) -SourceTool $toolId))
} else {
    $class=Get-ToolkitCapabilityFailureClassification -ExceptionMessage ($eventErrors.ToArray() -join "; ") -NoData -Context "Network-related Windows event logs"
    $capabilities.Add((New-ToolkitCapabilityStatus -Capability "Network-related Windows event logs" -Available $false -Status $class.Label -Detail $class.Detail -SourceTool $toolId))
}

$adapterCorrelations=New-Object System.Collections.Generic.List[object]
foreach($adapter in $activeAdapters) {
    $tokens=New-Object System.Collections.Generic.List[string]
    foreach($candidate in @([string]$adapter.Name,[string]$adapter.InterfaceDescription,[string]$adapter.MacAddress)) {
        if(-not [string]::IsNullOrWhiteSpace($candidate) -and $candidate.Length -ge 4){$tokens.Add($candidate)}
    }
    $matches=@()
    foreach($evt in $eventsSorted) {
        $msg=[string]$evt.Message
        foreach($token in $tokens.ToArray()) {
            if($msg.IndexOf($token,[System.StringComparison]::OrdinalIgnoreCase) -ge 0) {
                $matches += $evt
                break
            }
        }
    }
    $warnError=@($matches | Where-Object {$_.Level -in 1,2,3})
    $adapterCorrelations.Add([pscustomobject]@{
        Adapter=$adapter.Name
        Description=$adapter.InterfaceDescription
        Status=$adapter.Status
        DriverVersion=$adapter.DriverVersion
        DriverDate=$adapter.DriverDate
        MatchedEvents=$matches.Count
        WarningErrorEvents=$warnError.Count
        MostRecentEvent=$(if($matches.Count -gt 0){($matches|Sort-Object TimeCreated -Descending|Select-Object -First 1).TimeCreated}else{$null})
    })
}

# Recurring provider/event pairs can indicate repeated stack/driver trouble, but
# the report deliberately labels this LIKELY rather than asserting causation.
$repeatGroups=@($eventsSorted | Where-Object {$_.Level -in 1,2,3} |
    Group-Object ProviderName,Id |
    Where-Object {$_.Count -ge 3} |
    Sort-Object Count -Descending)

foreach($g in $repeatGroups) {
    $sample=$g.Group|Sort-Object TimeCreated -Descending|Select-Object -First 1
    $findings.Add((New-ToolkitDiagnosticFinding -Severity "WARNING" -Category "Network" -Confidence "Likely" `
        -Evidence ("Repeated network-related warning/error event: " + $sample.ProviderName + " Event " + $sample.Id + " occurred " + $g.Count + " times in 48 hours.") `
        -Action "Review the matching event timeline beside adapter driver/version and link-state history before changing the driver." `
        -SourceTool $toolId -Source ([string]$sample.ProviderName) -EventId ([string]$sample.Id)))
}

foreach($adapter in $activeAdapters) {
    if([string]$adapter.Status -eq "Disconnected") {
        $findings.Add((New-ToolkitDiagnosticFinding -Severity "INFO" -Category "Network" -Confidence "Context" `
            -Evidence ("Adapter currently reports Disconnected: " + $adapter.Name + " | " + $adapter.InterfaceDescription) `
            -Device ([string]$adapter.InterfaceDescription) `
            -Action "Determine whether the adapter is expected to be unused before treating this as a fault." `
            -SourceTool $toolId -Source "Get-NetAdapter"))
    }
}

foreach($evt in $eventsSorted) {
    $msg=([string]$evt.Message).Trim()
    $evidence.Add([pscustomobject]@{
        EvidenceId=Get-ToolkitEvidenceId -Category "WindowsEvent" -Source ([string]$evt.ProviderName) `
            -EventId ([string]$evt.Id) -Timestamp $evt.TimeCreated -Device "" -Evidence $msg
        Class="Network Event"
        DeviceContext=""
        Timestamp=$evt.TimeCreated
        Source=[string]$evt.ProviderName
        EventId=[string]$evt.Id
        Evidence=$msg
    })
}

$lines=New-Object System.Collections.Generic.List[string]
$lines.Add("NETWORK DRIVER / EVENT CORRELATION")
$lines.Add("Computer: " + $env:COMPUTERNAME)
$lines.Add("Generated: " + (Get-Date))
$lines.Add("")
$lines.Add("Read-only correlation of network adapters, signed-driver inventory, power")
$lines.Add("management, adapter statistics, and recent Windows network-stack/driver events.")
$lines.Add("Correlation is contextual and does not by itself prove that a driver caused an event.")

Add-Section -Lines $lines -Title "NETWORK ADAPTERS" -Value $adapters
Add-Section -Lines $lines -Title "SIGNED NETWORK DRIVER INVENTORY" -Value $driverInventory
Add-Section -Lines $lines -Title "ADAPTER POWER MANAGEMENT" -Value $powerRows.ToArray()
Add-Section -Lines $lines -Title "ADAPTER STATISTICS" -Value $stats
Add-Section -Lines $lines -Title "ADAPTER / EVENT CORRELATION SUMMARY" -Value $adapterCorrelations.ToArray()
Add-Section -Lines $lines -Title "REPEATED WARNING / ERROR GROUPS" -Value ($repeatGroups | ForEach-Object {
    $s=$_.Group|Select-Object -First 1
    [pscustomobject]@{Provider=$s.ProviderName;EventId=$s.Id;Count=$_.Count;Newest=($_.Group|Sort-Object TimeCreated -Descending|Select-Object -First 1).TimeCreated}
})
Add-Section -Lines $lines -Title "NETWORK-RELATED EVENT TIMELINE (48H)" -Value $eventsSorted
Add-Section -Lines $lines -Title "EVENT QUERY NOTES" -Value $eventErrors.ToArray()
Add-Section -Lines $lines -Title "DIAGNOSTIC FINDINGS" -Value $findings.ToArray()
Add-Section -Lines $lines -Title "CAPABILITY / QUERY STATUS" -Value $capabilities.ToArray()

$body=$lines.ToArray() -join [Environment]::NewLine
& $writer -BasePath $basePath -Title "Network Driver / Event Correlation" -Body $body -ToolId $toolId
if(Get-Command Write-ToolkitDiagnosticSidecar -ErrorAction SilentlyContinue) {
    Write-ToolkitDiagnosticSidecar -BasePath $basePath -ToolkitRoot $toolkitRoot -ToolId $toolId `
        -Title "Network Driver / Event Correlation" -Findings $findings.ToArray() `
        -Evidence $evidence.ToArray() -Capabilities $capabilities.ToArray()
}
Write-Host ("Report: " + $basePath + ".html")
try { Start-Process -FilePath ($basePath + ".html") } catch {}
exit 0

$ErrorActionPreference="SilentlyContinue"
$ProgressPreference="SilentlyContinue"
$toolkitRoot=Split-Path $PSScriptRoot -Parent
$foundation=Join-Path $toolkitRoot "00_Common\Foundation-Common.ps1"
if(Test-Path -LiteralPath $foundation -PathType Leaf){. $foundation}
$logs=Join-Path $toolkitRoot "Logs"
if(-not(Test-Path -LiteralPath $logs)){New-Item -ItemType Directory -Path $logs -Force|Out-Null}
$writer=Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"
$stamp=Get-Date -Format "yyyyMMdd_HHmmss"
$basePath=Join-Path $logs ($env:COMPUTERNAME+"_Certificate_TLS_Audit_"+$stamp)
$now=Get-Date
$warnDate=$now.AddDays(45)

$certRows=New-Object System.Collections.Generic.List[object]
foreach($storePath in @("Cert:\CurrentUser\My","Cert:\LocalMachine\My","Cert:\LocalMachine\Root","Cert:\LocalMachine\CA")){
 if(Test-Path -LiteralPath $storePath){
  foreach($c in Get-ChildItem -LiteralPath $storePath -ErrorAction SilentlyContinue){
   $status=if($c.NotAfter -lt $now){"EXPIRED"}elseif($c.NotAfter -lt $warnDate){"EXPIRING <=45D"}else{"OK"}
   $eku=@($c.EnhancedKeyUsageList|ForEach-Object{$_.FriendlyName})-join", "
   $certRows.Add([pscustomobject]@{
    Store=$storePath;Status=$status;Subject=$c.Subject;Issuer=$c.Issuer;Thumbprint=$c.Thumbprint;
    NotBefore=$c.NotBefore;NotAfter=$c.NotAfter;HasPrivateKey=$c.HasPrivateKey;EnhancedKeyUsage=$eku
   })
  }
 }
}

$expired=@($certRows|Where-Object Status -eq "EXPIRED")
$expiring=@($certRows|Where-Object Status -eq "EXPIRING <=45D")

$schannel=Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL" -ErrorAction SilentlyContinue
$protocolRows=New-Object System.Collections.Generic.List[object]
$protocolRoot="HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols"
foreach($proto in @("SSL 2.0","SSL 3.0","TLS 1.0","TLS 1.1","TLS 1.2","TLS 1.3")){
 foreach($side in @("Client","Server")){
  $path=Join-Path (Join-Path $protocolRoot $proto) $side
  $p=Get-ItemProperty -LiteralPath $path -ErrorAction SilentlyContinue
  $protocolRows.Add([pscustomobject]@{
   Protocol=$proto;Side=$side;Enabled=$p.Enabled;DisabledByDefault=$p.DisabledByDefault;
   RegistryPath=$path
  })
 }
}

$winHttpNative=Invoke-ToolkitNativeCommand -FilePath "netsh.exe" -Arguments @("winhttp","show","proxy") -Label "Certificate TLS WinHTTP Proxy" -Action "Certificate TLS Audit" -Quiet
$winHttp=(($winHttpNative.Output -join [Environment]::NewLine)|Out-String -Width 260).TrimEnd()
$lines=New-Object System.Collections.Generic.List[string]
$lines.Add("CERTIFICATE / TLS AUDIT")
$lines.Add("Computer: "+$env:COMPUTERNAME);$lines.Add("Generated: "+(Get-Date))
$lines.Add("")
$lines.Add("Read-only review of selected user/machine certificate stores and explicit SCHANNEL protocol registry settings.")
$lines.Add("Missing TLS registry values are reported as blank because Windows defaults vary by version/build and policy.")
$lines.Add("This is not a PKI trust/compliance certification.")
$lines.Add("")
$lines.Add("Summary: certificates="+$certRows.Count+"; expired="+$expired.Count+"; expiring within 45 days="+$expiring.Count)

$lines.Add("");$lines.Add(("="*78));$lines.Add("EXPIRED / EXPIRING CERTIFICATES");$lines.Add(("="*78))
$x=@($certRows|Where-Object Status -ne "OK"|Sort-Object NotAfter)|Format-Table Status,Store,NotAfter,Subject,Issuer -Wrap -AutoSize|Out-String -Width 260
if($x.Trim()){$lines.Add($x.TrimEnd())}else{$lines.Add("(No expired or <=45-day certificates found in audited stores.)")}

$lines.Add("");$lines.Add(("="*78));$lines.Add("CERTIFICATE INVENTORY");$lines.Add(("="*78))
$lines.Add(($certRows|Sort-Object Store,NotAfter|Format-Table Store,Status,NotAfter,HasPrivateKey,Subject -Wrap -AutoSize|Out-String -Width 260).TrimEnd())

$lines.Add("");$lines.Add(("="*78));$lines.Add("SCHANNEL TLS/SSL EXPLICIT REGISTRY SETTINGS");$lines.Add(("="*78))
$lines.Add(($protocolRows|Format-Table -AutoSize|Out-String -Width 260).TrimEnd())

$lines.Add("");$lines.Add(("="*78));$lines.Add("WINHTTP PROXY");$lines.Add(("="*78));$lines.Add($winHttp)

$body=$lines -join [Environment]::NewLine
& $writer -BasePath $basePath -Title "Certificate and TLS Audit" -Body $body
$html=$basePath+".html";Write-Host("Report: "+$html)
try{Start-Process -FilePath $html}catch{}
exit 0

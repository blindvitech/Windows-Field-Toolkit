@echo off
setlocal EnableExtensions
title User Profile Health Audit

echo User Profile Health Audit
echo.
echo Read-only assessment tool. Windows system state is not changed.
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Profile-Health-Audit.ps1"
set "RC=%errorlevel%"

echo.
if "%SRMODE%"=="1" (
    if "%RC%"=="0" (
        echo User Profile Health Audit completed.
    ) else (
        echo User Profile Health Audit returned error code %RC%.
    )
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

exit /b %RC%

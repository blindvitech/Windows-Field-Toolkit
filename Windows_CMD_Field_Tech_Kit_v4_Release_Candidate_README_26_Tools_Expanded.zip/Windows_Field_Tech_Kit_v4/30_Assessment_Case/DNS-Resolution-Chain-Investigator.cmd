@echo off
setlocal EnableExtensions
title DNS Resolution Chain Investigator

echo DNS Resolution Chain Investigator
echo.
echo Read-only network diagnostic / assessment tool. Windows system state is not changed.
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0DNS-Resolution-Chain-Investigator.ps1"
set "RC=%errorlevel%"

echo.
if "%SRMODE%"=="1" (
    if "%RC%"=="0" (
        echo DNS Resolution Chain Investigator completed.
    ) else (
        echo DNS Resolution Chain Investigator returned error code %RC%.
    )
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

exit /b %RC%

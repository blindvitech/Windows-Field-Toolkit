@echo off
setlocal EnableExtensions
title Scheduled Task Investigator

echo Scheduled Task Investigator
echo.
echo Read-only diagnostic / assessment tool. Windows system state is not changed.
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Scheduled-Task-Investigator.ps1"
set "RC=%errorlevel%"

echo.
if "%SRMODE%"=="1" (
    if "%RC%"=="0" (
        echo Scheduled Task Investigator completed.
    ) else (
        echo Scheduled Task Investigator returned error code %RC%.
    )
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

exit /b %RC%

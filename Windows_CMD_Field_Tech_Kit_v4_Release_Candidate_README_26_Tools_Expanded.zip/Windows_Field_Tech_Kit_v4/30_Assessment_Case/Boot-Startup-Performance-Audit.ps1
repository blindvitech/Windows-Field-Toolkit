$ErrorActionPreference="SilentlyContinue"
$ProgressPreference="SilentlyContinue"
$toolkitRoot=Split-Path $PSScriptRoot -Parent
$foundation=Join-Path $toolkitRoot "00_Common\Foundation-Common.ps1"
if(Test-Path -LiteralPath $foundation -PathType Leaf){. $foundation}
$logs=Join-Path $toolkitRoot "Logs"
if(-not(Test-Path -LiteralPath $logs)){New-Item -ItemType Directory -Path $logs -Force|Out-Null}
$writer=Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"
$stamp=Get-Date -Format "yyyyMMdd_HHmmss"
$basePath=Join-Path $logs ($env:COMPUTERNAME+"_Boot_Startup_Performance_Audit_"+$stamp)

$os=Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
$fast=Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power" -ErrorAction SilentlyContinue
$startup=Get-CimInstance Win32_StartupCommand -ErrorAction SilentlyContinue |
 Select-Object Name,Command,Location,User | Sort-Object Name
$autoServices=Get-CimInstance Win32_Service -ErrorAction SilentlyContinue |
 Where-Object StartMode -eq "Auto" |
 Select-Object Name,State,StartMode,StartName,PathName | Sort-Object Name
$bootTasks=@()
try{
 $bootTasks=Get-ScheduledTask -ErrorAction Stop | Where-Object {
  $_.Triggers | Where-Object { $_.CimClass.CimClassName -match 'BootTrigger|LogonTrigger' }
 } | Select-Object TaskPath,TaskName,State,@{N="Actions";E={($_.Actions.Execute -join "; ")}}
}catch{}

$perf=@()
$perfLog="Microsoft-Windows-Diagnostics-Performance/Operational"
try{
 $perf=Get-WinEvent -FilterHashtable @{LogName=$perfLog;StartTime=(Get-Date).AddDays(-14);Id=100,101,102,103,106,107,108,109,110} -ErrorAction Stop |
  Sort-Object TimeCreated -Descending | Select-Object -First 100 TimeCreated,Id,LevelDisplayName,
   @{N="Message";E={($_.Message-replace"[\r\n]+"," "-replace"\s{2,}"," ").Trim()}}
}catch{}

$kernel=@()
try{
 $kernel=Get-WinEvent -FilterHashtable @{LogName="System";StartTime=(Get-Date).AddDays(-14);Id=12,13,6005,6006,6008,41} -ErrorAction Stop |
  Sort-Object TimeCreated -Descending | Select-Object -First 100 TimeCreated,Id,ProviderName,
   @{N="Message";E={($_.Message-replace"[\r\n]+"," "-replace"\s{2,}"," ").Trim()}}
}catch{}

$powerANative=Invoke-ToolkitNativeCommand -FilePath "powercfg.exe" -Arguments @("/a") -Label "Boot Audit Sleep States" -Action "Boot Startup Performance Audit" -Quiet
$powerA=(($powerANative.Output -join [Environment]::NewLine)|Out-String -Width 260).TrimEnd()
$activeSchemeNative=Invoke-ToolkitNativeCommand -FilePath "powercfg.exe" -Arguments @("/getactivescheme") -Label "Boot Audit Active Power Scheme" -Action "Boot Startup Performance Audit" -Quiet
$activeScheme=(($activeSchemeNative.Output -join [Environment]::NewLine)|Out-String -Width 260).TrimEnd()

$lines=New-Object System.Collections.Generic.List[string]
$lines.Add("BOOT / STARTUP PERFORMANCE AUDIT")
$lines.Add("Computer: "+$env:COMPUTERNAME);$lines.Add("Generated: "+(Get-Date))
$lines.Add("Last boot: "+$os.LastBootUpTime)
$lines.Add("Fast Startup HiberbootEnabled: "+$fast.HiberbootEnabled)
$lines.Add("")
$lines.Add("Read-only audit. Diagnostics-Performance event availability depends on Windows logging configuration.")
foreach($pair in @(
 @("DIAGNOSTICS-PERFORMANCE BOOT/STARTUP EVENTS - 14 DAYS",$perf),
 @("SYSTEM BOOT/SHUTDOWN EVENTS - 14 DAYS",$kernel),
 @("STARTUP COMMANDS",$startup),
 @("AUTO-START SERVICES",$autoServices),
 @("BOOT / LOGON SCHEDULED TASKS",$bootTasks)
)){
 $lines.Add("");$lines.Add(("="*78));$lines.Add($pair[0]);$lines.Add(("="*78))
 $x=($pair[1]|Out-String -Width 260).TrimEnd();if($x){$lines.Add($x)}else{$lines.Add("(No data returned)")}
}
$lines.Add("");$lines.Add(("="*78));$lines.Add("POWERCFG /A");$lines.Add(("="*78));$lines.Add($powerA)
$lines.Add("");$lines.Add(("="*78));$lines.Add("ACTIVE POWER SCHEME");$lines.Add(("="*78));$lines.Add($activeScheme)
$body=$lines -join [Environment]::NewLine
& $writer -BasePath $basePath -Title "Boot and Startup Performance Audit" -Body $body
$html=$basePath+".html";Write-Host("Report: "+$html);try{Start-Process -FilePath $html}catch{}
exit 0

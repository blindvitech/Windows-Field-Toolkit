$ErrorActionPreference = "SilentlyContinue"
$ProgressPreference = "SilentlyContinue"

$toolkitRoot = Split-Path $PSScriptRoot -Parent
$foundation = Join-Path $toolkitRoot "00_Common\Foundation-Common.ps1"
$diagnostic = Join-Path $toolkitRoot "00_Common\Diagnostic-Evidence.ps1"
$writer = Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"
if (Test-Path -LiteralPath $foundation -PathType Leaf) { . $foundation }
if (Test-Path -LiteralPath $diagnostic -PathType Leaf) { . $diagnostic }

$logs = Get-ToolkitLogRoot
$toolId = $(if($env:FIELDTECH_TOOL_ID){$env:FIELDTECH_TOOL_ID}else{"ADV-072"})
$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$basePath = Join-Path $logs ($env:COMPUTERNAME + "_DHCP_Lease_State_" + $stamp)

$findings = New-Object System.Collections.Generic.List[object]
$evidence = New-Object System.Collections.Generic.List[object]
$capabilities = New-Object System.Collections.Generic.List[object]

function Add-Section {
    param([System.Collections.Generic.List[string]]$Lines,[string]$Title,$Value)
    $Lines.Add("")
    $Lines.Add(("=" * 78))
    $Lines.Add($Title)
    $Lines.Add(("=" * 78))
    $text = ($Value | Out-String -Width 260).TrimEnd()
    if ($text) { $Lines.Add($text) } else { $Lines.Add("(No data returned)") }
}

$netAdapters = @(Get-NetAdapter -ErrorAction SilentlyContinue |
    Select-Object Name,InterfaceDescription,Status,LinkSpeed,MacAddress,ifIndex |
    Sort-Object ifIndex)
$ipConfig = @(Get-NetIPConfiguration -ErrorAction SilentlyContinue |
    Select-Object InterfaceAlias,InterfaceDescription,InterfaceIndex,
        @{N="IPv4";E={$_.IPv4Address.IPAddress -join ", "}},
        @{N="IPv6";E={$_.IPv6Address.IPAddress -join ", "}},
        @{N="Gateway";E={$_.IPv4DefaultGateway.NextHop -join ", "}},
        @{N="DNS";E={$_.DNSServer.ServerAddresses -join ", "}} |
    Sort-Object InterfaceIndex)

$dhcpWmi = @()
$dhcpWmiError = ""
try {
    $dhcpWmi = @(Get-CimInstance Win32_NetworkAdapterConfiguration -ErrorAction Stop |
        Where-Object { $_.IPEnabled -or $_.DHCPEnabled } |
        Select-Object Description,SettingID,InterfaceIndex,IPEnabled,DHCPEnabled,DHCPServer,
            DHCPLeaseObtained,DHCPLeaseExpires,
            @{N="IPAddress";E={$_.IPAddress -join ", "}},
            @{N="DefaultGateway";E={$_.DefaultIPGateway -join ", "}},
            @{N="DNSServers";E={$_.DNSServerSearchOrder -join ", "}})
    $capabilities.Add((New-ToolkitCapabilityStatus -Capability "DHCP adapter configuration" -Available $true -Status "Available" -Detail ("Rows: " + $dhcpWmi.Count) -SourceTool $toolId))
}
catch {
    $dhcpWmiError = $_.Exception.Message
    $class = Get-ToolkitCapabilityFailureClassification -ExceptionMessage $dhcpWmiError -Context "Win32_NetworkAdapterConfiguration"
    $capabilities.Add((New-ToolkitCapabilityStatus -Capability "DHCP adapter configuration" -Available $false -Status $class.Label -Detail $class.Detail -SourceTool $toolId))
}

$ipInterface = @(Get-NetIPInterface -AddressFamily IPv4 -ErrorAction SilentlyContinue |
    Select-Object InterfaceAlias,InterfaceIndex,ConnectionState,Dhcp,AutomaticMetric,InterfaceMetric,NlMtu,WeakHostSend,WeakHostReceive |
    Sort-Object InterfaceIndex)

$addresses = @(Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
    Select-Object InterfaceAlias,InterfaceIndex,IPAddress,PrefixLength,PrefixOrigin,SuffixOrigin,AddressState,ValidLifetime,PreferredLifetime |
    Sort-Object InterfaceIndex,IPAddress)

$service = Get-Service -Name Dhcp -ErrorAction SilentlyContinue |
    Select-Object Name,DisplayName,Status,StartType

$registryRows = New-Object System.Collections.Generic.List[object]
$interfacesKey = "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces"
if (Test-Path -LiteralPath $interfacesKey) {
    foreach($key in @(Get-ChildItem -LiteralPath $interfacesKey -ErrorAction SilentlyContinue)) {
        $v = Get-ItemProperty -LiteralPath $key.PSPath -ErrorAction SilentlyContinue
        if($v) {
            $registryRows.Add([pscustomobject]@{
                InterfaceGuid=$key.PSChildName
                EnableDHCP=$v.EnableDHCP
                DhcpIPAddress=$v.DhcpIPAddress
                DhcpSubnetMask=$v.DhcpSubnetMask
                DhcpDefaultGateway=($v.DhcpDefaultGateway -join ", ")
                DhcpNameServer=$v.DhcpNameServer
                NameServer=$v.NameServer
                DhcpServer=$v.DhcpServer
                Lease=$v.Lease
                LeaseObtainedTime=$v.LeaseObtainedTime
                T1=$v.T1
                T2=$v.T2
            })
        }
    }
}

$ipconfigNative = Invoke-ToolkitNativeCommand -FilePath "ipconfig.exe" -Arguments @("/all") -Label "DHCP Deep Dive ipconfig" -Action "DHCP Lease State Deep Dive" -Quiet
$ipconfigText = ($ipconfigNative.Output -join [Environment]::NewLine).TrimEnd()

$dhcpEvents = New-Object System.Collections.Generic.List[object]
$eventQueries = @(
    [pscustomobject]@{Log="Microsoft-Windows-Dhcp-Client/Admin";Provider=""},
    [pscustomobject]@{Log="Microsoft-Windows-Dhcp-Client/Operational";Provider=""},
    [pscustomobject]@{Log="System";Provider="Microsoft-Windows-Dhcp-Client"}
)
$eventReadCount = 0
$eventErrors = New-Object System.Collections.Generic.List[string]
$start = (Get-Date).AddHours(-48)
foreach($spec in $eventQueries) {
    try {
        $filter = @{LogName=$spec.Log;StartTime=$start}
        if($spec.Provider){$filter.ProviderName=$spec.Provider}
        $rows = @(Get-WinEvent -FilterHashtable $filter -ErrorAction Stop |
            Where-Object { $_.Level -in 1,2,3 -or $_.Id -in 1001,1002,1003,1004,50034,50036,50058 } |
            Select-Object -First 100 TimeCreated,Id,Level,LevelDisplayName,ProviderName,LogName,Message)
        foreach($row in $rows){$dhcpEvents.Add($row)}
        $eventReadCount++
    }
    catch {
        $eventErrors.Add(($spec.Log + ": " + $_.Exception.Message))
    }
}
if($eventReadCount -gt 0) {
    $capabilities.Add((New-ToolkitCapabilityStatus -Capability "DHCP event logs" -Available $true -Status "Available" -Detail ("Readable log queries: " + $eventReadCount) -SourceTool $toolId))
} else {
    $class = Get-ToolkitCapabilityFailureClassification -ExceptionMessage ($eventErrors.ToArray() -join "; ") -Context "DHCP event logs"
    $capabilities.Add((New-ToolkitCapabilityStatus -Capability "DHCP event logs" -Available $false -Status $class.Label -Detail $class.Detail -SourceTool $toolId))
}

foreach($row in $dhcpWmi) {
    if([bool]$row.DHCPEnabled) {
        $ipText = [string]$row.IPAddress
        if($ipText -match '(^|,\s*)169\.254\.') {
            $findings.Add((New-ToolkitDiagnosticFinding -Severity "ERROR" -Category "DHCP" -Confidence "Confirmed" `
                -Evidence ("DHCP-enabled adapter has an APIPA address: " + $row.Description + " | " + $ipText) `
                -Device ([string]$row.Description) -Action "Check physical/link state, VLAN, DHCP reachability, and adapter/driver events." `
                -SourceTool $toolId -Source "Win32_NetworkAdapterConfiguration"))
        }
        if([string]::IsNullOrWhiteSpace([string]$row.DHCPServer)) {
            $findings.Add((New-ToolkitDiagnosticFinding -Severity "WARNING" -Category "DHCP" -Confidence "Likely" `
                -Evidence ("DHCP is enabled but no DHCP server is recorded for adapter: " + $row.Description) `
                -Device ([string]$row.Description) -Action "Confirm the adapter currently has a valid lease and can reach the expected DHCP service." `
                -SourceTool $toolId -Source "Win32_NetworkAdapterConfiguration"))
        }
        if($row.DHCPLeaseExpires) {
            try {
                $expires=[datetime]$row.DHCPLeaseExpires
                if($expires -lt (Get-Date)) {
                    $findings.Add((New-ToolkitDiagnosticFinding -Severity "ERROR" -Category "DHCP" -Confidence "Confirmed" `
                        -Evidence ("Recorded DHCP lease is expired for adapter: " + $row.Description + " | expired " + $expires) `
                        -Device ([string]$row.Description) -Action "Investigate renewal failures before forcing repair/reset." `
                        -SourceTool $toolId -Source "Win32_NetworkAdapterConfiguration"))
                }
            } catch {}
        }
    }
}

foreach($addr in $addresses) {
    if([string]$addr.IPAddress -match '^169\.254\.' -and [string]$addr.AddressState -ne "Deprecated") {
        $already=@($findings.ToArray() | Where-Object { $_.Evidence -match [regex]::Escape([string]$addr.IPAddress) }).Count
        if($already -eq 0) {
            $findings.Add((New-ToolkitDiagnosticFinding -Severity "ERROR" -Category "DHCP" -Confidence "Confirmed" `
                -Evidence ("APIPA IPv4 address detected: " + $addr.InterfaceAlias + " | " + $addr.IPAddress) `
                -Device ([string]$addr.InterfaceAlias) -Action "Check DHCP path, switch/VLAN, wireless association, and adapter events." `
                -SourceTool $toolId -Source "Get-NetIPAddress"))
        }
    }
}

foreach($evt in $dhcpEvents.ToArray()) {
    $msg = ([string]$evt.Message).Trim()
    $ev = [pscustomobject]@{
        EvidenceId = Get-ToolkitEvidenceId -Category "WindowsEvent" -Source ([string]$evt.ProviderName) `
            -EventId ([string]$evt.Id) -Timestamp $evt.TimeCreated -Device "" -Evidence $msg
        Class = "DHCP Event"
        DeviceContext = ""
        Timestamp = $evt.TimeCreated
        Source = [string]$evt.ProviderName
        EventId = [string]$evt.Id
        Evidence = $msg
    }
    $evidence.Add($ev)
}

$lines=New-Object System.Collections.Generic.List[string]
$lines.Add("DHCP LEASE / STATE DEEP DIVE")
$lines.Add("Computer: " + $env:COMPUTERNAME)
$lines.Add("Generated: " + (Get-Date))
$lines.Add("")
$lines.Add("Read-only inspection of adapter DHCP state, lease timing, IPv4 origin/state,")
$lines.Add("registry lease data, DHCP Client service state, ipconfig context, and recent DHCP events.")

Add-Section -Lines $lines -Title "NETWORK ADAPTERS" -Value $netAdapters
Add-Section -Lines $lines -Title "IP CONFIGURATION" -Value $ipConfig
Add-Section -Lines $lines -Title "DHCP ADAPTER CONFIGURATION" -Value $(if($dhcpWmi.Count -gt 0){$dhcpWmi}else{$dhcpWmiError})
Add-Section -Lines $lines -Title "IPv4 INTERFACE DHCP STATE" -Value $ipInterface
Add-Section -Lines $lines -Title "IPv4 ADDRESS ORIGIN / LIFETIME" -Value $addresses
Add-Section -Lines $lines -Title "DHCP CLIENT SERVICE" -Value $service
Add-Section -Lines $lines -Title "TCP/IP INTERFACE REGISTRY LEASE CONTEXT" -Value $registryRows.ToArray()
Add-Section -Lines $lines -Title "IPCONFIG /ALL" -Value $ipconfigText
Add-Section -Lines $lines -Title "RECENT DHCP CLIENT EVENTS (48H)" -Value $dhcpEvents.ToArray()
Add-Section -Lines $lines -Title "DHCP EVENT QUERY NOTES" -Value $eventErrors.ToArray()
Add-Section -Lines $lines -Title "DIAGNOSTIC FINDINGS" -Value $findings.ToArray()
Add-Section -Lines $lines -Title "CAPABILITY / QUERY STATUS" -Value $capabilities.ToArray()

$body=$lines.ToArray() -join [Environment]::NewLine
& $writer -BasePath $basePath -Title "DHCP Lease / State Deep Dive" -Body $body -ToolId $toolId
if(Get-Command Write-ToolkitDiagnosticSidecar -ErrorAction SilentlyContinue) {
    Write-ToolkitDiagnosticSidecar -BasePath $basePath -ToolkitRoot $toolkitRoot -ToolId $toolId `
        -Title "DHCP Lease / State Deep Dive" -Findings $findings.ToArray() `
        -Evidence $evidence.ToArray() -Capabilities $capabilities.ToArray()
}
Write-Host ("Report: " + $basePath + ".html")
try { Start-Process -FilePath ($basePath + ".html") } catch {}
exit 0

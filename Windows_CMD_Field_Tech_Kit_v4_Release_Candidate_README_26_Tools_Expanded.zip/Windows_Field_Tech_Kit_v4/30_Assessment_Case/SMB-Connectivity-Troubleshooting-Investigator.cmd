@echo off
setlocal EnableExtensions
title SMB Connectivity / Troubleshooting Investigator

echo SMB Connectivity / Troubleshooting Investigator
echo.
echo Modes 1 through 4 are read-only diagnostics.
echo Mode 5 performs one explicitly confirmed SMB authentication attempt.
echo Credential-test usernames, passwords, and tested server/share names are never written to toolkit logs or reports.
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0SMB-Connectivity-Troubleshooting-Investigator.ps1"
set "RC=%errorlevel%"

echo.
if "%SRMODE%"=="1" (
    if "%RC%"=="0" (
        echo SMB Connectivity / Troubleshooting Investigator completed.
    ) else (
        echo SMB Connectivity / Troubleshooting Investigator returned error code %RC%.
    )
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

exit /b %RC%

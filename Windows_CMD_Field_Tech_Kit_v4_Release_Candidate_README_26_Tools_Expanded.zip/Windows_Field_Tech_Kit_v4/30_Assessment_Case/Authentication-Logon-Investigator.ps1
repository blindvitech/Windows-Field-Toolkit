$screenReaderCommon = Join-Path (Split-Path $PSScriptRoot -Parent) "00_Common\ScreenReader-Common.ps1"
if (Test-Path -LiteralPath $screenReaderCommon -PathType Leaf) {
    . $screenReaderCommon
}

$ErrorActionPreference="SilentlyContinue"
$ProgressPreference="SilentlyContinue"
$toolkitRoot=Split-Path $PSScriptRoot -Parent
$logs=Join-Path $toolkitRoot "Logs"
if(-not(Test-Path -LiteralPath $logs)){New-Item -ItemType Directory -Path $logs -Force|Out-Null}
$writer=Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"

Write-Host "AUTHENTICATION / LOGON INVESTIGATOR"
Write-Host "Lookback: 1=24 hours, 2=3 days, 3=7 days, 4=14 days"
$c=Read-ToolkitPrompt "Select 1 through 4";$days=7
switch($c){"1"{$days=1};"2"{$days=3};"3"{$days=7};"4"{$days=14}}
$start=(Get-Date).AddDays(-$days)
$stamp=Get-Date -Format "yyyyMMdd_HHmmss"
$basePath=Join-Path $logs ($env:COMPUTERNAME+"_Authentication_Logon_Investigator_"+$stamp)

$identity=(& whoami.exe /all 2>&1|Out-String -Width 260).TrimEnd()
$dsreg=(& dsregcmd.exe /status 2>&1|Out-String -Width 260).TrimEnd()
$users=Get-LocalUser -ErrorAction SilentlyContinue|Select-Object Name,Enabled,LastLogon,PasswordExpires,UserMayChangePassword
$admins=@();try{$admins=Get-LocalGroupMember -Group Administrators -ErrorAction Stop|Select-Object Name,ObjectClass,PrincipalSource}catch{}

$security=@()
$securityNote=""
try{
 $security=Get-WinEvent -FilterHashtable @{LogName="Security";StartTime=$start;Id=4624,4625,4634,4648,4672,4740,4771,4776} -ErrorAction Stop|
  Sort-Object TimeCreated -Descending|Select-Object -First 250 TimeCreated,Id,LevelDisplayName,@{N="Message";E={
   $m=($_.Message-replace"[\r\n]+"," "-replace"\s{2,}"," ").Trim();if($m.Length -gt 900){$m.Substring(0,900)+"..."}else{$m}
  }}
}catch{$securityNote="Security log could not be read. Run elevated if detailed logon/security events are needed."}

$system=@()
try{
 $system=Get-WinEvent -FilterHashtable @{LogName="System";StartTime=$start;Level=1,2,3} -ErrorAction Stop|
  Where-Object{$_.ProviderName -match '(?i)(Netlogon|Kerberos|LsaSrv|GroupPolicy)' -or $_.Message -match '(?i)(authentication|logon|credential|trust relationship|domain controller)'}|
  Sort-Object TimeCreated -Descending|Select-Object -First 150 TimeCreated,Id,ProviderName,LevelDisplayName,@{N="Message";E={($_.Message-replace"[\r\n]+"," "-replace"\s{2,}"," ").Trim()}}
}catch{}

$lines=New-Object System.Collections.Generic.List[string]
$lines.Add("AUTHENTICATION / LOGON INVESTIGATOR");$lines.Add("Computer: "+$env:COMPUTERNAME);$lines.Add("Generated: "+(Get-Date));$lines.Add("Lookback: "+$days+" days")
$lines.Add("");$lines.Add("Read-only authentication/logon investigation. No passwords or credential secrets are collected.")
if($securityNote){$lines.Add("NOTE: "+$securityNote)}
foreach($pair in @(@("LOCAL USERS",$users),@("LOCAL ADMINISTRATORS",$admins),@("SECURITY LOGON / AUTHENTICATION EVENTS",$security),@("SYSTEM AUTHENTICATION / DOMAIN EVENTS",$system))){
 $lines.Add("");$lines.Add(("="*78));$lines.Add($pair[0]);$lines.Add(("="*78));$x=($pair[1]|Out-String -Width 260).TrimEnd();if($x){$lines.Add($x)}else{$lines.Add("(No data returned)")}
}
$lines.Add("");$lines.Add(("="*78));$lines.Add("WHOAMI /ALL");$lines.Add(("="*78));$lines.Add($identity)
$lines.Add("");$lines.Add(("="*78));$lines.Add("DSREGCMD /STATUS");$lines.Add(("="*78));$lines.Add($dsreg)
$body=$lines -join [Environment]::NewLine
& $writer -BasePath $basePath -Title "Authentication and Logon Investigator" -Body $body
$html=$basePath+".html";Write-Host("Report: "+$html);try{Start-Process -FilePath $html}catch{}
exit 0

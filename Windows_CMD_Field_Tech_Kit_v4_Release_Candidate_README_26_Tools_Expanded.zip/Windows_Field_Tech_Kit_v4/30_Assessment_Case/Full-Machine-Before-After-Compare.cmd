@echo off
setlocal EnableExtensions
title Full Machine Before / After Compare

echo Full Machine Before / After Compare
echo.
echo Assessment / comparison tool. It only creates or deletes its own baseline/report files under Logs.
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Full-Machine-Before-After-Compare.ps1"
set "RC=%errorlevel%"

echo.
if "%SRMODE%"=="1" (
    if "%RC%"=="0" (
        echo Full Machine Before / After Compare completed.
    ) else (
        echo Full Machine Before / After Compare returned error code %RC%.
    )
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

exit /b %RC%

$ErrorActionPreference = "SilentlyContinue"
$ProgressPreference = "SilentlyContinue"
$toolkitRoot = Split-Path $PSScriptRoot -Parent
$logs = Join-Path $toolkitRoot "Logs"
if (-not (Test-Path -LiteralPath $logs)) { New-Item -ItemType Directory -Path $logs -Force | Out-Null }
$writer = Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"
$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$basePath = Join-Path $logs ($env:COMPUTERNAME + "_Profile_Health_Audit_" + $stamp)

function Add-Section {
    param([System.Collections.Generic.List[string]]$Lines,[string]$Title,$Data,[string]$Note="")
    $Lines.Add("")
    $Lines.Add(("=" * 78)); $Lines.Add($Title); $Lines.Add(("=" * 78))
    if ($Note) { $Lines.Add("NOTE: " + $Note) }
    $text = ($Data | Out-String -Width 260).TrimEnd()
    if ([string]::IsNullOrWhiteSpace($text)) { $Lines.Add("(No data returned)") } else { $Lines.Add($text) }
}

$profileListRoot = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList"
$registryProfiles=@()
if (Test-Path -LiteralPath $profileListRoot) {
    foreach ($key in Get-ChildItem -LiteralPath $profileListRoot -ErrorAction SilentlyContinue) {
        $p=Get-ItemProperty -LiteralPath $key.PSPath -ErrorAction SilentlyContinue
        if ($p.ProfileImagePath) {
            $expanded=[Environment]::ExpandEnvironmentVariables([string]$p.ProfileImagePath)
            $registryProfiles += [pscustomobject]@{
                SID=$key.PSChildName; ProfileImagePath=$expanded; State=$p.State; RefCount=$p.RefCount;
                KeyEndsInBak=$key.PSChildName.EndsWith(".bak",[System.StringComparison]::OrdinalIgnoreCase);
                FolderExists=Test-Path -LiteralPath $expanded -PathType Container
            }
        }
    }
}
$cimProfiles=@(Get-CimInstance Win32_UserProfile -ErrorAction SilentlyContinue |
    Where-Object { -not $_.Special } |
    Select-Object SID,LocalPath,Loaded,RoamingConfigured,RoamingPath,LastUseTime,Status)

$health=New-Object System.Collections.Generic.List[object]
foreach ($reg in $registryProfiles | Where-Object { $_.SID -match '^S-1-5-21-' }) {
    $sid=$reg.SID -replace '\.bak$',''
    $cim=$cimProfiles | Where-Object SID -eq $sid | Select-Object -First 1
    $ntuser=Join-Path $reg.ProfileImagePath "NTUSER.DAT"
    $nt=Get-Item -LiteralPath $ntuser -Force -ErrorAction SilentlyContinue
    $hints=New-Object System.Collections.Generic.List[string]
    if ($reg.KeyEndsInBak) { $hints.Add("ProfileList .bak key present") }
    if ($reg.ProfileImagePath -match '(?i)\\TEMP(?:\.|\\|$)') { $hints.Add("Profile path resembles TEMP profile") }
    if (-not $reg.FolderExists) { $hints.Add("Profile folder missing") }
    if ($null -ne $reg.State -and [int64]$reg.State -ne 0) { $hints.Add("ProfileList State=" + $reg.State) }
    if (-not $nt -and $reg.FolderExists) { $hints.Add("NTUSER.DAT not found") }
    $health.Add([pscustomobject]@{
        SID=$reg.SID; ProfilePath=$reg.ProfileImagePath; Loaded=$cim.Loaded; LastUseTime=$cim.LastUseTime;
        FolderExists=$reg.FolderExists; NTUSER_DAT_Present=[bool]$nt;
        NTUSER_DAT_LastWrite=$(if ($nt) { $nt.LastWriteTime } else { $null });
        RoamingConfigured=$cim.RoamingConfigured;
        HealthHints=$(if ($hints.Count) { $hints -join "; " } else { "No obvious mapping warning detected" })
    })
}

$events=@()
foreach ($logName in @("Application","System")) {
    try {
        $events += Get-WinEvent -FilterHashtable @{LogName=$logName; StartTime=(Get-Date).AddDays(-14); Level=1,2,3} -ErrorAction Stop |
            Where-Object {
                $_.ProviderName -match '(?i)(User Profile Service|User Profiles Service|ProfSvc)' -or
                $_.Message -match '(?i)(temporary profile|user profile|profile cannot be loaded)'
            } |
            Select-Object -First 100 TimeCreated,LogName,Id,ProviderName,LevelDisplayName,
                @{N="Message";E={($_.Message -replace "[\r\n]+"," " -replace "\s{2,}"," ").Trim()}}
    } catch {}
}
$events=@($events | Sort-Object TimeCreated -Descending | Select-Object -First 100)

$lines=New-Object System.Collections.Generic.List[string]
$lines.Add("USER PROFILE HEALTH AUDIT")
$lines.Add("Computer: " + $env:COMPUTERNAME); $lines.Add("Generated: " + (Get-Date))
$lines.Add("Current user: " + $env:USERDOMAIN + "\" + $env:USERNAME)
$lines.Add("Current profile: " + $env:USERPROFILE)
$lines.Add("")
$lines.Add("Read-only audit for profile mapping, .bak keys, missing folders, TEMP-like paths,")
$lines.Add("NTUSER.DAT presence, and recent profile-service warnings/errors.")
$lines.Add("Warnings are troubleshooting clues, not proof of profile corruption.")
$warningCount=@($health | Where-Object HealthHints -notlike "No obvious*").Count
$lines.Add("Profiles checked: " + $health.Count + "; profiles with warning hints: " + $warningCount)
Add-Section $lines "PROFILE HEALTH SUMMARY" $health
Add-Section $lines "WIN32_USERPROFILE INVENTORY" $cimProfiles
Add-Section $lines "RECENT PROFILE-RELATED EVENTS - 14 DAYS" $events

$body=$lines -join [Environment]::NewLine
& $writer -BasePath $basePath -Title "User Profile Health Audit" -Body $body
$html=$basePath+".html"
Write-Host ("Report: " + $html)
try { Start-Process -FilePath $html } catch {}
exit 0

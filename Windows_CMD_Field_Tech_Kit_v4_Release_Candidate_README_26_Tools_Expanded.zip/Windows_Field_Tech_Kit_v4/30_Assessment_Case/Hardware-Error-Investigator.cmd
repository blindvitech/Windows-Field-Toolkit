@echo off
setlocal EnableExtensions
title Hardware Error Investigator

echo Hardware Error Investigator
echo.
echo Read-only diagnostic / assessment tool. Windows system state is not changed.
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Hardware-Error-Investigator.ps1"
set "RC=%errorlevel%"

echo.
if "%SRMODE%"=="1" (
    if "%RC%"=="0" (
        echo Hardware Error Investigator completed.
    ) else (
        echo Hardware Error Investigator returned error code %RC%.
    )
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

exit /b %RC%

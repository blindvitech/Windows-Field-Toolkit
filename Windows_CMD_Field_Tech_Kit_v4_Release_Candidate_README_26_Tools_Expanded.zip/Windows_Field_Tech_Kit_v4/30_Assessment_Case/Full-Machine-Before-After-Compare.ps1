$screenReaderCommon = Join-Path (Split-Path $PSScriptRoot -Parent) "00_Common\ScreenReader-Common.ps1"
if (Test-Path -LiteralPath $screenReaderCommon -PathType Leaf) {
    . $screenReaderCommon
}

$ErrorActionPreference = "SilentlyContinue"
$ProgressPreference = "SilentlyContinue"

$toolkitRoot = Split-Path $PSScriptRoot -Parent
$logs = Join-Path $toolkitRoot "Logs"
if (-not (Test-Path -LiteralPath $logs)) { New-Item -ItemType Directory -Path $logs -Force | Out-Null }
$writer = Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"
$sectionedHtml = Join-Path $toolkitRoot "00_Common\Sectioned-Html-Report.ps1"
if (Test-Path -LiteralPath $sectionedHtml -PathType Leaf) { . $sectionedHtml }

$safeComputer = ($env:COMPUTERNAME -replace '[^A-Za-z0-9._-]','_')
$baselineClixml = Join-Path $logs ("MACHINE_COMPARE_BASELINE_" + $safeComputer + ".clixml")
$baselineTxt = Join-Path $logs ("MACHINE_COMPARE_BASELINE_" + $safeComputer + ".txt")

function To-Lines {
    param($Data)
    if ($null -eq $Data) { return @() }
    $text = ($Data | Out-String -Width 300).TrimEnd()
    if ([string]::IsNullOrWhiteSpace($text)) { return @() }
    return @($text -split "`r?`n" | ForEach-Object { $_.TrimEnd() } | Where-Object { $_ -ne "" })
}

function Get-MachineSnapshot {
    $snap = [ordered]@{}
    $os = Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
    $cv = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion" -ErrorAction SilentlyContinue
    $cs = Get-CimInstance Win32_ComputerSystem -ErrorAction SilentlyContinue
    $bios = Get-CimInstance Win32_BIOS -ErrorAction SilentlyContinue

    $snap.Metadata = @(
        "Captured=" + (Get-Date -Format "o"),
        "Computer=" + $env:COMPUTERNAME,
        "Manufacturer=" + $cs.Manufacturer,
        "Model=" + $cs.Model,
        "Serial=" + $bios.SerialNumber,
        "Windows=" + $os.Caption,
        "Version=" + $os.Version,
        "Build=" + $os.BuildNumber,
        "DisplayVersion=" + $cv.DisplayVersion,
        "UBR=" + $cv.UBR
    )

    $snap.Services = To-Lines (Get-CimInstance Win32_Service -ErrorAction SilentlyContinue |
        Select-Object Name,State,StartMode,StartName,PathName |
        Sort-Object Name | Format-Table -AutoSize)

    $snap.Drivers = To-Lines (Get-CimInstance Win32_PnPSignedDriver -ErrorAction SilentlyContinue |
        Select-Object DeviceName,Manufacturer,DriverVersion,DriverDate,InfName |
        Sort-Object DeviceName,InfName | Format-Table -AutoSize)

    $apps = @()
    foreach ($p in @(
        "HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*",
        "HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*",
        "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*"
    )) {
        $apps += Get-ItemProperty $p -ErrorAction SilentlyContinue |
            Where-Object DisplayName |
            Select-Object DisplayName,DisplayVersion,Publisher,InstallDate
    }
    $snap.Applications = To-Lines ($apps | Sort-Object DisplayName,DisplayVersion,Publisher -Unique | Format-Table -AutoSize)

    $snap.Features = To-Lines (Get-WindowsOptionalFeature -Online -ErrorAction SilentlyContinue |
        Select-Object FeatureName,State | Sort-Object FeatureName | Format-Table -AutoSize)

    $snap.ScheduledTasks = To-Lines (Get-ScheduledTask -ErrorAction SilentlyContinue |
        Select-Object TaskPath,TaskName,State,@{N="Actions";E={($_.Actions.Execute -join "; ")}} |
        Sort-Object TaskPath,TaskName | Format-Table -AutoSize)

    $snap.Startup = To-Lines (Get-CimInstance Win32_StartupCommand -ErrorAction SilentlyContinue |
        Select-Object Name,Command,Location,User | Sort-Object Name,Location | Format-Table -AutoSize)

    $snap.Firewall = To-Lines (Get-NetFirewallProfile -ErrorAction SilentlyContinue |
        Select-Object Name,Enabled,DefaultInboundAction,DefaultOutboundAction |
        Sort-Object Name | Format-Table -AutoSize)

    $snap.Hotfixes = To-Lines (Get-CimInstance Win32_QuickFixEngineering -ErrorAction SilentlyContinue |
        Select-Object HotFixID,Description,InstalledOn |
        Sort-Object HotFixID | Format-Table -AutoSize)

    $snap.Volumes = To-Lines (Get-Volume -ErrorAction SilentlyContinue |
        Select-Object DriveLetter,FileSystemLabel,FileSystem,HealthStatus,
            @{N="SizeGB";E={[math]::Round($_.Size/1GB,2)}},
            @{N="FreeGB";E={[math]::Round($_.SizeRemaining/1GB,2)}} |
        Sort-Object DriveLetter | Format-Table -AutoSize)

    $snap.Disks = To-Lines (Get-Disk -ErrorAction SilentlyContinue |
        Select-Object Number,FriendlyName,SerialNumber,PartitionStyle,OperationalStatus,HealthStatus,
            @{N="SizeGB";E={[math]::Round($_.Size/1GB,2)}} |
        Sort-Object Number | Format-Table -AutoSize)

    $snap.ProblemDevices = To-Lines (Get-PnpDevice -PresentOnly -ErrorAction SilentlyContinue |
        Where-Object Status -ne "OK" |
        Select-Object Status,Class,FriendlyName,InstanceId |
        Sort-Object Class,FriendlyName | Format-Table -AutoSize)

    $snap.LocalUsers = To-Lines (Get-LocalUser -ErrorAction SilentlyContinue |
        Select-Object Name,Enabled,LastLogon,PasswordExpires,UserMayChangePassword |
        Sort-Object Name | Format-Table -AutoSize)

    $admins = @()
    try { $admins = Get-LocalGroupMember -Group "Administrators" -ErrorAction Stop | Select-Object Name,ObjectClass,PrincipalSource } catch {}
    $snap.LocalAdministrators = To-Lines ($admins | Sort-Object Name | Format-Table -AutoSize)

    $uac = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -ErrorAction SilentlyContinue
    $lsa = Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -ErrorAction SilentlyContinue
    $snap.SecuritySettings = @(
        "EnableLUA=" + $uac.EnableLUA,
        "ConsentPromptBehaviorAdmin=" + $uac.ConsentPromptBehaviorAdmin,
        "PromptOnSecureDesktop=" + $uac.PromptOnSecureDesktop,
        "RunAsPPL=" + $lsa.RunAsPPL
    )

    $snap.NetworkProfiles = To-Lines (Get-NetConnectionProfile -ErrorAction SilentlyContinue |
        Select-Object Name,InterfaceAlias,NetworkCategory,IPv4Connectivity,IPv6Connectivity |
        Sort-Object InterfaceAlias | Format-Table -AutoSize)

    return [pscustomobject]$snap
}

function Snapshot-ToText {
    param($Snapshot)
    $lines = New-Object System.Collections.Generic.List[string]
    foreach ($prop in $Snapshot.PSObject.Properties) {
        $lines.Add("")
        $lines.Add(("=" * 78))
        $lines.Add($prop.Name)
        $lines.Add(("=" * 78))
        foreach ($line in @($prop.Value)) { $lines.Add([string]$line) }
    }
    return ($lines -join [Environment]::NewLine)
}

function Confirm-Exact {
    param([string]$Phrase,[string]$Prompt)
    $answer = Read-ToolkitPrompt ($Prompt + " Type " + $Phrase + " exactly") -SpellExactPhrase $Phrase
    return ($answer -ceq $Phrase)
}

while ($true) {
    Write-Host ""
    Write-Host "FULL MACHINE BEFORE / AFTER COMPARE"
    Write-Host "1. Capture or replace baseline."
    Write-Host "2. Capture AFTER state and compare with baseline."
    Write-Host "3. Show baseline status."
    Write-Host "4. Delete baseline."
    Write-Host "0. Return."
    Write-Host ""
    $choice = Read-ToolkitPrompt "Select an option"

    switch ($choice) {
        "1" {
            if (Test-Path -LiteralPath $baselineClixml) {
                if (-not (Confirm-Exact "YES" "A baseline already exists and will be replaced.")) {
                    Write-Host "Canceled. Existing baseline was not changed."
                    continue
                }
            }
            Write-Host "Capturing machine baseline..."
            $snap = Get-MachineSnapshot
            $snap | Export-Clixml -LiteralPath $baselineClixml -Depth 8
            Snapshot-ToText $snap | Set-Content -LiteralPath $baselineTxt -Encoding UTF8
            Write-Host ("Baseline saved: " + $baselineClixml)
        }
        "2" {
            if (-not (Test-Path -LiteralPath $baselineClixml)) {
                Write-Host "No baseline exists. Capture one first."
                continue
            }
            Write-Host "Capturing AFTER state..."
            $before = Import-Clixml -LiteralPath $baselineClixml
            $after = Get-MachineSnapshot
            $stamp = Get-Date -Format "yyyyMMdd_HHmmss"
            $afterClixml = Join-Path $logs ("MACHINE_COMPARE_AFTER_" + $safeComputer + "_" + $stamp + ".clixml")
            $afterTxt = Join-Path $logs ("MACHINE_COMPARE_AFTER_" + $safeComputer + "_" + $stamp + ".txt")
            $after | Export-Clixml -LiteralPath $afterClixml -Depth 8
            Snapshot-ToText $after | Set-Content -LiteralPath $afterTxt -Encoding UTF8

            $lines = New-Object System.Collections.Generic.List[string]
            $lines.Add("FULL MACHINE BEFORE / AFTER COMPARISON")
            $lines.Add("Computer: " + $env:COMPUTERNAME)
            $lines.Add("Generated: " + (Get-Date))
            $lines.Add("Baseline: " + $baselineClixml)
            $lines.Add("After: " + $afterClixml)
            $lines.Add("")
            $lines.Add("Legend: <= baseline-only / removed or changed from baseline; => after-only / added or changed.")
            $changedSections = 0
            $sectionedReport = New-ToolkitSectionedReport -Title "Full Machine Before / After Compare" `
                -Subtitle "Changed categories are presented as clickable sections so large comparisons stay readable." `
                -Footer "Generated by Windows CMD Field Tech Kit. <= is baseline-only; => is after-only."
            Add-ToolkitSectionedReportSection -Report $sectionedReport -Title "Comparison Summary" `
                -Data ("Computer: " + $env:COMPUTERNAME + [Environment]::NewLine +
                       "Baseline: " + $baselineClixml + [Environment]::NewLine +
                       "After: " + $afterClixml) `
                -Kind "SUMMARY" -OpenByDefault:$true

            $names = @($before.PSObject.Properties.Name) + @($after.PSObject.Properties.Name)
            $names = @($names | Sort-Object -Unique)
            foreach ($name in $names) {
                $b = @($before.$name | ForEach-Object { [string]$_ } | Sort-Object)
                $a = @($after.$name | ForEach-Object { [string]$_ } | Sort-Object)
                $diff = @(Compare-Object -ReferenceObject $b -DifferenceObject $a -IncludeEqual:$false)
                if ($diff.Count -gt 0) {
                    $changedSections++
                    $lines.Add("")
                    $lines.Add(("=" * 78))
                    $lines.Add($name + " - CHANGES")
                    $lines.Add(("=" * 78))
                    $sectionLines = New-Object System.Collections.Generic.List[string]
                    foreach ($d in $diff) {
                        $changeLine = ($d.SideIndicator + " " + [string]$d.InputObject)
                        $lines.Add($changeLine)
                        $sectionLines.Add($changeLine)
                    }
                    Add-ToolkitSectionedReportSection -Report $sectionedReport `
                        -Title ($name + " - CHANGES") `
                        -Data ($sectionLines -join [Environment]::NewLine) `
                        -Kind "WARNING" -OpenByDefault:$true
                }
            }
            if ($changedSections -eq 0) {
                $lines.Add("")
                $lines.Add("No differences were detected in the captured categories.")
                Add-ToolkitSectionedReportSection -Report $sectionedReport `
                    -Title "No Changes Detected" `
                    -Data "No differences were detected in the captured categories." `
                    -Kind "SUMMARY" -OpenByDefault:$true
            }
            $lines.Insert(5,("Changed sections: " + $changedSections))
            $reportBase = Join-Path $logs ($env:COMPUTERNAME + "_Full_Machine_Before_After_Compare_" + $stamp)
            $body = $lines -join [Environment]::NewLine
            & $writer -BasePath $reportBase -Title "Full Machine Before / After Compare" -Body $body
            $html = $reportBase + ".html"
            Add-ToolkitSectionedReportSection -Report $sectionedReport `
                -Title "Changed Section Count" -Data ("Changed sections: " + $changedSections) `
                -Kind "SUMMARY" -OpenByDefault:$true
            [void](Write-ToolkitSectionedHtmlReport -Report $sectionedReport -Path $html `
                -Computer $env:COMPUTERNAME -Generated ([string](Get-Date)) `
                -ToolId $(if($env:FIELDTECH_TOOL_ID){$env:FIELDTECH_TOOL_ID}else{"ADV-058"}))
            Write-Host ("Comparison report: " + $html)
            try { Start-Process -FilePath $html } catch {}
        }
        "3" {
            Write-Host ("CLIXML baseline: " + $baselineClixml)
            Write-Host ("Exists: " + (Test-Path -LiteralPath $baselineClixml))
            if (Test-Path -LiteralPath $baselineClixml) {
                Write-Host ("Last modified: " + (Get-Item -LiteralPath $baselineClixml).LastWriteTime)
            }
        }
        "4" {
            if (-not (Test-Path -LiteralPath $baselineClixml) -and -not (Test-Path -LiteralPath $baselineTxt)) {
                Write-Host "No baseline files exist."
                continue
            }
            if (Confirm-Exact "DELETE" "Delete the stored full-machine comparison baseline?") {
                Remove-Item -LiteralPath $baselineClixml,$baselineTxt -Force -ErrorAction SilentlyContinue
                Write-Host "Baseline files deleted."
            } else {
                Write-Host "Canceled. Baseline files were not deleted."
            }
        }
        "0" { break }
        default { Write-Host "Choose 0 through 4." }
    }
    if ($choice -eq "0") { break }
}
exit 0

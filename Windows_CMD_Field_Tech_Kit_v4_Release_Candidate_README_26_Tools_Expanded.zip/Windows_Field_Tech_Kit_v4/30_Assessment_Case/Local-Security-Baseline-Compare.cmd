@echo off
setlocal EnableExtensions
title Local Security Baseline Compare

echo Local Security Baseline Compare
echo.
echo Read-only assessment tool. Windows system state is not changed.
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Local-Security-Baseline-Compare.ps1"
set "RC=%errorlevel%"

echo.
if "%SRMODE%"=="1" (
    if "%RC%"=="0" (
        echo Local Security Baseline Compare completed.
    ) else (
        echo Local Security Baseline Compare returned error code %RC%.
    )
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

exit /b %RC%

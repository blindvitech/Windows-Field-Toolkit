$screenReaderCommon = Join-Path (Split-Path $PSScriptRoot -Parent) "00_Common\ScreenReader-Common.ps1"
if (Test-Path -LiteralPath $screenReaderCommon -PathType Leaf) {
    . $screenReaderCommon
}

$ErrorActionPreference="SilentlyContinue"
$ProgressPreference="SilentlyContinue"
$toolkitRoot=Split-Path $PSScriptRoot -Parent
$logs=Join-Path $toolkitRoot "Logs"
if(-not(Test-Path -LiteralPath $logs)){New-Item -ItemType Directory -Path $logs -Force|Out-Null}
$writer=Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"

Write-Host "CHANGE COMPARISON DASHBOARD"
Write-Host "Compare two files or two case/report folders."
$recent=@(Get-ChildItem -LiteralPath $logs -Directory -ErrorAction SilentlyContinue|Where-Object{$_.Name -like "CASE_*"}|Sort-Object LastWriteTime -Descending|Select-Object -First 6)
if($recent.Count){
 Write-Host "Recent case folders:"
 for($i=0;$i -lt $recent.Count;$i++){Write-Host(("{0}. {1}" -f ($i+1),$recent[$i].FullName))}
 Write-Host ""
}
$a=(Read-ToolkitPrompt "Path A or recent-case number").Trim().Trim('"')
$b=(Read-ToolkitPrompt "Path B or recent-case number").Trim().Trim('"')
if($a -match '^\d+$' -and [int]$a -ge 1 -and [int]$a -le $recent.Count){$a=$recent[[int]$a-1].FullName}
if($b -match '^\d+$' -and [int]$b -ge 1 -and [int]$b -le $recent.Count){$b=$recent[[int]$b-1].FullName}
if(-not(Test-Path -LiteralPath $a)){Write-Host "Path A not found.";exit 1}
if(-not(Test-Path -LiteralPath $b)){Write-Host "Path B not found.";exit 1}

$stamp=Get-Date -Format "yyyyMMdd_HHmmss"
$basePath=Join-Path $logs ($env:COMPUTERNAME+"_Change_Comparison_Dashboard_"+$stamp)
$lines=New-Object System.Collections.Generic.List[string]
$lines.Add("CHANGE COMPARISON DASHBOARD");$lines.Add("Generated: "+(Get-Date));$lines.Add("A: "+$a);$lines.Add("B: "+$b)
$lines.Add("");$lines.Add("Read-only comparison. <= means A-only/removed or changed from A; => means B-only/added or changed in B.")

function Compare-FileText {
 param([string]$FileA,[string]$FileB,[System.Collections.Generic.List[string]]$Lines,[string]$Label)
 $Lines.Add("");$Lines.Add(("="*78));$Lines.Add($Label);$Lines.Add(("="*78))
 $extA=[IO.Path]::GetExtension($FileA).ToLowerInvariant()
 $extB=[IO.Path]::GetExtension($FileB).ToLowerInvariant()
 if($extA -in ".txt",".md",".csv",".log",".json" -and $extB -in ".txt",".md",".csv",".log",".json"){
  $la=@(Get-Content -LiteralPath $FileA -ErrorAction SilentlyContinue)
  $lb=@(Get-Content -LiteralPath $FileB -ErrorAction SilentlyContinue)
  $diff=@(Compare-Object -ReferenceObject $la -DifferenceObject $lb)
  if($diff.Count){foreach($d in $diff|Select-Object -First 500){$Lines.Add($d.SideIndicator+" "+$d.InputObject)}}else{$Lines.Add("No line-level differences detected.")}
 }else{
  $ha=Get-FileHash -LiteralPath $FileA -Algorithm SHA256 -ErrorAction SilentlyContinue
  $hb=Get-FileHash -LiteralPath $FileB -Algorithm SHA256 -ErrorAction SilentlyContinue
  $Lines.Add("A SHA256: "+$ha.Hash);$Lines.Add("B SHA256: "+$hb.Hash)
  $Lines.Add($(if($ha.Hash -eq $hb.Hash){"Files are byte-identical."}else{"Files differ; binary/non-text line comparison was not attempted."}))
 }
}

$itemA=Get-Item -LiteralPath $a -Force
$itemB=Get-Item -LiteralPath $b -Force
if(-not $itemA.PSIsContainer -and -not $itemB.PSIsContainer){
 Compare-FileText $a $b $lines "FILE COMPARISON"
}elseif($itemA.PSIsContainer -and $itemB.PSIsContainer){
 $filesA=@(Get-ChildItem -LiteralPath $a -File -Recurse -ErrorAction SilentlyContinue)
 $filesB=@(Get-ChildItem -LiteralPath $b -File -Recurse -ErrorAction SilentlyContinue)
 $mapA=@{};$mapB=@{}
 foreach($f in $filesA){$rel=$f.FullName.Substring($itemA.FullName.Length).TrimStart('\');$mapA[$rel]=$f}
 foreach($f in $filesB){$rel=$f.FullName.Substring($itemB.FullName.Length).TrimStart('\');$mapB[$rel]=$f}
 $all=@($mapA.Keys+$mapB.Keys|Sort-Object -Unique)
 $summary=New-Object System.Collections.Generic.List[object]
 foreach($rel in $all){
  $fa=$mapA[$rel];$fb=$mapB[$rel]
  if(-not $fa){$summary.Add([pscustomobject]@{Path=$rel;Status="B ONLY";ASize="";BSize=$fb.Length});continue}
  if(-not $fb){$summary.Add([pscustomobject]@{Path=$rel;Status="A ONLY";ASize=$fa.Length;BSize=""});continue}
  $ha=(Get-FileHash -LiteralPath $fa.FullName -Algorithm SHA256 -ErrorAction SilentlyContinue).Hash
  $hb=(Get-FileHash -LiteralPath $fb.FullName -Algorithm SHA256 -ErrorAction SilentlyContinue).Hash
  $status=if($ha -eq $hb){"SAME"}else{"CHANGED"}
  $summary.Add([pscustomobject]@{Path=$rel;Status=$status;ASize=$fa.Length;BSize=$fb.Length})
 }
 $lines.Add("");$lines.Add(("="*78));$lines.Add("FOLDER SUMMARY");$lines.Add(("="*78))
 $lines.Add(($summary|Sort-Object Status,Path|Format-Table -Wrap -AutoSize|Out-String -Width 260).TrimEnd())
 foreach($row in $summary|Where-Object Status -eq "CHANGED"|Select-Object -First 30){
  $fa=$mapA[$row.Path];$fb=$mapB[$row.Path]
  Compare-FileText $fa.FullName $fb.FullName $lines ("CHANGED: "+$row.Path)
 }
}else{
 $lines.Add("");$lines.Add("One path is a file and the other is a folder. Compare like-for-like paths.")
}

$body=$lines -join [Environment]::NewLine
& $writer -BasePath $basePath -Title "Change Comparison Dashboard" -Body $body
$html=$basePath+".html";Write-Host("Report: "+$html);try{Start-Process -FilePath $html}catch{}
exit 0

@echo off
setlocal EnableExtensions
title Case Notes / Technician Notes

echo Case Notes / Technician Notes
echo.
echo Case documentation tool. It writes notes into an existing CASE_ folder and refreshes that case ZIP.
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Case-Technician-Notes.ps1"
set "RC=%errorlevel%"

echo.
if "%SRMODE%"=="1" (
    if "%RC%"=="0" (
        echo Case Notes / Technician Notes completed.
    ) else (
        echo Case Notes / Technician Notes returned error code %RC%.
    )
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

exit /b %RC%

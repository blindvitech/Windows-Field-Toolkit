$ErrorActionPreference="SilentlyContinue"
$ProgressPreference="SilentlyContinue"
$toolkitRoot=Split-Path $PSScriptRoot -Parent
$logs=Join-Path $toolkitRoot "Logs"
if(-not(Test-Path -LiteralPath $logs)){New-Item -ItemType Directory -Path $logs -Force|Out-Null}
$writer=Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"
$stamp=Get-Date -Format "yyyyMMdd_HHmmss"
$basePath=Join-Path $logs ($env:COMPUTERNAME+"_USB_Removable_Device_History_"+$stamp)

$current=Get-PnpDevice -PresentOnly -ErrorAction SilentlyContinue|
 Where-Object{$_.InstanceId -match '^(?i)(USB|USBSTOR)\\'}|
 Select-Object Status,Class,FriendlyName,InstanceId|Sort-Object Class,FriendlyName

$usbStor=@()
$root="HKLM:\SYSTEM\CurrentControlSet\Enum\USBSTOR"
if(Test-Path -LiteralPath $root){
 foreach($device in Get-ChildItem -LiteralPath $root -ErrorAction SilentlyContinue){
  foreach($instance in Get-ChildItem -LiteralPath $device.PSPath -ErrorAction SilentlyContinue){
   $p=Get-ItemProperty -LiteralPath $instance.PSPath -ErrorAction SilentlyContinue
   $usbStor+=[pscustomobject]@{DeviceKey=$device.PSChildName;Instance=$instance.PSChildName;FriendlyName=$p.FriendlyName;DeviceDesc=$p.DeviceDesc;Mfg=$p.Mfg;Service=$p.Service;ClassGUID=$p.ClassGUID}
  }
 }
}

$events=@()
try{
 $events=Get-WinEvent -FilterHashtable @{LogName="System";StartTime=(Get-Date).AddDays(-30)} -ErrorAction Stop|
  Where-Object{$_.ProviderName -match '(?i)(Kernel-PnP|UserPnp|DriverFrameworks)' -and $_.Message -match '(?i)(USB|USBSTOR|removable)'}|
  Sort-Object TimeCreated -Descending|Select-Object -First 150 TimeCreated,Id,ProviderName,LevelDisplayName,@{N="Message";E={($_.Message-replace"[\r\n]+"," "-replace"\s{2,}"," ").Trim()}}
}catch{}

$setupMatches=@()
$setupLog=Join-Path $env:WINDIR "INF\setupapi.dev.log"
if(Test-Path -LiteralPath $setupLog){
 try{
  $tail=Get-Content -LiteralPath $setupLog -Tail 5000 -ErrorAction Stop
  $setupMatches=@($tail|Where-Object{$_ -match '(?i)(USBSTOR|USB\\VID_|removable)' }|Select-Object -Last 250)
 }catch{}
}

$lines=New-Object System.Collections.Generic.List[string]
$lines.Add("USB / REMOVABLE DEVICE HISTORY");$lines.Add("Computer: "+$env:COMPUTERNAME);$lines.Add("Generated: "+(Get-Date))
$lines.Add("");$lines.Add("Read-only troubleshooting inventory of currently present USB devices, USBSTOR registry enumeration, recent PnP events, and matching SetupAPI log lines.")
$lines.Add("Windows does not guarantee a complete authoritative first/last-connected history for every USB device.")
foreach($pair in @(@("CURRENT USB / USBSTOR DEVICES",$current),@("USBSTOR ENUMERATION HISTORY",$usbStor),@("RECENT USB-RELATED PNP EVENTS - 30 DAYS",$events),@("RECENT MATCHING SETUPAPI.DEV.LOG LINES",$setupMatches))){
 $lines.Add("");$lines.Add(("="*78));$lines.Add($pair[0]);$lines.Add(("="*78));$x=($pair[1]|Out-String -Width 260).TrimEnd();if($x){$lines.Add($x)}else{$lines.Add("(No data returned)")}
}
$body=$lines -join [Environment]::NewLine
& $writer -BasePath $basePath -Title "USB and Removable Device History" -Body $body
$html=$basePath+".html";Write-Host("Report: "+$html);try{Start-Process -FilePath $html}catch{}
exit 0

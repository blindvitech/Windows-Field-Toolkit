@echo off
setlocal EnableExtensions
title Case Closeout Report

echo Case Closeout Report
echo.
echo Case documentation tool. It consolidates existing evidence/notes and refreshes the selected case ZIP.
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Case-Closeout-Report.ps1"
set "RC=%errorlevel%"

echo.
if "%SRMODE%"=="1" (
    if "%RC%"=="0" (
        echo Case Closeout Report completed.
    ) else (
        echo Case Closeout Report returned error code %RC%.
    )
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

exit /b %RC%

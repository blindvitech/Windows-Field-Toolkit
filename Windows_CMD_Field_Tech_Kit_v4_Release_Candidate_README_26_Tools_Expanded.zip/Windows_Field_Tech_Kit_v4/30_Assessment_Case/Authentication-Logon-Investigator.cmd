@echo off
setlocal EnableExtensions
title Authentication / Logon Investigator

echo Authentication / Logon Investigator
echo.
echo Read-only diagnostic / assessment tool. Windows system state is not changed.
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Authentication-Logon-Investigator.ps1"
set "RC=%errorlevel%"

echo.
if "%SRMODE%"=="1" (
    if "%RC%"=="0" (
        echo Authentication / Logon Investigator completed.
    ) else (
        echo Authentication / Logon Investigator returned error code %RC%.
    )
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

exit /b %RC%

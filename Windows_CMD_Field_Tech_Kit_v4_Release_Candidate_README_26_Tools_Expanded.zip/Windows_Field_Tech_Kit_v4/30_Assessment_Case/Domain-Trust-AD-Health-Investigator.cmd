@echo off
setlocal EnableExtensions
title Domain Trust / AD Health Investigator

echo Domain Trust / AD Health Investigator
echo.
echo Read-only Active Directory / domain trust diagnostic.
echo This tool does not join or unjoin the domain, repair/reset the secure
echo channel, change DNS, change Windows Time, or modify credentials.
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Domain-Trust-AD-Health-Investigator.ps1"
set "RC=%errorlevel%"

echo.
if "%SRMODE%"=="1" (
    if "%RC%"=="0" (
        echo Domain Trust / AD Health Investigator completed.
    ) else (
        echo Domain Trust / AD Health Investigator returned error code %RC%.
    )
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

exit /b %RC%

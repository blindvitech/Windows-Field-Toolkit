@echo off
setlocal EnableExtensions
title Application Crash Investigator

echo Application Crash Investigator
echo.
echo Read-only assessment tool. Windows system state is not changed.
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Application-Crash-Investigator.ps1"
set "RC=%errorlevel%"

echo.
if "%SRMODE%"=="1" (
    if "%RC%"=="0" (
        echo Application Crash Investigator completed.
    ) else (
        echo Application Crash Investigator returned error code %RC%.
    )
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

exit /b %RC%

@echo off
setlocal
title Local Accounts Snapshot
set "LOGDIR=%~dp0..\Logs"
if not exist "%LOGDIR%" mkdir "%LOGDIR%"
set "LOG=%LOGDIR%\%COMPUTERNAME%_Accounts_%RANDOM%.txt"
(
echo LOCAL ACCOUNT SNAPSHOT
echo Computer: %COMPUTERNAME%
echo Date: %DATE% %TIME%
echo.
echo ===== LOCAL USERS =====
net user
echo.
echo ===== LOCAL ADMINISTRATORS =====
net localgroup administrators
echo.
echo ===== LOCAL GROUPS =====
net localgroup
) > "%LOG%" 2>&1

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\00_Common\Convert-TextReport.ps1" -TextPath "%LOG%" -Title "%~n0"


echo Saved to:
echo %LOG%
if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)
endlocal

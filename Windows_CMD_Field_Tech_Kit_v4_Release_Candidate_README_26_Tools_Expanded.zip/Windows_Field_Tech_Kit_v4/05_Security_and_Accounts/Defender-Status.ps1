$ErrorActionPreference = "SilentlyContinue"
if (-not (Get-Command Get-MpComputerStatus -ErrorAction SilentlyContinue)) {
    Write-Host "Microsoft Defender status cmdlet is unavailable on this system."
    exit 2
}
try {
    Get-MpComputerStatus -ErrorAction Stop |
        Format-List AMServiceEnabled,AntivirusEnabled,AntispywareEnabled,RealTimeProtectionEnabled,BehaviorMonitorEnabled,IoavProtectionEnabled,NISEnabled,AntivirusSignatureLastUpdated
    exit 0
}
catch {
    Write-Host "Could not collect Microsoft Defender status."
    Write-Host $_.Exception.Message
    exit 1
}

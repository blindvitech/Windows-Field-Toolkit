@echo off
setlocal EnableExtensions
title Microsoft Defender Status
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Defender-Status.ps1"
set "RC=%errorlevel%"
echo.
if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)
exit /b %RC%

@echo off
title BitLocker Status
manage-bde -status
if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

@echo off
title Windows Activation Status
cscript //nologo %windir%\system32\slmgr.vbs /dli
echo.
cscript //nologo %windir%\system32\slmgr.vbs /xpr
if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

@echo off
setlocal
title Proxy and Hosts Snapshot
set "LOGDIR=%~dp0..\Logs"
if not exist "%LOGDIR%" mkdir "%LOGDIR%"
set "LOG=%LOGDIR%\%COMPUTERNAME%_ProxyHosts_%RANDOM%.txt"

(
echo PROXY / HOSTS SNAPSHOT
echo Computer: %COMPUTERNAME%
echo Date: %DATE% %TIME%
echo.
echo ===== WINHTTP PROXY =====
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\00_Common\Invoke-Native-Bridge.ps1" -FilePath "netsh.exe" -Label "WinHTTP Proxy" winhttp show proxy
echo.
echo ===== INTERNET SETTINGS =====
reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\Internet Settings" /v ProxyEnable
reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\Internet Settings" /v ProxyServer
echo.
echo ===== HOSTS FILE =====
type "%SystemRoot%\System32\drivers\etc\hosts"
) > "%LOG%" 2>&1


powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\00_Common\Convert-TextReport.ps1" -TextPath "%LOG%" -Title "%~n0"


echo Saved to:
echo %LOG%
if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)
endlocal


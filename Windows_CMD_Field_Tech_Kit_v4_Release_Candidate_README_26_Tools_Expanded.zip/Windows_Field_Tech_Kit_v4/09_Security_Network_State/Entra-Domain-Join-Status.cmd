@echo off
setlocal
title Entra / Domain Join Status
set "LOGDIR=%~dp0..\Logs"
if not exist "%LOGDIR%" mkdir "%LOGDIR%"
set "LOG=%LOGDIR%\%COMPUTERNAME%_JoinStatus_%RANDOM%.txt"

(
echo ============================================================
echo ENTRA / DOMAIN JOIN STATUS
echo Computer: %COMPUTERNAME%
echo Date: %DATE% %TIME%
echo ============================================================
echo.
echo ===== DSREGCMD =====
dsregcmd /status
echo.
echo ===== WHOAMI =====
whoami /all
) > "%LOG%" 2>&1


powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\00_Common\Convert-TextReport.ps1" -TextPath "%LOG%" -Title "%~n0"


echo Saved to:
echo %LOG%
if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)
endlocal


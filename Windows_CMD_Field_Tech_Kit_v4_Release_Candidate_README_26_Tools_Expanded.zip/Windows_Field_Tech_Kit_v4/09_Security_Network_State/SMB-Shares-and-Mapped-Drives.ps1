$ErrorActionPreference = "SilentlyContinue"
$toolkitRoot = Split-Path $PSScriptRoot -Parent
$logs = Join-Path $toolkitRoot "Logs"
if (-not (Test-Path -LiteralPath $logs)) { New-Item -ItemType Directory -Path $logs -Force | Out-Null }
$writer = Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"
$basePath = Join-Path $logs ($env:COMPUTERNAME + "_SharesDrives_" + (Get-Date -Format "yyyyMMdd_HHmmss"))

$lines = New-Object System.Collections.Generic.List[string]
$lines.Add("SMB / MAPPED DRIVE SNAPSHOT")
$lines.Add("Computer: " + $env:COMPUTERNAME)
$lines.Add("Generated: " + (Get-Date))
$lines.Add("")
$lines.Add("LOCAL SHARES")
$lines.Add(((& net.exe share 2>&1) | Out-String -Width 240).TrimEnd())
$lines.Add("")
$lines.Add("MAPPED / ACTIVE CONNECTIONS")
$lines.Add(((& net.exe use 2>&1) | Out-String -Width 240).TrimEnd())
$lines.Add("")
$lines.Add("SMB CONNECTIONS")
try {
    $smb = Get-SmbConnection -ErrorAction Stop
    if ($smb) { $lines.Add(($smb | Format-Table -AutoSize | Out-String -Width 240).TrimEnd()) }
    else { $lines.Add("(No active SMB connections returned.)") }
}
catch { $lines.Add("Unavailable: " + $_.Exception.Message) }

& $writer -BasePath $basePath -Title "SMB Shares and Mapped Drives" -Body ($lines -join [Environment]::NewLine)
Write-Host ("Report: " + $basePath + ".html")
try { Start-Process -FilePath ($basePath + ".html") } catch {}
exit 0

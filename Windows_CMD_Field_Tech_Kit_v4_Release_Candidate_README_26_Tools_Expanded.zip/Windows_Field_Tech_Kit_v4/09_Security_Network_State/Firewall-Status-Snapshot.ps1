$ErrorActionPreference = "SilentlyContinue"
$toolkitRoot = Split-Path $PSScriptRoot -Parent
$foundation = Join-Path $toolkitRoot "00_Common\Foundation-Common.ps1"
if (Test-Path -LiteralPath $foundation -PathType Leaf) { . $foundation }
$logs = Join-Path $toolkitRoot "Logs"
if (-not (Test-Path -LiteralPath $logs)) { New-Item -ItemType Directory -Path $logs -Force | Out-Null }
$writer = Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"
$basePath = Join-Path $logs ($env:COMPUTERNAME + "_Firewall_" + (Get-Date -Format "yyyyMMdd_HHmmss"))

$lines = New-Object System.Collections.Generic.List[string]
$lines.Add("WINDOWS FIREWALL STATUS")
$lines.Add("Computer: " + $env:COMPUTERNAME)
$lines.Add("Generated: " + (Get-Date))
$lines.Add("")
$lines.Add("FIREWALL PROFILES")
$firewallNative = Invoke-ToolkitNativeCommand -FilePath "netsh.exe" -Arguments @("advfirewall","show","allprofiles") -Label "Firewall All Profiles" -Action "Firewall Status Snapshot" -Quiet
$lines.Add((($firewallNative.Output -join [Environment]::NewLine) | Out-String -Width 240).TrimEnd())
$lines.Add("")
$lines.Add("CURRENT NETWORK PROFILES")
try {
    $profiles = Get-NetConnectionProfile -ErrorAction Stop |
        Select-Object Name,InterfaceAlias,NetworkCategory,IPv4Connectivity,IPv6Connectivity
    $lines.Add(($profiles | Format-Table -AutoSize | Out-String -Width 240).TrimEnd())
}
catch { $lines.Add("Unavailable: " + $_.Exception.Message) }

& $writer -BasePath $basePath -Title "Windows Firewall Status" -Body ($lines -join [Environment]::NewLine)
Write-Host ("Report: " + $basePath + ".html")
try { Start-Process -FilePath ($basePath + ".html") } catch {}
exit 0

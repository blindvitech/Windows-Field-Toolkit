@echo off
setlocal EnableExtensions
title Windows Update Readiness

echo Windows Update Readiness
echo.
echo Collecting report data. This may take a moment.
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Windows-Update-Readiness.ps1"
set "RC=%errorlevel%"

if "%SRMODE%"=="1" (
    echo.
    if "%RC%"=="0" (
        echo Windows Update Readiness completed successfully.
    ) else (
        echo Windows Update Readiness returned error code %RC%.
    )
    echo Press any key to continue.
    pause >nul
) else (
    echo.
    pause
)

exit /b %RC%

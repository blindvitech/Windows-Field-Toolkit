$ErrorActionPreference = "SilentlyContinue"
$ProgressPreference = "SilentlyContinue"

$toolkitRoot = Split-Path $PSScriptRoot -Parent
$foundation = Join-Path $toolkitRoot "00_Common\Foundation-Common.ps1"
if (Test-Path -LiteralPath $foundation -PathType Leaf) { . $foundation }
$logs = Join-Path $toolkitRoot "Logs"
if (-not (Test-Path -LiteralPath $logs)) { New-Item -ItemType Directory -Path $logs -Force | Out-Null }
$writer = Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"
$basePath = Join-Path $logs ($env:COMPUTERNAME + "_Windows_Update_Readiness_" + (Get-Date -Format "yyyyMMdd_HHmmss"))

$lines = New-Object System.Collections.Generic.List[string]
$findings = New-Object System.Collections.Generic.List[object]

function Add-Section {
    param([string]$Title, $Data, [string]$Note = "")
    $lines.Add("")
    $lines.Add(("=" * 78))
    $lines.Add($Title)
    $lines.Add(("=" * 78))
    if ($Note) { $lines.Add("NOTE: " + $Note) }
    $text = ($Data | Out-String -Width 260).TrimEnd()
    if ([string]::IsNullOrWhiteSpace($text)) { $lines.Add("(No data returned / not applicable)") }
    else { $lines.Add($text) }
}
function Add-Finding {
    param([string]$Severity,[string]$Area,[string]$Finding)
    $findings.Add([pscustomobject]@{Severity=$Severity;Area=$Area;Finding=$Finding})
}

Write-Host "Collecting Windows Update Readiness..."

$services = @(Get-Service wuauserv,bits,cryptsvc,usosvc,TrustedInstaller -ErrorAction SilentlyContinue |
    Select-Object Name,Status,StartType)
foreach ($svc in $services) {
    if ($svc.StartType -eq "Disabled" -and $svc.Name -in @("wuauserv","bits","cryptsvc")) {
        Add-Finding "ATTENTION" "Service" ($svc.Name + " is Disabled.")
    }
}

$pending = [pscustomobject]@{
    CBS = Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending"
    WindowsUpdate = Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired"
    PendingFileRename = $null -ne (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager" -Name PendingFileRenameOperations -ErrorAction SilentlyContinue).PendingFileRenameOperations
}
if ($pending.CBS -or $pending.WindowsUpdate -or $pending.PendingFileRename) {
    Add-Finding "ATTENTION" "Pending reboot" "Windows reports one or more pending-reboot indicators."
}

$sysDrive = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='$env:SystemDrive'" -ErrorAction SilentlyContinue
$space = $null
if ($sysDrive) {
    $freeGB = [math]::Round($sysDrive.FreeSpace / 1GB,2)
    $sizeGB = [math]::Round($sysDrive.Size / 1GB,2)
    $pctFree = 0
    if ($sysDrive.Size -gt 0) { $pctFree = [math]::Round(($sysDrive.FreeSpace / $sysDrive.Size) * 100,1) }
    $space = [pscustomobject]@{Drive=$env:SystemDrive;SizeGB=$sizeGB;FreeGB=$freeGB;PercentFree=$pctFree}
    if ($freeGB -lt 10) { Add-Finding "BLOCKED" "System drive" ("Only " + $freeGB + " GB free.") }
    elseif ($freeGB -lt 20) { Add-Finding "ATTENTION" "System drive" ("Only " + $freeGB + " GB free; feature updates may need more working space.") }
}

$dismNative = Invoke-ToolkitNativeCommand -FilePath "dism.exe" -Arguments @("/Online","/Cleanup-Image","/CheckHealth") -Label "Update Readiness DISM CheckHealth" -Action "Windows Update Readiness" -Quiet
$dismText = (($dismNative.Output -join [Environment]::NewLine) | Out-String -Width 260).TrimEnd()
if ($dismNative.ExitCode -ne 0) {
    Add-Finding "ATTENTION" "Component store" ("DISM CheckHealth returned code " + $dismNative.ExitCode + ".")
}
elseif ($dismText -match '(?i)repairable|corrupt') {
    Add-Finding "ATTENTION" "Component store" "DISM CheckHealth reported component-store repair attention."
}

$policyRows = New-Object System.Collections.Generic.List[object]
foreach ($path in @(
    "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate",
    "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU"
)) {
    if (Test-Path $path) {
        try {
            $item = Get-ItemProperty $path -ErrorAction Stop
            foreach ($prop in $item.PSObject.Properties) {
                if ($prop.Name -notmatch '^PS(Path|ParentPath|ChildName|Drive|Provider)$') {
                    $policyRows.Add([pscustomobject]@{Path=$path;Name=$prop.Name;Value=[string]$prop.Value})
                }
            }
        } catch {}
    }
}

$wuEvents = @()
try {
    $wuEvents = @(Get-WinEvent -FilterHashtable @{LogName="Microsoft-Windows-WindowsUpdateClient/Operational";StartTime=(Get-Date).AddDays(-14)} -ErrorAction Stop |
        Where-Object { $_.Id -in 19,20,21,25,31,34,41,43,44 -or $_.Level -in 1,2,3 } |
        Sort-Object TimeCreated -Descending |
        Select-Object -First 100 TimeCreated,Id,LevelDisplayName,@{N="Message";E={($_.Message -replace "[\r\n]+"," " -replace "\s{2,}"," ").Trim()}})
} catch {}
$recentFailures = @($wuEvents | Where-Object { $_.Id -in 20,25,31,34 -or $_.LevelDisplayName -match 'Error|Critical' })
if ($recentFailures.Count -gt 0) {
    Add-Finding "ATTENTION" "Windows Update history" ($recentFailures.Count.ToString() + " recent failure/error events found in the last 14 days.")
}

$history = @()
try {
    $session = New-Object -ComObject Microsoft.Update.Session
    $searcher = $session.CreateUpdateSearcher()
    $count = $searcher.GetTotalHistoryCount()
    if ($count -gt 0) {
        $history = @($searcher.QueryHistory(0,[Math]::Min($count,100)) |
            Select-Object Date,Title,Operation,ResultCode,HResult)
    }
} catch {}

$hotfixes = @(Get-HotFix -ErrorAction SilentlyContinue |
    Sort-Object InstalledOn -Descending |
    Select-Object -First 25 HotFixID,InstalledOn,Description)

$status = "READY"
if (@($findings | Where-Object Severity -eq "BLOCKED").Count -gt 0) { $status = "BLOCKED" }
elseif ($findings.Count -gt 0) { $status = "ATTENTION" }

$lines.Add("WINDOWS UPDATE READINESS")
$lines.Add("Computer: " + $env:COMPUTERNAME)
$lines.Add("Generated: " + (Get-Date))
$lines.Add("Overall readiness: " + $status)
$lines.Add("")
$lines.Add("This is a read-only readiness assessment. ATTENTION does not mean updates will fail; it identifies conditions worth reviewing before servicing.")

Add-Section "READINESS FINDINGS" $(if ($findings.Count -gt 0) { $findings.ToArray() } else { [pscustomobject]@{Severity="INFO";Area="Readiness";Finding="No blocking or attention conditions were detected by this tool."} })
Add-Section "UPDATE / SERVICING SERVICES" $services
Add-Section "PENDING REBOOT STATE" $pending
Add-Section "SYSTEM DRIVE FREE SPACE" $space
Add-Section "WINDOWS UPDATE POLICY" $(if ($policyRows.Count -gt 0) { $policyRows.ToArray() } else { $null }) "Policy absence is normal on unmanaged PCs."
Add-Section "DISM CHECKHEALTH" $dismText
Add-Section "RECENT WINDOWS UPDATE EVENTS - 14 DAYS" $wuEvents
Add-Section "WINDOWS UPDATE HISTORY" $history
Add-Section "RECENT INSTALLED HOTFIXES" $hotfixes

& $writer -BasePath $basePath -Title "Windows Update Readiness" -Body ($lines -join [Environment]::NewLine)
$html = $basePath + ".html"
if (-not (Test-Path -LiteralPath $html)) { Write-Host "Report was not created."; exit 4 }
Write-Host ("Readiness: " + $status)
Write-Host ("Report: " + $html)
try { Start-Process -FilePath $html } catch {}
exit 0

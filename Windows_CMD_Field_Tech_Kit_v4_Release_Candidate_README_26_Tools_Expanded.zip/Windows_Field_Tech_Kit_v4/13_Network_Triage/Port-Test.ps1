$screenReaderCommon = Join-Path (Split-Path $PSScriptRoot -Parent) "00_Common\ScreenReader-Common.ps1"
if (Test-Path -LiteralPath $screenReaderCommon -PathType Leaf) {
    . $screenReaderCommon
}

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

$target = (Read-ToolkitPrompt "Hostname or IP").Trim()
if ([string]::IsNullOrWhiteSpace($target)) { exit 0 }
if ($target.Length -gt 253 -or $target -notmatch '^[A-Za-z0-9][A-Za-z0-9\.\-_:]*$') {
    Write-Host "Invalid hostname/IP characters."
    exit 2
}

$portText = (Read-ToolkitPrompt "TCP port").Trim()
$port = 0
if (-not [int]::TryParse($portText,[ref]$port) -or $port -lt 1 -or $port -gt 65535) {
    Write-Host "Enter a TCP port from 1 through 65535."
    exit 2
}

try {
    Test-NetConnection -ComputerName $target -Port $port -InformationLevel Detailed -WarningAction SilentlyContinue |
        Format-List
    exit 0
}
catch {
    Write-Host "TCP port test failed."
    Write-Host $_.Exception.Message
    exit 1
}

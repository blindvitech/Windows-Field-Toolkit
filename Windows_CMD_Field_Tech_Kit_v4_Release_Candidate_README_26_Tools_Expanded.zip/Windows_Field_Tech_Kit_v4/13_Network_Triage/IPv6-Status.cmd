@echo off
setlocal
title IPv6 Status
set "LOGDIR=%~dp0..\Logs"
if not exist "%LOGDIR%" mkdir "%LOGDIR%"
set "LOG=%LOGDIR%\%COMPUTERNAME%_IPv6_%RANDOM%.txt"

(
echo IPv6 STATUS
echo Computer: %COMPUTERNAME%
echo Date: %DATE% %TIME%
echo.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\00_Common\Invoke-Native-Bridge.ps1" -FilePath "netsh.exe" -Label "IPv6 Interface Status" interface ipv6 show interface
echo.
ipconfig /all
echo.
echo ===== IPv6 ROUTES =====
route print -6
echo.
echo ===== IPv6 TEST =====
ping -6 -n 3 ipv6.google.com
) > "%LOG%" 2>&1


powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\00_Common\Convert-TextReport.ps1" -TextPath "%LOG%" -Title "%~n0"


echo Saved to:
echo %LOG%
if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)
endlocal


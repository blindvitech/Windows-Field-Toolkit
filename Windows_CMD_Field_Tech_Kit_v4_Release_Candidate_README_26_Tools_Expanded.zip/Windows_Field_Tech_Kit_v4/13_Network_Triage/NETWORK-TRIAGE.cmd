@echo off
setlocal EnableExtensions
title Network Triage
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0NETWORK-TRIAGE.ps1"
set "RC=%errorlevel%"
echo.
if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)
exit /b %RC%

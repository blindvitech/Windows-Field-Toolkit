@echo off
setlocal
title DNS Comparison Test
set "LOGDIR=%~dp0..\Logs"
if not exist "%LOGDIR%" mkdir "%LOGDIR%"
set "LOG=%LOGDIR%\%COMPUTERNAME%_DNSCompare_%RANDOM%.txt"

set /p NAME=Hostname to test [default: www.microsoft.com]: 
if "%NAME%"=="" set "NAME=www.microsoft.com"

(
echo DNS COMPARISON TEST
echo Name: %NAME%
echo Date: %DATE% %TIME%
echo.
echo ===== SYSTEM CONFIGURED DNS =====
nslookup %NAME%
echo.
echo ===== CLOUDFLARE 1.1.1.1 =====
nslookup %NAME% 1.1.1.1
echo.
echo ===== GOOGLE 8.8.8.8 =====
nslookup %NAME% 8.8.8.8
) > "%LOG%" 2>&1


powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\00_Common\Convert-TextReport.ps1" -TextPath "%LOG%" -Title "%~n0"


echo Saved to:
echo %LOG%
if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)
endlocal


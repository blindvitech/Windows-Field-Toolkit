$screenReaderCommon = Join-Path (Split-Path $PSScriptRoot -Parent) "00_Common\ScreenReader-Common.ps1"
if (Test-Path -LiteralPath $screenReaderCommon -PathType Leaf) {
    . $screenReaderCommon
}

$ErrorActionPreference = "SilentlyContinue"
$ProgressPreference = "SilentlyContinue"

$toolkitRoot = Split-Path $PSScriptRoot -Parent
$foundation = Join-Path $toolkitRoot "00_Common\Foundation-Common.ps1"
if (Test-Path -LiteralPath $foundation -PathType Leaf) { . $foundation }
$logs = Join-Path $toolkitRoot "Logs"
if (-not (Test-Path -LiteralPath $logs)) { New-Item -ItemType Directory -Path $logs -Force | Out-Null }
$writer = Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"
$basePath = Join-Path $logs ($env:COMPUTERNAME + "_NetworkTriage_" + (Get-Date -Format "yyyyMMdd_HHmmss"))

$target = (Read-ToolkitPrompt "Optional target hostname/IP for port tests [press Enter to skip]").Trim()
if ($target.Length -gt 253) {
    Write-Host "Target is too long."
    exit 2
}
if ($target -and $target -notmatch '^[A-Za-z0-9][A-Za-z0-9\.\-_:]*$') {
    Write-Host "Target contains unsupported characters. Use a hostname or IP address only."
    exit 2
}

$lines = New-Object System.Collections.Generic.List[string]
function Add-Section([string]$Title) {
    $lines.Add("")
    $lines.Add(("=" * 72))
    $lines.Add($Title)
    $lines.Add(("=" * 72))
}
function Add-External([string]$Name,[scriptblock]$Command) {
    try {
        $out = & $Command 2>&1 | Out-String -Width 260
        $lines.Add($out.TrimEnd())
    }
    catch { $lines.Add($Name + " unavailable: " + $_.Exception.Message) }
}

$lines.Add("NETWORK TRIAGE REPORT")
$lines.Add("Computer: " + $env:COMPUTERNAME)
$lines.Add("Generated: " + (Get-Date))

Add-Section "ADAPTER / ADDRESS SUMMARY"
Add-External "ipconfig" { & ipconfig.exe /all }

Add-Section "NETWORK ADAPTER SANITY"
try {
    $adapterRows = @(Get-NetAdapter -ErrorAction Stop |
        Select-Object Name,InterfaceDescription,Status,LinkSpeed,MacAddress,DriverInformation,DriverFileName,DriverVersion)
    $lines.Add(($adapterRows | Format-Table -Wrap -AutoSize | Out-String -Width 260).TrimEnd())

    $lines.Add("")
    $lines.Add("Adapter statistics:")
    $stats = @(Get-NetAdapterStatistics -ErrorAction SilentlyContinue |
        Select-Object Name,ReceivedBytes,SentBytes,ReceivedUnicastPackets,SentUnicastPackets,ReceivedDiscardedPackets,OutboundDiscardedPackets,ReceivedPacketErrors,OutboundPacketErrors)
    $lines.Add(($stats | Format-Table -AutoSize | Out-String -Width 260).TrimEnd())

    $lines.Add("")
    $lines.Add("Signed network drivers:")
    $netDrivers = @(Get-CimInstance Win32_PnPSignedDriver -ErrorAction SilentlyContinue |
        Where-Object { $_.DeviceClass -eq "NET" } |
        Select-Object DeviceName,Manufacturer,DriverProviderName,DriverVersion,DriverDate,InfName,IsSigned)
    $lines.Add(($netDrivers | Format-Table -Wrap -AutoSize | Out-String -Width 260).TrimEnd())

    $lines.Add("")
    $lines.Add("Power-management state:")
    $powerRows = New-Object System.Collections.Generic.List[object]
    foreach ($adapter in $adapterRows) {
        try {
            $pm = Get-NetAdapterPowerManagement -Name $adapter.Name -ErrorAction Stop
            $powerRows.Add([pscustomobject]@{
                Name=$adapter.Name
                AllowComputerToTurnOffDevice=$pm.AllowComputerToTurnOffDevice
                WakeOnMagicPacket=$pm.WakeOnMagicPacket
                WakeOnPattern=$pm.WakeOnPattern
            })
        } catch {}
    }
    if ($powerRows.Count -gt 0) {
        $lines.Add(($powerRows.ToArray() | Format-Table -AutoSize | Out-String -Width 260).TrimEnd())
    }
    else {
        $lines.Add("(Power-management information not exposed by installed adapter drivers.)")
    }

    $lines.Add("")
    $lines.Add("Sanity findings:")
    $sanity = New-Object System.Collections.Generic.List[string]
    foreach ($adapter in $adapterRows) {
        if ($adapter.Status -eq "Disabled") { $sanity.Add($adapter.Name + ": adapter is disabled.") }
        elseif ($adapter.Status -notin @("Up","Disconnected")) { $sanity.Add($adapter.Name + ": status is " + $adapter.Status + ".") }
    }
    foreach ($stat in $stats) {
        $err = 0
        try { $err = [int64]$stat.ReceivedPacketErrors + [int64]$stat.OutboundPacketErrors } catch {}
        if ($err -gt 0) { $sanity.Add($stat.Name + ": packet errors are non-zero (" + $err + ").") }
    }
    foreach ($driver in $netDrivers) {
        $driverDate = $null
        try { $driverDate = [datetime]$driver.DriverDate } catch {}
        if ($driverDate -and $driverDate -lt (Get-Date).AddYears(-5)) {
            $sanity.Add($driver.DeviceName + ": driver date is older than five years (" + $driverDate.ToShortDateString() + "). Verify vendor/OEM support before changing it.")
        }
        if ($driver.IsSigned -eq $false) { $sanity.Add($driver.DeviceName + ": signed-driver inventory reports IsSigned=False.") }
    }
    if ($sanity.Count -gt 0) { foreach ($item in $sanity) { $lines.Add("ATTENTION: " + $item) } }
    else { $lines.Add("No adapter sanity finding was triggered by the exposed Windows data.") }
}
catch { $lines.Add("Adapter sanity collection unavailable: " + $_.Exception.Message) }

Add-Section "RECENT NETWORK ADAPTER / DRIVER EVENTS - 14 DAYS"
try {
    $netEvents = @(Get-WinEvent -FilterHashtable @{LogName="System";StartTime=(Get-Date).AddDays(-14)} -ErrorAction Stop |
        Where-Object {
            ($_.Level -in 1,2,3) -and
            ($_.ProviderName -match '(?i)(Netwtw|Tcpip|NDIS|e1d|e1rexpress|e2fexpress|rtwlane|NetAdapter|Kernel-PnP)')
        } |
        Sort-Object TimeCreated -Descending |
        Select-Object -First 100 TimeCreated,Id,ProviderName,LevelDisplayName,@{N="Message";E={($_.Message -replace "[\r\n]+"," " -replace "\s{2,}"," ").Trim()}})
    $lines.Add(($netEvents | Format-Table -Wrap -AutoSize | Out-String -Width 260).TrimEnd())
}
catch { $lines.Add("Recent adapter event query unavailable: " + $_.Exception.Message) }

Add-Section "ROUTES"
Add-External "route" { & route.exe print }

Add-Section "ARP / NEIGHBOR CACHE"
Add-External "arp" { & arp.exe -a }

Add-Section "DNS SERVERS + GATEWAY"
try {
    $cfg = Get-NetIPConfiguration -ErrorAction Stop
    $lines.Add(($cfg | Format-List InterfaceAlias,IPv4Address,IPv6Address,IPv4DefaultGateway,DNSServer | Out-String -Width 260).TrimEnd())
}
catch { $lines.Add("Unavailable: " + $_.Exception.Message) }

Add-Section "GATEWAY TEST"
try {
    $route = Get-NetRoute -DestinationPrefix "0.0.0.0/0" -ErrorAction Stop |
        Sort-Object RouteMetric,InterfaceMetric | Select-Object -First 1
    if ($route.NextHop) {
        $lines.Add("Gateway: " + $route.NextHop)
        $ping = Test-Connection -ComputerName $route.NextHop -Count 2 -ErrorAction SilentlyContinue
        if ($ping) { $lines.Add(($ping | Format-Table -AutoSize | Out-String -Width 260).TrimEnd()) }
        else { $lines.Add("No ICMP replies. ICMP may be filtered; this is not definitive.") }
    }
    else { $lines.Add("No IPv4 default gateway found.") }
}
catch { $lines.Add("Gateway test unavailable: " + $_.Exception.Message) }

Add-Section "INTERNET IP TEST"
Add-External "ping" { & ping.exe -n 3 1.1.1.1 }

Add-Section "DNS RESOLUTION TEST"
Add-External "nslookup" { & nslookup.exe www.microsoft.com }

Add-Section "HTTPS TEST"
try {
    $r = Invoke-WebRequest -Uri "https://www.msftconnecttest.com/connecttest.txt" -UseBasicParsing -TimeoutSec 10 -ErrorAction Stop
    $lines.Add("HTTPS status: " + $r.StatusCode)
}
catch { $lines.Add("HTTPS FAILED / BLOCKED: " + $_.Exception.Message) }

Add-Section "MTU PROBE"
Add-External "ping MTU" { & ping.exe -f -l 1472 -n 2 1.1.1.1 }

Add-Section "NETWORK PROFILE"
try {
    $profiles = Get-NetConnectionProfile -ErrorAction Stop
    $lines.Add(($profiles | Format-Table -AutoSize | Out-String -Width 260).TrimEnd())
}
catch { $lines.Add("Unavailable: " + $_.Exception.Message) }

Add-Section "WINHTTP PROXY"
Add-External "netsh winhttp" {
    $native = Invoke-ToolkitNativeCommand -FilePath "netsh.exe" -Arguments @("winhttp","show","proxy") -Label "Network Triage WinHTTP Proxy" -Action "Network Triage" -Quiet
    $native.Output
}

Add-Section "FIREWALL PROFILES"
Add-External "netsh advfirewall" {
    $native = Invoke-ToolkitNativeCommand -FilePath "netsh.exe" -Arguments @("advfirewall","show","allprofiles","state") -Label "Network Triage Firewall Profiles" -Action "Network Triage" -Quiet
    $native.Output
}

Add-Section "LISTENING PORTS"
Add-External "netstat" { & netstat.exe -ano }

if ($target) {
    Add-Section ("TARGET PORT TESTS: " + $target)
    $ports = @(22,53,80,135,139,443,445,3389)
    $rows = foreach ($port in $ports) {
        try {
            $r = Test-NetConnection -ComputerName $target -Port $port -WarningAction SilentlyContinue -InformationLevel Detailed
            [pscustomobject]@{
                Host=$target
                Port=$port
                Open=$r.TcpTestSucceeded
                RemoteAddress=$r.RemoteAddress
                SourceAddress=$r.SourceAddress
            }
        }
        catch {
            [pscustomobject]@{Host=$target;Port=$port;Open=$false;RemoteAddress="Unavailable";SourceAddress="Unavailable"}
        }
    }
    $lines.Add(($rows | Format-Table -AutoSize | Out-String -Width 260).TrimEnd())
}

& $writer -BasePath $basePath -Title "Network Triage" -Body ($lines -join [Environment]::NewLine)
Write-Host ""
Write-Host "Network triage complete."
Write-Host ("Report: " + $basePath + ".html")
try { Start-Process -FilePath ($basePath + ".html") } catch {}
exit 0

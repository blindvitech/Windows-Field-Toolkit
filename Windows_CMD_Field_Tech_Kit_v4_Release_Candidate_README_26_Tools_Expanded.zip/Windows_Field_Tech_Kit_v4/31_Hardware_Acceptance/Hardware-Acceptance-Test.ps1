$ErrorActionPreference="SilentlyContinue"
$ProgressPreference="SilentlyContinue"

$toolkitRoot=Split-Path $PSScriptRoot -Parent
$diagnosticEvidence=Join-Path $toolkitRoot "00_Common\Diagnostic-Evidence.ps1"
if(Test-Path -LiteralPath $diagnosticEvidence -PathType Leaf){. $diagnosticEvidence}
$logs=Join-Path $toolkitRoot "Logs"
if(-not(Test-Path -LiteralPath $logs)){New-Item -ItemType Directory -Path $logs -Force|Out-Null}
$writer=Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"
$basePath=Join-Path $logs ($env:COMPUTERNAME+"_Hardware_Acceptance_"+(Get-Date -Format "yyyyMMdd_HHmmss"))

$lines=New-Object System.Collections.Generic.List[string]
$findings=New-Object System.Collections.Generic.List[object]
$capabilityRows=New-Object System.Collections.Generic.List[object]
$hardwareEvidence=New-Object System.Collections.Generic.List[object]

function Add-Finding([string]$Severity,[string]$Area,[string]$Finding){
    $confidence="UNKNOWN"
    if($Severity -eq "FAIL"){$confidence="Confirmed"}
    elseif($Severity -eq "REVIEW"){$confidence="Possible"}
    else{$confidence="Context"}
    $findings.Add((New-ToolkitDiagnosticFinding -Severity $Severity -Category $Area -Evidence $Finding `
        -Confidence $confidence -SourceTool "ADV-070"))
}
function Add-Section([string]$Title,$Data,[string]$Note=""){
    $lines.Add("")
    $lines.Add(("="*78));$lines.Add($Title);$lines.Add(("="*78))
    if($Note){$lines.Add("NOTE: "+$Note)}
    $x=($Data|Out-String -Width 280).TrimEnd()
    if($x){$lines.Add($x)}else{$lines.Add("(No data returned / not applicable.)")}
}

Write-Host "Collecting Hardware Acceptance Test..."

$cs=Get-CimInstance Win32_ComputerSystem -ErrorAction SilentlyContinue
$bios=Get-CimInstance Win32_BIOS -ErrorAction SilentlyContinue
$os=Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
$identity=[pscustomobject]@{
    Manufacturer=$cs.Manufacturer
    Model=$cs.Model
    SystemType=$cs.SystemType
    SerialNumber=$bios.SerialNumber
    BIOSManufacturer=$bios.Manufacturer
    BIOSVersion=($bios.SMBIOSBIOSVersion -join ", ")
    BIOSReleaseDate=$bios.ReleaseDate
    Windows=$os.Caption
    Version=$os.Version
    Build=$os.BuildNumber
    Architecture=$os.OSArchitecture
}

$cpu=@(Get-CimInstance Win32_Processor -ErrorAction SilentlyContinue|
    Select-Object Name,Manufacturer,Status,NumberOfCores,NumberOfLogicalProcessors,MaxClockSpeed,CurrentClockSpeed)
foreach($c in $cpu){
    if($c.Status -and $c.Status -ne "OK"){Add-Finding "REVIEW" "CPU" ($c.Name+": status="+$c.Status)}
}

$memory=@(Get-CimInstance Win32_PhysicalMemory -ErrorAction SilentlyContinue|
    Select-Object Manufacturer,PartNumber,SerialNumber,@{N="CapacityGB";E={[math]::Round($_.Capacity/1GB,2)}},Speed,ConfiguredClockSpeed,Status)
foreach($m in $memory){
    if($m.Status -and $m.Status -ne "OK"){Add-Finding "REVIEW" "Memory" ($m.PartNumber+": status="+$m.Status)}
}
$totalRam=0
try{$totalRam=[math]::Round($cs.TotalPhysicalMemory/1GB,2)}catch{}

# TPM: distinguish a definitive state from a query that returned no usable data.
$tpm=$null
try{
    $t=Get-Tpm -ErrorAction Stop
    $usableTpmFields=@($t.TpmPresent,$t.TpmReady,$t.TpmEnabled,$t.TpmActivated) | Where-Object { $null -ne $_ }
    if($usableTpmFields.Count -eq 0){
        $cf=Get-ToolkitCapabilityFailureClassification -NoData -Context "Get-Tpm returned no usable state fields."
        $capabilityRows.Add((New-ToolkitCapabilityStatus -Capability "TPM query" -Available $false -Status $cf.Label -Detail $cf.Detail -SourceTool "ADV-070"))
        $tpm=[pscustomobject]@{
            QueryStatus=$cf.Label
            TpmPresent="Unknown"
            TpmReady="Unknown"
            TpmEnabled="Unknown"
            TpmActivated="Unknown"
            ManufacturerIdTxt=$t.ManufacturerIdTxt
            ManufacturerVersion=$t.ManufacturerVersion
        }
    } else {
        $capabilityRows.Add((New-ToolkitCapabilityStatus -Capability "TPM query" -Available $true -Status "Available" -Detail "Get-Tpm returned usable state fields." -SourceTool "ADV-070"))
        $tpm=[pscustomobject]@{
            QueryStatus="Available"
            TpmPresent=$t.TpmPresent
            TpmReady=$t.TpmReady
            TpmEnabled=$t.TpmEnabled
            TpmActivated=$t.TpmActivated
            ManufacturerIdTxt=$t.ManufacturerIdTxt
            ManufacturerVersion=$t.ManufacturerVersion
        }
        if($t.TpmPresent -eq $true -and $t.TpmReady -eq $false){Add-Finding "REVIEW" "TPM" "TPM is present but not ready."}
    }
}catch{
    $cf=Get-ToolkitCapabilityFailureClassification -ExceptionMessage $_.Exception.Message -Context "Get-Tpm"
    $capabilityRows.Add((New-ToolkitCapabilityStatus -Capability "TPM query" -Available $false -Status $cf.Label -Detail $cf.Detail -SourceTool "ADV-070"))
    $tpm=[pscustomobject]@{
        QueryStatus=$cf.Label
        TpmPresent="Unknown"
        TpmReady="Unknown"
        TpmEnabled="Unknown"
        TpmActivated="Unknown"
        ManufacturerIdTxt=""
        ManufacturerVersion=""
    }
}

# Secure Boot: report Disabled only when Windows actually returns False.
$secureBoot=[pscustomobject]@{QueryStatus="Unavailable / indeterminate";State="Unknown"}
try{
    $sb=Confirm-SecureBootUEFI -ErrorAction Stop
    if($sb -eq $true){
        $capabilityRows.Add((New-ToolkitCapabilityStatus -Capability "Secure Boot query" -Available $true -Status "Available" -Detail "Confirm-SecureBootUEFI returned a definitive state." -SourceTool "ADV-070"))
        $secureBoot=[pscustomobject]@{QueryStatus="Available";State="Enabled"}
    } elseif($sb -eq $false){
        $capabilityRows.Add((New-ToolkitCapabilityStatus -Capability "Secure Boot query" -Available $true -Status "Available" -Detail "Confirm-SecureBootUEFI returned a definitive state." -SourceTool "ADV-070"))
        $secureBoot=[pscustomobject]@{QueryStatus="Available";State="Disabled"}
        Add-Finding "REVIEW" "Secure Boot" "Secure Boot is disabled. This may be intentional; review against the intended acceptance baseline."
    }
}catch{
    $cf=Get-ToolkitCapabilityFailureClassification -ExceptionMessage $_.Exception.Message -Context "Confirm-SecureBootUEFI"
    $capabilityRows.Add((New-ToolkitCapabilityStatus -Capability "Secure Boot query" -Available $false -Status $cf.Label -Detail $cf.Detail -SourceTool "ADV-070"))
    $secureBoot=[pscustomobject]@{QueryStatus=$cf.Label;State="Unknown"}
}

$physical=@(Get-PhysicalDisk -ErrorAction SilentlyContinue)
$diskRows=@($physical|Select-Object FriendlyName,Model,SerialNumber,MediaType,BusType,HealthStatus,OperationalStatus,@{N="SizeGB";E={[math]::Round($_.Size/1GB,2)}})
$reliability=New-Object System.Collections.Generic.List[object]
foreach($d in $physical){
    if([string]$d.HealthStatus -notmatch '^(Healthy|Unknown)$'){Add-Finding "FAIL" "Storage" ($d.FriendlyName+": HealthStatus="+$d.HealthStatus)}
    if([string]$d.OperationalStatus -match 'Predictive Failure|Lost Communication|Error|Degraded'){Add-Finding "FAIL" "Storage" ($d.FriendlyName+": OperationalStatus="+($d.OperationalStatus -join ", "))}
    try{
        $r=$d|Get-StorageReliabilityCounter -ErrorAction Stop
        if($r){
            $reliability.Add([pscustomobject]@{
                FriendlyName=$d.FriendlyName
                Temperature=$r.Temperature
                Wear=$r.Wear
                PowerOnHours=$r.PowerOnHours
                ReadErrorsUncorrected=$r.ReadErrorsUncorrected
                WriteErrorsUncorrected=$r.WriteErrorsUncorrected
            })
            if(($null -ne $r.Wear)-and [int64]$r.Wear -ge 90){Add-Finding "FAIL" "Storage" ($d.FriendlyName+": wear="+$r.Wear+"%")}
            elseif(($null -ne $r.Wear)-and [int64]$r.Wear -ge 80){Add-Finding "REVIEW" "Storage" ($d.FriendlyName+": wear="+$r.Wear+"%")}
            if((($null -ne $r.ReadErrorsUncorrected)-and [int64]$r.ReadErrorsUncorrected -gt 0)-or(($null -ne $r.WriteErrorsUncorrected)-and [int64]$r.WriteErrorsUncorrected -gt 0)){
                Add-Finding "FAIL" "Storage" ($d.FriendlyName+": uncorrected I/O errors are non-zero.")
            }
        }
    }catch{
        $knownHidden=([string]$d.BusType -eq "RAID")
        $cf=Get-ToolkitCapabilityFailureClassification -ExceptionMessage $_.Exception.Message -Context ("Storage reliability for "+$d.FriendlyName) -KnownDriverOrApiNotExposed:$knownHidden
        $capabilityRows.Add((New-ToolkitCapabilityStatus -Capability ("Storage Reliability: "+$d.FriendlyName) -Available $false -Status $cf.Label -Detail $cf.Detail -SourceTool "ADV-070"))
    }
}

try{
    Get-CimInstance -Namespace root\wmi -ClassName MSStorageDriver_FailurePredictStatus -ErrorAction Stop|ForEach-Object{
        if($_.PredictFailure){Add-Finding "FAIL" "SMART" ($_.InstanceName+": SMART predicts failure.")}
    }
    $capabilityRows.Add((New-ToolkitCapabilityStatus -Capability "SMART failure prediction" -Available $true -Status "Available" -Detail "MSStorageDriver_FailurePredictStatus query completed." -SourceTool "ADV-070"))
}catch{
    $cf=Get-ToolkitCapabilityFailureClassification -ExceptionMessage $_.Exception.Message -Context "MSStorageDriver_FailurePredictStatus"
    $capabilityRows.Add((New-ToolkitCapabilityStatus -Capability "SMART failure prediction" -Available $false -Status $cf.Label -Detail $cf.Detail -SourceTool "ADV-070"))
}

# Keep zero-size / no-filesystem objects visible as context, but do not score them as "0% free".
$volumes=@(Get-Volume -ErrorAction SilentlyContinue|Select-Object DriveLetter,FileSystemLabel,FileSystem,HealthStatus,
    @{N="SizeGB";E={[math]::Round($_.Size/1GB,2)}},
    @{N="FreeGB";E={[math]::Round($_.SizeRemaining/1GB,2)}},
    @{N="PercentFree";E={if($_.Size -gt 0){[math]::Round(($_.SizeRemaining/$_.Size)*100,1)}else{$null}}})
foreach($v in $volumes){
    if($v.DriveLetter -and $v.FileSystem -and $null -ne $v.PercentFree -and $v.SizeGB -gt 0 -and $v.PercentFree -lt 5){
        Add-Finding "REVIEW" "Storage" ([string]$v.DriveLetter+": "+$v.FreeGB+" GB free / "+$v.PercentFree+"% free. Review before updates, imaging, or large repairs.")
    }
}

$batterySummary=$null
try{
    $static=Get-CimInstance -Namespace root\wmi -Class BatteryStaticData -ErrorAction Stop|Select-Object -First 1
    $full=Get-CimInstance -Namespace root\wmi -Class BatteryFullChargedCapacity -ErrorAction Stop|Select-Object -First 1
    if($static -and $full -and [int64]$static.DesignedCapacity -gt 0){
        $health=[math]::Round(([double]$full.FullChargedCapacity/[double]$static.DesignedCapacity)*100,1)
        $batterySummary=[pscustomobject]@{DesignedCapacity=$static.DesignedCapacity;FullChargedCapacity=$full.FullChargedCapacity;EstimatedHealthPercent=$health}
        if($health -lt 50){Add-Finding "FAIL" "Battery" ("Estimated full-charge capacity is "+$health+"% of design.")}
        elseif($health -lt 70){Add-Finding "REVIEW" "Battery" ("Estimated full-charge capacity is "+$health+"% of design.")}
    }
}catch{}
if(-not $batterySummary){
    $wb=Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue
    if($wb){
        $batterySummary=$wb|Select-Object Name,Status,EstimatedChargeRemaining,BatteryStatus
        $capabilityRows.Add((New-ToolkitCapabilityStatus -Capability "Battery telemetry" -Available $true -Status "Available" -Detail "Win32_Battery returned a battery." -SourceTool "ADV-070"))
    }
    else{
        $cf=Get-ToolkitCapabilityFailureClassification -NotApplicable -NotApplicableReason "No battery was detected; typical for a desktop or battery-less system."
        $capabilityRows.Add((New-ToolkitCapabilityStatus -Capability "Battery telemetry" -Available $false -Status $cf.Label -Detail $cf.Detail -SourceTool "ADV-070"))
        $batterySummary=[pscustomobject]@{Status="No battery detected / desktop system."}
    }
}

$adapters=@(Get-NetAdapter -Physical -ErrorAction SilentlyContinue|Select-Object Name,InterfaceDescription,Status,LinkSpeed,DriverInformation,DriverVersion)
$netDrivers=@(Get-CimInstance Win32_PnPSignedDriver -ErrorAction SilentlyContinue|Where-Object{$_.DeviceClass -eq "NET"}|Select-Object DeviceName,DriverProviderName,DriverVersion,DriverDate,IsSigned)
foreach($d in $netDrivers){
    if($d.IsSigned -eq $false){Add-Finding "REVIEW" "Network" ($d.DeviceName+": driver reports unsigned.")}
}

$problemDevices=@()
try{$problemDevices=@(Get-PnpDevice -ErrorAction Stop|Where-Object{$_.Status -notin @("OK","Unknown")}|Select-Object Status,Class,FriendlyName,InstanceId)}catch{}
if($problemDevices.Count -gt 0){Add-Finding "REVIEW" "Devices" ($problemDevices.Count.ToString()+" Plug and Play devices report a non-OK/non-Unknown status.")}

$whea=@()
try{
    $whea=@(Get-WinEvent -FilterHashtable @{LogName="System";ProviderName="Microsoft-Windows-WHEA-Logger";StartTime=(Get-Date).AddDays(-7)} -ErrorAction Stop|
        Where-Object{$_.Level -in 1,2,3}|
        Sort-Object TimeCreated -Descending|
        Select-Object -First 50 TimeCreated,Id,LevelDisplayName,@{N="Message";E={($_.Message -replace "[\r\n]+"," " -replace "\s{2,}"," ").Trim()}})
    $capabilityRows.Add((New-ToolkitCapabilityStatus -Capability "WHEA event query" -Available $true -Status "Available" -Detail "System WHEA event log query completed." -SourceTool "ADV-070"))
}catch{
    $cf=Get-ToolkitCapabilityFailureClassification -ExceptionMessage $_.Exception.Message -Context "WHEA event query"
    $capabilityRows.Add((New-ToolkitCapabilityStatus -Capability "WHEA event query" -Available $false -Status $cf.Label -Detail $cf.Detail -SourceTool "ADV-070"))
}
foreach($e in $whea){
    $cleanMessage=(($e.Message -replace "[\r\n]+"," " -replace "\s{2,}"," ").Trim())
    $hardwareEvidence.Add([pscustomobject]@{
        EvidenceId=(Get-ToolkitEvidenceId -Category "WindowsEvent" -Source "Microsoft-Windows-WHEA-Logger" -EventId ([string]$e.Id) -Timestamp $e.TimeCreated -Device "" -Evidence $cleanMessage)
        Timestamp=$e.TimeCreated
        ObservedAt=(Get-Date)
        Class="Hardware / WHEA"
        Confidence="CONFIRMED"
        Source="Microsoft-Windows-WHEA-Logger"
        EventId=[string]$e.Id
        Severity=$e.LevelDisplayName
        DeviceContext=""
        Summary=$cleanMessage
    })
}
if($whea.Count -gt 0){Add-Finding "REVIEW" "WHEA" ($whea.Count.ToString()+" WHEA warning/error event(s) found in the last 7 days.")}

$status="PASS"
if(@($findings|Where-Object Severity -eq "FAIL").Count -gt 0){$status="FAIL / INVESTIGATE"}
elseif($findings.Count -gt 0){$status="PASS WITH REVIEW ITEMS"}

$reliabilityNote="Windows/storage drivers do not always expose reliability counters."
if($reliability.Count -eq 0 -and @($physical|Where-Object{$_.BusType -eq "RAID"}).Count -gt 0){
    $reliabilityNote="No Storage Reliability counters were exposed. One or more drives are presented through RAID/VMD; the controller/driver may hide NVMe SMART/reliability telemetry. Absence of counters is UNKNOWN, not healthy or failed."
}

$lines.Add("HARDWARE ACCEPTANCE TEST")
$lines.Add("Computer: "+$env:COMPUTERNAME)
$lines.Add("Generated: "+(Get-Date))
$lines.Add("Acceptance result: "+$status)
$lines.Add("Installed RAM: "+$totalRam+" GB")
$lines.Add("")
$lines.Add("This is a read-only acceptance screen. It does not stress CPU/GPU/RAM, run a destructive disk test, or replace OEM diagnostics. REVIEW is not the same as hardware failure.")
$lines.Add("Unknown/unavailable TPM, Secure Boot, or storage telemetry is reported as indeterminate and is not scored as a pass or failure by itself.")

$findingDisplay=$(if($findings.Count -gt 0){@($findings.ToArray()|Select-Object Severity,Category,Confidence,Device,Evidence,Action,EvidenceId)}else{[pscustomobject]@{Severity="INFO";Category="Acceptance";Confidence="CONTEXT";Device="";Evidence="No failure/review threshold was triggered by exposed Windows data.";Action="";EvidenceId=""}})
Add-Section "ACCEPTANCE FINDINGS" $findingDisplay
Add-Section "CAPABILITY / QUERY STATUS" $(if($capabilityRows.Count -gt 0){$capabilityRows.ToArray()}else{$null}) "Failures are classified as Not Supported, Driver/API Did Not Expose, Requires Elevation, Not Applicable, Query/API Failed, or Unknown/Indeterminate."
Add-Section "SYSTEM / FIRMWARE IDENTITY" $identity
Add-Section "CPU" $cpu
Add-Section "MEMORY MODULES" $memory
Add-Section "TPM" $tpm "Unavailable / indeterminate means Windows did not return enough information to assert present/ready/disabled state."
Add-Section "SECURE BOOT" $secureBoot "Disabled is reported only when Confirm-SecureBootUEFI definitively returns False."
Add-Section "PHYSICAL STORAGE" $diskRows
Add-Section "STORAGE RELIABILITY" $(if($reliability.Count -gt 0){$reliability.ToArray()}else{$null}) $reliabilityNote
Add-Section "VOLUMES" $volumes "Zero-size/no-filesystem volume objects are retained for context but are excluded from free-space acceptance scoring."
Add-Section "BATTERY" $batterySummary
Add-Section "PHYSICAL NETWORK ADAPTERS" $adapters
Add-Section "SIGNED NETWORK DRIVERS" $netDrivers
Add-Section "PROBLEM DEVICES" $problemDevices
Add-Section "WHEA WARNING/ERROR EVENTS - 7 DAYS" $whea

& $writer -BasePath $basePath -Title "Hardware Acceptance Test" -Body ($lines -join [Environment]::NewLine) -ToolId "ADV-070"
Write-ToolkitDiagnosticSidecar -BasePath $basePath -ToolkitRoot $toolkitRoot -ToolId "ADV-070" `
    -Title "Hardware Acceptance Test" -Findings $(if($findings.Count -gt 0){$findings.ToArray()}else{@()}) `
    -Evidence $(if($hardwareEvidence.Count -gt 0){$hardwareEvidence.ToArray()}else{@()}) `
    -Capabilities $(if($capabilityRows.Count -gt 0){$capabilityRows.ToArray()}else{@()})
$html=$basePath+".html"
Write-Host("Acceptance result: "+$status)
Write-Host("Report: "+$html)
try{Start-Process -FilePath $html}catch{}
exit 0

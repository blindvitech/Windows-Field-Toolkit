@echo off
setlocal EnableExtensions
title Hardware Acceptance Test
echo Hardware Acceptance Test
echo.
echo Read-only acceptance pass for system identity, CPU, memory, firmware,
echo TPM/Secure Boot, storage health, battery, network, device errors, and WHEA.
echo This is not a CPU/GPU/RAM stress test and does not replace vendor diagnostics.
echo.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Hardware-Acceptance-Test.ps1"
set "RC=%errorlevel%"
echo.
if "%SRMODE%"=="1" (
  if "%RC%"=="0" (echo Hardware Acceptance Test completed successfully.) else (echo Hardware Acceptance Test returned error code %RC%.)
  echo Press any key to continue.
  pause >nul
) else (
  pause
)
exit /b %RC%

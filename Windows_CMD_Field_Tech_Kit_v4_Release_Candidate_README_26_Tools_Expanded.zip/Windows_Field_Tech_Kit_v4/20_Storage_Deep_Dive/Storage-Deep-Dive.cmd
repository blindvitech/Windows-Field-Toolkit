@echo off
setlocal EnableExtensions
title SMART and Drive Deep Dive

echo SMART / Drive Deep Dive
echo.
echo Collecting report data. This may take a moment.
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Storage-Deep-Dive.ps1"
set "RC=%errorlevel%"

if "%SRMODE%"=="1" (
    echo.
    if "%RC%"=="0" (
        echo SMART / Drive Deep Dive completed successfully.
    ) else (
        echo SMART / Drive Deep Dive returned error code %RC%.
    )
    echo Press any key to continue.
    pause >nul
) else (
    echo.
    pause
)

exit /b %RC%

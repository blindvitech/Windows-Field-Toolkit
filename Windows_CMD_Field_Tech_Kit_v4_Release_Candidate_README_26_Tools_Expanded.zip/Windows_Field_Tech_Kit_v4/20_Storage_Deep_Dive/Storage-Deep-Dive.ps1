$ErrorActionPreference = "SilentlyContinue"
$ProgressPreference = "SilentlyContinue"

$toolkitRoot = Split-Path $PSScriptRoot -Parent
$diagnosticEvidence = Join-Path $toolkitRoot "00_Common\Diagnostic-Evidence.ps1"
if (Test-Path -LiteralPath $diagnosticEvidence -PathType Leaf) { . $diagnosticEvidence }
$logs = Join-Path $toolkitRoot "Logs"
if (-not (Test-Path -LiteralPath $logs)) { New-Item -ItemType Directory -Path $logs -Force | Out-Null }
$writer = Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"
$basePath = Join-Path $logs ($env:COMPUTERNAME + "_SMART_Drive_Deep_Dive_" + (Get-Date -Format "yyyyMMdd_HHmmss"))

$lines = New-Object System.Collections.Generic.List[string]
$findings = New-Object System.Collections.Generic.List[object]
$capabilityRows = New-Object System.Collections.Generic.List[object]

function Add-Section {
    param([string]$Title,$Data,[string]$Note="")
    $lines.Add("")
    $lines.Add(("=" * 78)); $lines.Add($Title); $lines.Add(("=" * 78))
    if ($Note) { $lines.Add("NOTE: " + $Note) }
    $text = ($Data | Out-String -Width 280).TrimEnd()
    if ([string]::IsNullOrWhiteSpace($text)) { $lines.Add("(No data returned / not exposed by this hardware or driver.)") }
    else { $lines.Add($text) }
}
function Add-Finding {
    param([string]$Severity,[string]$Device,[string]$Finding)
    $confidence="UNKNOWN"
    if($Severity -eq "REPLACE_SOON"){$confidence="Likely"}
    elseif($Severity -eq "INVESTIGATE"){$confidence="Likely"}
    elseif($Severity -in @("MONITOR","ATTENTION")){$confidence="Possible"}
    elseif($Severity -eq "INFO"){$confidence="Context"}
    $findings.Add((New-ToolkitDiagnosticFinding -Severity $Severity -Category "Storage" -Evidence $Finding `
        -Confidence $confidence -Device $Device -SourceTool "ADV-006"))
}

Write-Host "Collecting SMART / drive deep-dive information..."

$physical = @(Get-PhysicalDisk -ErrorAction SilentlyContinue)
$physicalRows = @($physical | Select-Object FriendlyName,Manufacturer,Model,SerialNumber,MediaType,BusType,HealthStatus,OperationalStatus,@{N="SizeGB";E={[math]::Round($_.Size/1GB,2)}})

$reliabilityRows = New-Object System.Collections.Generic.List[object]
foreach ($disk in $physical) {
    $r = $null
    try {
        $r = $disk | Get-StorageReliabilityCounter -ErrorAction Stop
        if($r){
            $capabilityRows.Add((New-ToolkitCapabilityStatus -Capability ("Storage Reliability: "+$disk.FriendlyName) -Available $true -Status "Available" -Detail "Storage Reliability counters were exposed." -SourceTool "ADV-006"))
        }
    } catch {
        $knownHidden=([string]$disk.BusType -eq "RAID")
        $cf=Get-ToolkitCapabilityFailureClassification -ExceptionMessage $_.Exception.Message -Context ("Storage reliability for "+$disk.FriendlyName) -KnownDriverOrApiNotExposed:$knownHidden
        $capabilityRows.Add((New-ToolkitCapabilityStatus -Capability ("Storage Reliability: "+$disk.FriendlyName) -Available $false -Status $cf.Label -Detail $cf.Detail -SourceTool "ADV-006"))
    }
    if ($r) {
        $reliabilityRows.Add([pscustomobject]@{
            FriendlyName=$disk.FriendlyName
            DeviceId=$r.DeviceId
            Temperature=$r.Temperature
            TemperatureMax=$r.TemperatureMax
            Wear=$r.Wear
            PowerOnHours=$r.PowerOnHours
            ReadErrorsTotal=$r.ReadErrorsTotal
            ReadErrorsUncorrected=$r.ReadErrorsUncorrected
            WriteErrorsTotal=$r.WriteErrorsTotal
            WriteErrorsUncorrected=$r.WriteErrorsUncorrected
            StartStopCycleCount=$r.StartStopCycleCount
        })
        if ($null -ne $r.Wear -and [int64]$r.Wear -ge 90) { Add-Finding "REPLACE_SOON" $disk.FriendlyName ("Wear is " + $r.Wear + "%.") }
        elseif ($null -ne $r.Wear -and [int64]$r.Wear -ge 80) { Add-Finding "MONITOR" $disk.FriendlyName ("Wear is " + $r.Wear + "%.") }
        if (($null -ne $r.ReadErrorsUncorrected -and [int64]$r.ReadErrorsUncorrected -gt 0) -or ($null -ne $r.WriteErrorsUncorrected -and [int64]$r.WriteErrorsUncorrected -gt 0)) {
            Add-Finding "INVESTIGATE" $disk.FriendlyName "Uncorrected read/write errors are non-zero."
        }
        if ($null -ne $r.Temperature -and [int64]$r.Temperature -ge 70) { Add-Finding "INVESTIGATE" $disk.FriendlyName ("Temperature is " + $r.Temperature + " C.") }
        elseif ($null -ne $r.Temperature -and [int64]$r.Temperature -ge 60) { Add-Finding "MONITOR" $disk.FriendlyName ("Temperature is " + $r.Temperature + " C.") }
    }
    if ([string]$disk.HealthStatus -notmatch '^(Healthy|Unknown)$') {
        Add-Finding "INVESTIGATE" $disk.FriendlyName ("Storage health status: " + $disk.HealthStatus)
    }
    if ([string]$disk.OperationalStatus -match 'Lost Communication|Predictive Failure|Error|Degraded') {
        Add-Finding "REPLACE_SOON" $disk.FriendlyName ("Operational status: " + ($disk.OperationalStatus -join ", "))
    }
}

$smart = @()
try {
    $smart = @(Get-CimInstance -Namespace root\wmi -ClassName MSStorageDriver_FailurePredictStatus -ErrorAction Stop |
        Select-Object InstanceName,PredictFailure,Reason)
    foreach ($s in $smart) {
        if ($s.PredictFailure) { Add-Finding "REPLACE_SOON" $s.InstanceName ("SMART failure prediction asserted. Reason=" + $s.Reason) }
    }
    if($smart.Count -gt 0){
        $capabilityRows.Add((New-ToolkitCapabilityStatus -Capability "SMART failure prediction" -Available $true -Status "Available" -Detail "MSStorageDriver_FailurePredictStatus returned data." -SourceTool "ADV-006"))
    }else{
        $knownHidden=(@($physical|Where-Object{$_.BusType -eq "RAID"}).Count -gt 0)
        $cf=Get-ToolkitCapabilityFailureClassification -NoData -Context "MSStorageDriver_FailurePredictStatus returned no instances." -KnownDriverOrApiNotExposed:$knownHidden
        $capabilityRows.Add((New-ToolkitCapabilityStatus -Capability "SMART failure prediction" -Available $false -Status $cf.Label -Detail $cf.Detail -SourceTool "ADV-006"))
    }
} catch {
    $knownHidden=(@($physical|Where-Object{$_.BusType -eq "RAID"}).Count -gt 0)
    $cf=Get-ToolkitCapabilityFailureClassification -ExceptionMessage $_.Exception.Message -Context "MSStorageDriver_FailurePredictStatus" -KnownDriverOrApiNotExposed:$knownHidden
    $capabilityRows.Add((New-ToolkitCapabilityStatus -Capability "SMART failure prediction" -Available $false -Status $cf.Label -Detail $cf.Detail -SourceTool "ADV-006"))
}

# Build a current disk-number map so Event Log HarddiskN references can be interpreted.
$diskObjects = @(Get-Disk -ErrorAction SilentlyContinue)
$disks = @($diskObjects |
    Select-Object Number,FriendlyName,SerialNumber,BusType,PartitionStyle,HealthStatus,OperationalStatus,IsBoot,IsSystem,@{N="SizeGB";E={[math]::Round($_.Size/1GB,2)}})
$diskByNumber = @{}
foreach($d in $diskObjects){$diskByNumber[[int]$d.Number]=$d}

$volumes = @(Get-Volume -ErrorAction SilentlyContinue |
    Select-Object DriveLetter,FileSystemLabel,FileSystem,HealthStatus,
        @{N="SizeGB";E={[math]::Round($_.Size/1GB,2)}},
        @{N="FreeGB";E={[math]::Round($_.SizeRemaining/1GB,2)}},
        @{N="PercentFree";E={if($_.Size -gt 0){[math]::Round(($_.SizeRemaining/$_.Size)*100,1)}else{$null}}})
foreach ($v in $volumes) {
    if ($v.DriveLetter -and $v.FileSystem -and $v.SizeGB -gt 0 -and $null -ne $v.PercentFree -and $v.PercentFree -lt 5) {
        Add-Finding "ATTENTION" ([string]$v.DriveLetter + ":") ($v.FreeGB + " GB free / " + $v.PercentFree + "% free. Review before updates, imaging, or large repairs.")
    }
}

$storageEventsRaw = @()
try {
    $storageEventsRaw = @(Get-WinEvent -FilterHashtable @{LogName="System";StartTime=(Get-Date).AddDays(-30)} -ErrorAction Stop |
        Where-Object {
            $_.ProviderName -match '(?i)^(disk|stornvme|storahci|iaStor|iaStorA|Ntfs|volmgr|partmgr)$' -and
            ($_.Level -in 1,2,3 -or $_.Id -in 7,11,15,51,55,129,153,157,158)
        } |
        Sort-Object TimeCreated -Descending)
    $capabilityRows.Add((New-ToolkitCapabilityStatus -Capability "Storage Event Log query" -Available $true -Status "Available" -Detail "System storage-event query completed." -SourceTool "ADV-006"))
} catch {
    $cf=Get-ToolkitCapabilityFailureClassification -ExceptionMessage $_.Exception.Message -Context "System storage Event Log query"
    $capabilityRows.Add((New-ToolkitCapabilityStatus -Capability "Storage Event Log query" -Available $false -Status $cf.Label -Detail $cf.Detail -SourceTool "ADV-006"))
}

$storageEvents = New-Object System.Collections.Generic.List[object]
foreach($e in $storageEventsRaw){
    $dc=Get-ToolkitDiskContext -Message ([string]$e.Message) -DiskMap $diskByNumber
    $diskNumber=$dc.DiskNumber
    $mappedName=$dc.Name
    $deviceClass=$dc.Class
    $mappedBus=$dc.BusType
    $mappedStatus=$dc.OperationalStatus
    $mappedSizeGB=$dc.SizeGB

    $eventKind="Storage warning/error"
    if($e.Id -eq 11){$eventKind="Controller error"}
    elseif($e.Id -eq 157){$eventKind="Surprise removal"}
    elseif($e.Id -eq 158){$eventKind="Duplicate disk identifier"}
    elseif($e.Id -eq 129){$eventKind="Controller reset / timeout"}
    elseif($e.Id -eq 153){$eventKind="I/O retry"}
    elseif($e.Id -eq 55){$eventKind="File-system corruption / consistency"}
    elseif($e.ProviderName -eq "Ntfs"){$eventKind="NTFS warning/error"}

    $cleanMessage=(($e.Message -replace "[\r\n]+"," " -replace "\s{2,}"," ").Trim())
    $storageEvents.Add([pscustomobject]@{
        EvidenceId=(Get-ToolkitEvidenceId -Category "WindowsEvent" -Source $e.ProviderName -EventId ([string]$e.Id) `
            -Timestamp $e.TimeCreated -Device $dc.Description -Evidence $cleanMessage)
        TimeCreated=$e.TimeCreated
        ObservedAt=(Get-Date)
        Id=$e.Id
        ProviderName=$e.ProviderName
        Level=$e.LevelDisplayName
        DiskNumber=$(if($null -ne $diskNumber){$diskNumber}else{""})
        DeviceClass=$deviceClass
        MappedDevice=$mappedName
        BusType=$mappedBus
        SizeGB=$mappedSizeGB
        EventKind=$eventKind
        Message=$cleanMessage
    })
}

$eventSummary=@()
if($storageEvents.Count -gt 0){
    $eventSummary=@($storageEvents.ToArray() |
        Group-Object DeviceClass,DiskNumber,MappedDevice,Id,EventKind |
        Sort-Object Count -Descending |
        ForEach-Object{
            $first=$_.Group|Sort-Object TimeCreated -Descending|Select-Object -First 1
            [pscustomobject]@{
                Count=$_.Count
                DeviceClass=$first.DeviceClass
                DiskNumber=$first.DiskNumber
                MappedDevice=$first.MappedDevice
                EventId=$first.Id
                EventKind=$first.EventKind
                MostRecent=$first.TimeCreated
            }
        })
}

$internalSerious=@($storageEvents.ToArray()|Where-Object{
    $_.DeviceClass -eq "INTERNAL / FIXED" -and $_.Id -in 7,11,15,51,55,129,153
})
$unmappedSerious=@($storageEvents.ToArray()|Where-Object{
    $_.DeviceClass -eq "UNMAPPED" -and $_.Id -in 7,11,15,51,55,129,153
})
$removableContext=@($storageEvents.ToArray()|Where-Object{$_.DeviceClass -eq "REMOVABLE / NO-MEDIA"})

if($internalSerious.Count -gt 0){
    Add-Finding "INVESTIGATE" "Internal storage events" ($internalSerious.Count.ToString()+" serious storage event(s) map to current internal/fixed disks in 30 days.")
}
if($unmappedSerious.Count -gt 0){
    Add-Finding "ATTENTION" "Unmapped storage events" ($unmappedSerious.Count.ToString()+" serious storage event(s) could not be mapped to a current disk number.")
}
if($removableContext.Count -gt 0 -and $internalSerious.Count -eq 0 -and $unmappedSerious.Count -eq 0){
    Add-Finding "INFO" "Removable storage context" ($removableContext.Count.ToString()+" storage event(s) map to USB/no-media devices; they do not by themselves indicate internal-drive failure.")
}

$controllers = @(Get-PnpDevice -Class SCSIAdapter,HDC -ErrorAction SilentlyContinue |
    Select-Object Status,Class,FriendlyName,InstanceId)
$trim = (& fsutil.exe behavior query DisableDeleteNotify 2>&1 | Out-String -Width 260).TrimEnd()

$overall = "HEALTHY"
if (@($findings | Where-Object Severity -eq "REPLACE_SOON").Count -gt 0) { $overall = "REPLACEMENT / BACKUP ATTENTION" }
elseif (@($findings | Where-Object Severity -eq "INVESTIGATE").Count -gt 0) { $overall = "INVESTIGATE" }
elseif (@($findings | Where-Object Severity -in @("MONITOR","ATTENTION")).Count -gt 0) { $overall = "MONITOR" }

$reliabilityNote="Windows and storage drivers do not expose every vendor SMART/NVMe attribute."
if($reliabilityRows.Count -eq 0 -and @($physical|Where-Object{$_.BusType -eq "RAID"}).Count -gt 0){
    $reliabilityNote="No Storage Reliability counters were exposed. One or more NVMe drives are presented as RAID/VMD; Intel RST/VMD or another controller layer may hide direct NVMe SMART/reliability telemetry. Missing counters are UNKNOWN, not a clean bill of health."
}
$smartNote="MSStorageDriver_FailurePredictStatus availability varies by controller and storage driver."
if($smart.Count -eq 0 -and @($physical|Where-Object{$_.BusType -eq "RAID"}).Count -gt 0){
    $smartNote="SMART failure-prediction data was not exposed. RAID/VMD presentation can hide this WMI SMART interface; absence is UNKNOWN and should not be interpreted as SMART PASS."
}

$lines.Add("SMART / DRIVE DEEP DIVE")
$lines.Add("Computer: " + $env:COMPUTERNAME)
$lines.Add("Generated: " + (Get-Date))
$lines.Add("Overall interpretation: " + $overall)
$lines.Add("")
$lines.Add("Windows and storage drivers do not expose every vendor SMART/NVMe attribute. Missing counters are not treated as healthy or unhealthy by themselves.")
$lines.Add("Storage Event Log evidence is mapped to current Get-Disk numbers where possible. USB/no-media reader activity is separated from internal-drive evidence.")
$lines.Add("Event TimeCreated is source-event time; ObservedAt is when Toolkit v4 collected/classified the evidence.")
$lines.Add("A REPLACE_SOON finding means preserve data and validate with the drive/vendor diagnostic before relying on the device.")

$findingDisplay=$(if($findings.Count -gt 0){@($findings.ToArray()|Select-Object Severity,Category,Confidence,Device,Evidence,Action,EvidenceId)}else{[pscustomobject]@{Severity="INFO";Category="Storage";Confidence="CONTEXT";Device="All detected disks";Evidence="No threshold finding was triggered by exposed Windows health data.";Action="";EvidenceId=""}})
Add-Section "INTERPRETATION / FINDINGS" $findingDisplay
Add-Section "CAPABILITY / QUERY STATUS" $(if($capabilityRows.Count -gt 0){$capabilityRows.ToArray()}else{$null}) "Unavailable data is classified as Not Supported, Driver/API Did Not Expose, Requires Elevation, Not Applicable, Query/API Failed, or Unknown/Indeterminate."
Add-Section "PHYSICAL DISKS" $physicalRows
Add-Section "STORAGE RELIABILITY / NVME-EXPOSED COUNTERS" $(if($reliabilityRows.Count -gt 0){$reliabilityRows.ToArray()}else{$null}) $reliabilityNote
Add-Section "SMART FAILURE PREDICTION" $smart $smartNote
Add-Section "WINDOWS DISK INVENTORY" $disks
Add-Section "VOLUMES / FREE SPACE" $volumes "Zero-size/no-filesystem volume objects are retained for context but excluded from free-space scoring."
Add-Section "STORAGE EVENT SUMMARY - 30 DAYS" $eventSummary "Counts are grouped by mapped disk/device class and event type before raw detail is shown."
Add-Section "RECENT INTERNAL / UNMAPPED STORAGE EVENTS - MAX 50" @($storageEvents.ToArray()|Where-Object{$_.DeviceClass -ne "REMOVABLE / NO-MEDIA"}|Select-Object -First 50)
Add-Section "REMOVABLE / NO-MEDIA STORAGE CONTEXT - MAX 50" @($storageEvents.ToArray()|Where-Object{$_.DeviceClass -eq "REMOVABLE / NO-MEDIA"}|Select-Object -First 50) "Repeated controller errors, surprise removals, or duplicate-ID warnings on zero-size USB/no-media devices are context and do not automatically downgrade internal-drive health."
Add-Section "STORAGE CONTROLLERS" $controllers
Add-Section "TRIM / DELETE NOTIFY" $trim

& $writer -BasePath $basePath -Title "SMART / Drive Deep Dive" -Body ($lines -join [Environment]::NewLine) -ToolId "ADV-006"
Write-ToolkitDiagnosticSidecar -BasePath $basePath -ToolkitRoot $toolkitRoot -ToolId "ADV-006" `
    -Title "SMART / Drive Deep Dive" -Findings $(if($findings.Count -gt 0){$findings.ToArray()}else{@()}) `
    -Evidence $(if($storageEvents.Count -gt 0){$storageEvents.ToArray()}else{@()}) `
    -Capabilities $(if($capabilityRows.Count -gt 0){$capabilityRows.ToArray()}else{@()})
$html=$basePath+".html"
Write-Host ("Overall: " + $overall)
Write-Host ("Report: " + $html)
try { Start-Process -FilePath $html } catch {}
exit 0

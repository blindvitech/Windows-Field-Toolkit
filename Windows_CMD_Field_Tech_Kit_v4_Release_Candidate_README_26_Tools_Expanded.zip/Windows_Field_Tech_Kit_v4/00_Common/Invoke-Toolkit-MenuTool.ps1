param(
    [string]$ToolId = "",
    [Parameter(Mandatory=$true)][string]$ToolName,
    [Parameter(Mandatory=$true)][string]$ToolPath,
    [string]$Access = "",
    [switch]$EnforceAccess,
    [ValidateSet("Launcher","Search")][string]$Caller = "Launcher"
)

# IMPORTANT:
# Keep this launcher bridge deliberately small. It must not dot-source
# Foundation-Common.ps1 or evaluate the full capability/runtime stack before a
# tool launches. The target tool owns its own authoritative preflight/safety
# checks. This bridge only handles catalog metadata, access gating, inherited
# context, lightweight lifecycle evidence, and return-code reporting.

$toolkitRoot = Split-Path $PSScriptRoot -Parent
$isScreenReader = ($env:SRMODE -eq "1" -or $env:FIELDTECH_SCREEN_READER -eq "1")

function Test-BridgeAdmin {
    try {
        $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
        $principal = New-Object Security.Principal.WindowsPrincipal($identity)
        return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    }
    catch {
        return $false
    }
}

function Get-BridgeCatalogTool {
    param(
        [string]$Id,
        [string]$Name,
        [string]$Path
    )

    $catalogPath = Join-Path $toolkitRoot "00_Common\ToolCatalog.json"
    if (-not (Test-Path -LiteralPath $catalogPath -PathType Leaf)) {
        return $null
    }

    try {
        $catalog = Get-Content -LiteralPath $catalogPath -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
        $relativePath = ""
        try {
            $relativePath = $Path.Substring($toolkitRoot.Length).TrimStart("\") -replace "\\","/"
        }
        catch {
        }

        foreach ($tool in $catalog.Tools) {
            if ($Id -and [string]$tool.ToolId -ieq $Id) { return $tool }
            if ($relativePath -and [string]$tool.RelativePath -ieq $relativePath) { return $tool }
            if ($Name -and [string]$tool.Label -ieq $Name) { return $tool }
        }
    }
    catch {
    }

    return $null
}

function Write-BridgeLifecycle {
    param(
        [string]$Event,
        [int]$ReturnCode = 0
    )

    # Best-effort evidence only. Never block a tool launch if logging fails.
    try {
        $logs = Join-Path $toolkitRoot "Logs"
        if (-not (Test-Path -LiteralPath $logs -PathType Container)) {
            New-Item -ItemType Directory -Path $logs -Force -ErrorAction Stop | Out-Null
        }

        $entry = [ordered]@{
            SchemaVersion = 2
            Timestamp = (Get-Date).ToString("o")
            SessionId = [string]$env:FIELDTECH_SESSION_ID
            ToolId = [string]$ToolId
            Action = "Tool Lifecycle"
            Event = $Event
            Caller = $Caller
            ToolName = $ToolName
            ReturnCode = $ReturnCode
            Computer = $env:COMPUTERNAME
            User = ($env:USERDOMAIN + "\" + $env:USERNAME)
        }

        $line = ($entry | ConvertTo-Json -Compress) + [Environment]::NewLine
        [IO.File]::AppendAllText(
            (Join-Path $logs "TOOL_LIFECYCLE.jsonl"),
            $line,
            (New-Object Text.UTF8Encoding($false))
        )
    }
    catch {
    }
}

if (-not (Test-Path -LiteralPath $ToolPath -PathType Leaf)) {
    Write-Host ("Tool path is missing: " + $ToolPath)
    exit 2
}

$toolDef = Get-BridgeCatalogTool -Id $ToolId -Name $ToolName -Path $ToolPath
if ($toolDef) {
    $ToolId = [string]$toolDef.ToolId
    if (-not $Access -or $Access -eq "STANDARD") {
        $Access = [string]$toolDef.Access
    }
}

$isAdmin = Test-BridgeAdmin
$requiresAdmin = $Access -match '(?i)^ADMIN'

if ($EnforceAccess -and $requiresAdmin -and -not $isAdmin) {
    Write-Host ""
    Write-Host ("Cannot start: " + $ToolName)
    if ($ToolId) { Write-Host ("Tool ID: " + $ToolId) }
    Write-Host "Administrator rights are required for this tool."
    Write-Host "Relaunch the main toolkit as Administrator, then try again."
    Write-Host "No tool was started."
    Write-Host ""
    exit 5
}

$previousToolId = [string]$env:FIELDTECH_TOOL_ID
$previousTimeout = [string]$env:FIELDTECH_TOOL_TIMEOUT_SECONDS

if ($ToolId) {
    $env:FIELDTECH_TOOL_ID = $ToolId
}

if ($toolDef -and [int]$toolDef.DefaultTimeoutSeconds -gt 0) {
    $env:FIELDTECH_TOOL_TIMEOUT_SECONDS = [string][int]$toolDef.DefaultTimeoutSeconds
}
else {
    Remove-Item Env:FIELDTECH_TOOL_TIMEOUT_SECONDS -ErrorAction SilentlyContinue
}

$toolStartedAt = Get-Date
Write-BridgeLifecycle -Event "TOOL_START"

Write-Host ""
Write-Host ("STATUS: Starting tool: " + $ToolName + ".")
if ($isScreenReader) {
    if ($ToolId) { Write-Host ("Tool ID: " + $ToolId + ".") }
    if ($Access -ieq "ADMIN") {
        Write-Host "Administrator rights are required for this tool."
    }
    elseif ($Access -ieq "ADMINREBOOT") {
        Write-Host "Administrator rights are required for this tool. A reboot may be required."
    }
    Write-Host ("Launch source: " + $Caller + ".")
    Write-Host "Tool output follows."
}
Write-Host ""

& $ToolPath
$rc = $LASTEXITCODE
if ($null -eq $rc) { $rc = 0 }

Write-BridgeLifecycle -Event "TOOL_END" -ReturnCode ([int]$rc)

# Keep the launch bridge Foundation-independent. A dedicated best-effort helper
# mirrors toolkit-generated Logs artifacts only when Collect Case is ACTIVE.
$caseCapturePath = Join-Path $toolkitRoot "00_Common\Capture-Active-Case-Artifacts.ps1"
if (Test-Path -LiteralPath $caseCapturePath -PathType Leaf) {
    try {
        & $caseCapturePath -Since $toolStartedAt.ToString("o") -ToolId $ToolId `
            -ToolName $ToolName -ReturnCode ([int]$rc)
    }
    catch {
    }
}

if ($previousToolId) {
    $env:FIELDTECH_TOOL_ID = $previousToolId
}
else {
    Remove-Item Env:FIELDTECH_TOOL_ID -ErrorAction SilentlyContinue
}

if ($previousTimeout) {
    $env:FIELDTECH_TOOL_TIMEOUT_SECONDS = $previousTimeout
}
else {
    Remove-Item Env:FIELDTECH_TOOL_TIMEOUT_SECONDS -ErrorAction SilentlyContinue
}

Write-Host ""
Write-Host ("STATUS: Tool finished: " + $ToolName + ". Return code: " + $rc + ".")
if ($isScreenReader) {
    Write-Host "Returning to the previous menu."
}
Write-Host ""

exit [int]$rc

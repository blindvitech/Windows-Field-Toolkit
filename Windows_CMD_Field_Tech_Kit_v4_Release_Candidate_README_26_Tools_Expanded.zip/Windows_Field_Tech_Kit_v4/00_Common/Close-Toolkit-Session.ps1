$ErrorActionPreference = "Stop"

$toolkitRoot = Split-Path $PSScriptRoot -Parent
$foundation = Join-Path $toolkitRoot "00_Common\Foundation-Common.ps1"

$sessionId = $(if($env:FIELDTECH_SESSION_ID){[string]$env:FIELDTECH_SESSION_ID}else{"UNKNOWN"})
$logs = Join-Path $toolkitRoot "Logs"
$buildId = "UNVERSIONED"
$manifestHash = ""
$exitCode = 0
$status = "SUCCESS"
$errorType = ""
$errorMessage = ""
$statePath = ""
$closeoutPath = ""
$endedAt = (Get-Date).ToString("o")

function Write-ExitArtifacts {
    param(
        [string]$Status,
        [int]$ExitCode,
        [string]$ErrorType,
        [string]$ErrorMessage
    )

    if (-not (Test-Path -LiteralPath $logs -PathType Container)) {
        New-Item -ItemType Directory -Path $logs -Force -ErrorAction SilentlyContinue | Out-Null
    }

    $payload = [ordered]@{
        SchemaVersion = 1
        Timestamp = (Get-Date).ToString("o")
        ToolkitVersion = "v4"
        BuildId = $buildId
        BuildManifestSHA256 = $manifestHash
        SessionId = $sessionId
        Computer = $env:COMPUTERNAME
        User = ($env:USERDOMAIN + "\" + $env:USERNAME)
        ExitPath = "Launcher normal exit"
        CloseoutStatus = $Status
        ExitCode = $ExitCode
        SessionStatePath = $statePath
        SessionCloseoutPath = $closeoutPath
        ErrorType = $ErrorType
        ErrorMessage = $ErrorMessage
    }

    $jsonPath = Join-Path $logs "LAST_EXIT_STATUS.json"
    $textPath = Join-Path $logs "LAST_EXIT_STATUS.txt"

    $text = @(
        "WINDOWS FIELD TECH TOOLKIT v4 - LAST EXIT STATUS",
        ("Timestamp: " + $payload.Timestamp),
        ("BuildId: " + $payload.BuildId),
        ("SessionId: " + $payload.SessionId),
        ("Computer: " + $payload.Computer),
        ("Exit path: " + $payload.ExitPath),
        ("Closeout status: " + $payload.CloseoutStatus),
        ("Exit code: " + $payload.ExitCode),
        ("Session state: " + $payload.SessionStatePath),
        ("Session closeout: " + $payload.SessionCloseoutPath),
        ("Error type: " + $payload.ErrorType),
        ("Error message: " + $payload.ErrorMessage)
    ) -join [Environment]::NewLine

    try {
        if (Get-Command Set-ToolkitAtomicJson -ErrorAction SilentlyContinue) {
            [void](Set-ToolkitAtomicJson -Path $jsonPath -Object $payload)
            [void](Set-ToolkitAtomicText -Path $textPath -Content ($text + [Environment]::NewLine))
        }
        else {
            $payload | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $jsonPath -Encoding UTF8
            $text | Set-Content -LiteralPath $textPath -Encoding UTF8
        }

        # LAST_EXIT_STATUS is intentionally a current-state pair, not a history.
        # Remove any emergency/legacy timestamped variants after a successful
        # canonical write. EXIT_ERRORS.jsonl remains the append-only history.
        foreach($legacy in @(Get-ChildItem -LiteralPath $logs -File -ErrorAction SilentlyContinue |
            Where-Object {
                $_.Name -like "LAST_EXIT_STATUS_*" -and
                $_.Name -notin @("LAST_EXIT_STATUS.json","LAST_EXIT_STATUS.txt")
            })) {
            Remove-Item -LiteralPath $legacy.FullName -Force -ErrorAction SilentlyContinue
        }
    }
    catch {
        # Last-resort unique artifact so a failure in the shared atomic writer
        # cannot erase the only record of a closeout problem.
        $fallback = Join-Path $logs ("LAST_EXIT_STATUS_FALLBACK_" + (Get-Date -Format "yyyyMMdd_HHmmss_fff") + ".txt")
        try {
            [IO.File]::WriteAllText($fallback,$text + [Environment]::NewLine,(New-Object Text.UTF8Encoding($false)))
        } catch {}
    }

    if ($Status -ne "SUCCESS") {
        $errorEntry = [ordered]@{
            SchemaVersion = 1
            Timestamp = (Get-Date).ToString("o")
            BuildId = $buildId
            SessionId = $sessionId
            Computer = $env:COMPUTERNAME
            ExitPath = "Launcher normal exit"
            ErrorType = $ErrorType
            ErrorMessage = $ErrorMessage
            SessionStatePath = $statePath
            SessionCloseoutPath = $closeoutPath
        }
        $errorLog = Join-Path $logs "EXIT_ERRORS.jsonl"
        try {
            if (Get-Command Add-ToolkitJsonLine -ErrorAction SilentlyContinue) {
                Add-ToolkitJsonLine -Path $errorLog -Object $errorEntry
            }
            else {
                $line = ($errorEntry | ConvertTo-Json -Compress) + [Environment]::NewLine
                [IO.File]::AppendAllText($errorLog,$line,(New-Object Text.UTF8Encoding($false)))
            }
        } catch {}
    }
}

try {
    if (-not (Test-Path -LiteralPath $foundation -PathType Leaf)) {
        throw "Foundation-Common.ps1 is missing; session closeout cannot run."
    }

    . $foundation

    $sessionId = Get-ToolkitSessionId
    $logs = Get-ToolkitLogRoot
    $build = Get-ToolkitBuildIdentity
    $buildId = [string]$build.BuildId
    $manifestHash = [string]$build.ManifestSHA256
    $statePath = Join-Path $logs ("SESSION_STATE_" + $sessionId + ".json")
    $closeoutPath = Join-Path $logs ("SESSION_CLOSEOUT_" + $sessionId + ".txt")

    $state = Close-ToolkitSessionState

    # Independent final read-back so the closeout wrapper itself verifies what
    # the foundation persisted.
    $persisted = Get-Content -LiteralPath $statePath -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
    if ([string]$persisted.Status -ne "CLOSED" -or [string]::IsNullOrWhiteSpace([string]$persisted.Ended)) {
        throw "Closeout verification failed: persisted SESSION_STATE is not CLOSED with an Ended timestamp."
    }

    Write-Host ("Session closeout recorded and verified: " + $state.SessionId)
}
catch {
    $exitCode = 1
    $status = "FAILED"
    $errorType = $_.Exception.GetType().FullName
    $errorMessage = $_.Exception.Message

    Write-Host ""
    Write-Host "TOOLKIT CLOSEOUT ERROR"
    Write-Host ("Session: " + $sessionId)
    Write-Host ("Error: " + $errorMessage)
    Write-Host ("Details will be written under: " + $logs)
}
finally {
    Write-ExitArtifacts -Status $status -ExitCode $exitCode -ErrorType $errorType -ErrorMessage $errorMessage
}

exit $exitCode

param(
    [string]$Since = "",
    [string]$ToolId = $env:FIELDTECH_TOOL_ID,
    [string]$ToolName = "",
    [int]$ReturnCode = 0,
    [switch]$FinalSweep,
    [switch]$Quiet
)

# Foundation-independent, best-effort post-tool case capture.
# This helper is intentionally safe to invoke after every menu/search tool:
# when no Collect Case is ACTIVE, it performs no capture and exits 0.

$ErrorActionPreference = "SilentlyContinue"
$toolkitRoot = Split-Path $PSScriptRoot -Parent
$logs = Join-Path $toolkitRoot "Logs"

function Get-ActiveCaseLite {
    $jsonMarker = Join-Path $logs "ACTIVE_CASE.json"
    $txtMarker = Join-Path $logs "ACTIVE_CASE.txt"
    $caseId = ""
    $casePath = ""

    if(Test-Path -LiteralPath $jsonMarker -PathType Leaf){
        try{
            $state = Get-Content -LiteralPath $jsonMarker -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
            $caseId = [string]$state.CaseId
            $casePath = [string]$state.CasePath
            if(-not $casePath -and $caseId){$casePath=Join-Path $logs $caseId}
        }catch{}
    }

    if(-not $caseId -and (Test-Path -LiteralPath $txtMarker -PathType Leaf)){
        try{
            $caseId=(Get-Content -LiteralPath $txtMarker -Raw -ErrorAction Stop).Trim()
            if($caseId){$casePath=Join-Path $logs $caseId}
        }catch{}
    }

    if(-not $caseId -or -not $casePath -or -not (Test-Path -LiteralPath $casePath -PathType Container)){
        return $null
    }

    try{
        $logsFull=[IO.Path]::GetFullPath($logs).TrimEnd("\")+"\"
        $caseFull=[IO.Path]::GetFullPath($casePath).TrimEnd("\")+"\"
        if(-not $caseFull.StartsWith($logsFull,[System.StringComparison]::OrdinalIgnoreCase)){return $null}
    }catch{return $null}

    $caseStatePath=Join-Path $casePath "CASE_STATE.json"
    if(Test-Path -LiteralPath $caseStatePath -PathType Leaf){
        try{
            $caseState=Get-Content -LiteralPath $caseStatePath -Raw -ErrorAction Stop|ConvertFrom-Json -ErrorAction Stop
            if([string]$caseState.Status -and [string]$caseState.Status -ine "ACTIVE"){
                return $null
            }
        }catch{}
    }

    return [pscustomobject]@{CaseId=$caseId;CasePath=$casePath}
}

function Get-CaseStart {
    param([Parameter(Mandatory=$true)][string]$CasePath)
    $start=[datetime]::MinValue
    $meta=Join-Path $CasePath "CASE_METADATA.txt"
    if(Test-Path -LiteralPath $meta -PathType Leaf){
        foreach($line in @(Get-Content -LiteralPath $meta -ErrorAction SilentlyContinue)){
            if($line -like "StartTimeISO=*"){
                try{$start=[datetime]::Parse($line.Substring(13)).ToUniversalTime()}catch{}
                break
            }
        }
    }
    if($start -eq [datetime]::MinValue){
        $statePath=Join-Path $CasePath "CASE_STATE.json"
        if(Test-Path -LiteralPath $statePath -PathType Leaf){
            try{
                $state=Get-Content -LiteralPath $statePath -Raw -ErrorAction Stop|ConvertFrom-Json -ErrorAction Stop
                if($state.Created){$start=[datetime]::Parse([string]$state.Created).ToUniversalTime()}
            }catch{}
        }
    }
    return $start
}

function Write-JsonLine {
    param([Parameter(Mandatory=$true)][string]$Path,[Parameter(Mandatory=$true)]$Object)
    try{
        $parent=Split-Path $Path -Parent
        if($parent -and -not(Test-Path -LiteralPath $parent)){New-Item -ItemType Directory -Path $parent -Force|Out-Null}
        $line=($Object|ConvertTo-Json -Compress -Depth 8)+[Environment]::NewLine
        [IO.File]::AppendAllText($Path,$line,(New-Object Text.UTF8Encoding($false)))
    }catch{}
}

function Get-ShortPathKey {
    param([Parameter(Mandatory=$true)][string]$Text)
    $sha=$null
    try{
        $sha=[Security.Cryptography.SHA256]::Create()
        $bytes=[Text.Encoding]::UTF8.GetBytes($Text)
        $hash=$sha.ComputeHash($bytes)
        return ([BitConverter]::ToString($hash).Replace("-","").Substring(0,12))
    }catch{
        return ([guid]::NewGuid().ToString("N").Substring(0,12))
    }finally{
        if($sha){$sha.Dispose()}
    }
}

function Write-CaseLedgerSnapshot {
    param(
        [Parameter(Mandatory=$true)][string]$Source,
        [Parameter(Mandatory=$true)][string]$Destination,
        [Parameter(Mandatory=$true)][string]$CaseId
    )
    if(-not(Test-Path -LiteralPath $Source -PathType Leaf)){return}
    try{
        $out=New-Object System.Collections.Generic.List[string]
        foreach($line in @(Get-Content -LiteralPath $Source -ErrorAction SilentlyContinue)){
            if([string]::IsNullOrWhiteSpace($line)){continue}
            try{
                $obj=$line|ConvertFrom-Json -ErrorAction Stop
                if([string]$obj.CaseId -ieq $CaseId){$out.Add($line)}
            }catch{}
        }
        $parent=Split-Path $Destination -Parent
        if($parent -and -not(Test-Path -LiteralPath $parent)){New-Item -ItemType Directory -Path $parent -Force|Out-Null}
        $text=$(if($out.Count){($out.ToArray() -join [Environment]::NewLine)+[Environment]::NewLine}else{""})
        [IO.File]::WriteAllText($Destination,$text,(New-Object Text.UTF8Encoding($false)))
    }catch{}
}

function Write-RepairJournalSnapshot {
    param(
        [Parameter(Mandatory=$true)][string]$Source,
        [Parameter(Mandatory=$true)][string]$Destination,
        [datetime]$CaseStart,
        [string]$Computer
    )
    if(-not(Test-Path -LiteralPath $Source -PathType Leaf)){return}
    try{
        $out=New-Object System.Collections.Generic.List[string]
        foreach($line in @(Get-Content -LiteralPath $Source -ErrorAction SilentlyContinue)){
            if($Computer -and $line -notmatch ("Computer="+[regex]::Escape($Computer)+"\s*\|")){continue}
            $include=$true
            if($CaseStart -ne [datetime]::MinValue -and $line.Length -ge 19){
                [datetime]$ts=[datetime]::MinValue
                if([datetime]::TryParse($line.Substring(0,19),[ref]$ts)){
                    $include=($ts.ToUniversalTime() -ge $CaseStart)
                }
            }
            if($include){$out.Add($line)}
        }
        $parent=Split-Path $Destination -Parent
        if($parent -and -not(Test-Path -LiteralPath $parent)){New-Item -ItemType Directory -Path $parent -Force|Out-Null}
        $text=$(if($out.Count){($out.ToArray() -join [Environment]::NewLine)+[Environment]::NewLine}else{""})
        [IO.File]::WriteAllText($Destination,$text,(New-Object Text.UTF8Encoding($false)))
    }catch{}
}

$case=Get-ActiveCaseLite
if($null -eq $case){return}

$caseStart=Get-CaseStart -CasePath $case.CasePath
$sinceUtc=$caseStart
if(-not $FinalSweep -and -not [string]::IsNullOrWhiteSpace($Since)){
    try{$sinceUtc=[datetime]::Parse($Since).ToUniversalTime()}catch{}
}
if($sinceUtc -eq [datetime]::MinValue){$sinceUtc=(Get-Date).ToUniversalTime()}
$scanFloor=$sinceUtc.AddSeconds(-2)

$artifactRoot=Join-Path $case.CasePath "Artifacts\LogsMirror"
$activityRoot=Join-Path $case.CasePath "Activity"
New-Item -ItemType Directory -Path $artifactRoot -Force|Out-Null
New-Item -ItemType Directory -Path $activityRoot -Force|Out-Null

# Shared/global files can contain material from other cases/sessions. They are
# not mirrored raw; case-filtered snapshots are written under Activity instead.
$sharedRootNames=@(
    "ACTIVE_CASE.json","ACTIVE_CASE.txt",
    "OPERATION_LEDGER.jsonl","MUTATION_LEDGER.jsonl","TOOL_LIFECYCLE.jsonl",
    "REPAIR_SESSION_JOURNAL.txt",
    "EVIDENCE_CORRELATION_INDEX.json","EVIDENCE_CORRELATION_INDEX.txt",
    "REPORT_INDEX_CURRENT.html","REPORT_INDEX_CURRENT.csv","REPORT_INDEX_CURRENT.txt",
    "EXIT_ERRORS.jsonl","LAST_EXIT_STATUS.json","LAST_EXIT_STATUS.txt"
)

$captured=0
if(Test-Path -LiteralPath $logs -PathType Container){
    $logPrefix=$logs.TrimEnd("\")+"\\"
    $casePrefix=$case.CasePath.TrimEnd("\")+"\\"

    foreach($file in @(Get-ChildItem -LiteralPath $logs -File -Recurse -ErrorAction SilentlyContinue)){
        $full=[string]$file.FullName
        if($full.StartsWith($casePrefix,[System.StringComparison]::OrdinalIgnoreCase)){continue}
        $fileActivityUtc=$(if($file.CreationTimeUtc -gt $file.LastWriteTimeUtc){$file.CreationTimeUtc}else{$file.LastWriteTimeUtc})
        if($fileActivityUtc -lt $scanFloor){continue}

        if(-not $full.StartsWith($logPrefix,[System.StringComparison]::OrdinalIgnoreCase)){continue}
        $relative=$full.Substring($logPrefix.Length)

        $relativeNorm=$relative -replace "/","\"
        if($relativeNorm -match '(?i)^Archive\\'){continue}
        if($relativeNorm -match '(?i)^_ACTIVE_REPAIR_PROCESSES\\'){continue}
        if($relativeNorm -match '(?i)^CASE_[^\\]+\\'){continue}
        if($file.Name -like "CASE_*.zip"){continue}
        if($relativeNorm -notmatch '\\' -and ($sharedRootNames -contains $file.Name)){continue}

        $dest=Join-Path $artifactRoot $relativeNorm
        $capturedRelative=("Artifacts\LogsMirror\"+$relativeNorm)

        # The source can be a valid legacy-Windows path while adding the case
        # mirror prefix would exceed the practical Windows PowerShell 5.1 path
        # budget. Flatten only those unusually long destinations and retain the
        # original source-relative path in CASE_ARTIFACTS.jsonl.
        if($dest.Length -ge 235){
            $longDir=Join-Path $artifactRoot "_LongPaths"
            $leaf=[IO.Path]::GetFileName($relativeNorm)
            if($leaf.Length -gt 80){
                $ext=[IO.Path]::GetExtension($leaf)
                $stem=[IO.Path]::GetFileNameWithoutExtension($leaf)
                if($stem.Length -gt 60){$stem=$stem.Substring(0,60)}
                $leaf=$stem+$ext
            }
            $shortName=(Get-ShortPathKey -Text $relativeNorm)+"_"+$leaf
            $dest=Join-Path $longDir $shortName
            $capturedRelative=("Artifacts\LogsMirror\_LongPaths\"+$shortName)
        }

        $destParent=Split-Path $dest -Parent
        if($destParent -and -not(Test-Path -LiteralPath $destParent)){
            New-Item -ItemType Directory -Path $destParent -Force|Out-Null
        }

        $needsCopy=$true
        if(Test-Path -LiteralPath $dest -PathType Leaf){
            try{
                $dst=Get-Item -LiteralPath $dest -ErrorAction Stop
                $timeDelta=[math]::Abs(($dst.LastWriteTimeUtc-$file.LastWriteTimeUtc).TotalSeconds)
                if($dst.Length -eq $file.Length -and $timeDelta -lt 2){
                    $needsCopy=$false
                }
            }catch{}
        }

        if($needsCopy){
            try{
                Copy-Item -LiteralPath $file.FullName -Destination $dest -Force -ErrorAction Stop
                try{(Get-Item -LiteralPath $dest -ErrorAction Stop).LastWriteTimeUtc=$file.LastWriteTimeUtc}catch{}
                $hash=""
                try{$hash=(Get-FileHash -LiteralPath $dest -Algorithm SHA256 -ErrorAction Stop).Hash}catch{}
                $entry=[ordered]@{
                    SchemaVersion=1
                    Timestamp=(Get-Date).ToString("o")
                    CaseId=$case.CaseId
                    ToolId=$ToolId
                    ToolName=$ToolName
                    SourceRelativePath=$relativeNorm
                    CapturedRelativePath=$capturedRelative
                    Size=$file.Length
                    CreationTimeUtc=$file.CreationTimeUtc.ToString("o")
                    LastWriteTimeUtc=$file.LastWriteTimeUtc.ToString("o")
                    SHA256=$hash
                }
                Write-JsonLine -Path (Join-Path $case.CasePath "CASE_ARTIFACTS.jsonl") -Object $entry
                $captured++
            }catch{}
        }
    }
}

Write-CaseLedgerSnapshot -Source (Join-Path $logs "OPERATION_LEDGER.jsonl") `
    -Destination (Join-Path $activityRoot "CASE_OPERATION_LEDGER.jsonl") -CaseId $case.CaseId
Write-CaseLedgerSnapshot -Source (Join-Path $logs "MUTATION_LEDGER.jsonl") `
    -Destination (Join-Path $activityRoot "CASE_MUTATION_LEDGER.jsonl") -CaseId $case.CaseId

$caseComputer=$env:COMPUTERNAME
$metaPath=Join-Path $case.CasePath "CASE_METADATA.txt"
if(Test-Path -LiteralPath $metaPath -PathType Leaf){
    foreach($line in @(Get-Content -LiteralPath $metaPath -ErrorAction SilentlyContinue)){
        if($line -like "Computer=*"){
            $value=$line.Substring(9).Trim()
            if($value){$caseComputer=$value}
        }
    }
}
Write-RepairJournalSnapshot -Source (Join-Path $logs "REPAIR_SESSION_JOURNAL.txt") `
    -Destination (Join-Path $activityRoot "CASE_REPAIR_SESSION_JOURNAL.txt") `
    -CaseStart $caseStart -Computer $caseComputer

if($ToolName){
    $runEntry=[ordered]@{
        SchemaVersion=1
        Timestamp=(Get-Date).ToString("o")
        CaseId=$case.CaseId
        ToolId=$ToolId
        ToolName=$ToolName
        Since=$Since
        ReturnCode=$ReturnCode
        CapturedArtifacts=$captured
        Computer=$env:COMPUTERNAME
        SessionId=[string]$env:FIELDTECH_SESSION_ID
    }
    Write-JsonLine -Path (Join-Path $activityRoot "CASE_TOOL_RUNS.jsonl") -Object $runEntry
}

if(-not $Quiet){
    Write-Host ("STATUS: Active case "+$case.CaseId+" captured "+$captured+" new or updated toolkit artifact(s).")
}
return

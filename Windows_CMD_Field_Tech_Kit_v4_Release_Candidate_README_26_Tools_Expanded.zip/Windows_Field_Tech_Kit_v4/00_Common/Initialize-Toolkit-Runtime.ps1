$toolkitRoot = Split-Path $PSScriptRoot -Parent
$foundation = Join-Path $toolkitRoot "00_Common\Foundation-Common.ps1"
if (Test-Path -LiteralPath $foundation -PathType Leaf) {
    . $foundation
    try{[void](Sync-ToolkitFieldValidationStatus)}catch{}
    [void](Initialize-ToolkitRuntimeContext)
    [void](Initialize-ToolkitSessionState)

    $recovered=@($script:ToolkitLastRecoveredStaleSessions)
    if($recovered.Count -gt 0){
        Write-Host ""
        Write-Host ("NOTICE: Detected " + $recovered.Count + " interrupted prior toolkit session(s).")
        foreach($item in $recovered){
            Write-Host (" - Session " + $item.SessionId + " started " + $item.Started + " | " + $item.Reason)
        }
        Write-Host ("Details: " + (Join-Path (Get-ToolkitLogRoot) "INTERRUPTED_SESSIONS.jsonl"))
        Write-Host ""
    }
}

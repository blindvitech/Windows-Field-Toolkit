# Shared Screen Reader Mode context for the Windows Field Tech Toolkit.
# SRMODE is inherited from RUN-WINDOWS-FIELD-TECH.cmd by child processes.
# FIELDTECH_SCREEN_READER=1 remains a supported external/default signal.

function Test-ToolkitScreenReaderMode {
    return (
        $env:SRMODE -eq "1" -or
        $env:FIELDTECH_SCREEN_READER -eq "1"
    )
}

function Write-SRAnnouncement {
    param([Parameter(Mandatory=$true)][string]$Message)

    if (Test-ToolkitScreenReaderMode) {
        Write-Host $Message
    }
}

function Write-ToolkitStatus {
    param([Parameter(Mandatory=$true)][string]$Message)

    # Plain text by design: useful visually and reliably announced by console
    # screen readers without relying on color, cursor movement, or animation.
    Write-Host ("STATUS: " + $Message)
}

function ConvertTo-ToolkitSpokenExactPhrase {
    param([string]$Phrase = "")

    if ([string]::IsNullOrWhiteSpace($Phrase)) {
        return ""
    }

    $words = @([regex]::Split($Phrase.Trim(),'\s+') | Where-Object { $_ })
    $spokenWords = @(
        foreach($word in $words) {
            (($word.ToCharArray() | ForEach-Object { ([string]$_).ToUpperInvariant() }) -join " ")
        }
    )

    return ($spokenWords -join ", space, ")
}

function Read-ToolkitPrompt {
    param(
        [string]$Prompt = "",
        [string]$ScreenReaderPrompt = "",
        [string]$SpellExactPhrase = ""
    )

    if (Test-ToolkitScreenReaderMode) {
        # Announce the actual prompt once. Avoid synthetic Prompt/Input labels.
        # Exact safety phrases can be spelled only in SR mode so ordinary
        # console users keep the concise prompt while screen-reader users hear
        # every required character and spaces unambiguously.
        $effectivePrompt = $Prompt

        if (-not [string]::IsNullOrWhiteSpace($ScreenReaderPrompt)) {
            $effectivePrompt = $ScreenReaderPrompt
        }
        elseif (-not [string]::IsNullOrWhiteSpace($SpellExactPhrase)) {
            $spoken = ConvertTo-ToolkitSpokenExactPhrase -Phrase $SpellExactPhrase
            if (-not [string]::IsNullOrWhiteSpace($spoken)) {
                $effectivePrompt = $Prompt + " Screen reader spelling: " + $spoken + "."
            }
        }

        if (-not [string]::IsNullOrWhiteSpace($effectivePrompt)) {
            Write-Host $effectivePrompt
        }
        return Read-Host
    }

    if ([string]::IsNullOrWhiteSpace($Prompt)) {
        return Read-Host
    }

    return Read-Host $Prompt
}

$ToolkitScreenReaderMode = Test-ToolkitScreenReaderMode

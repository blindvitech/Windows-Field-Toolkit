param(
    [Parameter(Mandatory=$true)][string]$ScriptPath
)

$ErrorActionPreference = "Stop"

if (-not (Test-Path -LiteralPath $ScriptPath -PathType Leaf)) {
    Write-Host "Elevation target was not found:"
    Write-Host $ScriptPath
    exit 2
}

try {
    Start-Process -FilePath $ScriptPath -Verb RunAs -ErrorAction Stop
    exit 0
}
catch {
    Write-Host "Could not request Administrator privileges."
    Write-Host $_.Exception.Message
    exit 1
}

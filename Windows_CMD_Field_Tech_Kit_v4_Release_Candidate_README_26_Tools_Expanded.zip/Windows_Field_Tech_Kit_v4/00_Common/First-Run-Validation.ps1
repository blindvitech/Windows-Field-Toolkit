param(
    [switch]$Force
)

$toolkitRoot = Split-Path $PSScriptRoot -Parent
$foundation = Join-Path $toolkitRoot "00_Common\Foundation-Common.ps1"
if (-not (Test-Path -LiteralPath $foundation -PathType Leaf)) {
    Write-Host "FIRST-RUN VALIDATION FAILED"
    Write-Host "Foundation-Common.ps1 is missing."
    exit 1
}
. $foundation

$build = Get-ToolkitBuildIdentity
$logs = Get-ToolkitLogRoot
$marker = Join-Path $logs ("FIRST_RUN_VALIDATED_" + $build.BuildId + ".json")

if (-not $Force -and (Test-Path -LiteralPath $marker -PathType Leaf)) {
    # Normally the runtime status already reflects this completed build-keyed
    # check. If the mutable status file was reset independently, recover the
    # AUTO-VERIFIED state from the existing successful first-run record.
    try {
        $prior = Get-Content -LiteralPath $marker -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
        $currentStatus = Get-ToolkitFieldValidationStatus
        if ([int]$prior.CriticalFailureCount -eq 0 -and
            [string]$prior.BuildId -eq [string]$build.BuildId -and
            [string]$currentStatus.Status -eq "UNVALIDATED") {
            [void](Set-ToolkitFieldValidationStatus -Status "AUTO-VERIFIED" -BuildId $build.BuildId `
                -AutoVerificationResult ([string]$prior.Result) `
                -Details ("Automatic first-run verification " + [string]$prior.Result + "; no critical failures. Full field validation has not been completed."))
        }
    }
    catch {}
    exit 0
}

$checks = New-Object System.Collections.Generic.List[object]

function Add-FirstRunCheck {
    param(
        [string]$Name,
        [bool]$Passed,
        [ValidateSet("CRITICAL","WARNING","INFO")][string]$Severity,
        [string]$Details
    )
    $checks.Add([pscustomobject]@{
        Name = $Name
        Passed = $Passed
        Severity = $Severity
        Details = $Details
    })
}

Add-FirstRunCheck "PowerShell 5+" ($PSVersionTable.PSVersion.Major -ge 5) "CRITICAL" ("PowerShell " + $PSVersionTable.PSVersion)

$requiredFiles = @(
    "RUN-WINDOWS-FIELD-TECH.cmd",
    "00_Common\Foundation-Common.ps1",
    "00_Common\ScreenReader-Common.ps1",
    "00_Common\Diagnostic-Evidence.ps1",
    "00_Common\Diagnostic-Fixtures.json",
    "00_Common\Toolkit-Version.json",
    "VERSION.txt",
    "Documentation\RELEASE-MANIFEST-v4.txt",
    "FIELD-VALIDATION-STATUS.txt",
    "00_Common\Invoke-Native-Bridge.ps1",
    "00_Common\Invoke-Toolkit-MenuTool.ps1",
    "00_Common\Refresh-Menu-Capabilities.ps1",
    "00_Common\First-Run-Validation.ps1",
    "00_Common\ToolCatalog.json",
    "00_Common\Compatibility-Matrix.json",
    "00_Common\Retention-Maintenance.ps1",
    "00_Common\Close-Toolkit-Session.ps1",
    "26_Tools\Menu-Search.cmd",
    "26_Tools\Menu-Search.ps1",
    "26_Tools\Toolkit-Self-Test.ps1"
)
foreach ($relative in $requiredFiles) {
    Add-FirstRunCheck ("Required file: " + $relative) (Test-Path -LiteralPath (Join-Path $toolkitRoot $relative) -PathType Leaf) "CRITICAL" $relative
}

$diagnosticHelper = Join-Path $toolkitRoot "00_Common\Diagnostic-Evidence.ps1"
$diagnosticFixtures = Join-Path $toolkitRoot "00_Common\Diagnostic-Fixtures.json"
$diagnosticLogicPass = $false
$diagnosticLogicDetails = "Not run"
if((Test-Path -LiteralPath $diagnosticHelper -PathType Leaf) -and (Test-Path -LiteralPath $diagnosticFixtures -PathType Leaf)){
    try{
        . $diagnosticHelper
        $fixtureResults = @(Test-ToolkitDiagnosticFixtures -FixturePath $diagnosticFixtures)
        $fixtureFailures = @($fixtureResults | Where-Object { -not $_.Passed })
        $diagnosticLogicPass = ($fixtureResults.Count -gt 0 -and $fixtureFailures.Count -eq 0)
        $diagnosticLogicDetails = "Fixtures=" + $fixtureResults.Count + "; failures=" + $fixtureFailures.Count + "; classifier=" + (Get-ToolkitDiagnosticClassifierVersion)
    }catch{
        $diagnosticLogicDetails = $_.Exception.Message
    }
}
Add-FirstRunCheck "Toolkit v4 diagnostic classifier fixtures" $diagnosticLogicPass "CRITICAL" $diagnosticLogicDetails

$diagnosticHelperText=""
try{$diagnosticHelperText=Get-Content -LiteralPath $diagnosticHelper -Raw -ErrorAction Stop}catch{}
$diagnosticContracts=@(
    "Get-ToolkitCapabilityFailureClassification",
    "Update-ToolkitEvidenceCorrelationIndex",
    "Write-ToolkitDiagnosticSidecar"
)
$missingDiagnosticContracts=@($diagnosticContracts|Where-Object{$diagnosticHelperText.IndexOf($_,[System.StringComparison]::OrdinalIgnoreCase) -lt 0})
Add-FirstRunCheck "Toolkit v4 correlation/capability contracts" ($missingDiagnosticContracts.Count -eq 0) "CRITICAL" `
    $(if($missingDiagnosticContracts.Count -eq 0){"Evidence correlation and capability classification helpers present"}else{"Missing: "+($missingDiagnosticContracts -join "; ")})

$writePass = $false
try {
    $probe = Join-Path $logs (".first_run_write_" + [guid]::NewGuid().ToString("N") + ".tmp")
    "probe" | Set-Content -LiteralPath $probe -Encoding ASCII -ErrorAction Stop
    Remove-Item -LiteralPath $probe -Force -ErrorAction Stop
    $writePass = $true
}
catch {
}
Add-FirstRunCheck "Logging writable" $writePass "CRITICAL" $logs

$kg = Join-Path $toolkitRoot "26_Tools\KnownGood"
$kgZip = Join-Path $kg "Toolkit-Core-KnownGood.zip"
$kgZipHash = Join-Path $kg "Toolkit-Core-KnownGood.sha256"
$kgManifest = Join-Path $kg "Toolkit-Core-Manifest.json"
$kgManifestHash = Join-Path $kg "Toolkit-Core-Manifest.sha256"

$knownGoodFiles = @($kgZip,$kgZipHash,$kgManifest,$kgManifestHash)
Add-FirstRunCheck "Known-Good trust files present" (@($knownGoodFiles | Where-Object { -not (Test-Path -LiteralPath $_ -PathType Leaf) }).Count -eq 0) "CRITICAL" $kg

if (@($knownGoodFiles | Where-Object { -not (Test-Path -LiteralPath $_ -PathType Leaf) }).Count -eq 0) {
    try {
        $expectedZip = (Get-Content -LiteralPath $kgZipHash -Raw -ErrorAction Stop).Trim().ToUpperInvariant()
        $actualZip = (Get-FileHash -LiteralPath $kgZip -Algorithm SHA256 -ErrorAction Stop).Hash.ToUpperInvariant()
        Add-FirstRunCheck "Known-Good archive checksum" ($expectedZip -eq $actualZip) "CRITICAL" ("Expected=" + $expectedZip + "; Actual=" + $actualZip)
    }
    catch {
        Add-FirstRunCheck "Known-Good archive checksum" $false "CRITICAL" $_.Exception.Message
    }

    try {
        $expectedManifest = (Get-Content -LiteralPath $kgManifestHash -Raw -ErrorAction Stop).Trim().ToUpperInvariant()
        $actualManifest = (Get-FileHash -LiteralPath $kgManifest -Algorithm SHA256 -ErrorAction Stop).Hash.ToUpperInvariant()
        Add-FirstRunCheck "Known-Good manifest checksum" ($expectedManifest -eq $actualManifest) "CRITICAL" ("Expected=" + $expectedManifest + "; Actual=" + $actualManifest)
    }
    catch {
        Add-FirstRunCheck "Known-Good manifest checksum" $false "CRITICAL" $_.Exception.Message
    }
}

$arch = [string]$env:PROCESSOR_ARCHITECTURE
Add-FirstRunCheck "Windows architecture recognized" ($arch -in @("AMD64","ARM64","x86")) "WARNING" $arch
if ($arch -eq "x86") {
    Add-FirstRunCheck "32-bit Windows caution" $false "WARNING" "Some toolkit functions are designed primarily for modern 64-bit Windows."
}

$coreCommands = @("dism.exe","sfc.exe","chkdsk.exe","reagentc.exe","bcdedit.exe","netsh.exe","powercfg.exe")
foreach ($command in $coreCommands) {
    Add-FirstRunCheck ("Native command: " + $command) ([bool](Get-Command $command -ErrorAction SilentlyContinue)) "WARNING" $command
}

if ($toolkitRoot.StartsWith("\\", [System.StringComparison]::OrdinalIgnoreCase)) {
    Add-FirstRunCheck "Local extraction recommended" $false "WARNING" "Toolkit is running from a UNC path. Local extraction is the supported field workflow."
}
else {
    Add-FirstRunCheck "Toolkit path" $true "INFO" $toolkitRoot
}

if (Get-Command Get-ToolkitCompatibilityAssessment -ErrorAction SilentlyContinue) {
    $compat = Get-ToolkitCompatibilityAssessment
    $compatPass = [string]$compat.Status -eq "SUPPORTED_TARGET"
    $compatSeverity = $(if ([string]$compat.Status -eq "UNSUPPORTED") { "CRITICAL" } elseif ($compatPass) { "INFO" } else { "WARNING" })
    Add-FirstRunCheck "Runtime compatibility profile" $compatPass $compatSeverity (([string]$compat.Status) + "; " + (@($compat.Notes) -join "; "))
}

$criticalFailures = @($checks | Where-Object { -not $_.Passed -and $_.Severity -eq "CRITICAL" })
$warnings = @($checks | Where-Object { -not $_.Passed -and $_.Severity -eq "WARNING" })

$result = $(if ($criticalFailures.Count -gt 0) { "FAILED" } elseif ($warnings.Count -gt 0) { "ATTENTION" } else { "PASS" })

$record = [pscustomobject]@{
    SchemaVersion = 1
    Generated = (Get-Date).ToString("o")
    BuildId = $build.BuildId
    BuildManifestSHA256 = $build.ManifestSHA256
    ToolkitRoot = $toolkitRoot
    Result = $result
    CriticalFailureCount = $criticalFailures.Count
    WarningCount = $warnings.Count
    Checks = $checks.ToArray()
}

$reportPath = Join-Path $logs ("FIRST_RUN_VALIDATION_" + $build.BuildId + ".json")
$record | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $reportPath -Encoding UTF8

Write-Host ""
Write-Host "FIRST-RUN TOOLKIT VALIDATION"
Write-Host ("Build: " + $build.BuildId)
Write-Host ("Result: " + $result)
Write-Host ("Critical failures: " + $criticalFailures.Count)
Write-Host ("Warnings: " + $warnings.Count)
if ($warnings.Count -gt 0 -and $criticalFailures.Count -eq 0) {
    Write-Host "ATTENTION items require a one-time acknowledgement in the launcher for this build."
}

foreach ($failure in $criticalFailures) {
    Write-Host ("CRITICAL: " + $failure.Name + " - " + $failure.Details)
}
foreach ($warning in $warnings) {
    Write-Host ("WARNING: " + $warning.Name + " - " + $warning.Details)
}
Write-Host ("Validation record: " + $reportPath)
Write-Host ""

if ($criticalFailures.Count -eq 0) {
    $record | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $marker -Encoding UTF8

    try {
        $currentStatus = Get-ToolkitFieldValidationStatus
        if ([string]$currentStatus.Status -ne "VALIDATED") {
            $autoStatus = Set-ToolkitFieldValidationStatus -Status "AUTO-VERIFIED" -BuildId $build.BuildId `
                -AutoVerificationResult $result `
                -Details ("Automatic first-run verification " + $result + "; no critical failures. Full field validation has not been completed.")
            Write-Host ("Field validation status: " + $autoStatus.Status + " (" + $autoStatus.AutoVerificationResult + ")")
        }
        else {
            Write-Host ("Field validation status: VALIDATED (" + $build.BuildId + ")")
        }
    }
    catch {
        Write-Host ("WARNING: Could not update AUTO-VERIFIED status: " + $_.Exception.Message)
    }
}

if ($criticalFailures.Count -gt 0) { exit 1 }
if ($warnings.Count -gt 0) { exit 2 }

# Fresh clean first-run verification. The existing build-keyed early-exit path
# returns 0, so subsequent launches do not pause.
exit 3

param(
    [Parameter(Mandatory=$true)][string]$TextPath,
    [string]$Title = "Windows Field Tech Report"
)

if (-not (Test-Path $TextPath)) { exit 1 }

$txt = Get-Content -LiteralPath $TextPath -Raw -ErrorAction SilentlyContinue
if ($null -eq $txt) { $txt = "" }

$base = [System.IO.Path]::Combine(
    [System.IO.Path]::GetDirectoryName($TextPath),
    [System.IO.Path]::GetFileNameWithoutExtension($TextPath)
)

$mdPath = "$base.md"
$htmlPath = "$base.html"

# Markdown keeps original monospace-friendly content intact.
$md = @"
# $Title

Generated: $(Get-Date)

```text
$txt
```
"@
$md | Set-Content -LiteralPath $mdPath -Encoding UTF8

$encoded = [System.Net.WebUtility]::HtmlEncode($txt)
$html = @"
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>$Title</title>
<style>
body{font-family:"Segoe UI",Arial,sans-serif;margin:24px;background:#f5f7fa;color:#18212f}
h1{margin-bottom:4px}
.meta{color:#5c6675;margin-bottom:18px}
pre{white-space:pre-wrap;word-break:break-word;background:white;border:1px solid #d7dde5;border-radius:8px;padding:14px;line-height:1.35}
</style>
</head>
<body>
<h1>$Title</h1>
<div class="meta">Generated: $(Get-Date)</div>
<pre>$encoded</pre>
</body>
</html>
"@
$html | Set-Content -LiteralPath $htmlPath -Encoding UTF8

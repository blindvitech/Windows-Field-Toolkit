param(
    [Parameter(Mandatory=$true)][string]$BasePath,
    [Parameter(Mandatory=$true)][string]$Title,
    [Parameter(Mandatory=$true)][string]$Body,
    [string]$ToolId = $env:FIELDTECH_TOOL_ID
)

$txtPath = "$BasePath.txt"
$mdPath = "$BasePath.md"
$htmlPath = "$BasePath.html"
$metaPath = "$BasePath.meta.json"

$toolkitRoot = Split-Path $PSScriptRoot -Parent
$sectionedHtml = Join-Path $PSScriptRoot "Sectioned-Html-Report.ps1"
if (Test-Path -LiteralPath $sectionedHtml -PathType Leaf) { . $sectionedHtml }
$versionPath = Join-Path $PSScriptRoot "Toolkit-Version.json"
$version = $null
try {
    $version = Get-Content -LiteralPath $versionPath -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
} catch {}

$displayVersion = $(if($version){[string]$version.DisplayVersion}else{"v4"})
$reportSchema = $(if($version){[string]$version.ReportSchemaVersion}else{"1.0"})
$releaseLine = $(if($version){[string]$version.ReleaseLine}else{"Shared Diagnostic Engine"})

$manifestPath = Join-Path $toolkitRoot "26_Tools\KnownGood\Toolkit-Core-Manifest.json"
$buildId = ""
if (Test-Path -LiteralPath $manifestPath -PathType Leaf) {
    try { $buildId=(Get-FileHash -LiteralPath $manifestPath -Algorithm SHA256 -ErrorAction Stop).Hash } catch {}
}

$generated = Get-Date
$metadata = [pscustomobject]@{
    ReportSchemaVersion = $reportSchema
    ToolkitVersion = $displayVersion
    ReleaseLine = $releaseLine
    ToolId = $ToolId
    Title = $Title
    ToolkitBuildId = $buildId
    SessionId = $env:FIELDTECH_SESSION_ID
    GeneratedAt = $generated
    Computer = $env:COMPUTERNAME
}

$Body | Set-Content -LiteralPath $txtPath -Encoding UTF8

@"
# $Title

Generated: $generated
Toolkit: $displayVersion
Tool ID: $ToolId
Report schema: $reportSchema

```text
$Body
```
"@ | Set-Content -LiteralPath $mdPath -Encoding UTF8

$sectionMatches=[regex]::Matches(
    $Body,
    '(?ms)^(={20,})\r?\n([^\r\n]+)\r?\n\1\r?\n(.*?)(?=^={20,}\r?$|\z)'
)

$useSectionedHtml=(
    (Get-Command New-ToolkitSectionedReport -ErrorAction SilentlyContinue) -and
    $Body.Length -ge 5000 -and
    $sectionMatches.Count -ge 4
)

if($useSectionedHtml){
    $report=New-ToolkitSectionedReport -Title $Title `
        -Subtitle "Long-form report. Use the section links or expand/collapse controls to reduce visual noise." `
        -Footer "HTML is a presentation view of the same report body. TXT/MD and any structured sidecars remain unchanged."

    $firstSectionIndex=$sectionMatches[0].Index
    if($firstSectionIndex -gt 0){
        $lead=$Body.Substring(0,$firstSectionIndex).Trim()
        if($lead){
            Add-ToolkitSectionedReportSection -Report $report -Title "Report Summary / Metadata" `
                -Data $lead -Kind "SUMMARY" -OpenByDefault:$true
        }
    }

    foreach($m in $sectionMatches){
        $sectionTitle=$m.Groups[2].Value.Trim()
        $sectionBody=$m.Groups[3].Value.Trim()
        $kind="NORMAL"
        $open=$false

        if($sectionTitle -match '(?i)summary|overview|assessment|warning|failure|failed|error|problem|recommend|attention|pending reboot'){
            $kind=$(if($sectionTitle -match '(?i)recommend'){"RECOMMENDATION"}elseif($sectionTitle -match '(?i)warning|failure|failed|error|problem'){"WARNING"}else{"SUMMARY"})
            $open=$true
        }
        elseif($sectionTitle -match '(?i)raw|event|inventory|all services|installed|package|driver|application|scheduled task|evidence'){
            $kind="INVENTORY"
            $open=$false
        }

        Add-ToolkitSectionedReportSection -Report $report -Title $sectionTitle `
            -Data $sectionBody -Kind $kind -OpenByDefault:$open
    }

    [void](Write-ToolkitSectionedHtmlReport -Report $report -Path $htmlPath `
        -Computer $env:COMPUTERNAME -Generated ([string]$generated) -ToolId $ToolId)
}
else{
    $enc=[System.Net.WebUtility]::HtmlEncode($Body)
    $metaLine=[System.Net.WebUtility]::HtmlEncode(("Generated: "+$generated+" | Toolkit: "+$displayVersion+" | Tool ID: "+$ToolId+" | Report schema: "+$reportSchema))
@"
<!doctype html>
<html><head><meta charset="utf-8"><title>$Title</title>
<style>
body{font-family:"Segoe UI",Arial,sans-serif;margin:24px;background:#f5f7fa;color:#18212f}
h1{margin-bottom:4px}.meta{color:#5c6675;margin-bottom:18px}
pre{white-space:pre-wrap;word-break:break-word;background:white;border:1px solid #d7dde5;border-radius:8px;padding:14px;line-height:1.35}
</style></head><body><h1>$Title</h1><div class="meta">$metaLine</div><pre>$enc</pre></body></html>
"@ | Set-Content -LiteralPath $htmlPath -Encoding UTF8
}

$metadata | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $metaPath -Encoding UTF8

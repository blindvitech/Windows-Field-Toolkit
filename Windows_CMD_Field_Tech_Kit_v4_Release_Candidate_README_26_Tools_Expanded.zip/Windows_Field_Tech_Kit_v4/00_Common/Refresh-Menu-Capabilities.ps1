param(
    [Parameter(Mandatory=$true)][string]$OutputCmd
)

$toolkitRoot = Split-Path $PSScriptRoot -Parent
$foundation = Join-Path $toolkitRoot "00_Common\Foundation-Common.ps1"
if (-not (Test-Path -LiteralPath $foundation -PathType Leaf)) {
    exit 2
}

. $foundation

$cap = Get-ToolkitFeatureCapabilities

$map = [ordered]@{
    CAP_ADMIN = $cap.Administrator
    CAP_REBOOT = $cap.PendingReboot
    CAP_DISM = $cap.DISM
    CAP_SFC = $cap.SFC
    CAP_CHKDSK = $cap.CHKDSK
    CAP_PNPUTIL = $cap.PNPUtil
    CAP_BITLOCKER = $cap.BitLocker
    CAP_DEFENDER = $cap.Defender
    CAP_WINRE = $cap.WinRE
    CAP_WLAN = $cap.WLAN
    CAP_BATTERY = $cap.Battery
    CAP_TPM = $cap.TPM
    CAP_SECUREBOOT = $cap.SecureBoot
    CAP_HYPERV = $cap.HyperV
    CAP_POWERCFG = $cap.PowerCfg
}

$lines = New-Object System.Collections.Generic.List[string]
foreach ($entry in $map.GetEnumerator()) {
    $value = ([string]$entry.Value).Replace('"','')
    $lines.Add('set "' + $entry.Key + '=' + $value + '"')
}
$lines | Set-Content -LiteralPath $OutputCmd -Encoding ASCII

try {
    $logs = Get-ToolkitLogRoot
    $jsonPath = Join-Path $logs ("TOOLKIT_CAPABILITIES_" + (Get-ToolkitSessionId) + ".json")
    $cap | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $jsonPath -Encoding UTF8
}
catch {
}

exit 0

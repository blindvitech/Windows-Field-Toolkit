param(
    [int]$AgeDays = 90
)

$toolkitRoot = Split-Path $PSScriptRoot -Parent
$srCommon = Join-Path $toolkitRoot "00_Common\ScreenReader-Common.ps1"
if (Test-Path -LiteralPath $srCommon -PathType Leaf) { . $srCommon }

$foundation = Join-Path $toolkitRoot "00_Common\Foundation-Common.ps1"
if (-not (Test-Path -LiteralPath $foundation -PathType Leaf)) { exit 0 }
. $foundation

$logs = Get-ToolkitLogRoot
$cutoff = (Get-Date).AddDays(-1 * [math]::Abs($AgeDays))
$archiveRoot = Join-Path $logs "Archive"
if (-not (Test-Path -LiteralPath $archiveRoot)) {
    New-Item -ItemType Directory -Path $archiveRoot -Force -ErrorAction SilentlyContinue | Out-Null
}

$activeCase = Get-ToolkitCaseContext
$oldCases = @(
    Get-ChildItem -LiteralPath $logs -Directory -Filter "CASE_*" -ErrorAction SilentlyContinue |
        Where-Object {
            $_.LastWriteTime -lt $cutoff -and
            ([string]$activeCase.CasePath -eq "" -or $_.FullName -ne [string]$activeCase.CasePath)
        } |
        Sort-Object LastWriteTime
)

$reportPatterns = @("*.txt","*.json","*.jsonl","*.csv","*.html","*.zip","*.sha256")
$oldReports = New-Object System.Collections.Generic.List[object]
foreach ($pattern in $reportPatterns) {
    foreach ($file in Get-ChildItem -LiteralPath $logs -File -Filter $pattern -ErrorAction SilentlyContinue) {
        if ($file.LastWriteTime -lt $cutoff -and
            $file.Name -notmatch '^ACTIVE_CASE\.' -and
            $file.Name -notmatch '^FIRST_RUN_VALIDATED_' -and
            $file.Name -notmatch '^SESSION_STATE_' -and
            $file.Name -notmatch '^LAST_EXIT_STATUS(?:\.|_)' -and
            $file.Name -ne 'EXIT_ERRORS.jsonl' -and
            $file.DirectoryName -ne $archiveRoot) {
            $oldReports.Add($file)
        }
    }
}
$oldReports = @($oldReports | Sort-Object FullName -Unique)

function Get-OldExitErrorEntries {
    $path=Join-Path $logs "EXIT_ERRORS.jsonl"
    if(-not (Test-Path -LiteralPath $path -PathType Leaf)){return @()}

    $items=@()
    $lineNumber=0
    foreach($line in Get-Content -LiteralPath $path -ErrorAction SilentlyContinue){
        $lineNumber++
        if([string]::IsNullOrWhiteSpace($line)){continue}
        try{
            $entry=$line|ConvertFrom-Json -ErrorAction Stop
            $timestamp=[datetime]$entry.Timestamp
            if($timestamp -lt $cutoff){
                $items+=,[pscustomobject]@{
                    LineNumber=$lineNumber
                    Timestamp=$timestamp
                    ErrorType=[string]$entry.ErrorType
                    ErrorMessage=[string]$entry.ErrorMessage
                    RawLine=$line
                }
            }
        }catch{
            # Malformed entries are deliberately retained; retention never
            # silently discards a line it cannot classify.
        }
    }
    return @($items)
}

$oldExitErrors=@(Get-OldExitErrorEntries)

if ($oldCases.Count -eq 0 -and $oldReports.Count -eq 0 -and $oldExitErrors.Count -eq 0) { exit 0 }

function Invoke-RetentionChoice {
    param(
        [Parameter(Mandatory=$true)][string]$Kind,
        [Parameter(Mandatory=$true)][object[]]$Items,
        [Parameter(Mandatory=$true)][string]$ArchivePrefix
    )

    if ($Items.Count -eq 0) { return }

    Write-Host ""
    Write-Host ("RETENTION NOTICE: " + $Items.Count + " " + $Kind + " item(s) are more than " + $AgeDays + " days old.")
    $oldest = ($Items | Sort-Object LastWriteTime | Select-Object -First 1).LastWriteTime
    Write-Host ("Oldest item: " + $oldest)
    Write-Host "A = archive these items to a ZIP, then remove the originals."
    Write-Host "P = purge these items without archiving."
    Write-Host "D = dry run: list what would be affected, then ask again."
    Write-Host "S = skip and leave them in place."

    while ($true) {
        $choice = (Read-ToolkitPrompt ("Choose A, P, D, or S for old " + $Kind)).Trim().ToUpperInvariant()
        if ($choice -ne "D") { break }

        Write-Host ""
        Write-Host ("DRY RUN - old " + $Kind + " items that would be affected:")
        foreach ($item in $Items) {
            Write-Host ("  " + $item.FullName + " | LastWrite=" + $item.LastWriteTime)
        }
        Write-Host ("Dry run only. No " + $Kind + " items were changed.")
        Write-Host ""
    }

    if ($choice -eq "A") {
        $stamp = Get-Date -Format "yyyyMMdd_HHmmss"
        $staging = Join-Path $archiveRoot ("_RETENTION_STAGE_" + [guid]::NewGuid().ToString("N"))
        New-Item -ItemType Directory -Path $staging -Force | Out-Null
        try {
            foreach ($item in $Items) {
                if ($item.PSIsContainer) {
                    Copy-Item -LiteralPath $item.FullName -Destination (Join-Path $staging $item.Name) -Recurse -Force
                } else {
                    Copy-Item -LiteralPath $item.FullName -Destination (Join-Path $staging $item.Name) -Force
                }
            }
            $zip = Join-Path $archiveRoot ($ArchivePrefix + "_" + $stamp + ".zip")
            Compress-Archive -Path (Join-Path $staging "*") -DestinationPath $zip -Force
            if (-not (Test-Path -LiteralPath $zip -PathType Leaf)) {
                Write-Host "Archive creation failed. Originals were NOT removed."
                return
            }
            $zipHash = (Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToUpperInvariant()
            Set-ToolkitAtomicText -Path ($zip + ".sha256") -Content ($zipHash + [Environment]::NewLine) -Encoding ASCII | Out-Null

            foreach ($item in $Items) {
                Remove-Item -LiteralPath $item.FullName -Recurse -Force -ErrorAction Stop
            }
            Write-Host ("Archived and removed old " + $Kind + ": " + $zip)
        }
        catch {
            Write-Host ("Archive operation failed: " + $_.Exception.Message)
            Write-Host "Any originals not already removed were left in place."
        }
        finally {
            Remove-Item -LiteralPath $staging -Recurse -Force -ErrorAction SilentlyContinue
        }
        return
    }

    if ($choice -eq "P") {
        Write-Host ("PURGE WARNING: this will permanently delete " + $Items.Count + " old " + $Kind + " item(s).")
        $confirm = (Read-ToolkitPrompt "Type PURGE exactly to continue" -SpellExactPhrase "PURGE").Trim()
        if ($confirm -cne "PURGE") {
            Write-Host "Purge canceled. No retention items were deleted."
            return
        }
        foreach ($item in $Items) {
            Remove-Item -LiteralPath $item.FullName -Recurse -Force -ErrorAction SilentlyContinue
        }
        Write-Host ("Purged old " + $Kind + " items.")
        return
    }

    Write-Host ("Old " + $Kind + " items left in place.")
}

function Invoke-ExitErrorRetention {
    param([object[]]$OldEntries)

    if($OldEntries.Count -eq 0){return}

    $path=Join-Path $logs "EXIT_ERRORS.jsonl"
    Write-Host ""
    Write-Host ("RETENTION NOTICE: " + $OldEntries.Count + " EXIT_ERRORS.jsonl entry/entries are more than " + $AgeDays + " days old.")
    Write-Host "A = archive old entries to a ZIP, then compact EXIT_ERRORS.jsonl."
    Write-Host "P = purge old entries without archiving, after typed confirmation."
    Write-Host "D = dry run: list old entries, then ask again."
    Write-Host "S = skip and leave the append-only error history unchanged."

    while($true){
        $choice=(Read-ToolkitPrompt "Choose A, P, D, or S for old exit-error entries").Trim().ToUpperInvariant()
        if($choice -ne "D"){break}

        Write-Host ""
        Write-Host "DRY RUN - old EXIT_ERRORS.jsonl entries:"
        foreach($item in $OldEntries){
            Write-Host ("  Line " + $item.LineNumber + " | " + $item.Timestamp + " | " + $item.ErrorType + " | " + $item.ErrorMessage)
        }
        Write-Host "Dry run only. EXIT_ERRORS.jsonl was not changed."
        Write-Host ""
    }

    if($choice -notin @("A","P")){
        Write-Host "Old exit-error entries left in place."
        return
    }

    if($choice -eq "P"){
        Write-Host ("PURGE WARNING: this will permanently delete " + $OldEntries.Count + " old EXIT_ERRORS.jsonl entry/entries.")
        $confirm=(Read-ToolkitPrompt "Type PURGE exactly to continue" -SpellExactPhrase "PURGE").Trim()
        if($confirm -cne "PURGE"){
            Write-Host "Purge canceled. EXIT_ERRORS.jsonl was not changed."
            return
        }
    }

    $oldLineNumbers=@{}
    foreach($item in $OldEntries){$oldLineNumbers[[int]$item.LineNumber]=$true}
    $allLines=@(Get-Content -LiteralPath $path -ErrorAction Stop)
    $keepLines=New-Object System.Collections.Generic.List[string]
    $archiveLines=New-Object System.Collections.Generic.List[string]
    for($i=0;$i -lt $allLines.Count;$i++){
        $lineNo=$i+1
        if($oldLineNumbers.ContainsKey($lineNo)){
            $archiveLines.Add([string]$allLines[$i])
        }else{
            $keepLines.Add([string]$allLines[$i])
        }
    }

    if($choice -eq "A"){
        $stamp=Get-Date -Format "yyyyMMdd_HHmmss"
        $stage=Join-Path $archiveRoot ("_EXIT_ERRORS_STAGE_"+[guid]::NewGuid().ToString("N"))
        New-Item -ItemType Directory -Path $stage -Force|Out-Null
        try{
            $archiveJsonl=Join-Path $stage "EXIT_ERRORS_OLD.jsonl"
            $archiveContent=$(if($archiveLines.Count -gt 0){($archiveLines.ToArray() -join [Environment]::NewLine)+[Environment]::NewLine}else{""})
            Set-ToolkitAtomicText -Path $archiveJsonl -Content $archiveContent|Out-Null

            $zip=Join-Path $archiveRoot ("ExitErrors_OlderThan"+$AgeDays+"Days_"+$stamp+".zip")
            Compress-Archive -Path (Join-Path $stage "*") -DestinationPath $zip -Force
            if(-not (Test-Path -LiteralPath $zip -PathType Leaf)){
                Write-Host "Exit-error archive creation failed. EXIT_ERRORS.jsonl was NOT changed."
                return
            }
            $zipHash=(Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToUpperInvariant()
            Set-ToolkitAtomicText -Path ($zip+".sha256") -Content ($zipHash+[Environment]::NewLine) -Encoding ASCII|Out-Null
        }finally{
            Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue
        }
    }

    $newContent=$(if($keepLines.Count -gt 0){($keepLines.ToArray() -join [Environment]::NewLine)+[Environment]::NewLine}else{""})
    Set-ToolkitAtomicText -Path $path -Content $newContent|Out-Null

    if($choice -eq "A"){
        Write-Host ("Archived and compacted " + $OldEntries.Count + " old exit-error entry/entries.")
    }else{
        Write-Host ("Purged " + $OldEntries.Count + " old exit-error entry/entries.")
    }
}

Invoke-RetentionChoice -Kind "case" -Items $oldCases -ArchivePrefix "Cases_OlderThan90Days"
Invoke-RetentionChoice -Kind "report" -Items $oldReports -ArchivePrefix "Reports_OlderThan90Days"
Invoke-ExitErrorRetention -OldEntries $oldExitErrors

exit 0

param(
    [Parameter(Mandatory=$true)][string]$FilePath,
    [Parameter(Mandatory=$true)][string]$Label,
    [switch]$Mutation,
    [string]$Action = "Toolkit Native Command",
    [int]$TimeoutSeconds = 0,
    [Parameter(ValueFromRemainingArguments=$true)][string[]]$NativeArguments
)

$toolkitRoot = Split-Path $PSScriptRoot -Parent
$foundation = Join-Path $toolkitRoot "00_Common\Foundation-Common.ps1"
if (-not (Test-Path -LiteralPath $foundation -PathType Leaf)) {
    Write-Host "Required toolkit foundation helper is missing:"
    Write-Host $foundation
    exit 127
}

. $foundation

if ($TimeoutSeconds -le 0 -and $env:FIELDTECH_TOOL_TIMEOUT_SECONDS -match '^\d+$') {
    $TimeoutSeconds = [int]$env:FIELDTECH_TOOL_TIMEOUT_SECONDS
}

$result = Invoke-ToolkitNativeCommand `
    -FilePath $FilePath `
    -Arguments @($NativeArguments) `
    -Label $Label `
    -Action $Action `
    -Mutation:$Mutation `
    -TimeoutSeconds $TimeoutSeconds `
    -Quiet

$result.Output | ForEach-Object { Write-Host $_ }

if ($result.Status -eq "UNSUPPORTED") {
    Write-Host ("Result [UNSUPPORTED]: " + $Label)
    exit 127
}

if ($result.RebootRequired) {
    Write-Host ("Result [REBOOT_REQUIRED]: " + $Label)
}
elseif ($result.ExitCode -ne 0) {
    Write-Host ("Result [FAILED]: " + $Label + " (exit " + $result.ExitCode + ")")
}

exit $result.ExitCode

param(
    [string]$BasicChoice = "",
    [string]$ReturnCode = ""
)

# Advisory output only. This helper runs in a separate PowerShell process so
# it cannot alter launcher labels, GOTO flow, menu return targets, or the
# caller's environment.

if ([string]::IsNullOrWhiteSpace($BasicChoice)) { exit 0 }
if ([string]::IsNullOrWhiteSpace($ReturnCode)) { exit 0 }

[int]$rc = 0
if (-not [int]::TryParse($ReturnCode, [ref]$rc)) { exit 0 }

if ($rc -ne 0) {
    Write-Host ""
    Write-Host "NEXT STEP: The Basic tool did not complete successfully. Review its output before choosing a deeper investigator."
    exit 0
}

$messages = @{
    "1"  = @(
        "NEXT STEP: If the Full Machine Report flags a subsystem, use the matching Advanced investigator rather than rerunning broad checks.",
        "           Servicing/update concerns: Advanced 75. Domain trust/sign-in concerns: Advanced 76."
    )
    "2"  = @("NEXT STEP: If Quick Health flags storage, crashes, devices, or updates, consider Advanced 6, 7, 13, or 75 respectively.")
    "3"  = @("NEXT STEP: Use the intake flags to choose the deeper Advanced investigator. Update/servicing: Advanced 75. Domain trust/sign-in: Advanced 76.")
    "5"  = @("NEXT STEP: If the Windows build/update state needs deeper analysis, consider Advanced 5 or Advanced 75.")
    "6"  = @("NEXT STEP: If activation/licensing needs deeper analysis, consider Advanced 9 - Software / Activation / Licensing Deep Dive.")
    "7"  = @("NEXT STEP: For a suspicious network snapshot, consider Advanced 66 Network Path, Advanced 71 DNS, Advanced 72 DHCP, or Advanced 73 adapter/driver.")
    "8"  = @(
        "NEXT STEP: If IP connectivity works but name resolution fails, consider Advanced 71 - DNS Resolution Chain Investigator.",
        "           If addressing/lease state looks wrong, consider Advanced 72 - DHCP Lease / State Deep Dive."
    )
    "9"  = @("NEXT STEP: Deeper network follow-up: Advanced 66 Network Path, Advanced 71 DNS, Advanced 72 DHCP, Advanced 73 adapter/driver, or Advanced 74 SMB.")
    "10" = @("NEXT STEP: For Wi-Fi capability/driver concerns, consider Advanced 50 or Advanced 73.")
    "11" = @("NEXT STEP: Gateway/path trouble points toward Advanced 66. DNS-specific trouble points toward Advanced 71.")
    "12" = @("NEXT STEP: If adapter state or driver behavior looks abnormal, consider Advanced 73 - Network Driver / Event Correlation.")
    "13" = @("NEXT STEP: If DNS symptoms persist after the flush, consider Advanced 71 - DNS Resolution Chain Investigator.")
    "14" = @("NEXT STEP: If DHCP symptoms persist after release/renew, consider Advanced 72 - DHCP Lease / State Deep Dive.")
    "15" = @("NEXT STEP: If SFC found corruption, could not repair files, or the problem returns, consider Advanced 75 - Windows Servicing / Update Health Report.")
    "16" = @("NEXT STEP: If DISM CheckHealth reports a servicing concern, consider Advanced 75 - Windows Servicing / Update Health Report.")
    "17" = @("NEXT STEP: If RestoreHealth fails, repeats, or Windows Update remains unhealthy, consider Advanced 75 for servicing correlation and verification.")
    "18" = @("NEXT STEP: If CHKDSK reports disk/filesystem concerns, consider Advanced 6 - SMART / Drive Deep Dive and Advanced 67 - Hardware Error Investigator.")
    "19" = @("NEXT STEP: If printing problems persist after spooler cleanup, consider Advanced 65 - Printer Failure Investigator.")
    "20" = @("NEXT STEP: If battery behavior points to sleep/wake or power-management trouble, consider Advanced 64 - Power / Sleep / Wake Investigator.")
    "21" = @("NEXT STEP: For deeper sleep, wake, shutdown, or power-state analysis, consider Advanced 64 - Power / Sleep / Wake Investigator.")
    "22" = @("NEXT STEP: If storage health is suspicious, consider Advanced 6 - SMART / Drive Deep Dive and Advanced 67 - Hardware Error Investigator.")
    "23" = @("NEXT STEP: If software inventory raises activation/licensing questions, consider Advanced 9 - Software / Activation / Licensing Deep Dive.")
    "24" = @("NEXT STEP: For deeper BitLocker protector/state detail, consider Advanced 47 - BitLocker Protector Summary.")
    "25" = @("NEXT STEP: If Defender state needs deeper security review, consider Advanced 49 - Microsoft Defender Security Audit.")
}

if ($messages.ContainsKey($BasicChoice)) {
    Write-Host ""
    foreach ($line in $messages[$BasicChoice]) {
        Write-Host $line
    }
}

exit 0

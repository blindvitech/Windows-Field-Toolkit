# Shared offline HTML renderer for long technician reports.
# This is presentation-only. Existing TXT/MD/JSON/evidence outputs remain authoritative.

function New-ToolkitSectionedReport {
    param(
        [Parameter(Mandatory=$true)][string]$Title,
        [string]$Subtitle = "",
        [string]$Footer = ""
    )

    return [pscustomobject]@{
        Title = $Title
        Subtitle = $Subtitle
        Footer = $Footer
        Sections = (New-Object System.Collections.ArrayList)
    }
}

function ConvertTo-ToolkitSectionId {
    param([string]$Title)

    $id = ([string]$Title).ToLowerInvariant()
    $id = [regex]::Replace($id,'[^a-z0-9]+','-').Trim('-')
    if ([string]::IsNullOrWhiteSpace($id)) {
        $id = "section"
    }
    return $id
}

function Add-ToolkitSectionedReportSection {
    param(
        [Parameter(Mandatory=$true)]$Report,
        [Parameter(Mandatory=$true)][string]$Title,
        $Data,
        [string]$Note = "",
        [ValidateSet("SUMMARY","WARNING","FAILURE","RECOMMENDATION","NORMAL","EVIDENCE","INVENTORY")]
        [string]$Kind = "NORMAL",
        [bool]$OpenByDefault = $false,
        [string]$Confidence = ""
    )

    $body = ""
    if ($null -eq $Data) {
        $body = "(No data returned / not applicable)"
    }
    elseif ($Data -is [string]) {
        $body = [string]$Data
    }
    else {
        $body = ($Data | Out-String -Width 280).TrimEnd()
        if ([string]::IsNullOrWhiteSpace($body)) {
            $body = "(No data returned / not applicable)"
        }
    }

    if ($Kind -in @("SUMMARY","WARNING","FAILURE","RECOMMENDATION")) {
        $OpenByDefault = $true
    }

    $id = ConvertTo-ToolkitSectionId -Title $Title
    $duplicateCount = @($Report.Sections | Where-Object { $_.Id -eq $id }).Count
    if ($duplicateCount -gt 0) {
        $id = $id + "-" + ($duplicateCount + 1)
    }

    [void]$Report.Sections.Add([pscustomobject]@{
        Id = $id
        Title = $Title
        Body = $body
        Note = $Note
        Kind = $Kind
        OpenByDefault = $OpenByDefault
        Confidence = $Confidence
    })
}

function Write-ToolkitSectionedHtmlReport {
    param(
        [Parameter(Mandatory=$true)]$Report,
        [Parameter(Mandatory=$true)][string]$Path,
        [string]$Computer = $env:COMPUTERNAME,
        [string]$Generated = ([string](Get-Date)),
        [string]$ToolId = $env:FIELDTECH_TOOL_ID
    )

    $enc = [System.Net.WebUtility]
    $safeTitle = $enc::HtmlEncode([string]$Report.Title)
    $safeSubtitle = $enc::HtmlEncode([string]$Report.Subtitle)
    $safeComputer = $enc::HtmlEncode([string]$Computer)
    $safeGenerated = $enc::HtmlEncode([string]$Generated)
    $safeTool = $enc::HtmlEncode([string]$ToolId)

    $nav = New-Object System.Text.StringBuilder
    foreach ($section in @($Report.Sections)) {
        [void]$nav.Append(
            "<a href='#" + $enc::HtmlEncode([string]$section.Id) + "'>" +
            $enc::HtmlEncode([string]$section.Title) + "</a>"
        )
    }

    $sectionsHtml = New-Object System.Text.StringBuilder
    foreach ($section in @($Report.Sections)) {
        $open = $(if ([bool]$section.OpenByDefault) { " open" } else { "" })
        $kind = ([string]$section.Kind).ToLowerInvariant()

        $confidenceHtml = ""
        if (-not [string]::IsNullOrWhiteSpace([string]$section.Confidence)) {
            $confidenceHtml = "<span class='confidence'>" +
                $enc::HtmlEncode([string]$section.Confidence) + "</span>"
        }

        $noteHtml = ""
        if (-not [string]::IsNullOrWhiteSpace([string]$section.Note)) {
            $noteHtml = "<div class='note'>" +
                $enc::HtmlEncode([string]$section.Note) + "</div>"
        }

        [void]$sectionsHtml.AppendLine(
            "<section id='" + $enc::HtmlEncode([string]$section.Id) + "' class='kind-" + $kind + "'>" +
            "<details" + $open + "><summary>" + $enc::HtmlEncode([string]$section.Title) +
            $confidenceHtml + "</summary><div class='sectionbody'>" + $noteHtml +
            "<pre>" + $enc::HtmlEncode([string]$section.Body) + "</pre>" +
            "<div class='back'><a href='#top'>Back to top</a></div></div></details></section>"
        )
    }

    $safeFooter = $enc::HtmlEncode([string]$Report.Footer)

    $html = @"
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>$safeTitle</title>
<style>
body{font-family:"Segoe UI",Arial,sans-serif;margin:0;background:#f5f7fa;color:#18212f;line-height:1.4}
main{max-width:1500px;margin:0 auto;padding:24px}
h1{margin:0 0 4px}.meta,.subtitle{color:#5c6675}.subtitle{margin:6px 0 16px}
.toolbar{display:flex;gap:8px;flex-wrap:wrap;margin:14px 0}
button{font:inherit;padding:7px 10px;border:1px solid #aeb8c4;border-radius:6px;background:white;cursor:pointer}
.nav{display:flex;gap:8px;flex-wrap:wrap;background:white;border:1px solid #d7dde5;border-radius:8px;padding:10px;margin:12px 0 18px}
.nav a,.back a{color:#135f9c;text-decoration:none}.nav a:hover,.back a:hover{text-decoration:underline}
section{margin:10px 0;scroll-margin-top:12px}
details{background:white;border:1px solid #d7dde5;border-radius:8px;overflow:hidden}
summary{cursor:pointer;padding:12px 14px;font-weight:650;background:#eef2f6}
.kind-warning summary,.kind-failure summary,.kind-recommendation summary,.kind-summary summary{font-weight:750}
.sectionbody{padding:12px 14px;overflow-x:auto}
pre{white-space:pre-wrap;word-break:break-word;background:#f8fafc;border:1px solid #e3e7ec;border-radius:6px;padding:10px;margin:8px 0}
.note{font-size:13px;color:#5c6675;margin-bottom:8px}
.confidence{font-size:12px;margin-left:10px;padding:2px 7px;border:1px solid #c4ccd6;border-radius:999px;background:white}
.back{text-align:right;font-size:12px;margin-top:6px}.footer{margin-top:24px;font-size:12px;color:#6c7684}
@media print{
  .toolbar,.nav,.back{display:none}
  details{break-inside:avoid}
  details>summary{list-style:none}
  details:not([open])>*:not(summary){display:block}
}
</style>
<script>
function toolkitSetDetails(openState){
  document.querySelectorAll('details').forEach(function(d){d.open=openState;});
}
</script>
</head>
<body>
<main id="top">
<h1>$safeTitle</h1>
<div class="meta"><strong>Computer:</strong> $safeComputer | <strong>Generated:</strong> $safeGenerated | <strong>Tool:</strong> $safeTool</div>
<div class="subtitle">$safeSubtitle</div>
<div class="toolbar">
<button type="button" onclick="toolkitSetDetails(true)">Expand all</button>
<button type="button" onclick="toolkitSetDetails(false)">Collapse all</button>
</div>
<nav class="nav" aria-label="Report sections">$($nav.ToString())</nav>
$($sectionsHtml.ToString())
<div class="footer">$safeFooter</div>
</main>
</body>
</html>
"@

    $html | Set-Content -LiteralPath $Path -Encoding UTF8
    return $Path
}

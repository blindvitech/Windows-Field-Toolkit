# Windows Field Tech Toolkit shared foundation.
# PowerShell 5.1 compatible. No credentials, recovery passwords, or other
# authentication secrets are collected by this layer.

$script:ToolkitRoot = Split-Path $PSScriptRoot -Parent
$script:ToolkitOperationSchemaVersion = 2
$script:ToolkitStateSchemaVersion = 2
$script:ToolkitCatalogSchemaVersion = 1

if (-not (Get-Command Write-ToolkitStatus -ErrorAction SilentlyContinue)) {
    function Write-ToolkitStatus {
        param([Parameter(Mandatory=$true)][string]$Message)
        Write-Host ("STATUS: " + $Message)
    }
}

function Set-ToolkitAtomicText {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][AllowEmptyString()][string]$Content,
        [ValidateSet("UTF8","ASCII")][string]$Encoding = "UTF8",
        [ValidateRange(1,10)][int]$ReplaceAttempts = 4,
        [ValidateRange(0,2000)][int]$RetryDelayMilliseconds = 125
    )

    $dir = Split-Path $Path -Parent
    if ($dir -and -not (Test-Path -LiteralPath $dir)) {
        New-Item -ItemType Directory -Path $dir -Force -ErrorAction Stop | Out-Null
    }

    # Keep atomic staging names short and independent of the destination
    # filename. Appending a full GUID to a long SESSION_STATE filename can
    # cross the legacy 260-character path boundary used by Windows PowerShell
    # 5.1/.NET File APIs even when the destination itself is valid.
    $atomicDir = $(if($dir){$dir}else{(Get-Location).Path})
    $atomicNonce = [guid]::NewGuid().ToString("N").Substring(0,12)
    $tmp = Join-Path $atomicDir (".fttmp_" + $atomicNonce)
    $fallbackBackup = Join-Path $atomicDir (".ftbak_" + $atomicNonce)
    $writeException = $null

    try {
        if ($Encoding -eq "ASCII") {
            [IO.File]::WriteAllText($tmp,$Content,[Text.Encoding]::ASCII)
        }
        else {
            $utf8 = New-Object Text.UTF8Encoding($false)
            [IO.File]::WriteAllText($tmp,$Content,$utf8)
        }

        # Force the staged file to disk before replacing the destination.
        $stream = [IO.File]::Open($tmp,[IO.FileMode]::Open,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
        try { $stream.Flush($true) } finally { $stream.Dispose() }

        if (-not (Test-Path -LiteralPath $Path)) {
            [IO.File]::Move($tmp,$Path)
        }
        else {
            $replaceSucceeded = $false
            for ($attempt = 1; $attempt -le $ReplaceAttempts; $attempt++) {
                try {
                    # Preferred same-volume atomic replacement.
                    [IO.File]::Replace($tmp,$Path,$null,$true)
                    $replaceSucceeded = $true
                    break
                }
                catch {
                    $writeException = $_.Exception
                    if ($attempt -lt $ReplaceAttempts -and $RetryDelayMilliseconds -gt 0) {
                        Start-Sleep -Milliseconds $RetryDelayMilliseconds
                    }
                }
            }

            if (-not $replaceSucceeded) {
                # Recoverable fallback for systems/filesystems where File.Replace is
                # unavailable or transiently rejected. Preserve the old destination,
                # move the staged file into place, and restore the old destination if
                # the move fails. All paths stay in the same directory/volume.
                $oldMoved = $false
                try {
                    [IO.File]::Move($Path,$fallbackBackup)
                    $oldMoved = $true
                    [IO.File]::Move($tmp,$Path)
                    if (Test-Path -LiteralPath $fallbackBackup) {
                        Remove-Item -LiteralPath $fallbackBackup -Force -ErrorAction Stop
                    }
                }
                catch {
                    $fallbackException = $_.Exception
                    if ($oldMoved -and -not (Test-Path -LiteralPath $Path) -and (Test-Path -LiteralPath $fallbackBackup)) {
                        try { [IO.File]::Move($fallbackBackup,$Path) } catch {}
                    }
                    $message = "Atomic write failed for '$Path'. File.Replace error: " +
                        $(if($writeException){$writeException.Message}else{"unknown"}) +
                        "; fallback error: " + $fallbackException.Message
                    throw (New-Object IO.IOException -ArgumentList $message,$fallbackException)
                }
            }
        }

        if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
            throw (New-Object IO.IOException -ArgumentList ("Atomic write verification failed because the destination does not exist: " + $Path))
        }

        # Verify exact bytes/text content after replacement.
        $verifyEncoding = $(if($Encoding -eq "ASCII"){[Text.Encoding]::ASCII}else{New-Object Text.UTF8Encoding($false)})
        $actual = [IO.File]::ReadAllText($Path,$verifyEncoding)
        if ($actual -cne $Content) {
            throw (New-Object IO.IOException -ArgumentList ("Atomic write verification failed because destination content did not match staged content: " + $Path))
        }

        return $true
    }
    finally {
        foreach($cleanupPath in @($tmp,$fallbackBackup)) {
            if ($cleanupPath -and (Test-Path -LiteralPath $cleanupPath)) {
                Remove-Item -LiteralPath $cleanupPath -Force -ErrorAction SilentlyContinue
            }
        }
    }
}

function Set-ToolkitAtomicJson {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)]$Object,
        [int]$Depth = 8
    )
    $json = $Object | ConvertTo-Json -Depth $Depth
    return Set-ToolkitAtomicText -Path $Path -Content ($json + [Environment]::NewLine) -Encoding UTF8
}

function Add-ToolkitJsonLine {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)]$Object
    )
    $line = ($Object | ConvertTo-Json -Compress) + [Environment]::NewLine
    $bytes = (New-Object Text.UTF8Encoding($false)).GetBytes($line)
    $dir = Split-Path $Path -Parent
    if ($dir -and -not (Test-Path -LiteralPath $dir)) {
        New-Item -ItemType Directory -Path $dir -Force -ErrorAction Stop | Out-Null
    }
    $stream = New-Object IO.FileStream($Path,[IO.FileMode]::Append,[IO.FileAccess]::Write,[IO.FileShare]::Read)
    try {
        $stream.Write($bytes,0,$bytes.Length)
        $stream.Flush($true)
    }
    finally {
        $stream.Dispose()
    }
}

function Get-ToolkitToolCatalog {
    $path = Join-Path $script:ToolkitRoot "00_Common\ToolCatalog.json"
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { return $null }
    try { return (Get-Content -LiteralPath $path -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop) } catch { return $null }
}

function Get-ToolkitToolDefinition {
    param(
        [string]$ToolId = "",
        [string]$Label = "",
        [string]$RelativePath = ""
    )
    $catalog = Get-ToolkitToolCatalog
    if (-not $catalog) { return $null }
    foreach ($tool in @($catalog.Tools)) {
        if ($ToolId -and [string]$tool.ToolId -ieq $ToolId) { return $tool }
        if ($RelativePath -and ([string]$tool.RelativePath -replace '/','\') -ieq ($RelativePath -replace '/','\')) { return $tool }
        if ($Label -and [string]$tool.Label -ieq $Label) { return $tool }
    }
    return $null
}

function Test-ToolkitToolDependencies {
    param([Parameter(Mandatory=$true)]$Tool)
    $caps = Get-ToolkitFeatureCapabilities
    $reasons = New-Object System.Collections.Generic.List[string]
    $required = @($Tool.RequiredDependencies)
    if ($required.Count -eq 0 -and -not $Tool.PSObject.Properties["RequiredDependencies"]) {
        $required = @($Tool.Dependencies)
    }
    foreach ($dep in $required) {
        switch ([string]$dep) {
            "Admin" { if (-not (Test-ToolkitAdminContext)) { $reasons.Add("Administrator rights required") } }
            "BitLocker" { if ([string]$caps.BitLocker -eq "[UNAVAILABLE]") { $reasons.Add("BitLocker capability unavailable") } }
            "Defender" { if ([string]$caps.Defender -eq "[UNAVAILABLE]") { $reasons.Add("Defender capability unavailable") } }
            "WinRE" { if ([string]$caps.WinRE -eq "[UNAVAILABLE]") { $reasons.Add("WinRE tooling unavailable") } }
            "DISM" { if ([string]$caps.DISM -eq "[UNAVAILABLE]") { $reasons.Add("DISM unavailable") } }
            "SFC" { if ([string]$caps.SFC -eq "[UNAVAILABLE]") { $reasons.Add("SFC unavailable") } }
            "CHKDSK" { if ([string]$caps.CHKDSK -eq "[UNAVAILABLE]") { $reasons.Add("CHKDSK unavailable") } }
            "PNPUtil" { if ([string]$caps.PNPUtil -eq "[UNAVAILABLE]") { $reasons.Add("PnPUtil unavailable") } }
            "WLAN" { if ([string]$caps.WLAN -match 'NO WLAN|UNAVAILABLE') { $reasons.Add("No WLAN adapter/tooling available") } }
            "Battery" { if ([string]$caps.Battery -eq "[NO BATTERY]") { $reasons.Add("No battery detected") } }
            "TPM" { if ([string]$caps.TPM -match 'NO TPM|UNAVAILABLE') { $reasons.Add("TPM unavailable") } }
            "SecureBoot" { if ([string]$caps.SecureBoot -match 'UNSUPPORTED|UNAVAILABLE') { $reasons.Add("Secure Boot unavailable") } }
            "HyperV" { if ([string]$caps.HyperV -match 'UNAVAILABLE') { $reasons.Add("Hyper-V unavailable") } }
            "PowerCfg" { if ([string]$caps.PowerCfg -eq "[UNAVAILABLE]") { $reasons.Add("powercfg unavailable") } }
        }
    }
    return [pscustomobject]@{
        Ready = ($reasons.Count -eq 0)
        Reasons = $reasons.ToArray()
        RequiredDependencies = @($required)
        AdvisoryDependencies = @($Tool.AdvisoryDependencies)
        Capabilities = $caps
    }
}

$script:ToolkitResultStates = @(
    "SUCCESS",
    "FAILED",
    "UNSUPPORTED",
    "CANCELED",
    "PARTIAL",
    "REBOOT_REQUIRED"
)

function Test-ToolkitAdminContext {
    try {
        $id = [Security.Principal.WindowsIdentity]::GetCurrent()
        $principal = New-Object Security.Principal.WindowsPrincipal($id)
        return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    }
    catch {
        return $false
    }
}

function Get-ToolkitBuildIdentity {
    $knownGood = Join-Path $script:ToolkitRoot "26_Tools\KnownGood"
    $hashPath = Join-Path $knownGood "Toolkit-Core-Manifest.sha256"
    $manifestPath = Join-Path $knownGood "Toolkit-Core-Manifest.json"
    $fullHash = ""

    try {
        if (Test-Path -LiteralPath $hashPath -PathType Leaf) {
            $candidate = (Get-Content -LiteralPath $hashPath -Raw -ErrorAction Stop).Trim().ToUpperInvariant()
            if ($candidate -match '^[0-9A-F]{64}$') {
                $fullHash = $candidate
            }
        }

        if (-not $fullHash -and (Test-Path -LiteralPath $manifestPath -PathType Leaf)) {
            $fullHash = (Get-FileHash -LiteralPath $manifestPath -Algorithm SHA256 -ErrorAction Stop).Hash.ToUpperInvariant()
        }
    }
    catch {
    }

    $shortId = $(if ($fullHash.Length -ge 12) { $fullHash.Substring(0,12) } else { "UNVERSIONED" })
    return [pscustomobject]@{
        RootName = (Split-Path $script:ToolkitRoot -Leaf)
        ManifestSHA256 = $fullHash
        BuildId = $shortId
    }
}

function Get-ToolkitSessionId {
    if (-not [string]::IsNullOrWhiteSpace($env:FIELDTECH_SESSION_ID)) {
        return [string]$env:FIELDTECH_SESSION_ID
    }

    $id = [guid]::NewGuid().ToString("N")
    $env:FIELDTECH_SESSION_ID = $id
    return $id
}

function Get-ToolkitLogRoot {
    $preferred = Join-Path $script:ToolkitRoot "Logs"
    try {
        if (-not (Test-Path -LiteralPath $preferred)) {
            New-Item -ItemType Directory -Path $preferred -Force -ErrorAction Stop | Out-Null
        }

        $probe = Join-Path $preferred (".foundation_write_" + [guid]::NewGuid().ToString("N") + ".tmp")
        "probe" | Set-Content -LiteralPath $probe -Encoding ASCII -ErrorAction Stop
        Remove-Item -LiteralPath $probe -Force -ErrorAction Stop
        return $preferred
    }
    catch {
        $fallback = Join-Path $env:TEMP "WindowsFieldTechToolkit\Logs"
        if (-not (Test-Path -LiteralPath $fallback)) {
            New-Item -ItemType Directory -Path $fallback -Force -ErrorAction SilentlyContinue | Out-Null
        }
        $env:FIELDTECH_LOG_FALLBACK = $fallback
        return $fallback
    }
}

function Test-ToolkitCapability {
    param(
        [Parameter(Mandatory=$true)]
        [ValidateSet("Command","Module","Path")]
        [string]$Type,

        [Parameter(Mandatory=$true)]
        [string]$Name
    )

    switch ($Type) {
        "Command" {
            $item = Get-Command $Name -ErrorAction SilentlyContinue
            return [pscustomobject]@{
                Type = $Type
                Name = $Name
                Available = [bool]$item
                Detail = $(if ($item) { [string]$item.Source } else { "Not found" })
            }
        }
        "Module" {
            $item = Get-Module -ListAvailable -Name $Name -ErrorAction SilentlyContinue | Select-Object -First 1
            return [pscustomobject]@{
                Type = $Type
                Name = $Name
                Available = [bool]$item
                Detail = $(if ($item) { [string]$item.Version } else { "Not found" })
            }
        }
        "Path" {
            $available = Test-Path -LiteralPath $Name
            return [pscustomobject]@{
                Type = $Type
                Name = $Name
                Available = [bool]$available
                Detail = $(if ($available) { "Present" } else { "Not found" })
            }
        }
    }
}

function Get-ToolkitCapabilitySnapshot {
    $commands = @(
        "dism.exe",
        "sfc.exe",
        "chkdsk.exe",
        "reagentc.exe",
        "pnputil.exe",
        "bcdedit.exe",
        "manage-bde.exe",
        "powercfg.exe",
        "netsh.exe",
        "w32tm.exe"
    )

    $items = New-Object System.Collections.Generic.List[object]
    foreach ($command in $commands) {
        $items.Add((Test-ToolkitCapability -Type Command -Name $command))
    }

    foreach ($module in @("BitLocker","Defender")) {
        $items.Add((Test-ToolkitCapability -Type Module -Name $module))
    }

    return $items.ToArray()
}

function Test-ToolkitPendingReboot {
    $reasons = New-Object System.Collections.Generic.List[string]

    if (Test-Path -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending") {
        $reasons.Add("CBS RebootPending")
    }

    if (Test-Path -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired") {
        $reasons.Add("Windows Update RebootRequired")
    }

    try {
        $value = Get-ItemProperty -LiteralPath "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager" -Name PendingFileRenameOperations -ErrorAction SilentlyContinue
        if ($value.PendingFileRenameOperations) {
            $reasons.Add("PendingFileRenameOperations")
        }
    }
    catch {
    }

    return [pscustomobject]@{
        Pending = ($reasons.Count -gt 0)
        Reasons = $reasons.ToArray()
    }
}

function Get-ToolkitBitLockerContext {
    $result = [ordered]@{
        Available = $false
        MountPoint = [string]$env:SystemDrive
        VolumeStatus = "UNKNOWN"
        ProtectionStatus = "UNKNOWN"
        EncryptionPercentage = $null
        RecoveryProtectorPresent = $null
    }

    if ([string]::IsNullOrWhiteSpace($result.MountPoint)) {
        $result.MountPoint = "C:"
    }

    if (-not (Get-Command Get-BitLockerVolume -ErrorAction SilentlyContinue)) {
        return [pscustomobject]$result
    }

    try {
        $volume = Get-BitLockerVolume -MountPoint $result.MountPoint -ErrorAction Stop
        $types = @()
        if ($volume.KeyProtector) {
            $types = @($volume.KeyProtector | ForEach-Object { [string]$_.KeyProtectorType })
        }

        $result.Available = $true
        $result.VolumeStatus = [string]$volume.VolumeStatus
        $result.ProtectionStatus = [string]$volume.ProtectionStatus
        $result.EncryptionPercentage = $volume.EncryptionPercentage
        $result.RecoveryProtectorPresent = (@($types | Where-Object { $_ -eq "RecoveryPassword" }).Count -gt 0)
    }
    catch {
    }

    return [pscustomobject]$result
}

function Get-ToolkitWinREContext {
    $result = [ordered]@{
        Available = $false
        State = "UNKNOWN"
    }

    $command = Get-Command reagentc.exe -ErrorAction SilentlyContinue
    if (-not $command) {
        return [pscustomobject]$result
    }

    try {
        $text = ((& reagentc.exe /info 2>&1) | Out-String -Width 220).Trim()
        $result.Available = $true
        if ($text -match '(?im)^\s*Windows RE status:\s*Enabled\s*$') {
            $result.State = "ENABLED"
        }
        elseif ($text -match '(?im)^\s*Windows RE status:\s*Disabled\s*$') {
            $result.State = "DISABLED"
        }
        else {
            $result.State = "UNKNOWN"
        }
    }
    catch {
    }

    return [pscustomobject]$result
}

function Get-ToolkitCaseContext {
    $logs = Get-ToolkitLogRoot
    $jsonMarker = Join-Path $logs "ACTIVE_CASE.json"
    $legacyMarker = Join-Path $logs "ACTIVE_CASE.txt"
    $caseId = ""
    $casePath = ""
    $source = "NONE"
    $state = $null

    if (-not [string]::IsNullOrWhiteSpace($env:FIELDTECH_CASE_ID)) {
        $candidate = [string]$env:FIELDTECH_CASE_ID
        $candidatePath = Join-Path $logs $candidate
        if (Test-Path -LiteralPath $candidatePath -PathType Container) {
            $caseId = $candidate; $casePath = $candidatePath; $source = "ENVIRONMENT"
        }
    }

    if (-not $caseId -and (Test-Path -LiteralPath $jsonMarker -PathType Leaf)) {
        try {
            $state = Get-Content -LiteralPath $jsonMarker -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
            $candidate = [string]$state.CaseId
            $candidatePath = [string]$state.CasePath
            if (-not $candidatePath) { $candidatePath = Join-Path $logs $candidate }
            if ($candidate -and (Test-Path -LiteralPath $candidatePath -PathType Container)) {
                $caseId = $candidate; $casePath = $candidatePath; $source = "ACTIVE_JSON"
            }
        } catch {}
    }

    if (-not $caseId -and (Test-Path -LiteralPath $legacyMarker -PathType Leaf)) {
        try {
            $candidate = (Get-Content -LiteralPath $legacyMarker -Raw -ErrorAction Stop).Trim()
            $candidatePath = Join-Path $logs $candidate
            if ($candidate -and (Test-Path -LiteralPath $candidatePath -PathType Container)) {
                $caseId = $candidate; $casePath = $candidatePath; $source = "LEGACY_MARKER"
            }
        } catch {}
    }

    return [pscustomobject]@{
        SchemaVersion = $script:ToolkitStateSchemaVersion
        CaseId = $caseId
        CasePath = $casePath
        ActiveMarker = $jsonMarker
        LegacyMarker = $legacyMarker
        Source = $source
        ExplicitActiveCase = ($source -ne "NONE")
        State = $state
    }
}

function Set-ToolkitActiveCaseState {
    param(
        [Parameter(Mandatory=$true)][string]$CaseId,
        [Parameter(Mandatory=$true)][string]$CasePath,
        [string]$Status = "ACTIVE"
    )
    $logs = Get-ToolkitLogRoot
    $state = [ordered]@{
        SchemaVersion = $script:ToolkitStateSchemaVersion
        CaseId = $CaseId
        CasePath = $CasePath
        Status = $Status
        Computer = $env:COMPUTERNAME
        User = ($env:USERDOMAIN + "\" + $env:USERNAME)
        SessionId = Get-ToolkitSessionId
        Created = (Get-Date).ToString("o")
        Updated = (Get-Date).ToString("o")
    }
    [void](Set-ToolkitAtomicJson -Path (Join-Path $logs "ACTIVE_CASE.json") -Object $state)
    Set-ToolkitAtomicText -Path (Join-Path $logs "ACTIVE_CASE.txt") -Content ($CaseId + [Environment]::NewLine) -Encoding ASCII | Out-Null
    $env:FIELDTECH_CASE_ID = $CaseId
    return [pscustomobject]$state
}

function Clear-ToolkitActiveCaseState {
    param([string]$ExpectedCaseId = "")
    $ctx = Get-ToolkitCaseContext
    if ($ExpectedCaseId -and $ctx.CaseId -and $ctx.CaseId -ine $ExpectedCaseId) { return $false }
    foreach ($p in @((Join-Path (Get-ToolkitLogRoot) "ACTIVE_CASE.json"),(Join-Path (Get-ToolkitLogRoot) "ACTIVE_CASE.txt"))) {
        if (Test-Path -LiteralPath $p) { Remove-Item -LiteralPath $p -Force -ErrorAction SilentlyContinue }
    }
    Remove-Item Env:FIELDTECH_CASE_ID -ErrorAction SilentlyContinue
    return $true
}

function Get-ToolkitFeatureCapabilities {
    $bitLocker = Get-ToolkitBitLockerContext
    $winRE = Get-ToolkitWinREContext
    $pending = Test-ToolkitPendingReboot
    $isAdmin = Test-ToolkitAdminContext

    $batteryPresent = $false
    try {
        $batteryPresent = $null -ne (Get-CimInstance Win32_Battery -ErrorAction Stop | Select-Object -First 1)
    }
    catch {
    }

    $wlanTooling = [bool](Get-Command netsh.exe -ErrorAction SilentlyContinue)
    $wlanPresent = $false
    try {
        $wlanAdapters = @(
            Get-CimInstance Win32_NetworkAdapter -ErrorAction Stop |
                Where-Object {
                    $_.PhysicalAdapter -eq $true -and (
                        [string]$_.Name -match '(?i)wireless|wi-?fi|802\.11|wlan' -or
                        [string]$_.NetConnectionID -match '(?i)wi-?fi|wireless|wlan'
                    )
                }
        )
        $wlanPresent = $wlanAdapters.Count -gt 0
    }
    catch {
    }

    $defenderAvailable = [bool](Get-Command Get-MpComputerStatus -ErrorAction SilentlyContinue)
    $defenderText = "[UNAVAILABLE]"
    if ($defenderAvailable) {
        try {
            $mp = Get-MpComputerStatus -ErrorAction Stop
            $defenderText = $(if ($mp.AntivirusEnabled -or $mp.RealTimeProtectionEnabled) { "[ACTIVE]" } else { "[INSTALLED / INACTIVE]" })
        }
        catch {
            $defenderText = "[QUERY AVAILABLE]"
        }
    }

    $tpmAvailable = [bool](Get-Command Get-Tpm -ErrorAction SilentlyContinue)
    $tpmPresent = $false
    $tpmQuerySucceeded = $false
    if ($tpmAvailable) {
        try {
            $tpmState = Get-Tpm -ErrorAction Stop
            $tpmPresent = [bool]$tpmState.TpmPresent
            $tpmQuerySucceeded = $true
        }
        catch {
        }
    }

    $secureBootAvailable = [bool](Get-Command Confirm-SecureBootUEFI -ErrorAction SilentlyContinue)
    $secureBootText = "[UNAVAILABLE]"
    if ($secureBootAvailable) {
        try {
            $secureBootEnabled = Confirm-SecureBootUEFI -ErrorAction Stop
            $secureBootText = $(if ($secureBootEnabled) { "[ENABLED]" } else { "[DISABLED]" })
        }
        catch {
            $message = [string]$_.Exception.Message
            if ($message -match '(?i)not supported|unsupported|not UEFI') {
                $secureBootText = "[NOT UEFI / UNSUPPORTED]"
            }
            elseif (-not $isAdmin -or $message -match '(?i)access.*denied|privilege') {
                $secureBootText = "[QUERY REQUIRES ADMIN]"
            }
            else {
                $secureBootText = "[QUERY FAILED]"
            }
        }
    }

    $hyperVText = "[UNAVAILABLE]"
    $hyperVCmdlet = [bool](Get-Command Get-WindowsOptionalFeature -ErrorAction SilentlyContinue)
    $cpuVirtCapable = $null
    try {
        $processors = @(Get-CimInstance Win32_Processor -ErrorAction Stop)
        if ($processors.Count -gt 0) {
            $cpuVirtCapable = (@($processors | Where-Object {
                $_.VMMonitorModeExtensions -eq $false -or
                $_.SecondLevelAddressTranslationExtensions -eq $false
            }).Count -eq 0)
        }
    }
    catch {
    }

    if ($hyperVCmdlet) {
        try {
            $feature = Get-WindowsOptionalFeature -Online -FeatureName Microsoft-Hyper-V-All -ErrorAction Stop
            if ([string]$feature.State -eq "Enabled") {
                $hyperVText = "[ENABLED]"
            }
            elseif ($cpuVirtCapable -eq $false) {
                $hyperVText = "[CPU / FIRMWARE LIMIT]"
            }
            else {
                $hyperVText = "[AVAILABLE / DISABLED]"
            }
        }
        catch {
            $message = [string]$_.Exception.Message
            if (-not $isAdmin -or $message -match '(?i)access.*denied|elevation|privilege') {
                $hyperVText = "[QUERY REQUIRES ADMIN]"
            }
            elseif ($message -match '(?i)not found|unknown feature|feature name') {
                $hyperVText = "[UNAVAILABLE ON EDITION]"
            }
            else {
                $hyperVText = "[UNKNOWN]"
            }
        }
    }

    $bitLockerText = "[UNAVAILABLE]"
    if ($bitLocker.Available) {
        if ([string]$bitLocker.ProtectionStatus -eq "Off" -and [string]$bitLocker.VolumeStatus -ne "FullyDecrypted") {
            $bitLockerText = "[SUSPENDED]"
        }
        elseif ([string]$bitLocker.VolumeStatus -eq "FullyDecrypted") {
            $bitLockerText = "[NOT PROTECTED]"
        }
        else {
            $bitLockerText = "[PROTECTED]"
        }
    }

    $wlanText = $(if (-not $wlanTooling) { "[WLAN TOOLING UNAVAILABLE]" } elseif ($wlanPresent) { "[WLAN ADAPTER PRESENT]" } else { "[NO WLAN ADAPTER DETECTED]" })
    $tpmText = $(if (-not $tpmAvailable) { "[UNAVAILABLE]" } elseif ($tpmQuerySucceeded -and $tpmPresent) { "[TPM PRESENT]" } elseif ($tpmQuerySucceeded) { "[NO TPM]" } elseif (-not $isAdmin) { "[QUERY REQUIRES ADMIN]" } else { "[QUERY FAILED]" })

    return [pscustomobject]@{
        Generated = (Get-Date).ToString("o")
        Administrator = $(if ($isAdmin) { "[ADMIN ACTIVE]" } else { "[STANDARD USER]" })
        PendingReboot = $(if ($pending.Pending) { "[REBOOT PENDING]" } else { "[NO REBOOT PENDING]" })
        DISM = $(if (Get-Command dism.exe -ErrorAction SilentlyContinue) { "[AVAILABLE]" } else { "[UNAVAILABLE]" })
        SFC = $(if (Get-Command sfc.exe -ErrorAction SilentlyContinue) { "[AVAILABLE]" } else { "[UNAVAILABLE]" })
        CHKDSK = $(if (Get-Command chkdsk.exe -ErrorAction SilentlyContinue) { "[AVAILABLE]" } else { "[UNAVAILABLE]" })
        PNPUtil = $(if (Get-Command pnputil.exe -ErrorAction SilentlyContinue) { "[AVAILABLE]" } else { "[UNAVAILABLE]" })
        BitLocker = $bitLockerText
        Defender = $defenderText
        WinRE = $(if (-not $winRE.Available) { "[UNAVAILABLE]" } elseif ($winRE.State -eq "ENABLED") { "[ENABLED]" } elseif ($winRE.State -eq "DISABLED") { "[DISABLED]" } else { "[UNKNOWN]" })
        WLAN = $wlanText
        Battery = $(if ($batteryPresent) { "[BATTERY PRESENT]" } else { "[NO BATTERY]" })
        TPM = $tpmText
        SecureBoot = $secureBootText
        HyperV = $hyperVText
        PowerCfg = $(if (Get-Command powercfg.exe -ErrorAction SilentlyContinue) { "[AVAILABLE]" } else { "[UNAVAILABLE]" })
    }
}

function Get-ToolkitCapabilityForLabel {
    param(
        [Parameter(Mandatory=$true)][string]$Label,
        $Capabilities = $null
    )

    if (-not $Capabilities) {
        $Capabilities = Get-ToolkitFeatureCapabilities
    }

    $text = [string]$Label
    if ($text -match '(?i)Secure Boot' -and $text -match '(?i)TPM') {
        return ("SecureBoot " + [string]$Capabilities.SecureBoot + "; TPM " + [string]$Capabilities.TPM)
    }
    if ($text -match '(?i)BitLocker') { return [string]$Capabilities.BitLocker }
    if ($text -match '(?i)Defender') { return [string]$Capabilities.Defender }
    if ($text -match '(?i)WinRE|Recovery Environment') { return [string]$Capabilities.WinRE }
    if ($text -match '(?i)\bDISM\b|Windows Features') { return [string]$Capabilities.DISM }
    if ($text -match '(?i)\bSFC\b|System File Checker') { return [string]$Capabilities.SFC }
    if ($text -match '(?i)CHKDSK|File-System') { return [string]$Capabilities.CHKDSK }
    if ($text -match '(?i)Driver Recovery|Backup Third-Party Drivers|Driver Version') { return [string]$Capabilities.PNPUtil }
    if ($text -match '(?i)WLAN|Wi-Fi|WiFi') { return [string]$Capabilities.WLAN }
    if ($text -match '(?i)Battery') { return [string]$Capabilities.Battery }
    if ($text -match '(?i)Secure Boot') { return [string]$Capabilities.SecureBoot }
    if ($text -match '(?i)TPM') { return [string]$Capabilities.TPM }
    if ($text -match '(?i)Hyper-V|WSL|Sandbox') { return [string]$Capabilities.HyperV }
    if ($text -match '(?i)Power Report|Power / Sleep|Hibernation') { return [string]$Capabilities.PowerCfg }
    return ""
}

function Get-ToolkitCompatibilityAssessment {
    $os = $null
    $cs = $null
    try { $os = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop } catch {}
    try { $cs = Get-CimInstance Win32_ComputerSystem -ErrorAction Stop } catch {}

    $arch = [string]$env:PROCESSOR_ARCHITECTURE
    $caption = $(if ($os) { [string]$os.Caption } else { "Unknown Windows" })
    $build = $(if ($os) { [string]$os.BuildNumber } else { "" })
    $productType = $(if ($os) { [int]$os.ProductType } else { 0 })
    $isWinPE = Test-Path -LiteralPath "HKLM:\SYSTEM\CurrentControlSet\Control\MiniNT"
    $status = "SUPPORTED_TARGET"
    $notes = New-Object System.Collections.Generic.List[string]

    if ($isWinPE) {
        $status = "LIMITED_WINPE"
        $notes.Add("WinPE is detected. Only a subset of inventory/native diagnostics should be expected to work.")
    }
    elseif ($productType -ne 1 -and $productType -ne 0) {
        $status = "AWARE_NOT_VALIDATED"
        $notes.Add("Windows Server is detected. The toolkit is desktop-Windows oriented and Server behavior is not fully validated.")
    }
    elseif ($arch -eq "ARM64") {
        $status = "AWARE_NOT_VALIDATED"
        $notes.Add("ARM64 is detected. The toolkit avoids hard-coded x64 binaries where possible but ARM64 is not fully runtime-validated.")
    }
    elseif ($arch -eq "x86") {
        $status = "LIMITED"
        $notes.Add("32-bit Windows is detected. Some modern servicing/security functions may be unavailable.")
    }
    elseif ($arch -ne "AMD64") {
        $status = "UNKNOWN"
        $notes.Add("Unrecognized processor architecture: " + $arch)
    }

    if ($PSVersionTable.PSVersion.Major -lt 5) {
        $status = "UNSUPPORTED"
        $notes.Add("Windows PowerShell 5.1 or later compatible behavior is required.")
    }

    return [pscustomobject]@{
        SchemaVersion = 1
        Status = $status
        WindowsCaption = $caption
        WindowsBuild = $build
        ProductType = $productType
        Architecture = $arch
        PowerShellVersion = $PSVersionTable.PSVersion.ToString()
        WinPE = [bool]$isWinPE
        Notes = $notes.ToArray()
    }
}


function Get-ToolkitLauncherParentProcessId {
    try {
        $proc = Get-CimInstance Win32_Process -Filter ("ProcessId=" + $PID) -ErrorAction Stop
        if ($proc -and [int]$proc.ParentProcessId -gt 0) {
            return [int]$proc.ParentProcessId
        }
    }
    catch {}
    return 0
}

function Test-ToolkitProcessIdAlive {
    param([int]$ProcessId)
    if ($ProcessId -le 0) { return $false }
    try {
        $p = Get-Process -Id $ProcessId -ErrorAction Stop
        return ($null -ne $p)
    }
    catch {
        return $false
    }
}

function Recover-ToolkitStaleSessions {
    param(
        [int]$LegacyGraceMinutes = 5,
        [string]$LogRoot = "",
        [string]$CurrentSessionId = ""
    )

    $logs = $(if([string]::IsNullOrWhiteSpace($LogRoot)){Get-ToolkitLogRoot}else{$LogRoot})
    $currentSessionId = $(if([string]::IsNullOrWhiteSpace($CurrentSessionId)){Get-ToolkitSessionId}else{$CurrentSessionId})
    $now = Get-Date
    $recovered = New-Object System.Collections.Generic.List[object]

    foreach($file in @(Get-ChildItem -LiteralPath $logs -Filter "SESSION_STATE_*.json" -File -ErrorAction SilentlyContinue)) {
        $state = $null
        try {
            $state = Get-Content -LiteralPath $file.FullName -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
        }
        catch {
            continue
        }

        if (-not $state) { continue }
        if ([string]$state.SessionId -eq $currentSessionId) { continue }
        if ([string]$state.Status -ne "ACTIVE") { continue }

        $shouldRecover = $false
        $reason = ""
        $launcherPid = 0
        if ($state.PSObject.Properties["LauncherProcessId"]) {
            try { $launcherPid = [int]$state.LauncherProcessId } catch { $launcherPid = 0 }
        }

        if ($launcherPid -gt 0) {
            if (-not (Test-ToolkitProcessIdAlive -ProcessId $launcherPid)) {
                $shouldRecover = $true
                $reason = "Prior launcher process is no longer running."
            }
        }
        else {
            $referenceTime = $null
            foreach($candidate in @([string]$state.Updated,[string]$state.Started)) {
                if (-not [string]::IsNullOrWhiteSpace($candidate)) {
                    try {
                        $referenceTime = [datetime]$candidate
                        break
                    } catch {}
                }
            }
            if ($referenceTime -and (($now - $referenceTime).TotalMinutes -ge $LegacyGraceMinutes)) {
                $shouldRecover = $true
                $reason = "Legacy ACTIVE session has no launcher PID and exceeded the grace period."
            }
        }

        if (-not $shouldRecover) { continue }

        $interruptedAt = $now.ToString("o")
        $updated = [ordered]@{}
        foreach($prop in $state.PSObject.Properties) {
            $updated[$prop.Name] = $prop.Value
        }
        $updated["Status"] = "INTERRUPTED"
        $updated["Updated"] = $interruptedAt
        $updated["Ended"] = $null
        $updated["InterruptedAt"] = $interruptedAt
        $updated["InterruptedReason"] = $reason
        $updated["DetectedBySessionId"] = $currentSessionId

        try {
            [void](Set-ToolkitAtomicJson -Path $file.FullName -Object $updated -Depth 10)

            $entry = [ordered]@{
                SchemaVersion = 1
                Timestamp = $interruptedAt
                SessionId = [string]$state.SessionId
                Started = [string]$state.Started
                Computer = [string]$state.Computer
                User = [string]$state.User
                LauncherProcessId = $launcherPid
                Reason = $reason
                StatePath = $file.FullName
                DetectedBySessionId = $currentSessionId
            }
            Add-ToolkitJsonLine -Path (Join-Path $logs "INTERRUPTED_SESSIONS.jsonl") -Object $entry
            $recovered.Add([pscustomobject]$entry)
        }
        catch {}
    }

    $script:ToolkitLastRecoveredStaleSessions = $recovered.ToArray()
    return $recovered.ToArray()
}

function Get-ToolkitFieldValidationStatus {
    $path = Join-Path $script:ToolkitRoot "FIELD-VALIDATION-STATUS.txt"
    $result = [ordered]@{
        Status = "UNVALIDATED"
        BuildId = ""
        AutoVerifiedAt = ""
        AutoVerificationResult = ""
        ValidatedAt = ""
        Details = ""
        Path = $path
    }
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
        return [pscustomobject]$result
    }

    try {
        foreach($line in Get-Content -LiteralPath $path -ErrorAction Stop) {
            if ($line -match '^\s*Status\s*:\s*(.+?)\s*$') { $result.Status = $matches[1].Trim() }
            elseif ($line -match '^\s*BuildId\s*:\s*(.+?)\s*$') { $result.BuildId = $matches[1].Trim() }
            elseif ($line -match '^\s*AutoVerifiedAt\s*:\s*(.*?)\s*$') { $result.AutoVerifiedAt = $matches[1].Trim() }
            elseif ($line -match '^\s*AutoVerificationResult\s*:\s*(.*?)\s*$') { $result.AutoVerificationResult = $matches[1].Trim() }
            elseif ($line -match '^\s*ValidatedAt\s*:\s*(.*?)\s*$') { $result.ValidatedAt = $matches[1].Trim() }
            elseif ($line -match '^\s*Details\s*:\s*(.*?)\s*$') { $result.Details = $matches[1].Trim() }
        }
    }
    catch {}
    return [pscustomobject]$result
}

function Set-ToolkitFieldValidationStatus {
    param(
        [ValidateSet("UNVALIDATED","AUTO-VERIFIED","VALIDATED")][string]$Status,
        [string]$BuildId = "",
        [string]$Details = "",
        [string]$AutoVerificationResult = ""
    )

    if ([string]::IsNullOrWhiteSpace($BuildId)) {
        $BuildId = [string](Get-ToolkitBuildIdentity).BuildId
    }

    $existing = Get-ToolkitFieldValidationStatus
    $sameBuild = ([string]$existing.BuildId -eq [string]$BuildId)
    $autoVerifiedAt = ""
    $autoResult = ""
    $validatedAt = ""

    if ($Status -eq "AUTO-VERIFIED") {
        $autoVerifiedAt = (Get-Date).ToString("o")
        $autoResult = $(if([string]::IsNullOrWhiteSpace($AutoVerificationResult)){"PASS"}else{$AutoVerificationResult})
    }
    elseif ($Status -eq "VALIDATED") {
        $validatedAt = (Get-Date).ToString("o")
        if ($sameBuild) {
            $autoVerifiedAt = [string]$existing.AutoVerifiedAt
            $autoResult = [string]$existing.AutoVerificationResult
        }
    }

    $path = Join-Path $script:ToolkitRoot "FIELD-VALIDATION-STATUS.txt"
    $content = @(
        "WINDOWS CMD FIELD TECH TOOLKIT v4 - FIELD VALIDATION STATUS",
        ("Status: " + $Status),
        ("BuildId: " + $BuildId),
        ("AutoVerifiedAt: " + $autoVerifiedAt),
        ("AutoVerificationResult: " + $autoResult),
        ("ValidatedAt: " + $validatedAt),
        ("Details: " + $Details)
    ) -join [Environment]::NewLine

    [void](Set-ToolkitAtomicText -Path $path -Content ($content + [Environment]::NewLine))
    return Get-ToolkitFieldValidationStatus
}


function Sync-ToolkitFieldValidationStatus {
    $build = Get-ToolkitBuildIdentity
    $status = Get-ToolkitFieldValidationStatus
    if ([string]$status.BuildId -ne [string]$build.BuildId) {
        return Set-ToolkitFieldValidationStatus -Status "UNVALIDATED" -BuildId $build.BuildId `
            -Details "Build identity changed; Windows release validation is required for this build."
    }
    return $status
}

function Initialize-ToolkitSessionState {
    $logs = Get-ToolkitLogRoot
    $sessionId = Get-ToolkitSessionId
    [void](Recover-ToolkitStaleSessions)
    $launcherProcessId = Get-ToolkitLauncherParentProcessId
    $path = Join-Path $logs ("SESSION_STATE_" + $sessionId + ".json")
    $existing = $null
    if (Test-Path -LiteralPath $path -PathType Leaf) {
        try { $existing = Get-Content -LiteralPath $path -Raw | ConvertFrom-Json } catch {}
    }
    $state = [ordered]@{
        SchemaVersion = $script:ToolkitStateSchemaVersion
        SessionId = $sessionId
        Computer = $env:COMPUTERNAME
        User = ($env:USERDOMAIN + "\" + $env:USERNAME)
        LauncherProcessId = $launcherProcessId
        Status = "ACTIVE"
        Started = $(if ($existing -and $existing.Started) { [string]$existing.Started } else { (Get-Date).ToString("o") })
        Updated = (Get-Date).ToString("o")
        Ended = $null
        ActiveCaseId = [string](Get-ToolkitCaseContext).CaseId
        PendingRebootAtStart = $(if ($existing -and $null -ne $existing.PendingRebootAtStart) { [bool]$existing.PendingRebootAtStart } else { [bool](Test-ToolkitPendingReboot).Pending })
    }
    [void](Set-ToolkitAtomicJson -Path $path -Object $state)
    return [pscustomobject]$state
}

function Close-ToolkitSessionState {
    $logs = Get-ToolkitLogRoot
    $sessionId = Get-ToolkitSessionId
    $path = Join-Path $logs ("SESSION_STATE_" + $sessionId + ".json")
    $started = ""
    try {
        if (Test-Path -LiteralPath $path) {
            $old = Get-Content -LiteralPath $path -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
            $started = [string]$old.Started
        }
    } catch {}

    $operationCount = 0
    $mutationCount = 0
    foreach ($spec in @(
        @{Path=(Join-Path $logs "OPERATION_LEDGER.jsonl"); Kind="OP"},
        @{Path=(Join-Path $logs "MUTATION_LEDGER.jsonl"); Kind="MUT"}
    )) {
        if (Test-Path -LiteralPath $spec.Path) {
            try {
                $count = 0
                foreach ($line in Get-Content -LiteralPath $spec.Path -ErrorAction Stop) {
                    if ($line -and $line -match [regex]::Escape($sessionId)) { $count++ }
                }
                if ($spec.Kind -eq "OP") { $operationCount = $count } else { $mutationCount = $count }
            } catch {}
        }
    }

    $pending = Test-ToolkitPendingReboot
    $case = Get-ToolkitCaseContext
    $ended = (Get-Date).ToString("o")
    $state = [ordered]@{
        SchemaVersion = $script:ToolkitStateSchemaVersion
        SessionId = $sessionId
        Computer = $env:COMPUTERNAME
        User = ($env:USERDOMAIN + "\" + $env:USERNAME)
        Status = "CLOSED"
        Started = $started
        Updated = $ended
        Ended = $ended
        ActiveCaseId = [string]$case.CaseId
        OperationLedgerEntries = $operationCount
        MutationLedgerEntries = $mutationCount
        PendingRebootAtClose = [bool]$pending.Pending
        PendingRebootReasons = @($pending.Reasons)
    }

    [void](Set-ToolkitAtomicJson -Path $path -Object $state)

    # Read back and verify the persisted state. A closeout is not successful if
    # the file still says ACTIVE or has no Ended timestamp.
    $persisted = $null
    try {
        $persisted = Get-Content -LiteralPath $path -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
    }
    catch {
        throw (New-Object IO.IOException -ArgumentList ("Session closeout state could not be read back: " + $_.Exception.Message),$_.Exception)
    }
    if (-not $persisted -or [string]$persisted.Status -ne "CLOSED" -or [string]::IsNullOrWhiteSpace([string]$persisted.Ended)) {
        throw (New-Object IO.IOException -ArgumentList "Session closeout verification failed: SESSION_STATE did not persist CLOSED with an Ended timestamp.")
    }

    $summary = Join-Path $logs ("SESSION_CLOSEOUT_" + $sessionId + ".txt")
    $lines = @(
        "WINDOWS FIELD TECH TOOLKIT - SESSION CLOSEOUT",
        ("SessionId: " + $sessionId),
        ("Started: " + $started),
        ("Ended: " + $state.Ended),
        ("Computer: " + $env:COMPUTERNAME),
        ("ActiveCaseId: " + [string]$case.CaseId),
        ("Operation ledger entries: " + $operationCount),
        ("Mutation ledger entries: " + $mutationCount),
        ("Pending reboot: " + [string]$pending.Pending),
        ("Pending reboot reasons: " + (@($pending.Reasons) -join "; ")),
        "Session state verification: CLOSED"
    )
    [void](Set-ToolkitAtomicText -Path $summary -Content (($lines -join [Environment]::NewLine) + [Environment]::NewLine))
    return [pscustomobject]$state
}

function Get-ToolkitRuntimeContext {
    $os = $null
    try {
        $os = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop
    }
    catch {
    }

    $pending = Test-ToolkitPendingReboot
    $bitLocker = Get-ToolkitBitLockerContext
    $winRE = Get-ToolkitWinREContext
    $logs = Get-ToolkitLogRoot
    $case = Get-ToolkitCaseContext
    $build = Get-ToolkitBuildIdentity
    $compat = Get-ToolkitCompatibilityAssessment

    return [pscustomobject]@{
        SchemaVersion = 1
        SessionId = Get-ToolkitSessionId
        Timestamp = (Get-Date).ToString("o")
        BuildId = [string]$build.BuildId
        BuildManifestSHA256 = [string]$build.ManifestSHA256
        ToolkitRoot = $script:ToolkitRoot
        LogRoot = $logs
        LogFallbackActive = -not [string]::IsNullOrWhiteSpace($env:FIELDTECH_LOG_FALLBACK)
        ComputerName = $env:COMPUTERNAME
        User = ($env:USERDOMAIN + "\" + $env:USERNAME)
        Administrator = Test-ToolkitAdminContext
        ScreenReaderMode = ($env:SRMODE -eq "1" -or $env:FIELDTECH_SCREEN_READER -eq "1")
        PowerShellVersion = $PSVersionTable.PSVersion.ToString()
        ProcessArchitecture = $env:PROCESSOR_ARCHITECTURE
        WindowsCaption = $(if ($os) { [string]$os.Caption } else { "Unavailable" })
        WindowsVersion = $(if ($os) { [string]$os.Version } else { "Unavailable" })
        WindowsBuild = $(if ($os) { [string]$os.BuildNumber } else { "Unavailable" })
        PendingReboot = [bool]$pending.Pending
        PendingRebootReasons = @($pending.Reasons)
        CaseId = [string]$case.CaseId
        CasePath = [string]$case.CasePath
        Compatibility = $compat
        BitLocker = $bitLocker
        WinRE = $winRE
        Capabilities = @(Get-ToolkitCapabilitySnapshot)
    }
}

function Initialize-ToolkitRuntimeContext {
    $context = Get-ToolkitRuntimeContext
    $logs = [string]$context.LogRoot
    $path = Join-Path $logs ("TOOLKIT_RUNTIME_CONTEXT_" + $context.SessionId + ".json")

    try {
        [void](Set-ToolkitAtomicJson -Path $path -Object $context -Depth 8)
    }
    catch {
    }

    if ($context.LogFallbackActive) {
        Write-Host ("NOTICE: Toolkit log fallback is active. Logs are being written to: " + $logs)
    }

    return $context
}

function New-ToolkitResult {
    param(
        [Parameter(Mandatory=$true)]
        [ValidateSet("SUCCESS","FAILED","UNSUPPORTED","CANCELED","PARTIAL","REBOOT_REQUIRED","TIMED_OUT")]
        [string]$Status,

        [Parameter(Mandatory=$true)]
        [string]$Operation,

        [int]$ExitCode = 0,
        [string]$Details = "",
        [string]$LogPath = ""
    )

    return [pscustomobject]@{
        SchemaVersion = $script:ToolkitOperationSchemaVersion
        Status = $Status
        Operation = $Operation
        ExitCode = $ExitCode
        Details = $Details
        LogPath = $LogPath
        Timestamp = (Get-Date).ToString("o")
        SessionId = Get-ToolkitSessionId
    }
}

function Write-ToolkitResult {
    param(
        [Parameter(Mandatory=$true)]$Result
    )

    Write-Host ("Result [" + $Result.Status + "]: " + $Result.Operation)
    if (-not [string]::IsNullOrWhiteSpace([string]$Result.Details)) {
        Write-Host ("  " + $Result.Details)
    }
    if (-not [string]::IsNullOrWhiteSpace([string]$Result.LogPath)) {
        Write-Host ("  Log: " + $Result.LogPath)
    }
}

function ConvertTo-ToolkitResultState {
    param([Parameter(Mandatory=$true)][string]$Status)

    if ($Status -match '(?i)(TIMEOUT|TIMED_OUT)') { return "TIMED_OUT" }
    if ($Status -match '(?i)(PENDING_REBOOT|REBOOT_REQUIRED)') { return "REBOOT_REQUIRED" }
    if ($Status -match '(?i)(CANCELED|CANCELLED)') { return "CANCELED" }
    if ($Status -match '(?i)(UNSUPPORTED|UNAVAILABLE|NOT_APPLICABLE)') { return "UNSUPPORTED" }
    if ($Status -match '(?i)(FAILED|FAILURE|ERROR)') { return "FAILED" }
    if ($Status -match '(?i)(PARTIAL|WARNING|WARNINGS)') { return "PARTIAL" }
    if ($Status -match '(?i)(VERIFIED|SUCCESS|COMPLETED)$') { return "SUCCESS" }
    return ""
}

function Write-ToolkitOperationLedger {
    param(
        [Parameter(Mandatory=$true)][string]$Action,
        [Parameter(Mandatory=$true)][string]$Event,
        [string]$OperationId = "",
        [string]$Details = ""
    )

    try {
        $logs = Get-ToolkitLogRoot
        $ledger = Join-Path $logs "OPERATION_LEDGER.jsonl"
        if ([string]::IsNullOrWhiteSpace($OperationId)) {
            $OperationId = [guid]::NewGuid().ToString("N")
        }

        $case = Get-ToolkitCaseContext
        $resultState = ConvertTo-ToolkitResultState -Status $Event
        $entry = [ordered]@{
            SchemaVersion = $script:ToolkitOperationSchemaVersion
            Timestamp = (Get-Date).ToString("o")
            SessionId = Get-ToolkitSessionId
            OperationId = $OperationId
            CaseId = [string]$case.CaseId
            ToolId = [string]$env:FIELDTECH_TOOL_ID
            ResultState = $resultState
            Computer = $env:COMPUTERNAME
            User = ($env:USERDOMAIN + "\" + $env:USERNAME)
            Action = $Action
            Event = $Event
            Details = ($Details -replace "[\r\n]+"," ")
        }

        Add-ToolkitJsonLine -Path $ledger -Object $entry
    }
    catch {
    }
}

function Write-ToolkitMutationLedger {
    param(
        [Parameter(Mandatory=$true)][string]$Action,
        [Parameter(Mandatory=$true)][string]$Event,
        [string]$OperationId = "",
        [string]$Details = ""
    )

    try {
        $logs = Get-ToolkitLogRoot
        $ledger = Join-Path $logs "MUTATION_LEDGER.jsonl"
        if ([string]::IsNullOrWhiteSpace($OperationId)) {
            $OperationId = [guid]::NewGuid().ToString("N")
        }

        $case = Get-ToolkitCaseContext
        $resultState = ConvertTo-ToolkitResultState -Status $Event
        $entry = [ordered]@{
            SchemaVersion = $script:ToolkitOperationSchemaVersion
            Timestamp = (Get-Date).ToString("o")
            SessionId = Get-ToolkitSessionId
            OperationId = $OperationId
            CaseId = [string]$case.CaseId
            ToolId = [string]$env:FIELDTECH_TOOL_ID
            ResultState = $resultState
            Computer = $env:COMPUTERNAME
            User = ($env:USERDOMAIN + "\" + $env:USERNAME)
            Action = $Action
            Event = $Event
            Details = ($Details -replace "[\r\n]+"," ")
        }

        Add-ToolkitJsonLine -Path $ledger -Object $entry
    }
    catch {
    }
}

function Invoke-ToolkitPowerShellOperation {
    param(
        [Parameter(Mandatory=$true)][string]$Label,
        [Parameter(Mandatory=$true)][scriptblock]$ScriptBlock,
        [string]$Action = "PowerShell Operation",
        [switch]$Mutation,
        [int]$TimeoutSeconds = 0,
        [switch]$Quiet
    )

    $operationId = [guid]::NewGuid().ToString("N")
    $start = Get-Date
    if ($Mutation) {
        Write-ToolkitMutationLedger -Action $Action -Event "POWERSHELL_START" -OperationId $operationId -Details ("Label=" + $Label)
    }

    $status = "FAILED"; $details = ""; $output = @(); $errorText = ""
    try {
        if ($TimeoutSeconds -gt 0) {
            # Timeout mode uses an isolated background job. Callers must use a
            # self-contained script block because local scope/closures are not preserved.
            $job = Start-Job -ScriptBlock $ScriptBlock
            if (Wait-Job -Job $job -Timeout $TimeoutSeconds) {
                $output = @(Receive-Job -Job $job -ErrorAction SilentlyContinue)
                $status = $(if ($job.State -eq "Completed") { "SUCCESS" } else { "FAILED" })
            }
            else {
                Stop-Job -Job $job -ErrorAction SilentlyContinue
                $status = "TIMED_OUT"
                $details = "Timed out after " + $TimeoutSeconds + " seconds."
            }
            Remove-Job -Job $job -Force -ErrorAction SilentlyContinue
        }
        else {
            $output = @(& $ScriptBlock)
            $status = "SUCCESS"
        }
    }
    catch [System.Management.Automation.PipelineStoppedException] {
        $status = "CANCELED"; $details = "Operation canceled by the PowerShell host."
    }
    catch {
        $status = "FAILED"; $errorText = $_.Exception.Message; $details = $errorText
    }

    $duration = [math]::Round(((Get-Date)-$start).TotalSeconds,2)
    if (-not $details) { $details = "DurationSeconds=" + $duration }
    else { $details += "; DurationSeconds=" + $duration }

    $result = New-ToolkitResult -Status $status -Operation $Label -ExitCode $(if ($status -eq "SUCCESS") {0} elseif ($status -eq "TIMED_OUT") {124} elseif ($status -eq "CANCELED") {125} else {1}) -Details $details
    $result | Add-Member -NotePropertyName Output -NotePropertyValue @($output)
    $result | Add-Member -NotePropertyName DurationSeconds -NotePropertyValue $duration

    if ($Mutation) {
        Write-ToolkitMutationLedger -Action $Action -Event ("POWERSHELL_" + $status) -OperationId $operationId -Details $details
    }
    if (-not $Quiet) { Write-ToolkitResult $result }
    return $result
}

function Invoke-ToolkitNativeCommand {
    param(
        [Parameter(Mandatory=$true)][string]$FilePath,
        [string[]]$Arguments = @(),
        [Parameter(Mandatory=$true)][string]$Label,
        [string]$Action = "Native Command",
        [switch]$Mutation,
        [int[]]$RebootExitCodes = @(3010,1641),
        [ValidateRange(0,2147483)][int]$TimeoutSeconds = 0,
        [string]$LogPath = "",
        [switch]$Quiet
    )

    if ($TimeoutSeconds -le 0 -and $env:FIELDTECH_TOOL_TIMEOUT_SECONDS -match '^\d+$') {
        $TimeoutSeconds = [int]$env:FIELDTECH_TOOL_TIMEOUT_SECONDS
    }

    $command = Get-Command $FilePath -ErrorAction SilentlyContinue
    if (-not $command) {
        $result = New-ToolkitResult -Status "UNSUPPORTED" -Operation $Label -ExitCode 127 -Details ($FilePath + " was not found.") -LogPath $LogPath
        if (-not $Quiet) { Write-ToolkitResult $result }
        return $result
    }

    if ([string]::IsNullOrWhiteSpace($LogPath)) {
        $safe = ($Label -replace '[^A-Za-z0-9_.-]+','_').Trim('_')
        $LogPath = Join-Path (Get-ToolkitLogRoot) ("NATIVE_" + $safe + "_" + (Get-Date -Format "yyyyMMdd_HHmmssfff") + ".txt")
    }

    $operationId = [guid]::NewGuid().ToString("N")
    if ($Mutation) {
        Write-ToolkitMutationLedger -Action $Action -Event "NATIVE_START" -OperationId $operationId -Details ("Label=" + $Label + "; File=" + $FilePath + "; Arguments=" + ($Arguments -join " "))
    }

    $start = Get-Date
    $outputLines = New-Object System.Collections.Generic.List[string]
    $exitCode = 1
    $launchError = ""
    $timedOut = $false
    $canceled = $false
    $process = $null

    try {
        $psi = New-Object System.Diagnostics.ProcessStartInfo
        $resolvedPath = ""
        try { $resolvedPath = [string]$command.Path } catch {}
        if ([string]::IsNullOrWhiteSpace($resolvedPath)) {
            try { $resolvedPath = [string]$command.Source } catch {}
        }
        if ([string]::IsNullOrWhiteSpace($resolvedPath)) {
            $resolvedPath = $FilePath
        }
        $psi.FileName = $resolvedPath

        # Windows PowerShell 5.1 lacks ProcessStartInfo.ArgumentList. Quote each
        # argument for CreateProcess while avoiding cmd.exe interpolation.
        $quotedArgs = foreach ($arg in $Arguments) {
            $value = [string]$arg
            if ($value -match '[\s"]') {
                '"' + ($value -replace '(\\*)"', '$1$1\"' -replace '(\\+)$', '$1$1') + '"'
            }
            else {
                $value
            }
        }
        $psi.Arguments = ($quotedArgs -join " ")
        $psi.UseShellExecute = $false
        $psi.RedirectStandardOutput = $true
        $psi.RedirectStandardError = $true
        $psi.CreateNoWindow = $true

        $process = New-Object System.Diagnostics.Process
        $process.StartInfo = $psi

        [void]$process.Start()
        $stdoutTask = $process.StandardOutput.ReadToEndAsync()
        $stderrTask = $process.StandardError.ReadToEndAsync()

        # Poll instead of sitting silently in WaitForExit. This gives every
        # native-command-backed tool a common progress heartbeat without
        # changing command semantics or requiring each tool to implement its
        # own timer. Quick commands remain quiet.
        $statusAfterSeconds = 5
        $statusIntervalSeconds = 10
        $nextStatusSeconds = $statusAfterSeconds
        $statusAnnounced = $false

        while (-not $process.HasExited) {
            Start-Sleep -Milliseconds 250
            $elapsedSeconds = [int][math]::Floor(((Get-Date) - $start).TotalSeconds)

            if ($elapsedSeconds -ge $nextStatusSeconds) {
                Write-ToolkitStatus ($Label + " is still running. Elapsed: " + $elapsedSeconds + " seconds.")
                $statusAnnounced = $true
                $nextStatusSeconds += $statusIntervalSeconds
            }

            if ($TimeoutSeconds -gt 0 -and $elapsedSeconds -ge $TimeoutSeconds) {
                $timedOut = $true
                Write-ToolkitStatus ($Label + " reached the toolkit timeout of " + $TimeoutSeconds + " seconds. Stopping the process.")
                try { $process.Kill() } catch {}
                break
            }
        }

        try { $process.WaitForExit() } catch {}

        $stdout = $stdoutTask.Result
        $stderr = $stderrTask.Result
        if (-not $timedOut) {
            $exitCode = $process.ExitCode
        }
        else {
            $exitCode = 124
            $outputLines.Add("Toolkit timeout: process exceeded " + $TimeoutSeconds + " seconds and was terminated.")
        }

        foreach ($line in @($stdout -split "\r?\n")) {
            if (-not [string]::IsNullOrWhiteSpace($line)) {
                $outputLines.Add($line)
            }
        }
        foreach ($line in @($stderr -split "\r?\n")) {
            if (-not [string]::IsNullOrWhiteSpace($line)) {
                $outputLines.Add($line)
            }
        }
    }
    catch [System.Management.Automation.PipelineStoppedException] {
        $canceled = $true
        try { if ($process -and -not $process.HasExited) { $process.Kill() } } catch {}
        $launchError = "Operation canceled by PowerShell host."
        $outputLines.Add($launchError)
        $exitCode = 125
    }
    catch {
        try { if ($process -and -not $process.HasExited) { $process.Kill() } } catch {}
        $launchError = $_.Exception.Message
        $outputLines.Add("Launch error: " + $launchError)
        $exitCode = 1
    }

    $end = Get-Date
    $duration = [math]::Round(($end - $start).TotalSeconds,2)

    if ($statusAnnounced -and -not $timedOut) {
        Write-ToolkitStatus ($Label + " completed after " + $duration + " seconds.")
    }

    $caseContext = Get-ToolkitCaseContext
    $logHeader = @(
        "WINDOWS FIELD TECH TOOLKIT - NATIVE COMMAND",
        ("Label: " + $Label),
        ("Action: " + $Action),
        ("SessionId: " + (Get-ToolkitSessionId)),
        ("OperationId: " + $operationId),
        ("CaseId: " + [string]$caseContext.CaseId),
        ("Started: " + $start.ToString("o")),
        ("Ended: " + $end.ToString("o")),
        ("DurationSeconds: " + $duration),
        ("File: " + $FilePath),
        ("Arguments: " + ($Arguments -join " ")),
        ("ExitCode: " + $exitCode),
        ("TimeoutSeconds: " + $TimeoutSeconds),
        ("TimedOut: " + $timedOut),
        ("Canceled: " + $canceled),
        ""
    )

    try {
        $logText = (($logHeader + $outputLines.ToArray()) -join [Environment]::NewLine) + [Environment]::NewLine
        [void](Set-ToolkitAtomicText -Path $LogPath -Content $logText -Encoding UTF8)
    }
    catch {
    }

    if (-not $Quiet) {
        $outputLines | ForEach-Object { Write-Host $_ }
    }

    $rebootTextClue = (($outputLines -join [Environment]::NewLine) -match '(?i)restart.*required|reboot.*required')
    $status = "FAILED"
    if ($timedOut) {
        $status = "TIMED_OUT"
    }
    elseif ($canceled) {
        $status = "CANCELED"
    }
    elseif (($RebootExitCodes -contains $exitCode) -or ($exitCode -eq 0 -and $rebootTextClue)) {
        $status = "REBOOT_REQUIRED"
    }
    elseif ($exitCode -eq 0) {
        $status = "SUCCESS"
    }

    $details = "ExitCode=" + $exitCode + "; DurationSeconds=" + $duration + "; TimeoutSeconds=" + $TimeoutSeconds + "; RebootClue=" + $rebootTextClue
    if ($launchError) {
        $details += "; Error=" + $launchError
    }

    $result = New-ToolkitResult -Status $status -Operation $Label -ExitCode $exitCode -Details $details -LogPath $LogPath

    if ($Mutation) {
        Write-ToolkitMutationLedger -Action $Action -Event ("NATIVE_" + $status) -OperationId $operationId -Details $details
    }

    if (-not $Quiet) {
        Write-ToolkitResult $result
    }

    # Preserve captured output for callers that need semantic verification.
    $result | Add-Member -NotePropertyName Output -NotePropertyValue $outputLines.ToArray()
    $result | Add-Member -NotePropertyName DurationSeconds -NotePropertyValue $duration
    $result | Add-Member -NotePropertyName RebootRequired -NotePropertyValue ($status -eq "REBOOT_REQUIRED")
    return $result
}

function Get-ToolkitActiveOperationRoot {
    $path = Join-Path (Get-ToolkitLogRoot) "_ACTIVE_REPAIR_PROCESSES"
    if (-not (Test-Path -LiteralPath $path)) {
        New-Item -ItemType Directory -Path $path -Force -ErrorAction SilentlyContinue | Out-Null
    }
    return $path
}

function Get-ToolkitInterruptedOperations {
    $root = Get-ToolkitActiveOperationRoot
    [void](Get-ToolkitSessionId)
    $items = New-Object System.Collections.Generic.List[object]

    foreach ($file in Get-ChildItem -LiteralPath $root -Filter "*.json" -File -ErrorAction SilentlyContinue) {
        try {
            $entry = Get-Content -LiteralPath $file.FullName -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
            $isLiveProcess = $false

            try {
                $process = Get-Process -Id ([int]$entry.ProcessId) -ErrorAction Stop
                $startText = $process.StartTime.ToString("o")
                $pathText = ""
                try { $pathText = [string]$process.Path } catch {}
                $nameText = [string]$process.ProcessName
                $sessionText = [string]$process.SessionId

                $startMatches = $startText -eq [string]$entry.ProcessStartTime
                $pathMatches = (
                    [string]::IsNullOrWhiteSpace([string]$entry.ProcessPath) -or
                    [string]::IsNullOrWhiteSpace($pathText) -or
                    $pathText -ieq [string]$entry.ProcessPath
                )
                $nameMatches = (
                    [string]::IsNullOrWhiteSpace([string]$entry.ProcessName) -or
                    $nameText -ieq [string]$entry.ProcessName
                )
                $sessionMatches = (
                    [string]::IsNullOrWhiteSpace([string]$entry.ProcessSessionId) -or
                    $sessionText -eq [string]$entry.ProcessSessionId
                )

                if ($startMatches -and $pathMatches -and $nameMatches -and $sessionMatches) {
                    $isLiveProcess = $true
                }
            }
            catch {
            }

            if (-not $isLiveProcess) {
                $items.Add([pscustomobject]@{
                    MarkerPath = $file.FullName
                    MarkerNonce = [string]$entry.MarkerNonce
                    SessionId = [string]$entry.SessionId
                    ProcessId = [int]$entry.ProcessId
                    ProcessName = [string]$entry.ProcessName
                    ProcessPath = [string]$entry.ProcessPath
                    ProcessSessionId = [string]$entry.ProcessSessionId
                    Script = [string]$entry.Script
                    Started = [string]$entry.Started
                    ProcessStartTime = [string]$entry.ProcessStartTime
                })
            }
        }
        catch {
        }
    }

    return $items.ToArray()
}

function Initialize-ToolkitRepairProcess {
    param([string]$CallerScript = "")

    $interrupted = @(Get-ToolkitInterruptedOperations)
    if ($interrupted.Count -gt 0) {
        Write-Host ""
        Write-Host "ATTENTION: An earlier repair process did not record a clean exit."
        foreach ($item in $interrupted) {
            Write-Host ("  Script: " + $item.Script + " | Started: " + $item.Started)
            try {
                $alertPath = Join-Path (Get-ToolkitLogRoot) "INTERRUPTED_REPAIR_ALERTS.txt"
                ("{0} | PriorSession={1} | PID={2} | Script={3} | Started={4}" -f `
                    (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $item.SessionId, $item.ProcessId, $item.Script, $item.Started) |
                    Add-Content -LiteralPath $alertPath -Encoding UTF8
                Remove-Item -LiteralPath $item.MarkerPath -Force -ErrorAction SilentlyContinue
            }
            catch {
            }
        }
        Write-Host "Review the repair journal and mutation ledger before making additional changes."
        Write-Host ""
    }

    $root = Get-ToolkitActiveOperationRoot
    $session = Get-ToolkitSessionId
    $safeScript = $(if ($CallerScript) { Split-Path $CallerScript -Leaf } else { "UnknownRepairScript.ps1" })
    $marker = Join-Path $root ($session + "_" + $PID + "_" + ($safeScript -replace '[^A-Za-z0-9_.-]','_') + ".json")

    $processStart = ""
    $processName = ""
    $processPath = ""
    $processSessionId = ""
    try {
        $selfProcess = Get-Process -Id $PID -ErrorAction Stop
        $processStart = $selfProcess.StartTime.ToString("o")
        $processName = [string]$selfProcess.ProcessName
        $processSessionId = [string]$selfProcess.SessionId
        try { $processPath = [string]$selfProcess.Path } catch {}
    }
    catch {
        $processStart = (Get-Date).ToString("o")
    }

    $entry = [ordered]@{
        SchemaVersion = $script:ToolkitStateSchemaVersion
        MarkerNonce = [guid]::NewGuid().ToString("N")
        SessionId = $session
        ProcessId = $PID
        ProcessName = $processName
        ProcessPath = $processPath
        ProcessSessionId = $processSessionId
        ProcessStartTime = $processStart
        Script = $CallerScript
        Started = (Get-Date).ToString("o")
    }

    try {
        [void](Set-ToolkitAtomicJson -Path $marker -Object $entry -Depth 6)
        $script:ToolkitRepairProcessMarkerPath = $marker

        Register-EngineEvent -SourceIdentifier PowerShell.Exiting -MessageData $marker -Action {
            $path = [string]$Event.MessageData
            if ($path -and (Test-Path -LiteralPath $path)) {
                Remove-Item -LiteralPath $path -Force -ErrorAction SilentlyContinue
            }
        } | Out-Null
    }
    catch {
    }

    return $marker
}

function Complete-ToolkitRepairProcess {
    if ($script:ToolkitRepairProcessMarkerPath -and (Test-Path -LiteralPath $script:ToolkitRepairProcessMarkerPath)) {
        Remove-Item -LiteralPath $script:ToolkitRepairProcessMarkerPath -Force -ErrorAction SilentlyContinue
    }
}

# Shared read-only diagnostic evidence/classification layer.
# PowerShell 5.1 compatible. This helper does not mutate Windows state.

$script:ToolkitDiagnosticSchemaVersion = "1.0"
$script:ToolkitDiagnosticClassifierVersion = "4.1.0"

function Get-ToolkitDiagnosticSchemaVersion {
    return $script:ToolkitDiagnosticSchemaVersion
}

function Get-ToolkitDiagnosticClassifierVersion {
    return $script:ToolkitDiagnosticClassifierVersion
}

function Get-ToolkitConfidenceLabel {
    param(
        [ValidateSet("Confirmed","Likely","Possible","Context","Unknown")]
        [string]$Level = "Unknown"
    )
    return $Level.ToUpperInvariant()
}

function Get-ToolkitEvidenceId {
    param(
        [Parameter(Mandatory=$true)][string]$Category,
        [string]$Source = "",
        [string]$EventId = "",
        [datetime]$Timestamp = [datetime]::MinValue,
        [string]$Device = "",
        [string]$Evidence = ""
    )

    $timeText = ""
    if ($Timestamp -ne [datetime]::MinValue) {
        $timeText = $Timestamp.ToUniversalTime().ToString("o")
    }
    $material = $Category.Trim() + "|" + $Source.Trim() + "|" + $EventId.Trim() + "|" +
        $timeText + "|" + $Device.Trim() + "|" + $Evidence.Trim()

    $bytes = [Text.Encoding]::UTF8.GetBytes($material)
    $sha = [Security.Cryptography.SHA256]::Create()
    try {
        $hash = $sha.ComputeHash($bytes)
    }
    finally {
        $sha.Dispose()
    }
    return ([BitConverter]::ToString($hash).Replace("-","").Substring(0,24))
}

function New-ToolkitDiagnosticFinding {
    param(
        [Parameter(Mandatory=$true)][string]$Severity,
        [Parameter(Mandatory=$true)][string]$Category,
        [Parameter(Mandatory=$true)][string]$Evidence,
        [ValidateSet("Confirmed","Likely","Possible","Context","Unknown")]
        [string]$Confidence = "Unknown",
        [string]$Device = "",
        [datetime]$EventTimestamp = [datetime]::MinValue,
        [datetime]$ArtifactTimestamp = [datetime]::MinValue,
        [datetime]$ObservedAt = (Get-Date),
        [string]$Action = "",
        [string]$SourceTool = "",
        [string]$Source = "",
        [string]$EventId = ""
    )

    $evidenceId = Get-ToolkitEvidenceId -Category $Category -Source $Source -EventId $EventId `
        -Timestamp $EventTimestamp -Device $Device -Evidence $Evidence

    return [pscustomobject]@{
        SchemaVersion = $script:ToolkitDiagnosticSchemaVersion
        ClassifierVersion = $script:ToolkitDiagnosticClassifierVersion
        EvidenceId = $evidenceId
        Severity = $Severity
        Category = $Category
        Confidence = (Get-ToolkitConfidenceLabel -Level $Confidence)
        Evidence = $Evidence
        Device = $Device
        EventTimestamp = $(if($EventTimestamp -ne [datetime]::MinValue){$EventTimestamp}else{$null})
        ArtifactTimestamp = $(if($ArtifactTimestamp -ne [datetime]::MinValue){$ArtifactTimestamp}else{$null})
        ObservedAt = $ObservedAt
        Action = $Action
        SourceTool = $SourceTool
        Source = $Source
        EventId = $EventId
    }
}

function Get-ToolkitDiskContext {
    param(
        [string]$Message,
        [hashtable]$DiskMap
    )

    $diskNumber = $null
    if ([string]$Message -match '(?i)\\Device\\Harddisk(\d+)') {
        $diskNumber = [int]$matches[1]
    }

    if ($null -eq $diskNumber) {
        return [pscustomobject]@{
            DiskNumber=""
            Class="UNMAPPED"
            Name="Unmapped"
            BusType=""
            OperationalStatus=""
            SizeGB=$null
            Description="Unmapped storage event"
        }
    }

    if (-not $DiskMap -or -not $DiskMap.ContainsKey($diskNumber)) {
        return [pscustomobject]@{
            DiskNumber=$diskNumber
            Class="UNMAPPED"
            Name="Unmapped"
            BusType=""
            OperationalStatus=""
            SizeGB=$null
            Description=("Harddisk"+$diskNumber+" not present in current Get-Disk inventory")
        }
    }

    $d = $DiskMap[$diskNumber]
    $bus = [string]$d.BusType
    $op = ([string[]]$d.OperationalStatus -join ", ")
    $sizeGB = [math]::Round([double]$d.Size/1GB,2)
    $class = "INTERNAL / FIXED"
    if ([double]$d.Size -le 0 -or $op -match '(?i)No Media' -or $bus -match '(?i)USB|SD|MMC') {
        $class = "REMOVABLE / NO-MEDIA"
    }

    return [pscustomobject]@{
        DiskNumber=$diskNumber
        Class=$class
        Name=[string]$d.FriendlyName
        BusType=$bus
        OperationalStatus=$op
        SizeGB=$sizeGB
        Description=("Disk "+$diskNumber+" "+$d.FriendlyName+" | "+$bus+" | "+$op+" | "+$sizeGB+" GB")
    }
}

function Get-ToolkitSystemEventClassification {
    param(
        [string]$ProviderName,
        [int]$EventId,
        [int]$Level,
        [string]$Message,
        [hashtable]$DiskMap
    )

    $class = ""
    $isAnchor = $false
    $confidence = "Context"
    $deviceContext = ""
    $category = ""

    if ($ProviderName -match '(?i)WHEA' -and $Level -in 1,2,3) {
        $class="Hardware / WHEA"; $isAnchor=$true; $confidence="Confirmed"; $category="Hardware"
    }
    elseif ($ProviderName -match '(?i)^(disk|stornvme|storahci|iaStor|iaStorA|Ntfs|volmgr|partmgr)$' -and
            ($Level -in 1,2,3 -or $EventId -in 7,11,15,51,55,129,153,157,158)) {
        $dc = Get-ToolkitDiskContext -Message $Message -DiskMap $DiskMap
        $deviceContext = $dc.Description
        $category="Storage"
        $class="Storage warning/error"
        $isAnchor=$true
        $confidence="Confirmed"
        if ($dc.Class -eq "REMOVABLE / NO-MEDIA") {
            $class="Removable storage context"
            $isAnchor=$false
            $confidence="Context"
        }
        elseif ($dc.Class -eq "UNMAPPED") {
            $class="Unmapped storage warning/error"
            $confidence="Possible"
        }
        if ($EventId -eq 158) {
            $isAnchor=$false
            $confidence="Context"
        }
    }
    elseif (($ProviderName -match '(?i)Kernel-Power' -and $EventId -eq 41) -or $EventId -eq 6008) {
        $class="Unexpected shutdown / power"; $isAnchor=$true; $confidence="Confirmed"; $category="Power"
    }
    elseif ($ProviderName -match '(?i)BugCheck' -and $EventId -eq 1001) {
        $class="Bugcheck"; $isAnchor=$true; $confidence="Confirmed"; $category="Crash"
    }
    elseif ($ProviderName -match '(?i)(Display|nvlddmkm|amdkmdag)' -and ($Level -in 1,2,3 -or $EventId -eq 4101)) {
        $class="Graphics / display"; $isAnchor=$true; $confidence="Likely"; $category="Graphics"
    }
    elseif (($ProviderName -match '(?i)Kernel-Power' -and $EventId -in 42,107,506,507) -or
            ($ProviderName -match '(?i)Power-Troubleshooter' -and $EventId -eq 1)) {
        $class="Power / resume context"; $isAnchor=$false; $confidence="Context"; $category="Power"
    }
    elseif ($Level -in 1,2,3) {
        $class="System warning/error"; $isAnchor=$false; $confidence="Context"; $category="System"
    }

    return [pscustomobject]@{
        Class=$class
        Category=$category
        IsAnchor=$isAnchor
        Confidence=(Get-ToolkitConfidenceLabel -Level $confidence)
        DeviceContext=$deviceContext
    }
}

function Get-ToolkitWerClassification {
    param(
        [string]$Message,
        [datetime]$EventTime,
        [datetime]$LookbackStart,
        [string]$FallbackId = ""
    )

    $eventName=""
    if ($Message -match '(?is)Event Name:\s*([^\r\n]+?)\s+Response:') {
        $eventName=$matches[1].Trim()
    }

    $reportId=""
    if ($Message -match '(?i)Report Id:\s*([0-9a-f-]{8,})') {
        $reportId=$matches[1]
    }

    $dumpName=""
    $artifactTimestamp=[datetime]::MinValue
    if ($Message -match '(?i)(WATCHDOG-(\d{8})-\d+\.dmp)') {
        $dumpName=$matches[1]
        try { $artifactTimestamp=[datetime]::ParseExact($matches[2],"yyyyMMdd",$null) } catch {}
    }

    $class="WER diagnostic context"
    $category="WER"
    $isAnchor=$false
    $confidence="Context"
    $incidentKey="WERCTX|"+$(if($reportId){$reportId}else{$FallbackId})

    if ($eventName -match '(?i)^LiveKernelEvent$') {
        $historical=($artifactTimestamp -ne [datetime]::MinValue -and $artifactTimestamp -lt $LookbackStart.Date)
        if ($historical) {
            $class="Historical WER replay"
            $isAnchor=$false
            $confidence="Context"
        }
        else {
            $class="LiveKernelEvent"
            $isAnchor=$true
            $confidence="Likely"
        }
        $category="Kernel"
        $incidentKey=$(if($dumpName){"LIVEKERNEL|"+$dumpName}else{"LIVEKERNEL|"+$reportId})
    }
    elseif ($eventName -match '(?i)StoreAgentInstallFailure|Update' -or $Message -match '(?i)StoreAgentInstallFailure') {
        $class="Update / install failure"; $category="Update"; $isAnchor=$false; $confidence="Confirmed"
        $incidentKey="UPDATEFAIL|"+$(if($reportId){$reportId}else{$FallbackId})
    }
    elseif ($eventName -match '(?i)RADAR_PRE_LEAK') {
        $class="Resource / leak diagnostic"; $category="Resource"; $isAnchor=$false; $confidence="Context"
        $incidentKey="RADAR|"+$eventName+"|"+$EventTime.ToString("yyyyMMddHHmm")
    }
    elseif ($eventName -match '(?i)MoAppHang|AppHang') {
        $class="Application hang"; $category="Application"; $isAnchor=$true; $confidence="Confirmed"
        $incidentKey="WERHANG|"+$eventName+"|"+$EventTime.ToString("yyyyMMddHHmmss")
    }
    elseif ($eventName -match '(?i)APPCRASH|BEX') {
        $class="Application crash"; $category="Application"; $isAnchor=$true; $confidence="Confirmed"
        $incidentKey="WERCRASH|"+$eventName+"|"+$EventTime.ToString("yyyyMMddHHmmss")
    }

    return [pscustomobject]@{
        Class=$class
        Category=$category
        IsAnchor=$isAnchor
        Confidence=(Get-ToolkitConfidenceLabel -Level $confidence)
        IncidentKey=$incidentKey
        EventName=$eventName
        ReportId=$reportId
        DumpName=$dumpName
        ArtifactTimestamp=$(if($artifactTimestamp -ne [datetime]::MinValue){$artifactTimestamp}else{$null})
    }
}

function New-ToolkitReportMetadata {
    param(
        [Parameter(Mandatory=$true)][string]$ToolkitRoot,
        [string]$ToolId = $env:FIELDTECH_TOOL_ID,
        [string]$Title = ""
    )

    $versionPath = Join-Path $ToolkitRoot "00_Common\Toolkit-Version.json"
    $version = $null
    try { $version = Get-Content -LiteralPath $versionPath -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop } catch {}

    $manifestPath = Join-Path $ToolkitRoot "26_Tools\KnownGood\Toolkit-Core-Manifest.json"
    $buildId = ""
    if (Test-Path -LiteralPath $manifestPath -PathType Leaf) {
        try { $buildId=(Get-FileHash -LiteralPath $manifestPath -Algorithm SHA256 -ErrorAction Stop).Hash } catch {}
    }

    return [pscustomobject]@{
        ReportSchemaVersion = $(if($version){[string]$version.ReportSchemaVersion}else{"1.0"})
        ToolkitVersion = $(if($version){[string]$version.DisplayVersion}else{"v4"})
        ReleaseLine = $(if($version){[string]$version.ReleaseLine}else{"Shared Diagnostic Engine"})
        ToolId = $ToolId
        Title = $Title
        ToolkitBuildId = $buildId
        SessionId = $env:FIELDTECH_SESSION_ID
        GeneratedAt = (Get-Date)
        Computer = $env:COMPUTERNAME
    }
}

function Write-ToolkitDiagnosticSidecar {
    param(
        [Parameter(Mandatory=$true)][string]$BasePath,
        [Parameter(Mandatory=$true)][string]$ToolkitRoot,
        [string]$ToolId = $env:FIELDTECH_TOOL_ID,
        [string]$Title = "",
        [object[]]$Findings = @(),
        [object[]]$Evidence = @(),
        [object[]]$Capabilities = @()
    )

    $meta = New-ToolkitReportMetadata -ToolkitRoot $ToolkitRoot -ToolId $ToolId -Title $Title
    $payload = [pscustomobject]@{
        Report = $meta
        DiagnosticSchemaVersion = $script:ToolkitDiagnosticSchemaVersion
        ClassifierVersion = $script:ToolkitDiagnosticClassifierVersion
        ConfidenceVocabulary = @("CONFIRMED","LIKELY","POSSIBLE","CONTEXT","UNKNOWN")
        CapabilityFailureVocabulary = @("Not Supported","Driver/API Did Not Expose","Requires Elevation","Not Applicable","Query/API Failed","Unknown/Indeterminate")
        Findings = @($Findings)
        Evidence = @($Evidence)
        Capabilities = @($Capabilities)
    }

    $json = $payload | ConvertTo-Json -Depth 10
    $utf8 = New-Object Text.UTF8Encoding($false)
    [IO.File]::WriteAllText(($BasePath + ".evidence.json"),$json + [Environment]::NewLine,$utf8)

    $defaultLogRoot=Join-Path $ToolkitRoot "Logs"
    if(Test-Path -LiteralPath $defaultLogRoot -PathType Container){
        [void](Update-ToolkitEvidenceCorrelationIndex -LogRoot $defaultLogRoot)
    }
}


function Get-ToolkitCapabilityFailureClassification {
    param(
        [string]$ExceptionMessage = "",
        [string]$Context = "",
        [switch]$NoData,
        [switch]$NotApplicable,
        [string]$NotApplicableReason = "",
        [switch]$KnownDriverOrApiNotExposed
    )

    $message = ([string]$ExceptionMessage).Trim()
    $combined = ($message + " " + $Context).Trim()

    if ($NotApplicable) {
        return [pscustomobject]@{
            Code="NOT_APPLICABLE"
            Label="Not Applicable"
            Detail=$(if($NotApplicableReason){$NotApplicableReason}else{"Capability does not apply to this device or scenario."})
        }
    }

    if ($KnownDriverOrApiNotExposed) {
        return [pscustomobject]@{
            Code="DRIVER_API_NOT_EXPOSED"
            Label="Driver/API Did Not Expose"
            Detail=$(if($combined){$combined}else{"The installed driver/controller/API did not expose the requested telemetry."})
        }
    }

    if ($combined -match '(?i)access is denied|access denied|unauthorized|privilege|elevation|administrator rights|required privilege') {
        return [pscustomobject]@{Code="REQUIRES_ELEVATION";Label="Requires Elevation";Detail=$combined}
    }

    if ($combined -match '(?i)not supported|unsupported platform|not implemented|platform does not support|uefi.*not supported') {
        return [pscustomobject]@{Code="NOT_SUPPORTED";Label="Not Supported";Detail=$combined}
    }

    if ($combined -match '(?i)invalid class|class not found|invalid namespace|no instance|not exposed|property.*not found|provider.*not found') {
        return [pscustomobject]@{Code="DRIVER_API_NOT_EXPOSED";Label="Driver/API Did Not Expose";Detail=$combined}
    }

    if ($message) {
        return [pscustomobject]@{Code="QUERY_API_FAILED";Label="Query/API Failed";Detail=$message}
    }

    if ($NoData) {
        return [pscustomobject]@{Code="UNKNOWN_INDETERMINATE";Label="Unknown/Indeterminate";Detail=$(if($Context){$Context}else{"The query returned no usable data."})}
    }

    return [pscustomobject]@{Code="UNKNOWN_INDETERMINATE";Label="Unknown/Indeterminate";Detail=$(if($Context){$Context}else{"State could not be determined."})}
}

function New-ToolkitCapabilityStatus {
    param(
        [Parameter(Mandatory=$true)][string]$Capability,
        [bool]$Available = $false,
        [string]$Status = "",
        [string]$Detail = "",
        [string]$SourceTool = ""
    )

    return [pscustomobject]@{
        Capability=$Capability
        Available=$Available
        Status=$(if($Status){$Status}else{$(if($Available){"Available"}else{"Unknown/Indeterminate"})})
        Detail=$Detail
        SourceTool=$SourceTool
        ObservedAt=(Get-Date)
    }
}

function Update-ToolkitEvidenceCorrelationIndex {
    param(
        [Parameter(Mandatory=$true)][string]$LogRoot
    )

    if (-not (Test-Path -LiteralPath $LogRoot -PathType Container)) { return $null }

    $sidecars=@(Get-ChildItem -LiteralPath $LogRoot -Filter "*.evidence.json" -File -Recurse -ErrorAction SilentlyContinue)
    $map=@{}
    $sourceCount=0

    foreach($file in $sidecars){
        try{
            $payload=Get-Content -LiteralPath $file.FullName -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
            $toolId=[string]$payload.Report.ToolId
            $title=[string]$payload.Report.Title
            $generated=[string]$payload.Report.GeneratedAt
            $relative=$file.FullName.Substring($LogRoot.Length).TrimStart("\")
            foreach($entry in @($payload.Findings)+@($payload.Evidence)){
                $evidenceId=[string]$entry.EvidenceId
                if(-not $evidenceId){continue}
                $sourceCount++
                if(-not $map.ContainsKey($evidenceId)){
                    $map[$evidenceId]=New-Object System.Collections.Generic.List[object]
                }
                $map[$evidenceId].Add([pscustomobject]@{
                    ToolId=$toolId
                    Title=$title
                    ReportGeneratedAt=$generated
                    Sidecar=$relative
                    Category=[string]$(if($entry.Category){$entry.Category}else{$entry.Class})
                    Device=[string]$(if($entry.Device){$entry.Device}else{$entry.DeviceContext})
                    EventTimestamp=[string]$(if($entry.EventTimestamp){$entry.EventTimestamp}else{$entry.Timestamp})
                    Source=[string]$entry.Source
                    EventId=[string]$entry.EventId
                })
            }
        }catch{}
    }

    $entries=New-Object System.Collections.Generic.List[object]
    $correlated=New-Object System.Collections.Generic.List[object]
    foreach($key in @($map.Keys|Sort-Object)){
        $sources=$map[$key].ToArray()
        $uniqueReports=@($sources|Select-Object ToolId,Sidecar -Unique)
        $item=[pscustomobject]@{
            EvidenceId=$key
            OccurrenceCount=$sources.Count
            ReportCount=$uniqueReports.Count
            CorrelatedAcrossReports=($uniqueReports.Count -gt 1)
            Sources=$sources
        }
        $entries.Add($item)
        if($uniqueReports.Count -gt 1){$correlated.Add($item)}
    }

    $payload=[pscustomobject]@{
        SchemaVersion="1.0"
        GeneratedAt=(Get-Date)
        LogRoot=$LogRoot
        EvidenceSidecarCount=$sidecars.Count
        EvidenceOccurrenceCount=$sourceCount
        UniqueEvidenceCount=$entries.Count
        CorrelatedEvidenceCount=$correlated.Count
        CorrelatedEvidence=$correlated.ToArray()
        Evidence=$entries.ToArray()
    }

    $jsonPath=Join-Path $LogRoot "EVIDENCE_CORRELATION_INDEX.json"
    $txtPath=Join-Path $LogRoot "EVIDENCE_CORRELATION_INDEX.txt"
    $json=$payload|ConvertTo-Json -Depth 10
    [IO.File]::WriteAllText($jsonPath,$json+[Environment]::NewLine,(New-Object Text.UTF8Encoding($false)))

    $txt=New-Object System.Collections.Generic.List[string]
    $txt.Add("FIELD TECH TOOLKIT v4 - EVIDENCE CORRELATION INDEX")
    $txt.Add("Generated: "+(Get-Date))
    $txt.Add("Evidence sidecars scanned: "+$sidecars.Count)
    $txt.Add("Unique evidence IDs: "+$entries.Count)
    $txt.Add("Evidence IDs found in multiple reports: "+$correlated.Count)
    $txt.Add("")
    if($correlated.Count -eq 0){
        $txt.Add("No cross-report EvidenceId correlations are currently present.")
    }else{
        foreach($item in $correlated.ToArray()){
            $txt.Add("EvidenceId: "+$item.EvidenceId)
            $txt.Add("Reports: "+$item.ReportCount+"  Occurrences: "+$item.OccurrenceCount)
            foreach($s in @($item.Sources)){
                $txt.Add("  - "+$s.ToolId+" | "+$s.Title+" | "+$s.Sidecar)
            }
            $txt.Add("")
        }
    }
    [IO.File]::WriteAllLines($txtPath,$txt.ToArray(),(New-Object Text.UTF8Encoding($false)))
    return $payload
}


function Get-ToolkitEvidenceCorrelationHealth {
    param(
        [Parameter(Mandatory=$true)][string]$LogRoot
    )

    $indexPath = Join-Path $LogRoot "EVIDENCE_CORRELATION_INDEX.json"
    $sidecars = @(Get-ChildItem -LiteralPath $LogRoot -Filter "*.evidence.json" -File -Recurse -ErrorAction SilentlyContinue)

    if($sidecars.Count -eq 0){
        return [pscustomobject]@{
            Status="NO_SIDECARS"
            Healthy=$true
            EvidenceSidecarCount=0
            IndexPath=$indexPath
            IndexExists=(Test-Path -LiteralPath $indexPath -PathType Leaf)
            NewestSidecar=""
            IndexGeneratedAt=""
            Detail="No diagnostic evidence sidecars exist yet."
        }
    }

    $newest = $sidecars | Sort-Object LastWriteTimeUtc -Descending | Select-Object -First 1

    if(-not (Test-Path -LiteralPath $indexPath -PathType Leaf)){
        return [pscustomobject]@{
            Status="MISSING"
            Healthy=$false
            EvidenceSidecarCount=$sidecars.Count
            IndexPath=$indexPath
            IndexExists=$false
            NewestSidecar=$newest.FullName
            IndexGeneratedAt=""
            Detail="Evidence sidecars exist but the correlation index is missing."
        }
    }

    try{
        $indexFile=Get-Item -LiteralPath $indexPath -ErrorAction Stop
        $payload=Get-Content -LiteralPath $indexPath -Raw -ErrorAction Stop|ConvertFrom-Json -ErrorAction Stop
        $countMatches=([int]$payload.EvidenceSidecarCount -eq $sidecars.Count)
        $timeCurrent=($indexFile.LastWriteTimeUtc -ge $newest.LastWriteTimeUtc)

        if($countMatches -and $timeCurrent){
            return [pscustomobject]@{
                Status="CURRENT"
                Healthy=$true
                EvidenceSidecarCount=$sidecars.Count
                IndexPath=$indexPath
                IndexExists=$true
                NewestSidecar=$newest.FullName
                IndexGeneratedAt=[string]$payload.GeneratedAt
                Detail="Correlation index is current relative to diagnostic evidence sidecars."
            }
        }

        return [pscustomobject]@{
            Status="STALE"
            Healthy=$false
            EvidenceSidecarCount=$sidecars.Count
            IndexPath=$indexPath
            IndexExists=$true
            NewestSidecar=$newest.FullName
            IndexGeneratedAt=[string]$payload.GeneratedAt
            Detail=("Correlation index is stale. Indexed sidecars=" + $payload.EvidenceSidecarCount + "; current sidecars=" + $sidecars.Count + ".")
        }
    }
    catch{
        return [pscustomobject]@{
            Status="UNREADABLE"
            Healthy=$false
            EvidenceSidecarCount=$sidecars.Count
            IndexPath=$indexPath
            IndexExists=$true
            NewestSidecar=$newest.FullName
            IndexGeneratedAt=""
            Detail=("Correlation index could not be read: " + $_.Exception.Message)
        }
    }
}

function Test-ToolkitDiagnosticFixtures {
    param(
        [Parameter(Mandatory=$true)][string]$FixturePath
    )

    $results = New-Object System.Collections.Generic.List[object]
    $fixtures = Get-Content -LiteralPath $FixturePath -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop

    foreach($case in @($fixtures.DiskContextCases)) {
        $map=@{}
        foreach($d in @($case.Disks)) {
            $map[[int]$d.Number]=[pscustomobject]@{
                Number=[int]$d.Number
                FriendlyName=[string]$d.FriendlyName
                BusType=[string]$d.BusType
                OperationalStatus=@([string]$d.OperationalStatus)
                Size=[double]$d.SizeBytes
            }
        }
        $actual=Get-ToolkitDiskContext -Message ([string]$case.Message) -DiskMap $map
        $passed=([string]$actual.Class -eq [string]$case.ExpectedClass)
        $results.Add([pscustomobject]@{Test=("Disk fixture: "+$case.Name);Passed=$passed;Expected=$case.ExpectedClass;Actual=$actual.Class})
    }

    foreach($case in @($fixtures.WerCases)) {
        $eventTime=[datetime]$case.EventTime
        $lookback=[datetime]$case.LookbackStart
        $actual=Get-ToolkitWerClassification -Message ([string]$case.Message) -EventTime $eventTime -LookbackStart $lookback -FallbackId ([string]$case.Name)
        $passed=([string]$actual.Class -eq [string]$case.ExpectedClass -and [bool]$actual.IsAnchor -eq [bool]$case.ExpectedAnchor)
        $results.Add([pscustomobject]@{Test=("WER fixture: "+$case.Name);Passed=$passed;Expected=($case.ExpectedClass+" / Anchor="+$case.ExpectedAnchor);Actual=($actual.Class+" / Anchor="+$actual.IsAnchor)})
    }

    foreach($case in @($fixtures.CapabilityCases)) {
        $params=@{
            ExceptionMessage=[string]$case.ExceptionMessage
            Context=[string]$case.Context
        }
        if($case.NoData -eq $true){$params.NoData=$true}
        if($case.NotApplicable -eq $true){
            $params.NotApplicable=$true
            $params.NotApplicableReason=[string]$case.NotApplicableReason
        }
        $actual=Get-ToolkitCapabilityFailureClassification @params
        $passed=([string]$actual.Label -eq [string]$case.ExpectedLabel)
        $results.Add([pscustomobject]@{Test=("Capability fixture: "+$case.Name);Passed=$passed;Expected=$case.ExpectedLabel;Actual=$actual.Label})
    }

    $fixedTime=[datetime]"2026-09-11T20:00:00"
    $idA=Get-ToolkitEvidenceId -Category "WindowsEvent" -Source "disk" -EventId "11" -Timestamp $fixedTime -Device "Disk 3 Generic Reader" -Evidence "controller error"
    $idB=Get-ToolkitEvidenceId -Category "WindowsEvent" -Source "disk" -EventId "11" -Timestamp $fixedTime -Device "Disk 3 Generic Reader" -Evidence "controller error"
    $idC=Get-ToolkitEvidenceId -Category "WindowsEvent" -Source "disk" -EventId "11" -Timestamp $fixedTime -Device "Disk 0 Internal" -Evidence "controller error"
    $results.Add([pscustomobject]@{Test="EvidenceId fixture: deterministic and device-sensitive";Passed=($idA -eq $idB -and $idA -ne $idC);Expected="same canonical evidence => same ID; changed device => different ID";Actual=($idA+" / "+$idB+" / "+$idC)})

    return $results.ToArray()
}

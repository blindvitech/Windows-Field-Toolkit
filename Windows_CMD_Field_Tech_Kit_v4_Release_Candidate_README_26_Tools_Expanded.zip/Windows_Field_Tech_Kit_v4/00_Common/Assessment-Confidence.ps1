# Shared qualitative confidence model for technician-facing assessments.
#
# This does not replace the lower-level diagnostic engine vocabulary used by
# existing evidence classifiers. It provides a stable, non-numeric convention
# for umbrella reports and investigator conclusions.

function Get-ToolkitAssessmentConfidenceDefinition {
    return @(
        [pscustomobject]@{
            Confidence = "CONFIRMED"
            Meaning = "Direct evidence establishes the condition."
        },
        [pscustomobject]@{
            Confidence = "STRONG_EVIDENCE"
            Meaning = "Multiple or high-quality indicators strongly support the condition."
        },
        [pscustomobject]@{
            Confidence = "POSSIBLE"
            Meaning = "Evidence suggests the condition, but plausible alternatives remain."
        },
        [pscustomobject]@{
            Confidence = "INDETERMINATE"
            Meaning = "Available evidence cannot distinguish the likely causes."
        },
        [pscustomobject]@{
            Confidence = "NOT_TESTED"
            Meaning = "A prerequisite, capability, or evidence source was unavailable or not applicable."
        }
    )
}

function Get-ToolkitAssessmentConfidence {
    param(
        [ValidateSet(
            "CONFIRMED",
            "STRONG_EVIDENCE",
            "POSSIBLE",
            "INDETERMINATE",
            "NOT_TESTED"
        )]
        [string]$Confidence = "INDETERMINATE"
    )

    return $Confidence
}

function ConvertTo-ToolkitAssessmentConfidence {
    param(
        [string]$LegacyConfidence = ""
    )

    switch -Regex ($LegacyConfidence.Trim()) {
        '^(?i:CONFIRMED)$' { return "CONFIRMED" }
        '^(?i:LIKELY|STRONG_EVIDENCE|STRONG EVIDENCE)$' { return "STRONG_EVIDENCE" }
        '^(?i:POSSIBLE)$' { return "POSSIBLE" }
        '^(?i:CONTEXT|UNKNOWN|INDETERMINATE)$' { return "INDETERMINATE" }
        '^(?i:NOT_TESTED|NOT TESTED|NOT_APPLICABLE|NOT APPLICABLE|UNAVAILABLE)$' { return "NOT_TESTED" }
        default { return "INDETERMINATE" }
    }
}

function New-ToolkitAssessment {
    param(
        [Parameter(Mandatory=$true)][string]$Area,
        [Parameter(Mandatory=$true)][string]$Finding,
        [ValidateSet(
            "CLEAR",
            "CONTEXT",
            "ATTENTION",
            "FAILURE",
            "PARTIAL",
            "INDETERMINATE",
            "NOT_TESTED"
        )]
        [string]$Status = "CONTEXT",
        [ValidateSet(
            "CONFIRMED",
            "STRONG_EVIDENCE",
            "POSSIBLE",
            "INDETERMINATE",
            "NOT_TESTED"
        )]
        [string]$Confidence = "INDETERMINATE",
        [string]$Evidence = "",
        [string]$RecommendedAction = ""
    )

    return [pscustomobject]@{
        Area = $Area
        Status = $Status
        Confidence = (Get-ToolkitAssessmentConfidence -Confidence $Confidence)
        Finding = $Finding
        Evidence = $Evidence
        RecommendedAction = $RecommendedAction
    }
}

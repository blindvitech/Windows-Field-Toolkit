@echo off
setlocal EnableExtensions
title Windows Field Tech Toolkit v4

rem WinPE / WinRE uses a native-CMD offline companion before any PowerShell
rem dependency is touched. MiniNT is present in Windows PE / Windows RE.
reg query HKLM\SYSTEM\CurrentControlSet\Control\MiniNT >nul 2>&1
if errorlevel 1 goto :FIELDTECH_NORMAL_START
if not exist "%~dp090_WinPE_Offline_Companion\RUN-WINPE-OFFLINE-TECH.cmd" goto :FIELDTECH_NORMAL_START
call "%~dp090_WinPE_Offline_Companion\RUN-WINPE-OFFLINE-TECH.cmd" %*
exit /b %errorlevel%

:FIELDTECH_NORMAL_START
rem Screen Reader Mode can be enabled from any menu with A.
rem It can also be enabled at launch with /accessibility or /screenreader.
set "SRMODE=0"
if /I "%~1"=="/accessibility" set "SRMODE=1"
if /I "%~1"=="/screenreader" set "SRMODE=1"
if "%FIELDTECH_SCREEN_READER%"=="1" set "SRMODE=1"

rem One toolkit session ID is inherited by all child CMD/PowerShell tools.
if not defined FIELDTECH_SESSION_ID (
  for /f "usebackq delims=" %%I in (`powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp000_Common\Get-Toolkit-SessionId.ps1"`) do set "FIELDTECH_SESSION_ID=%%I"
)
if not defined FIELDTECH_SESSION_ID set "FIELDTECH_SESSION_ID=CMD-%RANDOM%-%RANDOM%"

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp000_Common\Initialize-Toolkit-Runtime.ps1"

set "CAPFILE=%TEMP%\FieldTechCaps_%FIELDTECH_SESSION_ID%.cmd"
call :REFRESH_CAPS

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp000_Common\First-Run-Validation.ps1"
set "FIRST_RUN_RC=%errorlevel%"
if "%FIRST_RUN_RC%"=="1" (
  echo First-run validation found a critical toolkit problem.
  echo Review the validation details above before using repair functions.
  if "%SRMODE%"=="1" (
    echo Press any key to acknowledge and continue to the toolkit.
    pause >nul
  ) else (
    echo Press any key to acknowledge and continue.
    pause
  )
)
if "%FIRST_RUN_RC%"=="2" (
  echo First-run validation completed with ATTENTION items.
  echo Review the warning details above. This acknowledgement is shown once for this toolkit build.
  if "%SRMODE%"=="1" (
    echo Press any key to acknowledge the first-run warnings and continue.
    pause >nul
  ) else (
    echo Press any key to acknowledge the first-run warnings and continue.
    pause
  )
)
if "%FIRST_RUN_RC%"=="3" (
  echo.
  echo Automatic first-run verification: PASS
  echo Field validation status: AUTO-VERIFIED
  echo Starting toolkit in 3 seconds...
  timeout /t 3 /nobreak >nul
)

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp000_Common\Retention-Maintenance.ps1" -AgeDays 90

set "ISADMIN=0"
net session >nul 2>&1 && set "ISADMIN=1"

:HOME
call :PREP_MENU
if "%SRMODE%"=="1" (
  echo HOME MENU - WINDOWS FIELD TECH TOOLKIT V4.
  echo Screen Reader Mode is ON.
  if "%ISADMIN%"=="1" (echo Current elevation: Administrator.) else (echo Current elevation: Standard user.)
  echo Capability summary: %CAP_ADMIN%. %CAP_REBOOT%. BitLocker %CAP_BITLOCKER%.
  echo Type a menu number and press Enter.
  echo.
  echo  1. Basic menu.
  echo  2. Advanced menu with categorized navigation.
  echo  3. Tools menu.
  echo  4. Relaunch toolkit as Administrator.
  echo  5. Repair menu. State-changing technician repair tools.
  echo  S. Search all toolkit menus.
  echo  R. Repeat this menu.
  echo  A. Turn Screen Reader Mode off.
  echo  0. Exit.
) else (
  echo ============================================================
  echo             WINDOWS FIELD TECH TOOLKIT V4
  echo ============================================================
  echo.
  echo Capability: %CAP_ADMIN%  %CAP_REBOOT%  BitLocker %CAP_BITLOCKER%
  echo.
  echo   1. BASIC
  echo   2. ADVANCED
  echo   3. TOOLS
  echo   4. Relaunch as Administrator
  echo   5. REPAIR
  echo   A. Screen Reader Mode
  echo  S. Search all toolkit menus.
  echo   R. Repeat Menu
  echo   0. Exit
  echo.
  echo Screen reader users can press A then Enter.
)
echo.
set "choice="
set /p choice=Select an option: 
if /I "%choice%"=="S" call :RUN_TOOL "Toolkit Menu Search" "%~dp026_Tools\Menu-Search.cmd" ""
if /I "%choice%"=="A" (
  call :TOGGLE_SR
  goto HOME
)
if /I "%choice%"=="R" goto HOME
if "%choice%"=="1" goto BASIC
if "%choice%"=="2" goto ADVANCED
if "%choice%"=="3" goto TOOLS
if "%choice%"=="4" goto RELAUNCH_ADMIN
if "%choice%"=="5" goto REPAIR
if "%choice%"=="0" goto TOOLKIT_EXIT
goto HOME

:BASIC
call :PREP_MENU
if "%SRMODE%"=="1" goto BASIC_SR_DISPLAY
echo ============================================================
echo                        BASIC
echo ============================================================
echo.
echo Completed Basic tools may suggest a deeper Advanced follow-up when useful.
echo.
echo SYSTEM / INTAKE
echo   1. Full Machine Report
echo   2. Quick Health Snapshot
echo   3. Machine Intake Summary
echo   4. System Snapshot
echo   5. Windows Build / Edition
echo   6. Activation Status
echo.
echo NETWORK
echo   7. Network Snapshot
echo   8. Internet / DNS Test
echo   9. Full Network Triage
echo  10. Wi-Fi Information
echo  11. Gateway / DNS Test
echo  12. Network Adapter Snapshot
echo  13. Flush DNS
echo  14. Release / Renew DHCP [ADMIN]
echo.
echo WINDOWS REPAIR
echo  15. SFC Scan / Repair [ADMIN] %CAP_SFC%
echo  16. DISM CheckHealth [ADMIN] %CAP_DISM%
echo  17. DISM RestoreHealth [ADMIN] %CAP_DISM%
echo  18. CHKDSK Online Scan [ADMIN] %CAP_CHKDSK%
echo  19. Print Spooler Cleanup [ADMIN]
echo.
echo HARDWARE / SECURITY
echo  20. Battery Report %CAP_BATTERY%
echo  21. Power Report %CAP_POWERCFG%
echo  22. Storage Health Snapshot
echo  23. Installed Apps Snapshot
echo  24. BitLocker Status %CAP_BITLOCKER%
echo  25. Defender Status %CAP_DEFENDER%
echo.
echo  S. Search all toolkit menus.
echo  R. Repeat this menu.
if "%SRMODE%"=="1" (echo  A. Turn Screen Reader Mode off.) else (echo  A. Turn Screen Reader Mode on.)
echo  99. Back to Home.
echo   0. Exit.
echo.
goto BASIC_PROMPT

:BASIC_SR_DISPLAY
echo BASIC MENU.
echo Common diagnostics, repair, hardware, network, and security tools.
echo There are 25 numbered tools.
echo Type a number and press Enter.
echo Administrator-required tools are announced in full.
echo Completed Basic tools may suggest a deeper Advanced follow-up when useful.
echo.
echo SYSTEM AND INTAKE.
echo  1. Full Machine Report.
echo  2. Quick Health Snapshot.
echo  3. Machine Intake Summary.
echo  4. System Snapshot.
echo  5. Windows Build / Edition.
echo  6. Activation Status.
echo.
echo NETWORK.
echo  7. Network Snapshot.
echo  8. Internet / DNS Test.
echo  9. Full Network Triage.
echo  10. Wi-Fi Information.
echo  11. Gateway / DNS Test.
echo  12. Network Adapter Snapshot.
echo  13. Flush DNS.
echo  14. Release / Renew DHCP. Administrator required.
echo.
echo WINDOWS REPAIR.
echo  15. SFC Scan / Repair. Administrator required. Capability %CAP_SFC%.
echo  16. DISM CheckHealth. Administrator required. Capability %CAP_DISM%.
echo  17. DISM RestoreHealth. Administrator required. Capability %CAP_DISM%.
echo  18. CHKDSK Online Scan. Administrator required. Capability %CAP_CHKDSK%.
echo  19. Print Spooler Cleanup. Administrator required.
echo.
echo HARDWARE AND SECURITY.
echo  20. Battery Report %CAP_BATTERY%.
echo  21. Power Report %CAP_POWERCFG%.
echo  22. Storage Health Snapshot.
echo  23. Installed Apps Snapshot.
echo  24. BitLocker Status %CAP_BITLOCKER%.
echo  25. Defender Status %CAP_DEFENDER%.
echo.
echo  S. Search all toolkit menus.
echo  R. Repeat this menu.
if "%SRMODE%"=="1" (echo  A. Turn Screen Reader Mode off.) else (echo  A. Turn Screen Reader Mode on.)
echo  99. Back to Home.
echo   0. Exit.
echo.
:BASIC_PROMPT
set "choice="
set /p choice=Select an option: 
set "TOOL_RC="
if /I "%choice%"=="S" call :RUN_TOOL "Toolkit Menu Search" "%~dp026_Tools\Menu-Search.cmd" ""
if /I "%choice%"=="A" (
  call :TOGGLE_SR
  goto BASIC
)
if /I "%choice%"=="R" goto BASIC
if "%choice%"=="99" goto HOME
if "%choice%"=="0" goto TOOLKIT_EXIT
if "%choice%"=="1" call :RUN_TOOL "Full Machine Report" "%~dp000_Full_Machine_Report\RUN-FULL-MACHINE-REPORT.cmd" ""
if "%choice%"=="2" call :RUN_TOOL "Quick Health Snapshot" "%~dp001_Diagnostics\Quick-Health-Snapshot.cmd" ""
if "%choice%"=="3" call :RUN_TOOL "Machine Intake Summary" "%~dp012_Field_Intake\Machine-Intake-Summary.cmd" ""
if "%choice%"=="4" call :RUN_TOOL "System Snapshot" "%~dp001_Diagnostics\System-Snapshot.cmd" ""
if "%choice%"=="5" call :RUN_TOOL "Windows Build / Edition" "%~dp014_Windows_Configuration\Windows-Build-Edition.cmd" ""
if "%choice%"=="6" call :RUN_TOOL "Activation Status" "%~dp005_Security_and_Accounts\Windows-Activation-Status.cmd" ""
if "%choice%"=="7" call :RUN_TOOL "Network Snapshot" "%~dp001_Diagnostics\Network-Snapshot.cmd" ""
if "%choice%"=="8" call :RUN_TOOL "Internet / DNS Test" "%~dp001_Diagnostics\Internet-Test.cmd" ""
if "%choice%"=="9" call :RUN_TOOL "Full Network Triage" "%~dp013_Network_Triage\NETWORK-TRIAGE.cmd" ""
if "%choice%"=="10" call :RUN_TOOL "Wi-Fi Information" "%~dp001_Diagnostics\WiFi-Info.cmd" ""
if "%choice%"=="11" call :RUN_TOOL "Gateway / DNS Test" "%~dp002_Network\Gateway-DNS-Test.cmd" ""
if "%choice%"=="12" call :RUN_TOOL "Network Adapter Snapshot" "%~dp002_Network\Network-Adapters-Snapshot.cmd" ""
if "%choice%"=="13" call :RUN_TOOL "Flush DNS" "%~dp002_Network\Flush-DNS.cmd" ""
if "%choice%"=="14" call :RUN_TOOL "Release / Renew DHCP" "%~dp002_Network\Renew-DHCP-ADMIN.cmd" "ADMIN"
if "%choice%"=="15" call :RUN_TOOL "SFC Scan / Repair" "%~dp003_Windows_Repair\SFC-Scan-ADMIN.cmd" "ADMIN"
if "%choice%"=="16" call :RUN_TOOL "DISM CheckHealth" "%~dp003_Windows_Repair\DISM-CheckHealth-ADMIN.cmd" "ADMIN"
if "%choice%"=="17" call :RUN_TOOL "DISM RestoreHealth" "%~dp003_Windows_Repair\DISM-RestoreHealth-ADMIN.cmd" "ADMIN"
if "%choice%"=="18" call :RUN_TOOL "CHKDSK Online Scan" "%~dp003_Windows_Repair\CHKDSK-Online-Scan-ADMIN.cmd" "ADMIN"
if "%choice%"=="19" call :RUN_TOOL "Print Spooler Cleanup" "%~dp003_Windows_Repair\Print-Spooler-Cleanup-ADMIN.cmd" "ADMIN"
if "%choice%"=="20" call :RUN_TOOL "Battery Report" "%~dp006_Hardware\Battery-Report.cmd" ""
if "%choice%"=="21" call :RUN_TOOL "Power Report" "%~dp006_Hardware\Power-Report.cmd" ""
if "%choice%"=="22" call :RUN_TOOL "Storage Health Snapshot" "%~dp006_Hardware\Storage-Health-Snapshot.cmd" ""
if "%choice%"=="23" call :RUN_TOOL "Installed Apps Snapshot" "%~dp004_Logs_and_Backup\Installed-Apps-Snapshot.cmd" ""
if "%choice%"=="24" call :RUN_TOOL "BitLocker Status" "%~dp005_Security_and_Accounts\BitLocker-Status.cmd" ""
if "%choice%"=="25" call :RUN_TOOL "Defender Status" "%~dp005_Security_and_Accounts\Defender-Status.cmd" ""
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp000_Common\Show-Basic-Next-Step.ps1" -BasicChoice "%choice%" -ReturnCode "%TOOL_RC%"
goto BASIC


:ADVANCED
if "%SRMODE%"=="1" goto ADVANCED_SR
call :PREP_MENU
set "ADV_RETURN=ADVANCED"
echo ============================================================
echo                       ADVANCED
echo ============================================================
echo.
echo State-changing actions explain their impact and require confirmation before changes are made.
echo.
echo DIAGNOSTICS
echo   1. Security Posture Summary
echo   2. Browser / Network Sanity
echo   3. Remote Access State
echo   4. Local Policy Snapshot
echo   5. Windows Update Readiness
echo   6. SMART / Drive Deep Dive
echo   7. Crash Correlation / Reliability Investigator
echo   8. Performance Snapshot
echo   9. Software / Activation / Licensing Deep Dive
echo  10. Peripheral Inventory
echo  11. Listening Ports / Connections
echo  12. Recent Critical + Error Events
echo  13. Problem Devices
echo  14. Windows Update History
echo  15. Blue Screen Dump Inventory
echo  16. Services Snapshot
echo  17. Startup / Scheduled Tasks Snapshot
echo.
echo NETWORK / SECURITY STATE
echo  18. Firewall + Network Profile Status
echo  19. Proxy + HOSTS Snapshot
echo  20. SMB Shares + Mapped Drives
echo  21. Entra / Domain Join Status
echo  22. Local Accounts Snapshot
echo  23. WLAN HTML Report [ADMIN] %CAP_WLAN%
echo  24. Windows Time Status / Resync [ADMIN]
echo  25. DNS Comparison Test
echo  26. TCP Port Test
echo  27. IPv6 Status
echo.
echo DEVICE / FIRMWARE
echo  28. BIOS / UEFI / Secure Boot / TPM %CAP_SECUREBOOT% %CAP_TPM%
echo  29. Driver Version CSV %CAP_PNPUTIL%
echo  30. Hardware Identity CSV
echo  31. Printer Snapshot
echo  32. User Profile Inventory
echo.
echo WINDOWS / RECOVERY
echo  33. DISM Component Store Analysis [ADMIN] %CAP_DISM%
echo  34. Windows Update Repair [ADMIN]
echo  35. Reset Winsock + TCP/IP [ADMIN/REBOOT]
echo  36. Pending Reboot Check
echo  37. .NET Framework Version
echo  38. Hyper-V / WSL / Sandbox Status %CAP_HYPERV%
echo  39. Hibernation / Fast Startup
echo  40. Pagefile Status
echo  41. WinRE Status %CAP_WINRE%
echo  42. Boot Configuration Snapshot
echo  43. Windows Features Snapshot %CAP_DISM%
echo  44. System Restore Status
echo.
echo STORAGE / BACKUP
echo  45. Disk / Partition Layout
echo  46. VSS Shadow Copy Inventory
echo  47. BitLocker Protector Summary %CAP_BITLOCKER%
echo.
echo ADDITIONAL AUDITS
echo  48. What Changed? Recent Changes Analyzer
echo  49. Microsoft Defender Security Audit %CAP_DEFENDER%
echo  50. Wi-Fi Adapter Capability Report
echo  51. Why Did This PC Reboot?
echo  52. Network Before / After Compare
echo  53. User Profile Health Audit
echo  54. Application Crash Investigator
echo  55. Local Security Baseline Compare
echo  56. Event Viewer - What Matters?
echo  57. Certificate / TLS Audit
echo.
echo DEEP INVESTIGATORS / COMPARISON
echo  58. Full Machine Before / After Compare
echo  59. Boot / Startup Performance Audit
echo  60. Browser Health Audit
echo  61. Windows Update Failure Investigator
echo  62. Authentication / Logon Investigator
echo  63. USB / Removable Device History
echo  64. Power / Sleep / Wake Investigator
echo  65. Printer Failure Investigator
echo  66. Network Path Investigator
echo  67. Hardware Error Investigator
echo  68. Scheduled Task Investigator
echo  69. Service Failure Investigator
echo  70. Hardware Acceptance Test
echo  71. DNS Resolution Chain Investigator
echo  72. DHCP Lease / State Deep Dive
echo  73. Network Driver / Event Correlation
echo  74. SMB Connectivity / Troubleshooting Investigator
echo  75. Windows Servicing / Update Health Report
echo  76. Domain Trust / AD Health Investigator
echo.
echo  S. Search all toolkit menus.
echo  R. Repeat this menu.
if "%SRMODE%"=="1" (echo  A. Turn Screen Reader Mode off.) else (echo  A. Turn Screen Reader Mode on.)
echo  99. Back to Home.
echo   0. Exit.
echo.
set "choice="
set /p choice=Select an option: 
if /I "%choice%"=="S" call :RUN_TOOL "Toolkit Menu Search" "%~dp026_Tools\Menu-Search.cmd" ""
if /I "%choice%"=="A" (
  call :TOGGLE_SR
  goto ADVANCED
)
if /I "%choice%"=="R" goto ADVANCED
if "%choice%"=="99" goto HOME
if "%choice%"=="0" goto TOOLKIT_EXIT
goto ADV_EXEC

:ADVANCED_SR
call :PREP_MENU
echo ADVANCED MENU.
echo Screen Reader Mode is ON.
echo State-changing actions explain their impact and require confirmation before changes are made.
echo Advanced tools are grouped into smaller categories to reduce long menu reading.
echo Type a category number and press Enter.
echo.
echo  1. Diagnostics and reporting. Tools 1 through 17.
echo  2. Network and security state. Tools 18 through 27.
echo  3. Device and firmware. Tools 28 through 32.
echo  4. Windows and recovery. Tools 33 through 44.
echo  5. Storage and backup. Tools 45 through 47.
echo  6. Field audits, crash analysis, security baseline, events, and certificates. Tools 48 through 57.
echo  7. Deep investigators and network troubleshooting. Tools 58 through 76.
echo  8. All 76 Advanced tools in one list.
echo  S. Search all toolkit menus.
echo  R. Repeat this menu.
echo  A. Turn Screen Reader Mode off.
echo  99. Home.
echo   0. Exit.
echo.
set "choice="
set /p choice=Select an option: 
if /I "%choice%"=="S" call :RUN_TOOL "Toolkit Menu Search" "%~dp026_Tools\Menu-Search.cmd" ""
if /I "%choice%"=="A" (
  call :TOGGLE_SR
  goto ADVANCED
)
if /I "%choice%"=="R" goto ADVANCED_SR
if "%choice%"=="1" goto ADV_DIAGNOSTICS
if "%choice%"=="2" goto ADV_NETSEC
if "%choice%"=="3" goto ADV_DEVICE
if "%choice%"=="4" goto ADV_WINREC
if "%choice%"=="5" goto ADV_STORAGE
if "%choice%"=="6" goto ADV_AUDITS
if "%choice%"=="7" goto ADV_INVESTIGATORS
if "%choice%"=="8" goto ADV_ALL
if "%choice%"=="99" goto HOME
if "%choice%"=="0" goto TOOLKIT_EXIT
goto ADVANCED_SR

:ADV_ALL
call :PREP_MENU
set "ADV_RETURN=ADV_ALL"
echo ALL ADVANCED TOOLS.
echo There are 76 numbered advanced tools.
echo Type a tool number and press Enter.
echo Administrator-required tools are announced in full.
echo.
echo DIAGNOSTICS.
echo  1. Security Posture Summary.
echo  2. Browser / Network Sanity.
echo  3. Remote Access State.
echo  4. Local Policy Snapshot.
echo  5. Windows Update Readiness.
echo  6. SMART / Drive Deep Dive.
echo  7. Crash Correlation / Reliability Investigator.
echo  8. Performance Snapshot.
echo  9. Software / Activation / Licensing Deep Dive.
echo  10. Peripheral Inventory.
echo  11. Listening Ports / Connections.
echo  12. Recent Critical + Error Events.
echo  13. Problem Devices.
echo  14. Windows Update History.
echo  15. Blue Screen Dump Inventory.
echo  16. Services Snapshot.
echo  17. Startup / Scheduled Tasks Snapshot.
echo.
echo NETWORK AND SECURITY STATE.
echo  18. Firewall + Network Profile Status.
echo  19. Proxy + HOSTS Snapshot.
echo  20. SMB Shares + Mapped Drives.
echo  21. Entra / Domain Join Status.
echo  22. Local Accounts Snapshot.
echo  23. WLAN HTML Report. Administrator required. Capability %CAP_WLAN%.
echo  24. Windows Time Status / Resync. Administrator required.
echo  25. DNS Comparison Test.
echo  26. TCP Port Test.
echo  27. IPv6 Status.
echo.
echo DEVICE AND FIRMWARE.
echo  28. BIOS / UEFI / Secure Boot / TPM %CAP_SECUREBOOT% %CAP_TPM%.
echo  29. Driver Version CSV %CAP_PNPUTIL%.
echo  30. Hardware Identity CSV.
echo  31. Printer Snapshot.
echo  32. User Profile Inventory.
echo.
echo WINDOWS AND RECOVERY.
echo  33. DISM Component Store Analysis. Administrator required. Capability %CAP_DISM%.
echo  34. Windows Update Repair. Administrator required.
echo  35. Reset Winsock + TCP/IP. Administrator required. Reboot may be required.
echo  36. Pending Reboot Check.
echo  37. .NET Framework Version.
echo  38. Hyper-V / WSL / Sandbox Status %CAP_HYPERV%.
echo  39. Hibernation / Fast Startup.
echo  40. Pagefile Status.
echo  41. WinRE Status %CAP_WINRE%.
echo  42. Boot Configuration Snapshot.
echo  43. Windows Features Snapshot %CAP_DISM%.
echo  44. System Restore Status.
echo.
echo STORAGE AND BACKUP.
echo  45. Disk / Partition Layout.
echo  46. VSS Shadow Copy Inventory.
echo  47. BitLocker Protector Summary %CAP_BITLOCKER%.
echo.
echo ADDITIONAL AUDITS.
echo  48. What Changed? Recent Changes Analyzer.
echo  49. Microsoft Defender Security Audit %CAP_DEFENDER%.
echo  50. Wi-Fi Adapter Capability Report.
echo  51. Why Did This PC Reboot?
echo  52. Network Before / After Compare.
echo  53. User Profile Health Audit.
echo  54. Application Crash Investigator.
echo  55. Local Security Baseline Compare.
echo  56. Event Viewer - What Matters?
echo  57. Certificate / TLS Audit.
echo.
echo DEEP INVESTIGATORS AND COMPARISON.
echo  58. Full Machine Before / After Compare.
echo  59. Boot / Startup Performance Audit.
echo  60. Browser Health Audit.
echo  61. Windows Update Failure Investigator.
echo  62. Authentication / Logon Investigator.
echo  63. USB / Removable Device History.
echo  64. Power / Sleep / Wake Investigator.
echo  65. Printer Failure Investigator.
echo  66. Network Path Investigator.
echo  67. Hardware Error Investigator.
echo  68. Scheduled Task Investigator.
echo  69. Service Failure Investigator.
echo  70. Hardware Acceptance Test.
echo  71. DNS Resolution Chain Investigator.
echo  72. DHCP Lease / State Deep Dive.
echo  73. Network Driver / Event Correlation.
echo  74. SMB Connectivity / Troubleshooting Investigator.
echo  75. Windows Servicing / Update Health Report.
echo  76. Domain Trust / AD Health Investigator.
echo.
echo  98. Back to Advanced Categories.
echo  S. Search all toolkit menus.
echo  R. Repeat this menu.
echo  A. Turn Screen Reader Mode off.
echo  99. Home.
echo   0. Exit.
echo.
set "choice="
set /p choice=Select an option: 
if /I "%choice%"=="S" call :RUN_TOOL "Toolkit Menu Search" "%~dp026_Tools\Menu-Search.cmd" ""
if /I "%choice%"=="A" (
  call :TOGGLE_SR
  goto ADVANCED
)
if /I "%choice%"=="R" goto ADV_ALL
if "%choice%"=="98" goto ADVANCED_SR
if "%choice%"=="99" goto HOME
if "%choice%"=="0" goto TOOLKIT_EXIT
goto ADV_EXEC

:ADV_DIAGNOSTICS
call :PREP_MENU
set "ADV_RETURN=ADV_DIAGNOSTICS"
echo ADVANCED CATEGORY: DIAGNOSTICS AND REPORTING.
echo This category contains 17 tools.
echo Type a tool number and press Enter.
echo Administrator-required tools are announced in full.
echo.
echo  1. Security Posture Summary.
echo  2. Browser / Network Sanity.
echo  3. Remote Access State.
echo  4. Local Policy Snapshot.
echo  5. Windows Update Readiness.
echo  6. SMART / Drive Deep Dive.
echo  7. Crash Correlation / Reliability Investigator.
echo  8. Performance Snapshot.
echo  9. Software / Activation / Licensing Deep Dive.
echo  10. Peripheral Inventory.
echo  11. Listening Ports / Connections.
echo  12. Recent Critical + Error Events.
echo  13. Problem Devices.
echo  14. Windows Update History.
echo  15. Blue Screen Dump Inventory.
echo  16. Services Snapshot.
echo  17. Startup / Scheduled Tasks Snapshot.
echo.
echo  S. Search all toolkit menus.
echo  R. Repeat this category.
echo  98. Back to Advanced Categories.
echo  99. Home.
echo   0. Exit.
echo.
set "choice="
set /p choice=Select an option: 
if /I "%choice%"=="S" call :RUN_TOOL "Toolkit Menu Search" "%~dp026_Tools\Menu-Search.cmd" ""
if /I "%choice%"=="R" goto ADV_DIAGNOSTICS
if "%choice%"=="98" goto ADVANCED_SR
if "%choice%"=="99" goto HOME
if "%choice%"=="0" goto TOOLKIT_EXIT
goto ADV_EXEC

:ADV_NETSEC
call :PREP_MENU
set "ADV_RETURN=ADV_NETSEC"
echo ADVANCED CATEGORY: NETWORK AND SECURITY STATE.
echo This category contains 10 tools.
echo Type a tool number and press Enter.
echo Administrator-required tools are announced in full.
echo.
echo  18. Firewall + Network Profile Status.
echo  19. Proxy + HOSTS Snapshot.
echo  20. SMB Shares + Mapped Drives.
echo  21. Entra / Domain Join Status.
echo  22. Local Accounts Snapshot.
echo  23. WLAN HTML Report. Administrator required. Capability %CAP_WLAN%.
echo  24. Windows Time Status / Resync. Administrator required.
echo  25. DNS Comparison Test.
echo  26. TCP Port Test.
echo  27. IPv6 Status.
echo.
echo  S. Search all toolkit menus.
echo  R. Repeat this category.
echo  98. Back to Advanced Categories.
echo  99. Home.
echo   0. Exit.
echo.
set "choice="
set /p choice=Select an option: 
if /I "%choice%"=="S" call :RUN_TOOL "Toolkit Menu Search" "%~dp026_Tools\Menu-Search.cmd" ""
if /I "%choice%"=="R" goto ADV_NETSEC
if "%choice%"=="98" goto ADVANCED_SR
if "%choice%"=="99" goto HOME
if "%choice%"=="0" goto TOOLKIT_EXIT
goto ADV_EXEC

:ADV_DEVICE
call :PREP_MENU
set "ADV_RETURN=ADV_DEVICE"
echo ADVANCED CATEGORY: DEVICE AND FIRMWARE.
echo This category contains 5 tools.
echo Type a tool number and press Enter.
echo Administrator-required tools are announced in full.
echo.
echo  28. BIOS / UEFI / Secure Boot / TPM %CAP_SECUREBOOT% %CAP_TPM%.
echo  29. Driver Version CSV %CAP_PNPUTIL%.
echo  30. Hardware Identity CSV.
echo  31. Printer Snapshot.
echo  32. User Profile Inventory.
echo.
echo  S. Search all toolkit menus.
echo  R. Repeat this category.
echo  98. Back to Advanced Categories.
echo  99. Home.
echo   0. Exit.
echo.
set "choice="
set /p choice=Select an option: 
if /I "%choice%"=="S" call :RUN_TOOL "Toolkit Menu Search" "%~dp026_Tools\Menu-Search.cmd" ""
if /I "%choice%"=="R" goto ADV_DEVICE
if "%choice%"=="98" goto ADVANCED_SR
if "%choice%"=="99" goto HOME
if "%choice%"=="0" goto TOOLKIT_EXIT
goto ADV_EXEC

:ADV_WINREC
call :PREP_MENU
set "ADV_RETURN=ADV_WINREC"
echo ADVANCED CATEGORY: WINDOWS AND RECOVERY.
echo This category contains 17 tools.
echo Type a tool number and press Enter.
echo Administrator-required tools are announced in full.
echo.
echo  33. DISM Component Store Analysis. Administrator required. Capability %CAP_DISM%.
echo  34. Windows Update Repair. Administrator required.
echo  35. Reset Winsock + TCP/IP. Administrator required. Reboot may be required.
echo  36. Pending Reboot Check.
echo  37. .NET Framework Version.
echo  38. Hyper-V / WSL / Sandbox Status %CAP_HYPERV%.
echo  39. Hibernation / Fast Startup.
echo  40. Pagefile Status.
echo  41. WinRE Status %CAP_WINRE%.
echo  42. Boot Configuration Snapshot.
echo  43. Windows Features Snapshot %CAP_DISM%.
echo  44. System Restore Status.
echo.
echo  S. Search all toolkit menus.
echo  R. Repeat this category.
echo  98. Back to Advanced Categories.
echo  99. Home.
echo   0. Exit.
echo.
set "choice="
set /p choice=Select an option: 
if /I "%choice%"=="S" call :RUN_TOOL "Toolkit Menu Search" "%~dp026_Tools\Menu-Search.cmd" ""
if /I "%choice%"=="R" goto ADV_WINREC
if "%choice%"=="98" goto ADVANCED_SR
if "%choice%"=="99" goto HOME
if "%choice%"=="0" goto TOOLKIT_EXIT
goto ADV_EXEC

:ADV_STORAGE
call :PREP_MENU
set "ADV_RETURN=ADV_STORAGE"
echo ADVANCED CATEGORY: STORAGE AND BACKUP.
echo This category contains 3 tools.
echo Type a tool number and press Enter.
echo Administrator-required tools are announced in full.
echo.
echo  45. Disk / Partition Layout.
echo  46. VSS Shadow Copy Inventory.
echo  47. BitLocker Protector Summary %CAP_BITLOCKER%.
echo.
echo  S. Search all toolkit menus.
echo  R. Repeat this category.
echo  98. Back to Advanced Categories.
echo  99. Home.
echo   0. Exit.
echo.
set "choice="
set /p choice=Select an option: 
if /I "%choice%"=="S" call :RUN_TOOL "Toolkit Menu Search" "%~dp026_Tools\Menu-Search.cmd" ""
if /I "%choice%"=="R" goto ADV_STORAGE
if "%choice%"=="98" goto ADVANCED_SR
if "%choice%"=="99" goto HOME
if "%choice%"=="0" goto TOOLKIT_EXIT
goto ADV_EXEC

:ADV_AUDITS
call :PREP_MENU
set "ADV_RETURN=ADV_AUDITS"
echo ADVANCED CATEGORY: FIELD AUDITS AND ASSESSMENT.
echo This category contains 10 tools.
echo Type a tool number and press Enter.
echo These tools are read-only diagnostics except network baseline file creation/deletion.
echo.
echo  48. What Changed? Recent Changes Analyzer.
echo  49. Microsoft Defender Security Audit %CAP_DEFENDER%.
echo  50. Wi-Fi Adapter Capability Report.
echo  51. Why Did This PC Reboot?
echo  52. Network Before / After Compare.
echo  53. User Profile Health Audit.
echo  54. Application Crash Investigator.
echo  55. Local Security Baseline Compare.
echo  56. Event Viewer - What Matters?
echo  57. Certificate / TLS Audit.
echo.
echo  S. Search all toolkit menus.
echo  R. Repeat this category.
echo  98. Back to Advanced Categories.
echo  99. Home.
echo   0. Exit.
echo.
set "choice="
set /p choice=Select an option: 
if /I "%choice%"=="S" call :RUN_TOOL "Toolkit Menu Search" "%~dp026_Tools\Menu-Search.cmd" ""
if /I "%choice%"=="R" goto ADV_AUDITS
if "%choice%"=="98" goto ADVANCED_SR
if "%choice%"=="99" goto HOME
if "%choice%"=="0" goto TOOLKIT_EXIT
goto ADV_EXEC

:ADV_INVESTIGATORS
call :PREP_MENU
set "ADV_RETURN=ADV_INVESTIGATORS"
echo ADVANCED CATEGORY: DEEP INVESTIGATORS AND NETWORK TROUBLESHOOTING.
echo This category contains 19 tools.
echo Type a tool number and press Enter.
echo These tools are read-only diagnostics except full-machine baseline file creation/deletion.
echo.
echo  58. Full Machine Before / After Compare.
echo  59. Boot / Startup Performance Audit.
echo  60. Browser Health Audit.
echo  61. Windows Update Failure Investigator.
echo  62. Authentication / Logon Investigator.
echo  63. USB / Removable Device History.
echo  64. Power / Sleep / Wake Investigator.
echo  65. Printer Failure Investigator.
echo  66. Network Path Investigator.
echo  67. Hardware Error Investigator.
echo  68. Scheduled Task Investigator.
echo  69. Service Failure Investigator.
echo  70. Hardware Acceptance Test.
echo  71. DNS Resolution Chain Investigator.
echo  72. DHCP Lease / State Deep Dive.
echo  73. Network Driver / Event Correlation.
echo  74. SMB Connectivity / Troubleshooting Investigator.
echo  75. Windows Servicing / Update Health Report.
echo  76. Domain Trust / AD Health Investigator.
echo.
echo  S. Search all toolkit menus.
echo  R. Repeat this category.
echo  98. Back to Advanced Categories.
echo  99. Home.
echo   0. Exit.
echo.
set "choice="
set /p choice=Select an option: 
if /I "%choice%"=="S" call :RUN_TOOL "Toolkit Menu Search" "%~dp026_Tools\Menu-Search.cmd" ""
if /I "%choice%"=="R" goto ADV_INVESTIGATORS
if "%choice%"=="98" goto ADVANCED_SR
if "%choice%"=="99" goto HOME
if "%choice%"=="0" goto TOOLKIT_EXIT
goto ADV_EXEC

:ADV_EXEC
if "%choice%"=="1" call :RUN_TOOL "Security Posture Summary" "%~dp023_Security_Posture\Security-Posture-Summary.cmd" ""
if "%choice%"=="2" call :RUN_TOOL "Browser / Network Sanity" "%~dp016_Browser_and_Network_Sanity\Browser-Network-Sanity.cmd" ""
if "%choice%"=="3" call :RUN_TOOL "Remote Access State" "%~dp017_Remote_Access\Remote-Access-State.cmd" ""
if "%choice%"=="4" call :RUN_TOOL "Local Policy Snapshot" "%~dp018_Local_Policy\Local-Policy-Snapshot.cmd" ""
if "%choice%"=="5" call :RUN_TOOL "Windows Update Readiness" "%~dp019_Update_Readiness\Windows-Update-Readiness.cmd" ""
if "%choice%"=="6" call :RUN_TOOL "SMART / Drive Deep Dive" "%~dp020_Storage_Deep_Dive\Storage-Deep-Dive.cmd" ""
if "%choice%"=="7" call :RUN_TOOL "Crash Correlation / Reliability Investigator" "%~dp021_Crash_and_Reliability\Crash-Reliability-Report.cmd" ""
if "%choice%"=="8" call :RUN_TOOL "Performance Snapshot" "%~dp022_Performance\Performance-Snapshot.cmd" ""
if "%choice%"=="9" call :RUN_TOOL "Software / Activation / Licensing Deep Dive" "%~dp024_Software_and_Licensing\Software-License-Inventory.cmd" ""
if "%choice%"=="10" call :RUN_TOOL "Peripheral Inventory" "%~dp025_Peripherals\Peripheral-Inventory.cmd" ""
if "%choice%"=="11" call :RUN_TOOL "Listening Ports / Connections" "%~dp008_Advanced_Diagnostics\Listening-Ports-Snapshot.cmd" ""
if "%choice%"=="12" call :RUN_TOOL "Recent Critical + Error Events" "%~dp008_Advanced_Diagnostics\Recent-Critical-Errors.cmd" ""
if "%choice%"=="13" call :RUN_TOOL "Problem Devices" "%~dp008_Advanced_Diagnostics\Problem-Devices.cmd" ""
if "%choice%"=="14" call :RUN_TOOL "Windows Update History" "%~dp008_Advanced_Diagnostics\Windows-Update-History.cmd" ""
if "%choice%"=="15" call :RUN_TOOL "Blue Screen Dump Inventory" "%~dp008_Advanced_Diagnostics\BlueScreen-Dump-Inventory.cmd" ""
if "%choice%"=="16" call :RUN_TOOL "Services Snapshot" "%~dp001_Diagnostics\Services-Snapshot.cmd" ""
if "%choice%"=="17" call :RUN_TOOL "Startup / Scheduled Tasks Snapshot" "%~dp001_Diagnostics\Startup-Snapshot.cmd" ""
if "%choice%"=="18" call :RUN_TOOL "Firewall + Network Profile Status" "%~dp009_Security_Network_State\Firewall-Status-Snapshot.cmd" ""
if "%choice%"=="19" call :RUN_TOOL "Proxy + HOSTS Snapshot" "%~dp009_Security_Network_State\Proxy-and-Hosts-Snapshot.cmd" ""
if "%choice%"=="20" call :RUN_TOOL "SMB Shares + Mapped Drives" "%~dp009_Security_Network_State\SMB-Shares-and-Mapped-Drives.cmd" ""
if "%choice%"=="21" call :RUN_TOOL "Entra / Domain Join Status" "%~dp009_Security_Network_State\Entra-Domain-Join-Status.cmd" ""
if "%choice%"=="22" call :RUN_TOOL "Local Accounts Snapshot" "%~dp005_Security_and_Accounts\Local-Accounts-Snapshot.cmd" ""
if "%choice%"=="23" call :RUN_TOOL "WLAN HTML Report" "%~dp002_Network\WLAN-Report-ADMIN.cmd" "ADMIN"
if "%choice%"=="24" call :RUN_TOOL "Windows Time Status / Resync" "%~dp002_Network\Time-Sync-ADMIN.cmd" "ADMIN"
if "%choice%"=="25" call :RUN_TOOL "DNS Comparison Test" "%~dp013_Network_Triage\DNS-Comparison-Test.cmd" ""
if "%choice%"=="26" call :RUN_TOOL "TCP Port Test" "%~dp013_Network_Triage\Port-Test.cmd" ""
if "%choice%"=="27" call :RUN_TOOL "IPv6 Status" "%~dp013_Network_Triage\IPv6-Status.cmd" ""
if "%choice%"=="28" call :RUN_TOOL "BIOS / UEFI / Secure Boot / TPM" "%~dp010_Device_and_Firmware\BIOS-UEFI-SecureBoot-TPM.cmd" ""
if "%choice%"=="29" call :RUN_TOOL "Driver Version CSV" "%~dp010_Device_and_Firmware\Driver-Version-Snapshot.cmd" ""
if "%choice%"=="30" call :RUN_TOOL "Hardware Identity CSV" "%~dp012_Field_Intake\Hardware-Identity-CSV.cmd" ""
if "%choice%"=="31" call :RUN_TOOL "Printer Snapshot" "%~dp010_Device_and_Firmware\Printer-Snapshot.cmd" ""
if "%choice%"=="32" call :RUN_TOOL "User Profile Inventory" "%~dp012_Field_Intake\User-Profile-Inventory.cmd" ""
if "%choice%"=="33" call :RUN_TOOL "DISM Component Store Analysis" "%~dp003_Windows_Repair\DISM-ComponentStore-Analyze-ADMIN.cmd" "ADMIN"
if "%choice%"=="34" call :RUN_TOOL "Windows Update Repair" "%~dp003_Windows_Repair\Windows-Update-Repair-ADMIN.cmd" "ADMIN"
if "%choice%"=="35" call :RUN_TOOL "Reset Winsock + TCP/IP" "%~dp002_Network\Reset-Winsock-IP-ADMIN.cmd" "ADMINREBOOT"
if "%choice%"=="36" call :RUN_TOOL "Pending Reboot Check" "%~dp014_Windows_Configuration\Pending-Reboot-Check.cmd" ""
if "%choice%"=="37" call :RUN_TOOL ".NET Framework Version" "%~dp014_Windows_Configuration\DotNet-Version.cmd" ""
if "%choice%"=="38" call :RUN_TOOL "Hyper-V / WSL / Sandbox Status" "%~dp014_Windows_Configuration\Virtualization-Feature-Status.cmd" ""
if "%choice%"=="39" call :RUN_TOOL "Hibernation / Fast Startup" "%~dp014_Windows_Configuration\Hibernation-FastStartup-Status.cmd" ""
if "%choice%"=="40" call :RUN_TOOL "Pagefile Status" "%~dp014_Windows_Configuration\Pagefile-Status.cmd" ""
if "%choice%"=="41" call :RUN_TOOL "WinRE Status" "%~dp011_Windows_State\Recovery-Environment-Status.cmd" ""
if "%choice%"=="42" call :RUN_TOOL "Boot Configuration Snapshot" "%~dp011_Windows_State\Boot-Configuration-Snapshot.cmd" ""
if "%choice%"=="43" call :RUN_TOOL "Windows Features Snapshot" "%~dp011_Windows_State\Windows-Features-Snapshot.cmd" ""
if "%choice%"=="44" call :RUN_TOOL "System Restore Status" "%~dp011_Windows_State\System-Restore-Status.cmd" ""
if "%choice%"=="45" call :RUN_TOOL "Disk / Partition Layout" "%~dp015_Storage_and_Recovery\Disk-Partition-Layout.cmd" ""
if "%choice%"=="46" call :RUN_TOOL "VSS Shadow Copy Inventory" "%~dp015_Storage_and_Recovery\Shadow-Copy-Inventory.cmd" ""
if "%choice%"=="47" call :RUN_TOOL "BitLocker Protector Summary" "%~dp015_Storage_and_Recovery\BitLocker-Protector-Summary.cmd" ""
if "%choice%"=="48" call :RUN_TOOL "What Changed? Recent Changes Analyzer" "%~dp029_Advanced_Audit\Recent-Changes-Timeline.cmd" ""
if "%choice%"=="49" call :RUN_TOOL "Microsoft Defender Security Audit" "%~dp029_Advanced_Audit\Defender-Security-Audit.cmd" ""
if "%choice%"=="50" call :RUN_TOOL "Wi-Fi Adapter Capability Report" "%~dp029_Advanced_Audit\WiFi-Adapter-Capability.cmd" ""
if "%choice%"=="51" call :RUN_TOOL "Why Did This PC Reboot?" "%~dp029_Advanced_Audit\Why-Did-This-PC-Reboot.cmd" ""
if "%choice%"=="52" call :RUN_TOOL "Network Before / After Compare" "%~dp029_Advanced_Audit\Network-Before-After-Compare.cmd" ""
if "%choice%"=="53" call :RUN_TOOL "User Profile Health Audit" "%~dp030_Assessment_Case\Profile-Health-Audit.cmd" ""
if "%choice%"=="54" call :RUN_TOOL "Application Crash Investigator" "%~dp030_Assessment_Case\Application-Crash-Investigator.cmd" ""
if "%choice%"=="55" call :RUN_TOOL "Local Security Baseline Compare" "%~dp030_Assessment_Case\Local-Security-Baseline-Compare.cmd" ""
if "%choice%"=="56" call :RUN_TOOL "Event Viewer - What Matters?" "%~dp030_Assessment_Case\Event-Viewer-What-Matters.cmd" ""
if "%choice%"=="57" call :RUN_TOOL "Certificate / TLS Audit" "%~dp030_Assessment_Case\Certificate-TLS-Audit.cmd" ""
if "%choice%"=="58" call :RUN_TOOL "Full Machine Before / After Compare" "%~dp030_Assessment_Case\Full-Machine-Before-After-Compare.cmd" ""
if "%choice%"=="59" call :RUN_TOOL "Boot / Startup Performance Audit" "%~dp030_Assessment_Case\Boot-Startup-Performance-Audit.cmd" ""
if "%choice%"=="60" call :RUN_TOOL "Browser Health Audit" "%~dp030_Assessment_Case\Browser-Health-Audit.cmd" ""
if "%choice%"=="61" call :RUN_TOOL "Windows Update Failure Investigator" "%~dp030_Assessment_Case\Windows-Update-Failure-Investigator.cmd" ""
if "%choice%"=="62" call :RUN_TOOL "Authentication / Logon Investigator" "%~dp030_Assessment_Case\Authentication-Logon-Investigator.cmd" ""
if "%choice%"=="63" call :RUN_TOOL "USB / Removable Device History" "%~dp030_Assessment_Case\USB-Removable-Device-History.cmd" ""
if "%choice%"=="64" call :RUN_TOOL "Power / Sleep / Wake Investigator" "%~dp030_Assessment_Case\Power-Sleep-Wake-Investigator.cmd" ""
if "%choice%"=="65" call :RUN_TOOL "Printer Failure Investigator" "%~dp030_Assessment_Case\Printer-Failure-Investigator.cmd" ""
if "%choice%"=="66" call :RUN_TOOL "Network Path Investigator" "%~dp030_Assessment_Case\Network-Path-Investigator.cmd" ""
if "%choice%"=="67" call :RUN_TOOL "Hardware Error Investigator" "%~dp030_Assessment_Case\Hardware-Error-Investigator.cmd" ""
if "%choice%"=="68" call :RUN_TOOL "Scheduled Task Investigator" "%~dp030_Assessment_Case\Scheduled-Task-Investigator.cmd" ""
if "%choice%"=="69" call :RUN_TOOL "Service Failure Investigator" "%~dp030_Assessment_Case\Service-Failure-Investigator.cmd" ""
if "%choice%"=="70" call :RUN_TOOL "Hardware Acceptance Test" "%~dp031_Hardware_Acceptance\Hardware-Acceptance-Test.cmd" ""
if "%choice%"=="71" call :RUN_TOOL "DNS Resolution Chain Investigator" "%~dp030_Assessment_Case\DNS-Resolution-Chain-Investigator.cmd" ""
if "%choice%"=="72" call :RUN_TOOL "DHCP Lease / State Deep Dive" "%~dp030_Assessment_Case\DHCP-Lease-State-Deep-Dive.cmd" ""
if "%choice%"=="73" call :RUN_TOOL "Network Driver / Event Correlation" "%~dp030_Assessment_Case\Network-Driver-Event-Correlation.cmd" ""
if "%choice%"=="74" call :RUN_TOOL "SMB Connectivity / Troubleshooting Investigator" "%~dp030_Assessment_Case\SMB-Connectivity-Troubleshooting-Investigator.cmd" ""
if "%choice%"=="75" call :RUN_TOOL "Windows Servicing / Update Health Report" "%~dp030_Assessment_Case\Windows-Servicing-Update-Health-Report.cmd" ""
if "%choice%"=="76" call :RUN_TOOL "Domain Trust / AD Health Investigator" "%~dp030_Assessment_Case\Domain-Trust-AD-Health-Investigator.cmd" ""
goto %ADV_RETURN%

:TOOLS
call :PREP_MENU
if "%SRMODE%"=="1" goto TOOLS_SR_DISPLAY
echo ============================================================
echo                         TOOLS
echo ============================================================
echo.
echo PACKET CAPTURE
echo   1. Start PKTMON Capture [ADMIN]
echo   2. Stop + Convert to PCAPNG [ADMIN]
echo   3. PKTMON Status
echo.
echo SUPPORT / EXPORT
echo   4. Create Support Bundle ZIP
echo   5. Backup Third-Party Drivers [ADMIN] %CAP_DISM%
echo   6. Export Event Logs [ADMIN]
echo   7. Robocopy Recovery Helper
echo.
echo QUICK OPEN
echo   8. Elevated CMD
echo   9. Device Manager
echo  10. Disk Management
echo  11. Event Viewer
echo  12. Network Connections
echo  13. Services
echo.
echo TRUSTED RESOURCES
echo  14. Sysinternals Live
echo  15. Microsoft Update Catalog
echo  16. Windows Release Health
echo  17. Dell Support
echo  18. HP Support
echo  19. Lenovo Support
echo  20. Ninite
echo  21. WinGet Documentation
echo  22. ASUS Support
echo  23. Acer Support
echo  24. MSI Support
echo  25. Microsoft Surface Support
echo  26. Samsung Support
echo  27. Gigabyte Support
echo  28. Framework Support
echo.
echo FIELD HELPERS
echo  29. VirusTotal
echo  30. Have I Been Pwned
echo  31. Speedtest
echo  32. Serial / Service Tag Lookup
echo  33. Copy Machine ID to Clipboard
echo  34. Open Support Page for This PC
echo.
echo TOOLKIT MAINTENANCE
echo  35. Toolkit Self-Test
echo  36. Create Share-Safe Full Machine Report
echo  37. Create Report / Export Index
echo  38. Collect Case Mode
echo  39. Change Comparison Dashboard
echo  40. Case Notes / Technician Notes
echo  41. Case Closeout Report
echo  42. Toolkit Known-Good Integrity / Rebuild
echo  43. Toolkit Foundation Health
echo.
echo  S. Search all toolkit menus.
echo  R. Repeat this menu.
if "%SRMODE%"=="1" (echo  A. Turn Screen Reader Mode off.) else (echo  A. Turn Screen Reader Mode on.)
echo  99. Back to Home.
echo   0. Exit.
echo.
goto TOOLS_PROMPT

:TOOLS_SR_DISPLAY
echo TOOLS MENU.
echo Packet capture, export, Windows consoles, trusted resources, field helpers, and toolkit maintenance.
echo There are 43 numbered tools.
echo Type a number and press Enter.
echo Administrator-required tools are announced in full.
echo.
echo PACKET CAPTURE.
echo  1. Start PKTMON Capture. Administrator required.
echo  2. Stop + Convert to PCAPNG. Administrator required.
echo  3. PKTMON Status.
echo.
echo SUPPORT AND EXPORT.
echo  4. Create Support Bundle ZIP.
echo  5. Backup Third-Party Drivers. Administrator required. Capability %CAP_DISM%.
echo  6. Export Event Logs. Administrator required.
echo  7. Robocopy Recovery Helper.
echo.
echo QUICK OPEN.
echo  8. Elevated CMD.
echo  9. Device Manager.
echo  10. Disk Management.
echo  11. Event Viewer.
echo  12. Network Connections.
echo  13. Services.
echo.
echo TRUSTED RESOURCES.
echo  14. Sysinternals Live.
echo  15. Microsoft Update Catalog.
echo  16. Windows Release Health.
echo  17. Dell Support.
echo  18. HP Support.
echo  19. Lenovo Support.
echo  20. Ninite.
echo  21. WinGet Documentation.
echo  22. ASUS Support.
echo  23. Acer Support.
echo  24. MSI Support.
echo  25. Microsoft Surface Support.
echo  26. Samsung Support.
echo  27. Gigabyte Support.
echo  28. Framework Support.
echo.
echo FIELD HELPERS.
echo  29. VirusTotal.
echo  30. Have I Been Pwned.
echo  31. Speedtest.
echo  32. Serial / Service Tag Lookup.
echo  33. Copy Machine ID to Clipboard.
echo  34. Open Support Page for This PC.
echo.
echo TOOLKIT MAINTENANCE.
echo  35. Toolkit Self-Test.
echo  36. Create Share-Safe Full Machine Report.
echo  37. Create Report / Export Index.
echo  38. Collect Case Mode.
echo  39. Change Comparison Dashboard.
echo  40. Case Notes / Technician Notes.
echo  41. Case Closeout Report.
echo  42. Toolkit Known-Good Integrity / Rebuild.
echo  43. Toolkit Foundation Health. Read-only runtime, capability, logging, session, and interrupted-repair checks.
echo.
echo  S. Search all toolkit menus.
echo  R. Repeat this menu.
if "%SRMODE%"=="1" (echo  A. Turn Screen Reader Mode off.) else (echo  A. Turn Screen Reader Mode on.)
echo  99. Back to Home.
echo   0. Exit.
echo.
:TOOLS_PROMPT
set "choice="
set /p choice=Select an option: 
if /I "%choice%"=="S" call :RUN_TOOL "Toolkit Menu Search" "%~dp026_Tools\Menu-Search.cmd" ""
if /I "%choice%"=="A" (
  call :TOGGLE_SR
  goto TOOLS
)
if /I "%choice%"=="R" goto TOOLS
if "%choice%"=="99" goto HOME
if "%choice%"=="0" goto TOOLKIT_EXIT
if "%choice%"=="1" call :RUN_TOOL "Start PKTMON Capture" "%~dp026_Tools\PKTMON-Start-Capture-ADMIN.cmd" "ADMIN"
if "%choice%"=="2" call :RUN_TOOL "Stop + Convert to PCAPNG" "%~dp026_Tools\PKTMON-Stop-and-Convert-ADMIN.cmd" "ADMIN"
if "%choice%"=="3" call :RUN_TOOL "PKTMON Status" "%~dp026_Tools\PKTMON-Status.cmd" ""
if "%choice%"=="4" call :RUN_TOOL "Create Support Bundle ZIP" "%~dp027_Support_Bundle\CREATE-SUPPORT-BUNDLE.cmd" ""
if "%choice%"=="5" call :RUN_TOOL "Backup Third-Party Drivers" "%~dp004_Logs_and_Backup\Backup-Drivers-ADMIN.cmd" "ADMIN"
if "%choice%"=="6" call :RUN_TOOL "Export Event Logs" "%~dp004_Logs_and_Backup\Export-Event-Logs-ADMIN.cmd" "ADMIN"
if "%choice%"=="7" call :RUN_TOOL "Robocopy Recovery Helper" "%~dp015_Storage_and_Recovery\ROBOCOPY-Recovery-Helper.cmd" ""
if "%choice%"=="8" call :RUN_TOOL "Elevated CMD" "%~dp007_Convenience\Open-Admin-CMD.cmd" ""
if "%choice%"=="9" call :RUN_TOOL "Device Manager" "%~dp007_Convenience\Open-Device-Manager.cmd" ""
if "%choice%"=="10" call :RUN_TOOL "Disk Management" "%~dp007_Convenience\Open-Disk-Management.cmd" ""
if "%choice%"=="11" call :RUN_TOOL "Event Viewer" "%~dp007_Convenience\Open-Event-Viewer.cmd" ""
if "%choice%"=="12" call :RUN_TOOL "Network Connections" "%~dp007_Convenience\Open-Network-Connections.cmd" ""
if "%choice%"=="13" call :RUN_TOOL "Services" "%~dp007_Convenience\Open-Services.cmd" ""
if "%choice%"=="14" call :RUN_TOOL "Sysinternals Live" "%~dp026_Tools\Open-Sysinternals-Live.cmd" ""
if "%choice%"=="15" call :RUN_TOOL "Microsoft Update Catalog" "%~dp026_Tools\Open-Microsoft-Update-Catalog.cmd" ""
if "%choice%"=="16" call :RUN_TOOL "Windows Release Health" "%~dp026_Tools\Open-Windows-Release-Health.cmd" ""
if "%choice%"=="17" call :RUN_TOOL "Dell Support" "%~dp026_Tools\Open-Dell-Support.cmd" ""
if "%choice%"=="18" call :RUN_TOOL "HP Support" "%~dp026_Tools\Open-HP-Support.cmd" ""
if "%choice%"=="19" call :RUN_TOOL "Lenovo Support" "%~dp026_Tools\Open-Lenovo-Support.cmd" ""
if "%choice%"=="20" call :RUN_TOOL "Ninite" "%~dp026_Tools\Open-Ninite.cmd" ""
if "%choice%"=="21" call :RUN_TOOL "WinGet Documentation" "%~dp026_Tools\Open-WinGet-Docs.cmd" ""
if "%choice%"=="22" call :RUN_TOOL "ASUS Support" "%~dp026_Tools\Open-ASUS-Support.cmd" ""
if "%choice%"=="23" call :RUN_TOOL "Acer Support" "%~dp026_Tools\Open-Acer-Support.cmd" ""
if "%choice%"=="24" call :RUN_TOOL "MSI Support" "%~dp026_Tools\Open-MSI-Support.cmd" ""
if "%choice%"=="25" call :RUN_TOOL "Microsoft Surface Support" "%~dp026_Tools\Open-Microsoft-Surface-Support.cmd" ""
if "%choice%"=="26" call :RUN_TOOL "Samsung Support" "%~dp026_Tools\Open-Samsung-Support.cmd" ""
if "%choice%"=="27" call :RUN_TOOL "Gigabyte Support" "%~dp026_Tools\Open-Gigabyte-Support.cmd" ""
if "%choice%"=="28" call :RUN_TOOL "Framework Support" "%~dp026_Tools\Open-Framework-Support.cmd" ""
if "%choice%"=="29" call :RUN_TOOL "VirusTotal" "%~dp026_Tools\Open-VirusTotal.cmd" ""
if "%choice%"=="30" call :RUN_TOOL "Have I Been Pwned" "%~dp026_Tools\Open-HaveIBeenPwned.cmd" ""
if "%choice%"=="31" call :RUN_TOOL "Speedtest" "%~dp026_Tools\Open-Speedtest.cmd" ""
if "%choice%"=="32" call :RUN_TOOL "Serial / Service Tag Lookup" "%~dp026_Tools\Serial-Lookup.cmd" ""
if "%choice%"=="33" call :RUN_TOOL "Copy Machine ID to Clipboard" "%~dp026_Tools\Copy-Machine-ID-To-Clipboard.cmd" ""
if "%choice%"=="34" call :RUN_TOOL "Open Support Page for This PC" "%~dp026_Tools\Open-Support-Page-For-This-PC.cmd" ""
if "%choice%"=="35" call :RUN_TOOL "Toolkit Self-Test" "%~dp026_Tools\Toolkit-Self-Test.cmd" ""
if "%choice%"=="36" call :RUN_TOOL "Create Share-Safe Full Machine Report" "%~dp027_Support_Bundle\Create-Share-Safe-Report.cmd" ""
if "%choice%"=="37" call :RUN_TOOL "Create Report / Export Index" "%~dp026_Tools\Create-Report-Index.cmd" ""
if "%choice%"=="38" call :RUN_TOOL "Collect Case Mode" "%~dp030_Assessment_Case\Collect-Case-Mode.cmd" ""
if "%choice%"=="39" call :RUN_TOOL "Change Comparison Dashboard" "%~dp030_Assessment_Case\Change-Comparison-Dashboard.cmd" ""
if "%choice%"=="40" call :RUN_TOOL "Case Notes / Technician Notes" "%~dp030_Assessment_Case\Case-Technician-Notes.cmd" ""
if "%choice%"=="41" call :RUN_TOOL "Case Closeout Report" "%~dp030_Assessment_Case\Case-Closeout-Report.cmd" ""
if "%choice%"=="42" call :RUN_TOOL "Toolkit Known-Good Integrity / Rebuild" "%~dp026_Tools\Toolkit-Known-Good-Rebuild.cmd" ""
if "%choice%"=="43" call :RUN_TOOL "Toolkit Foundation Health" "%~dp026_Tools\Toolkit-Foundation-Health.cmd" ""
goto TOOLS


:REPAIR
call :PREP_MENU
if "%SRMODE%"=="1" goto REPAIR_SR_DISPLAY
echo ============================================================
echo                         REPAIR
echo ============================================================
echo.
echo CONTROLLED REPAIR / RECOVERY
echo   1. Microsoft Defender Offline Scan      [ADMIN/REBOOT] %CAP_DEFENDER%
echo   2. Restore Point + Repair Safety Backup [ADMIN]
echo   3. Microsoft Store Repair               [ADMIN]
echo   4. Print System Repair                  [ADMIN]
echo   5. Safe Free Space Recovery             [ADMIN]
echo   6. Safe Process Investigation
echo   7. Disk / File-System Health + Repair     [ADMIN]
echo   8. Deep Windows Update Reset              [ADMIN]
echo   9. Windows Repair Chain                   [ADMIN]
echo  10. Driver Recovery                        [ADMIN] %CAP_PNPUTIL%
echo  11. WinRE Repair                           [ADMIN] %CAP_WINRE%
echo  12. Service Recovery                       [ADMIN]
echo  13. DISM Service Center                    [ADMIN] %CAP_DISM%
echo  14. BitLocker Protection Control           [ADMIN] %CAP_BITLOCKER%
echo.
echo These tools can change system state except Process Investigation and scan-only actions.
echo Repair actions explain impact, require confirmation before changes, verify where possible, and are logged.
echo Higher-impact actions require typed confirmation such as RESET, REPAIR, REBOOT, FIX, WINRE, SUSPEND, RESETBASE, REMOVE, REVERT, COMMIT, or DISCARD.
echo.
echo  S. Search all toolkit menus.
echo   R. Repeat this menu.
if "%SRMODE%"=="1" (echo   A. Turn Screen Reader Mode off.) else (echo   A. Turn Screen Reader Mode on.)
echo  99. Back to Home.
echo   0. Exit.
echo.
goto REPAIR_PROMPT

:REPAIR_SR_DISPLAY
echo REPAIR MENU.
echo Controlled state-changing technician repair and recovery tools.
echo Repair actions require confirmation and write to the repair session journal.
echo Safe Process Investigation is read-only.
echo.
echo  1. Microsoft Defender Offline Scan. Administrator required. Reboot expected. Capability %CAP_DEFENDER%.
echo  2. Restore Point and Repair Safety Backup. Administrator required.
echo  3. Microsoft Store Repair. Administrator required.
echo  4. Print System Repair. Administrator required.
echo  5. Safe Free Space Recovery. Administrator required.
echo  6. Safe Process Investigation. Read-only.
echo  7. Disk and File-System Health and Repair. Administrator required.
echo  8. Deep Windows Update Reset. Administrator required.
echo  9. Windows Repair Chain. Administrator required.
echo  10. Driver Recovery. Administrator required. Capability %CAP_PNPUTIL%.
echo  11. Windows Recovery Environment Repair. Administrator required. Capability %CAP_WINRE%.
echo  12. Service Recovery. Administrator required.
echo  13. DISM Service Center. Administrator required. Capability %CAP_DISM%. Includes read-only, repair, source-assisted, offline, and advanced DISM workflows.
echo  14. BitLocker Protection Control. Administrator required. Capability %CAP_BITLOCKER%. Read-only status, temporary 1 to 3 reboot suspension, and explicit resume with verification. Recovery passwords are never displayed.
echo.
echo  S. Search all toolkit menus.
echo  R. Repeat this menu.
echo  A. Turn Screen Reader Mode off.
echo  99. Back to Home.
echo   0. Exit.
echo.

:REPAIR_PROMPT
set "choice="
set /p choice=Select an option: 
if /I "%choice%"=="S" call :RUN_TOOL "Toolkit Menu Search" "%~dp026_Tools\Menu-Search.cmd" ""
if /I "%choice%"=="A" (
  call :TOGGLE_SR
  goto REPAIR
)
if /I "%choice%"=="R" goto REPAIR
if "%choice%"=="99" goto HOME
if "%choice%"=="0" goto TOOLKIT_EXIT
if "%choice%"=="1" call :RUN_TOOL "Microsoft Defender Offline Scan" "%~dp028_Repair\Defender-Offline-Scan-ADMIN.cmd" "ADMINREBOOT"
if "%choice%"=="2" call :RUN_TOOL "Restore Point and Repair Safety Backup" "%~dp028_Repair\Create-Restore-Point-and-Safety-Backup-ADMIN.cmd" "ADMIN"
if "%choice%"=="3" call :RUN_TOOL "Microsoft Store Repair" "%~dp028_Repair\Microsoft-Store-Repair-ADMIN.cmd" "ADMIN"
if "%choice%"=="4" call :RUN_TOOL "Print System Repair" "%~dp028_Repair\Print-System-Repair-ADMIN.cmd" "ADMIN"
if "%choice%"=="5" call :RUN_TOOL "Safe Free Space Recovery" "%~dp028_Repair\Safe-Free-Space-Recovery-ADMIN.cmd" "ADMIN"
if "%choice%"=="6" call :RUN_TOOL "Safe Process Investigation" "%~dp028_Repair\Safe-Process-Investigation.cmd" ""
if "%choice%"=="7" call :RUN_TOOL "Disk and File-System Health and Repair" "%~dp028_Repair\Disk-FileSystem-Health-Repair-ADMIN.cmd" "ADMIN"
if "%choice%"=="8" call :RUN_TOOL "Deep Windows Update Reset" "%~dp028_Repair\Deep-Windows-Update-Reset-ADMIN.cmd" "ADMIN"
if "%choice%"=="9" call :RUN_TOOL "Windows Repair Chain" "%~dp028_Repair\Windows-Repair-Chain-ADMIN.cmd" "ADMIN"
if "%choice%"=="10" call :RUN_TOOL "Driver Recovery" "%~dp028_Repair\Driver-Recovery-ADMIN.cmd" "ADMIN"
if "%choice%"=="11" call :RUN_TOOL "Windows Recovery Environment Repair" "%~dp028_Repair\WinRE-Repair-ADMIN.cmd" "ADMIN"
if "%choice%"=="12" call :RUN_TOOL "Service Recovery" "%~dp028_Repair\Service-Recovery-ADMIN.cmd" "ADMIN"
if "%choice%"=="13" call :RUN_TOOL "DISM Service Center" "%~dp028_Repair\DISM-Service-Center-ADMIN.cmd" "ADMIN"
if "%choice%"=="14" call :RUN_TOOL "BitLocker Protection Control" "%~dp028_Repair\BitLocker-Protection-Control-ADMIN.cmd" "ADMIN"
goto REPAIR

:TOOLKIT_EXIT
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp000_Common\Close-Toolkit-Session.ps1"
set "CLOSEOUT_RC=%errorlevel%"
if exist "%CAPFILE%" del /q "%CAPFILE%" >nul 2>nul
if not "%CLOSEOUT_RC%"=="0" (
  echo.
  echo Toolkit closeout encountered an error.
  echo Details were saved under the toolkit Logs folder.
  echo LAST_EXIT_STATUS.txt and EXIT_ERRORS.jsonl contain the persistent record.
  if "%SRMODE%"=="1" (
    echo Press any key to close the toolkit.
    pause >nul
  ) else (
    pause
  )
  exit /b %CLOSEOUT_RC%
)
exit /b 0

:RELAUNCH_ADMIN
if "%ISADMIN%"=="1" (
  echo.
  echo The toolkit is already running as Administrator.
  if "%SRMODE%"=="1" (
    echo Press any key to return to the Home menu.
    pause >nul
  ) else (
    pause
  )
  goto HOME
)
echo.
echo Requesting Administrator elevation through Windows User Account Control.
if "%SRMODE%"=="1" echo A Windows User Account Control prompt may appear.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp026_Tools\Relaunch-Toolkit-As-Administrator.ps1" -Launcher "%~f0" -ScreenReaderMode "%SRMODE%"
set "RELAUNCH_RC=%errorlevel%"
if "%RELAUNCH_RC%"=="0" (
  echo Elevated toolkit launch requested successfully.
  exit /b 0
)
echo Administrator relaunch was canceled or failed.
if "%SRMODE%"=="1" (
  echo Press any key to return to the Home menu.
  pause >nul
) else (
  pause
)
goto HOME

:REFRESH_CAPS
set "CAP_ADMIN=[UNKNOWN]"
set "CAP_REBOOT=[UNKNOWN]"
set "CAP_DISM=[UNKNOWN]"
set "CAP_SFC=[UNKNOWN]"
set "CAP_CHKDSK=[UNKNOWN]"
set "CAP_PNPUTIL=[UNKNOWN]"
set "CAP_BITLOCKER=[UNKNOWN]"
set "CAP_DEFENDER=[UNKNOWN]"
set "CAP_WINRE=[UNKNOWN]"
set "CAP_WLAN=[UNKNOWN]"
set "CAP_BATTERY=[UNKNOWN]"
set "CAP_TPM=[UNKNOWN]"
set "CAP_SECUREBOOT=[UNKNOWN]"
set "CAP_HYPERV=[UNKNOWN]"
set "CAP_POWERCFG=[UNKNOWN]"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp000_Common\Refresh-Menu-Capabilities.ps1" -OutputCmd "%CAPFILE%" >nul 2>&1
if exist "%CAPFILE%" call "%CAPFILE%"
exit /b 0

:PREP_MENU
if not "%SRMODE%"=="1" cls
exit /b 0

:TOGGLE_SR
if "%SRMODE%"=="1" (
  set "SRMODE=0"
  echo Screen Reader Mode is now OFF.
) else (
  set "SRMODE=1"
  echo Screen Reader Mode is now ON.
  echo Automatic screen clearing is disabled.
  echo Advanced tools will use categorized navigation.
)
exit /b 0

:RUN_TOOL
set "TOOL_NAME=%~1"
set "TOOL_PATH=%~2"
set "TOOL_ACCESS=%~3"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp000_Common\Invoke-Toolkit-MenuTool.ps1" -ToolName "%TOOL_NAME%" -ToolPath "%TOOL_PATH%" -Access "%TOOL_ACCESS%" -Caller "Launcher"
set "TOOL_RC=%errorlevel%"
call :REFRESH_CAPS
exit /b %TOOL_RC%


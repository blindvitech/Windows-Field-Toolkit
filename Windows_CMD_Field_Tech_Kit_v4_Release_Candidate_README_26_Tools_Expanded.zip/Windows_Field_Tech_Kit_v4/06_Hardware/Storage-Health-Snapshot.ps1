$ErrorActionPreference = "SilentlyContinue"
$toolkitRoot = Split-Path $PSScriptRoot -Parent
$logs = Join-Path $toolkitRoot "Logs"
if (-not (Test-Path -LiteralPath $logs)) { New-Item -ItemType Directory -Path $logs -Force | Out-Null }
$writer = Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"
$basePath = Join-Path $logs ($env:COMPUTERNAME + "_Storage_" + (Get-Date -Format "yyyyMMdd_HHmmss"))

$lines = New-Object System.Collections.Generic.List[string]
$lines.Add("STORAGE HEALTH SNAPSHOT")
$lines.Add("Computer: " + $env:COMPUTERNAME)
$lines.Add("Generated: " + (Get-Date))
$lines.Add("")
$lines.Add("FILESYSTEM DRIVES")
$lines.Add(((& fsutil.exe fsinfo drives 2>&1) | Out-String -Width 220).TrimEnd())
$lines.Add("")
$lines.Add("PHYSICAL DISKS")
try {
    $d = Get-PhysicalDisk -ErrorAction Stop |
        Select-Object FriendlyName,MediaType,BusType,HealthStatus,OperationalStatus,@{N="SizeGB";E={[math]::Round($_.Size/1GB,2)}}
    $lines.Add(($d | Format-Table -AutoSize | Out-String -Width 220).TrimEnd())
}
catch { $lines.Add("Unavailable: " + $_.Exception.Message) }
$lines.Add("")
$lines.Add("VOLUMES")
try {
    $v = Get-Volume -ErrorAction Stop |
        Select-Object DriveLetter,FileSystemLabel,FileSystem,HealthStatus,@{N="FreeGB";E={[math]::Round($_.SizeRemaining/1GB,2)}},@{N="SizeGB";E={[math]::Round($_.Size/1GB,2)}}
    $lines.Add(($v | Format-Table -AutoSize | Out-String -Width 220).TrimEnd())
}
catch { $lines.Add("Unavailable: " + $_.Exception.Message) }

& $writer -BasePath $basePath -Title "Storage Health Snapshot" -Body ($lines -join [Environment]::NewLine)
Write-Host ("Report: " + $basePath + ".html")
try { Start-Process -FilePath ($basePath + ".html") } catch {}
exit 0

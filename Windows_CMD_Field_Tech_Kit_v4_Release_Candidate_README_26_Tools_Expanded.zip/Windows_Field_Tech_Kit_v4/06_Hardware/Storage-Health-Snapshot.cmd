@echo off
setlocal EnableExtensions
title Storage Health Snapshot
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Storage-Health-Snapshot.ps1"
set "RC=%errorlevel%"
echo.
if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)
exit /b %RC%

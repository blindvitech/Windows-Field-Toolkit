@echo off
setlocal
title Battery Report
set "LOGDIR=%~dp0..\Logs"
if not exist "%LOGDIR%" mkdir "%LOGDIR%"
set "OUT=%LOGDIR%\%COMPUTERNAME%_BatteryReport.html"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\00_Common\Invoke-Native-Bridge.ps1" -FilePath "powercfg.exe" -Label "Battery Report" /batteryreport /output "%OUT%"
echo.
echo Battery report saved to:
echo %OUT%
if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)
endlocal

@echo off
setlocal EnableExtensions
title User Profile Inventory

echo User Profile Inventory
echo.
echo Running dedicated PowerShell collector...
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0User-Profile-Inventory.ps1"
set "RC=%errorlevel%"

echo.
if "%RC%"=="0" (
    echo User Profile Inventory completed.
) else (
    echo User Profile Inventory returned error code %RC%.
)

if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

exit /b %RC%

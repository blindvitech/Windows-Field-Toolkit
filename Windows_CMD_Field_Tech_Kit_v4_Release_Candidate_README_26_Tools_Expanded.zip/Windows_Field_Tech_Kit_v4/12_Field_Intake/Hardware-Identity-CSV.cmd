@echo off
setlocal EnableExtensions
title Hardware Identity CSV

echo Hardware Identity CSV
echo.
echo Running dedicated PowerShell collector...
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Hardware-Identity-CSV.ps1"
set "RC=%errorlevel%"

echo.
if "%RC%"=="0" (
    echo Hardware Identity CSV completed.
) else (
    echo Hardware Identity CSV returned error code %RC%.
)

if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

exit /b %RC%

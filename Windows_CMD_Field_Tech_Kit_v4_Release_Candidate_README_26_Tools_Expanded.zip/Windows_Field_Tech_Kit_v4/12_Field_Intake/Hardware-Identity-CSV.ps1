$ErrorActionPreference = "SilentlyContinue"
$ProgressPreference = "SilentlyContinue"
$toolkitRoot = Split-Path $PSScriptRoot -Parent
$logs = Join-Path $toolkitRoot "Logs"
if (-not (Test-Path -LiteralPath $logs)) { New-Item -ItemType Directory -Path $logs -Force | Out-Null }
$writer = Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"
$stamp = Get-Date -Format "yyyyMMdd_HHmmss"

$csv = Join-Path $logs ($env:COMPUTERNAME + "_HardwareIdentity_" + $stamp + ".csv")
$cs = Get-CimInstance Win32_ComputerSystem -ErrorAction SilentlyContinue
$bios = Get-CimInstance Win32_BIOS -ErrorAction SilentlyContinue
$board = Get-CimInstance Win32_BaseBoard -ErrorAction SilentlyContinue
$cpu = Get-CimInstance Win32_Processor -ErrorAction SilentlyContinue | Select-Object -First 1
[pscustomobject]@{
    Computer=$env:COMPUTERNAME
    Manufacturer=$cs.Manufacturer
    Model=$cs.Model
    SystemSerial=$bios.SerialNumber
    BIOSVersion=$bios.SMBIOSBIOSVersion
    Motherboard=$board.Product
    BoardSerial=$board.SerialNumber
    CPU=$cpu.Name
    RAMBytes=$cs.TotalPhysicalMemory
} | Export-Csv -LiteralPath $csv -NoTypeInformation -Encoding UTF8
Write-Host ("Saved CSV: " + $csv)
exit 0

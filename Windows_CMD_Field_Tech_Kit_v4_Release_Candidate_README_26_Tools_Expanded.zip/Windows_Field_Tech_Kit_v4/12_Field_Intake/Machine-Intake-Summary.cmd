@echo off
setlocal EnableExtensions
title Machine Intake Summary

echo MACHINE INTAKE SUMMARY
echo.
echo Collecting technician first-look hardware, Windows, security, storage, and network context...
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Machine-Intake-Summary.ps1"
set "RC=%errorlevel%"

echo.
if "%RC%"=="0" (
    echo Machine Intake Summary completed.
) else (
    echo Machine Intake Summary returned error code %RC%.
)

if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

exit /b %RC%

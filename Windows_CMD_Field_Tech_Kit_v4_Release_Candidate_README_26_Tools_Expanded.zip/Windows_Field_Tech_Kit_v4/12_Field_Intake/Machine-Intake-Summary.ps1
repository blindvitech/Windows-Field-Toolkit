$ErrorActionPreference = "SilentlyContinue"
$ProgressPreference = "SilentlyContinue"

$toolkitRoot = Split-Path $PSScriptRoot -Parent
$foundation = Join-Path $toolkitRoot "00_Common\Foundation-Common.ps1"
if (Test-Path -LiteralPath $foundation -PathType Leaf) { . $foundation }
$logs = Join-Path $toolkitRoot "Logs"
if (-not (Test-Path -LiteralPath $logs)) {
    New-Item -ItemType Directory -Path $logs -Force | Out-Null
}

$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$reportBase = Join-Path $logs ($env:COMPUTERNAME + "_MachineIntake_" + $stamp)
$txtPath = $reportBase + ".txt"
$mdPath = $reportBase + ".md"
$htmlPath = $reportBase + ".html"
$writer = Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"

$collector = New-Object System.Collections.Generic.List[object]
$flags = New-Object System.Collections.Generic.List[object]

function Add-Collector {
    param([string]$Name,[string]$Status,[string]$Details)
    $collector.Add([pscustomobject]@{Name=$Name;Status=$Status;Details=$Details})
}

function Add-Flag {
    param(
        [ValidateSet("CRITICAL","REVIEW","INFO")][string]$Severity,
        [string]$Category,
        [string]$Message
    )
    $flags.Add([pscustomobject]@{Severity=$Severity;Category=$Category;Message=$Message})
}

function Text-Or {
    param($Value,[string]$Fallback="Unavailable")
    if ($null -eq $Value) { return $Fallback }
    $text = [string]$Value
    if ([string]::IsNullOrWhiteSpace($text)) { return $Fallback }
    return $text.Trim()
}

function Safe-Cim {
    param([string]$ClassName,[string]$Namespace="root\cimv2",[string]$Label=$ClassName)
    try {
        $v = @(Get-CimInstance -Namespace $Namespace -ClassName $ClassName -ErrorAction Stop)
        Add-Collector $Label "OK" ("Returned " + $v.Count + " object(s)")
        return $v
    }
    catch {
        Add-Collector $Label "UNAVAILABLE" $_.Exception.Message
        return @()
    }
}

function Safe-Command {
    param([string]$Label,[scriptblock]$Script)
    try {
        $value = & $Script
        Add-Collector $Label "OK" "Collected"
        return $value
    }
    catch {
        Add-Collector $Label "UNAVAILABLE" $_.Exception.Message
        return $null
    }
}

function Section {
    param([System.Collections.Generic.List[string]]$Lines,[string]$Title)
    $Lines.Add("")
    $Lines.Add(("=" * 78))
    $Lines.Add($Title)
    $Lines.Add(("=" * 78))
}

function Add-KV {
    param([System.Collections.Generic.List[string]]$Lines,[string]$Key,$Value)
    $Lines.Add(("{0,-28}: {1}" -f $Key,(Text-Or $Value)))
}

function Decode-MonitorString {
    param($Data)
    if ($null -eq $Data) { return "" }
    try {
        $chars = @($Data | Where-Object { $_ -gt 0 } | ForEach-Object { [char]$_ })
        return (($chars -join "")).Trim()
    }
    catch { return "" }
}

function Get-UninstallApps {
    $paths = @(
        "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*",
        "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*",
        "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*"
    )
    $items = New-Object System.Collections.Generic.List[object]
    foreach ($path in $paths) {
        try {
            foreach ($item in @(Get-ItemProperty $path -ErrorAction SilentlyContinue)) {
                if ($item.DisplayName) {
                    $items.Add([pscustomobject]@{
                        Name=[string]$item.DisplayName
                        Version=[string]$item.DisplayVersion
                        Publisher=[string]$item.Publisher
                    })
                }
            }
        }
        catch {}
    }
    return @($items | Sort-Object Name,Version -Unique)
}

Write-Host "Collecting expanded machine intake information..."
Write-Host "This is a compact technician intake, not the full machine report."
Write-Host ""

# ---------------------------------------------------------------------------
# Identity / lifecycle
# ---------------------------------------------------------------------------
$cs = @(Safe-Cim "Win32_ComputerSystem" "root\cimv2" "Computer system") | Select-Object -First 1
$bios = @(Safe-Cim "Win32_BIOS" "root\cimv2" "BIOS") | Select-Object -First 1
$os = @(Safe-Cim "Win32_OperatingSystem" "root\cimv2" "Operating system") | Select-Object -First 1
$cpu = @(Safe-Cim "Win32_Processor" "root\cimv2" "Processor") | Select-Object -First 1
$board = @(Safe-Cim "Win32_BaseBoard" "root\cimv2" "Baseboard") | Select-Object -First 1
$enclosure = @(Safe-Cim "Win32_SystemEnclosure" "root\cimv2" "Chassis") | Select-Object -First 1
$ramModules = @(Safe-Cim "Win32_PhysicalMemory" "root\cimv2" "Physical memory")
$memoryArray = @(Safe-Cim "Win32_PhysicalMemoryArray" "root\cimv2" "Physical memory array") | Select-Object -First 1
$gpus = @(Safe-Cim "Win32_VideoController" "root\cimv2" "Video controllers")
$cv = Safe-Command "Windows CurrentVersion registry" {
    Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion" -ErrorAction Stop
}

$bootTime = $os.LastBootUpTime
$uptimeDays = $null
if ($bootTime) {
    try { $uptimeDays = [math]::Round(((Get-Date) - [datetime]$bootTime).TotalDays,1) } catch {}
}

$biosAgeYears = $null
if ($bios.ReleaseDate) {
    try { $biosAgeYears = [math]::Round(((Get-Date) - [datetime]$bios.ReleaseDate).TotalDays / 365.25,1) } catch {}
}

$chassisMap = @{
    3="Desktop";4="Low Profile Desktop";5="Pizza Box";6="Mini Tower";7="Tower";
    8="Portable";9="Laptop";10="Notebook";11="Hand Held";12="Docking Station";
    13="All in One";14="Sub Notebook";15="Space-Saving";16="Lunch Box";
    30="Tablet";31="Convertible";32="Detachable";35="Mini PC";36="Stick PC"
}
$chassisCode = @($enclosure.ChassisTypes | Select-Object -First 1)
$chassisType = if ($chassisCode -and $chassisMap.ContainsKey([int]$chassisCode[0])) { $chassisMap[[int]$chassisCode[0]] } else { Text-Or $chassisCode "Unknown" }

# ---------------------------------------------------------------------------
# Boot / firmware / TPM / recovery
# ---------------------------------------------------------------------------
$secureBoot = "Unavailable"
$firmwareMode = "Unknown"
try {
    $sb = Confirm-SecureBootUEFI -ErrorAction Stop
    $secureBoot = if ($sb) { "Enabled" } else { "Disabled" }
    $firmwareMode = "UEFI"
    Add-Collector "Secure Boot" "OK" $secureBoot
}
catch {
    $secureBootState = Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\SecureBoot\State" -ErrorAction SilentlyContinue
    if ($null -ne $secureBootState.UEFISecureBootEnabled) {
        $firmwareMode = "UEFI"
        $secureBoot = if ($secureBootState.UEFISecureBootEnabled -eq 1) { "Enabled" } else { "Disabled" }
        Add-Collector "Secure Boot" "OK" $secureBoot
    }
    else {
        Add-Collector "Secure Boot" "UNAVAILABLE" "Secure Boot state not exposed; firmware mode could not be confirmed."
    }
}

$tpm = Safe-Command "TPM" {
    if (Get-Command Get-Tpm -ErrorAction SilentlyContinue) { Get-Tpm -ErrorAction Stop } else { throw "Get-Tpm is unavailable." }
}
$tpmState = if ($tpm) {
    "Present=" + $tpm.TpmPresent + "; Ready=" + $tpm.TpmReady + "; Enabled=" + $tpm.TpmEnabled
} else { "Unavailable" }

$winreOutput = Safe-Command "Windows Recovery Environment" {
    $native = Invoke-ToolkitNativeCommand -FilePath "reagentc.exe" -Arguments @("/info") -Label "Machine Intake WinRE Status" -Action "Machine Intake" -Quiet
    (($native.Output -join [Environment]::NewLine) | Out-String -Width 220).Trim()
}
$winreStatus = "Unavailable"
$winreLocation = "Unavailable"
if ($winreOutput) {
    $m = [regex]::Match([string]$winreOutput,"(?im)Windows RE status:\s*(.+)$")
    if ($m.Success) { $winreStatus = $m.Groups[1].Value.Trim() }
    $m = [regex]::Match([string]$winreOutput,"(?im)Windows RE location:\s*(.+)$")
    if ($m.Success) { $winreLocation = $m.Groups[1].Value.Trim() }
}

# ---------------------------------------------------------------------------
# Storage / disk health / encryption
# ---------------------------------------------------------------------------
$disks = @(Safe-Command "Storage disks" { Get-Disk -ErrorAction Stop })
if ($null -eq $disks) { $disks = @() }
$physicalDisks = @(Safe-Command "Physical disks" { Get-PhysicalDisk -ErrorAction Stop })
if ($null -eq $physicalDisks) { $physicalDisks = @() }
$volumes = @(Safe-Command "Volumes" { Get-Volume -ErrorAction Stop | Where-Object { $_.DriveLetter } })
if ($null -eq $volumes) { $volumes = @() }
$partitions = @(Safe-Command "Partitions" { Get-Partition -ErrorAction Stop })
if ($null -eq $partitions) { $partitions = @() }

if ($disks.Count -eq 0) {
    $diskFallback = @(Safe-Cim "Win32_DiskDrive" "root\cimv2" "Disk fallback")
}
else {
    $diskFallback = @()
}

$systemDrive = if ($env:SystemDrive) { $env:SystemDrive.TrimEnd(":") } else { "C" }
$systemVolume = @($volumes | Where-Object DriveLetter -eq $systemDrive | Select-Object -First 1)
$systemFreePct = $null
if ($systemVolume -and $systemVolume.Size -gt 0) {
    $systemFreePct = [math]::Round(($systemVolume.SizeRemaining / $systemVolume.Size) * 100,1)
}

$bitLocker = Safe-Command "BitLocker" {
    if (Get-Command Get-BitLockerVolume -ErrorAction SilentlyContinue) {
        Get-BitLockerVolume -MountPoint ($systemDrive + ":") -ErrorAction Stop
    }
    else { throw "Get-BitLockerVolume is unavailable." }
}
$bitLockerState = if ($bitLocker) {
    "Protection=" + $bitLocker.ProtectionStatus + "; Volume=" + $bitLocker.VolumeStatus + "; Method=" + $bitLocker.EncryptionMethod
} else { "Unavailable" }

$reliabilityRows = New-Object System.Collections.Generic.List[object]
foreach ($pd in $physicalDisks) {
    $rel = $null
    try { $rel = $pd | Get-StorageReliabilityCounter -ErrorAction Stop } catch {}
    $reliabilityRows.Add([pscustomobject]@{
        Name=$pd.FriendlyName
        MediaType=$pd.MediaType
        BusType=$pd.BusType
        Health=$pd.HealthStatus
        OperationalStatus=($pd.OperationalStatus -join ", ")
        Temperature=$(if($rel){$rel.Temperature}else{$null})
        Wear=$(if($rel){$rel.Wear}else{$null})
        ReadErrorsTotal=$(if($rel){$rel.ReadErrorsTotal}else{$null})
        WriteErrorsTotal=$(if($rel){$rel.WriteErrorsTotal}else{$null})
        PowerOnHours=$(if($rel){$rel.PowerOnHours}else{$null})
    })
}
if ($physicalDisks.Count -gt 0) {
    Add-Collector "Storage reliability counters" $(if($reliabilityRows.Count -gt 0){"OK"}else{"UNAVAILABLE"}) ("Rows: " + $reliabilityRows.Count)
}

# ---------------------------------------------------------------------------
# Network / time
# ---------------------------------------------------------------------------
$netConfigs = @(Safe-Command "Active network configuration" {
    Get-NetIPConfiguration -ErrorAction Stop | Where-Object { $_.NetAdapter.Status -eq "Up" }
})
if ($null -eq $netConfigs) { $netConfigs = @() }

$netProfiles = @(Safe-Command "Network profiles" { Get-NetConnectionProfile -ErrorAction Stop })
if ($null -eq $netProfiles) { $netProfiles = @() }

$nicCim = @(Safe-Cim "Win32_NetworkAdapterConfiguration" "root\cimv2" "Network adapter configuration")
$defaultRoute = Safe-Command "Default IPv4 route" {
    Get-NetRoute -DestinationPrefix "0.0.0.0/0" -ErrorAction Stop |
        Sort-Object RouteMetric,InterfaceMetric |
        Select-Object -First 1
}
$gateway = if ($defaultRoute) { $defaultRoute.NextHop } else { "" }

$gatewayReachable = "Not tested"
if ($gateway -and $gateway -ne "0.0.0.0") {
    try {
        $gatewayReachable = if (Test-Connection -ComputerName $gateway -Count 1 -Quiet -ErrorAction Stop) { "PASS" } else { "NO REPLY" }
        Add-Collector "Gateway reachability" "OK" $gatewayReachable
    }
    catch {
        $gatewayReachable = "Unavailable"
        Add-Collector "Gateway reachability" "UNAVAILABLE" $_.Exception.Message
    }
}

$dnsTest = "Not tested"
try {
    $dnsResult = Resolve-DnsName "www.microsoft.com" -Type A -DnsOnly -ErrorAction Stop | Select-Object -First 1
    $dnsTest = if ($dnsResult.IPAddress) { "PASS (" + $dnsResult.IPAddress + ")" } else { "PASS" }
    Add-Collector "DNS sanity test" "OK" $dnsTest
}
catch {
    $dnsTest = "FAIL / unavailable"
    Add-Collector "DNS sanity test" "UNAVAILABLE" $_.Exception.Message
}

$httpsTest = "Not tested"
try {
    $resp = Invoke-WebRequest -Uri "https://www.msftconnecttest.com/connecttest.txt" -UseBasicParsing -TimeoutSec 5 -ErrorAction Stop
    $httpsTest = if ($resp.StatusCode -ge 200 -and $resp.StatusCode -lt 400) { "PASS (HTTP " + $resp.StatusCode + ")" } else { "HTTP " + $resp.StatusCode }
    Add-Collector "HTTPS sanity test" "OK" $httpsTest
}
catch {
    $httpsTest = "Unavailable / blocked"
    Add-Collector "HTTPS sanity test" "UNAVAILABLE" $_.Exception.Message
}

$wifiSSID = "Not connected / unavailable"
try {
    $wlanNative = Invoke-ToolkitNativeCommand -FilePath "netsh.exe" -Arguments @("wlan","show","interfaces") -Label "Machine Intake WLAN Interfaces" -Action "Machine Intake" -Quiet
    $wlan = ($wlanNative.Output -join [Environment]::NewLine) | Out-String -Width 220
    $ssidMatch = [regex]::Match($wlan,"(?im)^\s*SSID\s*:\s*(.+)$")
    if ($ssidMatch.Success) { $wifiSSID = $ssidMatch.Groups[1].Value.Trim() }
    Add-Collector "Wi-Fi interface" "OK" $wifiSSID
}
catch {
    Add-Collector "Wi-Fi interface" "UNAVAILABLE" $_.Exception.Message
}

$tz = Safe-Command "Time zone" { Get-TimeZone -ErrorAction Stop }
$timeStatus = Safe-Command "Windows Time status" {
    $native = Invoke-ToolkitNativeCommand -FilePath "w32tm.exe" -Arguments @("/query","/status") -Label "Machine Intake Windows Time" -Action "Machine Intake" -Quiet
    (($native.Output -join [Environment]::NewLine) | Out-String -Width 220).Trim()
}
$timeSource = "Unavailable"
if ($timeStatus) {
    $m = [regex]::Match([string]$timeStatus,"(?im)^Source:\s*(.+)$")
    if ($m.Success) { $timeSource = $m.Groups[1].Value.Trim() }
}

$proxy = Safe-Command "WinHTTP proxy" {
    $native = Invoke-ToolkitNativeCommand -FilePath "netsh.exe" -Arguments @("winhttp","show","proxy") -Label "Machine Intake WinHTTP Proxy" -Action "Machine Intake" -Quiet
    (($native.Output -join [Environment]::NewLine) | Out-String -Width 220).Trim()
}

# ---------------------------------------------------------------------------
# Security / activation / reboot
# ---------------------------------------------------------------------------
$defender = Safe-Command "Microsoft Defender" {
    if (Get-Command Get-MpComputerStatus -ErrorAction SilentlyContinue) { Get-MpComputerStatus -ErrorAction Stop } else { throw "Get-MpComputerStatus is unavailable." }
}
$defenderState = if ($defender) {
    "AV=" + $defender.AntivirusEnabled + "; RealTime=" + $defender.RealTimeProtectionEnabled + "; Signatures=" + (Text-Or $defender.AntivirusSignatureVersion)
} else { "Unavailable" }

$firewall = @(Safe-Command "Windows Firewall profiles" { Get-NetFirewallProfile -ErrorAction Stop })
if ($null -eq $firewall) { $firewall = @() }
$firewallSummary = if ($firewall.Count -gt 0) {
    (@($firewall | ForEach-Object { $_.Name + "=" + $(if($_.Enabled){"On"}else{"Off"}) })) -join "; "
} else { "Unavailable" }

$uac = Safe-Command "UAC" {
    Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -ErrorAction Stop
}
$uacState = if ($uac) { "EnableLUA=" + $uac.EnableLUA + "; ConsentPromptBehaviorAdmin=" + $uac.ConsentPromptBehaviorAdmin } else { "Unavailable" }

$activation = Safe-Command "Windows activation" {
    Get-CimInstance SoftwareLicensingProduct -ErrorAction Stop |
        Where-Object { $_.PartialProductKey -and $_.Name -match "^Windows" } |
        Sort-Object LicenseStatus -Descending |
        Select-Object -First 1
}
$activationState = "Unavailable"
if ($activation) {
    $licenseMap = @{0="Unlicensed";1="Licensed";2="OOBGrace";3="OOTGrace";4="NonGenuineGrace";5="Notification";6="ExtendedGrace"}
    $licenseText = if ($licenseMap.ContainsKey([int]$activation.LicenseStatus)) { $licenseMap[[int]$activation.LicenseStatus] } else { [string]$activation.LicenseStatus }
    $activationState = $licenseText + "; Channel=" + (Text-Or $activation.Description) + "; Partial=" + (Text-Or $activation.PartialProductKey)
}

$pending = [ordered]@{}
$pending.CBS = Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending"
$pending.WindowsUpdate = Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired"
$pending.PendingFileRename = $null -ne (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager" -Name PendingFileRenameOperations -ErrorAction SilentlyContinue).PendingFileRenameOperations
$pendingReasons = @($pending.GetEnumerator() | Where-Object Value | ForEach-Object Key)
$pendingReboot = if ($pendingReasons.Count -gt 0) { "YES (" + ($pendingReasons -join ", ") + ")" } else { "No common pending-reboot indicators detected" }
Add-Collector "Pending reboot indicators" "OK" $pendingReboot

# ---------------------------------------------------------------------------
# User / join / management context
# ---------------------------------------------------------------------------
$dsreg = Safe-Command "Entra / domain registration" {
    (& dsregcmd.exe /status 2>&1 | Out-String -Width 240)
}
$azureAdJoined = "Unavailable"
$domainJoined = if ($cs.PartOfDomain) { "YES (" + $cs.Domain + ")" } else { "No" }
$workplaceJoined = "Unavailable"
$mdmClue = "Unavailable"
if ($dsreg) {
    foreach ($pair in @(
        @("AzureAdJoined","AzureAdJoined"),
        @("DomainJoined","DomainJoined"),
        @("WorkplaceJoined","WorkplaceJoined"),
        @("MdmUrl","MdmUrl")
    )) {
        $m = [regex]::Match([string]$dsreg,"(?im)^\s*" + [regex]::Escape($pair[0]) + "\s*:\s*(.+)$")
        if ($m.Success) {
            switch ($pair[1]) {
                "AzureAdJoined" { $azureAdJoined=$m.Groups[1].Value.Trim() }
                "DomainJoined" { if ($m.Groups[1].Value.Trim() -eq "YES") { $domainJoined="YES (" + (Text-Or $cs.Domain) + ")" } }
                "WorkplaceJoined" { $workplaceJoined=$m.Groups[1].Value.Trim() }
                "MdmUrl" { $mdmClue=$(if([string]::IsNullOrWhiteSpace($m.Groups[1].Value)){"Not shown"}else{"Present"}) }
            }
        }
    }
}

$profiles = @(Safe-Cim "Win32_UserProfile" "root\cimv2" "User profiles" | Where-Object { -not $_.Special })
$localAdmins = @(Safe-Command "Local Administrators" {
    if (Get-Command Get-LocalGroupMember -ErrorAction SilentlyContinue) {
        Get-LocalGroupMember -Group "Administrators" -ErrorAction Stop
    }
    else { throw "Get-LocalGroupMember is unavailable." }
})
if ($null -eq $localAdmins) { $localAdmins=@() }

$enrollmentCount = 0
try {
    $enrollments = @(Get-ChildItem "HKLM:\SOFTWARE\Microsoft\Enrollments" -ErrorAction Stop)
    $enrollmentCount = $enrollments.Count
    Add-Collector "MDM enrollment registry" "OK" ("Enrollment keys: " + $enrollmentCount)
}
catch {
    Add-Collector "MDM enrollment registry" "UNAVAILABLE" $_.Exception.Message
}

# ---------------------------------------------------------------------------
# Power / battery
# ---------------------------------------------------------------------------
$batteries = @(Safe-Cim "Win32_Battery" "root\cimv2" "Battery")
$batteryDesign = @(Safe-Cim "BatteryStaticData" "root\wmi" "Battery design capacity") | Select-Object -First 1
$batteryFull = @(Safe-Cim "BatteryFullChargedCapacity" "root\wmi" "Battery full-charge capacity") | Select-Object -First 1
$batteryCycle = @(Safe-Cim "BatteryCycleCount" "root\wmi" "Battery cycle count") | Select-Object -First 1
$batteryWearPct = $null
if ($batteryDesign.DesignedCapacity -and $batteryFull.FullChargedCapacity -and $batteryDesign.DesignedCapacity -gt 0) {
    $batteryWearPct = [math]::Round((1 - ([double]$batteryFull.FullChargedCapacity / [double]$batteryDesign.DesignedCapacity)) * 100,1)
}
$powerPlan = Safe-Command "Active power plan" {
    $native = Invoke-ToolkitNativeCommand -FilePath "powercfg.exe" -Arguments @("/getactivescheme") -Label "Machine Intake Active Power Scheme" -Action "Machine Intake" -Quiet
    (($native.Output -join [Environment]::NewLine) | Out-String -Width 220).Trim()
}

# ---------------------------------------------------------------------------
# Displays / audio / peripherals / USB
# ---------------------------------------------------------------------------
$monitorIds = @(Safe-Cim "WmiMonitorID" "root\wmi" "Monitor identity")
$monitorRows = New-Object System.Collections.Generic.List[object]
foreach ($m in $monitorIds) {
    $name = Decode-MonitorString $m.UserFriendlyName
    if (-not $name) { $name = Decode-MonitorString $m.ManufacturerName }
    $serial = Decode-MonitorString $m.SerialNumberID
    $monitorRows.Add([pscustomobject]@{Name=(Text-Or $name "Unnamed monitor");Serial=(Text-Or $serial "Unavailable");Active=$m.Active})
}

$sound = @(Safe-Cim "Win32_SoundDevice" "root\cimv2" "Audio devices")
$printers = @(Safe-Cim "Win32_Printer" "root\cimv2" "Printers")
$defaultPrinter = @($printers | Where-Object Default | Select-Object -First 1)

$pnpPresent = @(Safe-Command "Present PnP devices" {
    if (Get-Command Get-PnpDevice -ErrorAction SilentlyContinue) { Get-PnpDevice -PresentOnly -ErrorAction Stop } else { throw "Get-PnpDevice is unavailable." }
})
if ($null -eq $pnpPresent) { $pnpPresent=@() }
$problemDevices = @($pnpPresent | Where-Object Status -ne "OK")
$dockLike = @($pnpPresent | Where-Object { $_.FriendlyName -match "(?i)\bdock(ing)?\b" } | Select-Object -ExpandProperty FriendlyName -Unique)
$usbStorage = @($pnpPresent | Where-Object {
    ($_.Class -eq "DiskDrive" -and $_.InstanceId -match "^USB") -or
    ($_.FriendlyName -match "(?i)USB.*(disk|storage|drive)")
} | Select-Object FriendlyName,Class,InstanceId)

# ---------------------------------------------------------------------------
# Software quick look / endpoint protection / remote support
# ---------------------------------------------------------------------------
$apps = @(Safe-Command "Installed applications quick index" { Get-UninstallApps })
if ($null -eq $apps) { $apps=@() }

$browserRows = New-Object System.Collections.Generic.List[object]
$browserCandidates = @(
    @("Microsoft Edge","${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe"),
    @("Microsoft Edge","$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe"),
    @("Google Chrome","$env:ProgramFiles\Google\Chrome\Application\chrome.exe"),
    @("Google Chrome","${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe"),
    @("Mozilla Firefox","$env:ProgramFiles\Mozilla Firefox\firefox.exe"),
    @("Mozilla Firefox","${env:ProgramFiles(x86)}\Mozilla Firefox\firefox.exe"),
    @("Brave","$env:ProgramFiles\BraveSoftware\Brave-Browser\Application\brave.exe"),
    @("Brave","${env:ProgramFiles(x86)}\BraveSoftware\Brave-Browser\Application\brave.exe")
)
$seenBrowser = @{}
foreach ($candidate in $browserCandidates) {
    $name=$candidate[0];$path=$candidate[1]
    if ($path -and (Test-Path -LiteralPath $path) -and -not $seenBrowser.ContainsKey($name)) {
        try {
            $browserRows.Add([pscustomobject]@{Name=$name;Version=(Get-Item -LiteralPath $path).VersionInfo.ProductVersion})
            $seenBrowser[$name]=$true
        }
        catch {}
    }
}
Add-Collector "Browser quick versions" "OK" ("Detected: " + $browserRows.Count)

$officeApps = @($apps | Where-Object { $_.Name -match "(?i)Microsoft 365|Microsoft Office|Office Professional|Office Standard" } | Select-Object -First 5)
$remoteApps = @($apps | Where-Object {
    $_.Name -match "(?i)TeamViewer|AnyDesk|ScreenConnect|ConnectWise|Splashtop|BeyondTrust|Bomgar|LogMeIn|GoToAssist|DWService|RustDesk|Atera|Kaseya|N-able|Ninja"
} | Select-Object -First 20)

$avProducts = @(Safe-Command "Registered antivirus products" {
    Get-CimInstance -Namespace "root\SecurityCenter2" -ClassName AntiVirusProduct -ErrorAction Stop |
        Select-Object displayName,pathToSignedProductExe,productState
})
if ($null -eq $avProducts) { $avProducts=@() }

# ---------------------------------------------------------------------------
# Updates / recent stability / startup pressure
# ---------------------------------------------------------------------------
$hotfixes = @(Safe-Command "Installed hotfixes" { Get-HotFix -ErrorAction Stop | Sort-Object InstalledOn -Descending })
if ($null -eq $hotfixes) { $hotfixes=@() }
$latestHotfix = @($hotfixes | Where-Object InstalledOn | Select-Object -First 1)

$since = (Get-Date).AddDays(-7)
$systemEvents = @(Safe-Command "Recent System stability events" {
    Get-WinEvent -FilterHashtable @{LogName="System";StartTime=$since;Level=1,2} -MaxEvents 1000 -ErrorAction Stop
})
if ($null -eq $systemEvents) { $systemEvents=@() }

$appEvents = @(Safe-Command "Recent Application stability events" {
    Get-WinEvent -FilterHashtable @{LogName="Application";StartTime=$since;Level=1,2} -MaxEvents 500 -ErrorAction Stop
})
if ($null -eq $appEvents) { $appEvents=@() }

$unexpectedShutdownCount = @($systemEvents | Where-Object { $_.Id -in 41,6008 }).Count
$hardwareEventCount = @($systemEvents | Where-Object {
    $_.ProviderName -match "(?i)WHEA|disk|ntfs|storahci|stornvme|volmgr|volsnap|display"
}).Count
$appCrashCount = @($appEvents | Where-Object { $_.Id -in 1000,1001,1002 }).Count

$wuFailures = 0
try {
    $wuEvents = @(Get-WinEvent -FilterHashtable @{LogName="Microsoft-Windows-WindowsUpdateClient/Operational";StartTime=$since;Level=1,2} -MaxEvents 200 -ErrorAction Stop)
    $wuFailures = $wuEvents.Count
    Add-Collector "Recent Windows Update failures" "OK" ("Count: " + $wuFailures)
}
catch {
    Add-Collector "Recent Windows Update failures" "UNAVAILABLE" $_.Exception.Message
}

$startup = @(Safe-Cim "Win32_StartupCommand" "root\cimv2" "Startup commands")
$autoServices = @(Safe-Command "Automatic services" {
    Get-CimInstance Win32_Service -ErrorAction Stop | Where-Object StartMode -eq "Auto"
})
if ($null -eq $autoServices) { $autoServices=@() }
$stoppedAutoServices = @($autoServices | Where-Object State -ne "Running")

# ---------------------------------------------------------------------------
# Assessments / attention flags
# ---------------------------------------------------------------------------
if ($systemFreePct -ne $null) {
    if ($systemFreePct -lt 8) { Add-Flag "CRITICAL" "Storage" ("System volume free space is only " + $systemFreePct + "%.") }
    elseif ($systemFreePct -lt 15) { Add-Flag "REVIEW" "Storage" ("System volume free space is " + $systemFreePct + "%.") }
}
foreach ($disk in $disks) {
    if ($disk.HealthStatus -and [string]$disk.HealthStatus -notmatch "(?i)^Healthy$") {
        Add-Flag "CRITICAL" "Hardware" ("Disk " + $disk.Number + " health reports " + $disk.HealthStatus + ".")
    }
}
foreach ($pd in $physicalDisks) {
    if ($pd.HealthStatus -and [string]$pd.HealthStatus -notmatch "(?i)^Healthy$") {
        Add-Flag "CRITICAL" "Hardware" ("Physical disk " + $pd.FriendlyName + " health reports " + $pd.HealthStatus + ".")
    }
}
if ($problemDevices.Count -gt 0) { Add-Flag "REVIEW" "Hardware" ($problemDevices.Count.ToString() + " present PnP device(s) are not reporting OK.") }
if ($hardwareEventCount -gt 0) { Add-Flag "REVIEW" "Hardware" ($hardwareEventCount.ToString() + " hardware/storage/display-oriented System error event(s) found in the last 7 days.") }

if ($uptimeDays -ne $null -and $uptimeDays -ge 30) { Add-Flag "REVIEW" "Windows" ("Uptime is " + $uptimeDays + " days.") }
if ($pendingReasons.Count -gt 0) { Add-Flag "REVIEW" "Windows" ("Pending reboot indicators: " + ($pendingReasons -join ", ") + ".") }
if ($unexpectedShutdownCount -gt 0) { Add-Flag "REVIEW" "Windows" ($unexpectedShutdownCount.ToString() + " unexpected shutdown / Kernel-Power event(s) found in the last 7 days.") }
if ($appCrashCount -gt 0) { Add-Flag "INFO" "Windows" ($appCrashCount.ToString() + " application crash/hang event(s) found in the last 7 days.") }
if ($wuFailures -gt 0) { Add-Flag "REVIEW" "Windows" ($wuFailures.ToString() + " Windows Update error event(s) found in the last 7 days.") }

if ($defender) {
    if (-not $defender.AntivirusEnabled) { Add-Flag "CRITICAL" "Security" "Microsoft Defender Antivirus reports disabled." }
    elseif (-not $defender.RealTimeProtectionEnabled) { Add-Flag "REVIEW" "Security" "Microsoft Defender real-time protection reports disabled." }
}
if (@($firewall | Where-Object { -not $_.Enabled }).Count -gt 0) {
    Add-Flag "REVIEW" "Security" "One or more Windows Firewall profiles report disabled."
}
if ($secureBoot -eq "Disabled") { Add-Flag "REVIEW" "Security" "Secure Boot is disabled." }
if ($tpm -and -not $tpm.TpmReady) { Add-Flag "REVIEW" "Security" "TPM is present but not ready." }
if ($bitLocker -and [string]$bitLocker.ProtectionStatus -notmatch "(?i)On") { Add-Flag "REVIEW" "Security" "System volume BitLocker protection is not On." }
if ($activation -and [int]$activation.LicenseStatus -ne 1) { Add-Flag "REVIEW" "Windows" ("Windows activation state is " + $licenseText + ".") }

if ($gateway -and $gatewayReachable -eq "NO REPLY") { Add-Flag "INFO" "Network" ("Default gateway " + $gateway + " did not answer one ICMP probe; this is not definitive because ICMP may be filtered.") }
if ($dnsTest -like "FAIL*") { Add-Flag "REVIEW" "Network" "DNS sanity test did not succeed." }
if ($httpsTest -like "Unavailable*") { Add-Flag "INFO" "Network" "HTTPS connectivity sanity test was unavailable or blocked." }

if ($batteryWearPct -ne $null) {
    if ($batteryWearPct -ge 40) { Add-Flag "REVIEW" "Hardware" ("Battery wear is approximately " + $batteryWearPct + "% based on design vs full-charge capacity.") }
    elseif ($batteryWearPct -ge 20) { Add-Flag "INFO" "Hardware" ("Battery wear is approximately " + $batteryWearPct + "%.") }
}

if ($biosAgeYears -ne $null -and $biosAgeYears -ge 6) {
    Add-Flag "INFO" "Hardware" ("BIOS release-date age clue is approximately " + $biosAgeYears + " years; this is not the purchase date.")
}
if ($ramModules.Count -gt 1) {
    $ramSizes = @($ramModules | ForEach-Object Capacity | Where-Object { $_ } | Sort-Object -Unique)
    $ramSpeeds = @($ramModules | ForEach-Object ConfiguredClockSpeed | Where-Object { $_ } | Sort-Object -Unique)
    if ($ramSizes.Count -gt 1 -or $ramSpeeds.Count -gt 1) {
        Add-Flag "INFO" "Hardware" "Mixed DIMM capacities and/or configured memory speeds were detected; this can be intentional."
    }
}
if ($os.Caption -match "(?i)Windows 10" -and $os.Caption -notmatch "(?i)LTSC|LTSB|IoT") {
    Add-Flag "INFO" "Windows" "Windows 10 non-LTSC edition detected; verify the servicing/support lifecycle for this edition."
}
if ($stoppedAutoServices.Count -gt 0) {
    Add-Flag "INFO" "Windows" ($stoppedAutoServices.Count.ToString() + " automatic service(s) are currently stopped; context is required.")
}

function Get-CategoryVerdict {
    param([string]$Category)
    $categoryFlags=@($flags | Where-Object Category -eq $Category)
    if (@($categoryFlags | Where-Object Severity -eq "CRITICAL").Count -gt 0) { return "CRITICAL" }
    if (@($categoryFlags | Where-Object Severity -eq "REVIEW").Count -gt 0) { return "REVIEW" }
    return "PASS"
}

$hardwareVerdict = Get-CategoryVerdict "Hardware"
$windowsVerdict = Get-CategoryVerdict "Windows"
$securityVerdict = Get-CategoryVerdict "Security"
$storageVerdict = Get-CategoryVerdict "Storage"
$networkVerdict = Get-CategoryVerdict "Network"

$overall = if (@($flags | Where-Object Severity -eq "CRITICAL").Count -gt 0) { "CRITICAL" }
    elseif (@($flags | Where-Object Severity -eq "REVIEW").Count -gt 0) { "REVIEW" }
    else { "PASS" }

# ---------------------------------------------------------------------------
# Plain-text / Markdown body
# ---------------------------------------------------------------------------
$lines = New-Object System.Collections.Generic.List[string]
$lines.Add("MACHINE INTAKE SUMMARY")
$lines.Add("Generated: " + (Get-Date))
$lines.Add("Computer: " + (Text-Or $env:COMPUTERNAME))
$lines.Add("Purpose: quick technician intake / first-look triage. Not a compliance report.")
$lines.Add("")

Section $lines "TECHNICIAN QUICK VERDICT"
Add-KV $lines "Overall" $overall
Add-KV $lines "Hardware" $hardwareVerdict
Add-KV $lines "Windows" $windowsVerdict
Add-KV $lines "Security" $securityVerdict
Add-KV $lines "Storage" $storageVerdict
Add-KV $lines "Network" $networkVerdict
Add-KV $lines "Attention items" $flags.Count

if ($flags.Count -gt 0) {
    Section $lines "ATTENTION / REVIEW ITEMS"
    foreach ($flag in $flags | Sort-Object @{Expression={switch($_.Severity){"CRITICAL"{0}"REVIEW"{1}default{2}}}},Category,Message) {
        $lines.Add(("[" + $flag.Severity + "] [" + $flag.Category + "] " + $flag.Message))
    }
}
else {
    Section $lines "ATTENTION / REVIEW ITEMS"
    $lines.Add("No intake-level review flags were raised by the collectors that returned data.")
}

Section $lines "SYSTEM IDENTITY / LIFECYCLE"
Add-KV $lines "Computer" $env:COMPUTERNAME
Add-KV $lines "Manufacturer" $cs.Manufacturer
Add-KV $lines "Model" $cs.Model
Add-KV $lines "System SKU" $cs.SystemSKUNumber
Add-KV $lines "Serial / service tag" $bios.SerialNumber
Add-KV $lines "Chassis type" $chassisType
Add-KV $lines "Baseboard" (($board.Manufacturer + " " + $board.Product).Trim())
Add-KV $lines "Baseboard serial" $board.SerialNumber
Add-KV $lines "BIOS version" $bios.SMBIOSBIOSVersion
Add-KV $lines "BIOS release date" $bios.ReleaseDate
Add-KV $lines "BIOS age clue (years)" $biosAgeYears
Add-KV $lines "Windows" $(if($os.Caption){$os.Caption}else{$cv.ProductName})
Add-KV $lines "Display version" $cv.DisplayVersion
Add-KV $lines "Version / build" (($os.Version + " / " + $os.BuildNumber + "." + (Text-Or $cv.UBR "")).TrimEnd("."))
Add-KV $lines "Architecture" $os.OSArchitecture
Add-KV $lines "Install date" $os.InstallDate
Add-KV $lines "Last boot" $bootTime
Add-KV $lines "Uptime days" $uptimeDays
Add-KV $lines "Current user" ($env:USERDOMAIN + "\" + $env:USERNAME)
Add-KV $lines "Profile path" $env:USERPROFILE

Section $lines "CORE HARDWARE"
Add-KV $lines "CPU" $cpu.Name
Add-KV $lines "Physical cores" $cpu.NumberOfCores
Add-KV $lines "Logical processors" $cpu.NumberOfLogicalProcessors
Add-KV $lines "Installed RAM GB" $(if($cs.TotalPhysicalMemory){[math]::Round([double]$cs.TotalPhysicalMemory/1GB,1)}else{$null})
Add-KV $lines "Memory modules" $ramModules.Count
Add-KV $lines "Memory slots reported" $memoryArray.MemoryDevices
if ($ramModules.Count -gt 0) {
    foreach ($m in $ramModules) {
        $lines.Add(("  DIMM: {0} GB | {1} MHz | {2} | {3}" -f
            $(if($m.Capacity){[math]::Round([double]$m.Capacity/1GB,1)}else{"?"}),
            (Text-Or $m.ConfiguredClockSpeed),
            (Text-Or $m.Manufacturer),
            (Text-Or $m.PartNumber)))
    }
}
if ($gpus.Count -gt 0) {
    foreach ($gpu in $gpus) {
        $lines.Add(("  GPU: " + (Text-Or $gpu.Name) + " | Driver " + (Text-Or $gpu.DriverVersion) +
            " | Current " + (Text-Or $gpu.CurrentHorizontalResolution "?") + "x" +
            (Text-Or $gpu.CurrentVerticalResolution "?") + " @ " + (Text-Or $gpu.CurrentRefreshRate "?") + " Hz"))
    }
}
Add-KV $lines "TPM" $tpmState

Section $lines "STORAGE / ENCRYPTION"
if ($disks.Count -gt 0) {
    foreach ($d in $disks) {
        $lines.Add(("Disk {0}: {1} | {2} GB | {3} | {4} | Health={5} | Status={6}" -f
            $d.Number,(Text-Or $d.FriendlyName),
            $(if($d.Size){[math]::Round([double]$d.Size/1GB,1)}else{"?"}),
            (Text-Or $d.BusType),(Text-Or $d.PartitionStyle),(Text-Or $d.HealthStatus),
            (($d.OperationalStatus -join ", "))))
    }
}
elseif ($diskFallback.Count -gt 0) {
    foreach ($d in $diskFallback) {
        $lines.Add(("Disk: {0} | {1} GB | Interface={2} | Status={3}" -f
            (Text-Or $d.Model),$(if($d.Size){[math]::Round([double]$d.Size/1GB,1)}else{"?"}),
            (Text-Or $d.InterfaceType),(Text-Or $d.Status)))
    }
}
if ($reliabilityRows.Count -gt 0) {
    $lines.Add("")
    $lines.Add("Physical disk / reliability clues:")
    foreach ($r in $reliabilityRows) {
        $lines.Add(("  {0} | Media={1} Bus={2} Health={3} Temp={4}C Wear={5} PowerOnHours={6} ReadErr={7} WriteErr={8}" -f
            (Text-Or $r.Name),(Text-Or $r.MediaType),(Text-Or $r.BusType),(Text-Or $r.Health),
            (Text-Or $r.Temperature),(Text-Or $r.Wear),(Text-Or $r.PowerOnHours),
            (Text-Or $r.ReadErrorsTotal),(Text-Or $r.WriteErrorsTotal)))
    }
}
$lines.Add("")
$lines.Add("Volumes:")
foreach ($v in $volumes) {
    $freePct = if ($v.Size -gt 0) {[math]::Round(($v.SizeRemaining/$v.Size)*100,1)} else {$null}
    $lines.Add(("  {0}: | {1} | {2} | Size={3} GB | Free={4} GB ({5}%) | Health={6}" -f
        $v.DriveLetter,(Text-Or $v.FileSystemLabel),(Text-Or $v.FileSystem),
        $(if($v.Size){[math]::Round([double]$v.Size/1GB,1)}else{"?"}),
        $(if($v.SizeRemaining -ne $null){[math]::Round([double]$v.SizeRemaining/1GB,1)}else{"?"}),
        (Text-Or $freePct),(Text-Or $v.HealthStatus)))
}
Add-KV $lines "System volume BitLocker" $bitLockerState
$lines.Add("BitLocker recovery passwords/keys are intentionally not collected.")

Section $lines "BOOT / RECOVERY"
Add-KV $lines "Firmware mode" $firmwareMode
Add-KV $lines "Secure Boot" $secureBoot
Add-KV $lines "WinRE status" $winreStatus
Add-KV $lines "WinRE location" $winreLocation
$recoveryPartitions = @($partitions | Where-Object { $_.Type -match "(?i)Recovery" -or $_.GptType -match "DE94BBA4" })
Add-KV $lines "Recovery partitions found" $recoveryPartitions.Count

Section $lines "SECURITY / WINDOWS STATE"
Add-KV $lines "Windows activation" $activationState
Add-KV $lines "Defender" $defenderState
Add-KV $lines "Firewall profiles" $firewallSummary
Add-KV $lines "UAC" $uacState
Add-KV $lines "Pending reboot" $pendingReboot
Add-KV $lines "Registered AV products" $(if($avProducts.Count){($avProducts.displayName -join "; ")}else{"Unavailable / none returned"})
Add-KV $lines "Local Administrators count" $localAdmins.Count

Section $lines "NETWORK / TIME"
Add-KV $lines "Wi-Fi SSID" $wifiSSID
Add-KV $lines "Default IPv4 gateway" $gateway
Add-KV $lines "Gateway probe" $gatewayReachable
Add-KV $lines "DNS sanity" $dnsTest
Add-KV $lines "HTTPS sanity" $httpsTest
foreach ($cfg in $netConfigs) {
    $alias = $cfg.InterfaceAlias
    $adapter = $cfg.NetAdapter
    $v4 = @($cfg.IPv4Address | ForEach-Object IPAddress) -join ", "
    $v6 = @($cfg.IPv6Address | Where-Object { $_.IPAddress -notlike "fe80:*" } | ForEach-Object IPAddress) -join ", "
    $dns = @($cfg.DNSServer.ServerAddresses) -join ", "
    $dhcp = @($nicCim | Where-Object Description -eq $adapter.InterfaceDescription | Select-Object -First 1)
    $lines.Add(("  {0} | {1} | Link={2} | IPv4={3} | IPv6={4} | DNS={5} | DHCP={6}" -f
        (Text-Or $alias),(Text-Or $adapter.InterfaceDescription),(Text-Or $adapter.LinkSpeed),
        (Text-Or $v4),(Text-Or $v6),(Text-Or $dns),$(if($dhcp){$dhcp.DHCPEnabled}else{"Unknown"})))
}
if ($netProfiles.Count -gt 0) {
    Add-KV $lines "Network profile(s)" ((@($netProfiles | ForEach-Object { $_.Name + "=" + $_.NetworkCategory })) -join "; ")
}
Add-KV $lines "Time zone" $(if($tz){$tz.DisplayName}else{$null})
Add-KV $lines "Windows Time source" $timeSource
if ($proxy) {
    $proxyLine = (($proxy -split "`r?`n") | Where-Object { $_ -match "(?i)Direct access|Proxy Server" } | Select-Object -First 2) -join " | "
    Add-KV $lines "WinHTTP proxy" $proxyLine
}

Section $lines "JOIN / MANAGEMENT / USER CONTEXT"
Add-KV $lines "Domain joined" $domainJoined
Add-KV $lines "Entra joined" $azureAdJoined
Add-KV $lines "Workplace joined" $workplaceJoined
Add-KV $lines "MDM URL clue" $mdmClue
Add-KV $lines "MDM enrollment keys" $enrollmentCount
Add-KV $lines "Non-special profiles" $profiles.Count

Section $lines "POWER / BATTERY"
Add-KV $lines "Battery count" $batteries.Count
if ($batteries.Count -gt 0) {
    foreach ($b in $batteries) {
        $lines.Add(("  Battery: " + (Text-Or $b.Name) + " | Estimated charge=" + (Text-Or $b.EstimatedChargeRemaining) +
            "% | Status=" + (Text-Or $b.Status)))
    }
}
Add-KV $lines "Design capacity" $batteryDesign.DesignedCapacity
Add-KV $lines "Full-charge capacity" $batteryFull.FullChargedCapacity
Add-KV $lines "Battery cycle count" $batteryCycle.CycleCount
Add-KV $lines "Approx. battery wear %" $batteryWearPct
if ($powerPlan) {
    Add-KV $lines "Active power plan" (([string]$powerPlan -replace "\s+"," ").Trim())
}

Section $lines "DISPLAY / AUDIO / PERIPHERALS"
Add-KV $lines "Monitor count" $monitorRows.Count
foreach ($m in $monitorRows) { $lines.Add(("  Monitor: " + $m.Name + " | Serial=" + $m.Serial + " | Active=" + $m.Active)) }
Add-KV $lines "Audio device count" $sound.Count
foreach ($s in $sound | Select-Object -First 8) { $lines.Add(("  Audio: " + (Text-Or $s.Name) + " | Status=" + (Text-Or $s.Status))) }
Add-KV $lines "Printer count" $printers.Count
Add-KV $lines "Default printer" $(if($defaultPrinter){$defaultPrinter.Name}else{"None / unavailable"})
Add-KV $lines "Dock-like devices" $(if($dockLike.Count){($dockLike -join "; ")}else{"None detected"})
Add-KV $lines "Present USB storage count" $usbStorage.Count
foreach ($u in $usbStorage) { $lines.Add(("  USB storage: " + (Text-Or $u.FriendlyName) + " | " + (Text-Or $u.InstanceId))) }

Section $lines "SOFTWARE QUICK LOOK"
Add-KV $lines "Browsers detected" $browserRows.Count
foreach ($b in $browserRows) { $lines.Add(("  Browser: " + $b.Name + " " + (Text-Or $b.Version))) }
Add-KV $lines "Office / Microsoft 365" $(if($officeApps.Count){(@($officeApps | ForEach-Object { $_.Name + " " + $_.Version }) -join "; ")}else{"Not detected in uninstall inventory"})
Add-KV $lines "Remote-support footprint" $(if($remoteApps.Count){(@($remoteApps | ForEach-Object { $_.Name + " " + $_.Version }) -join "; ")}else{"None detected in uninstall inventory"})
$lines.Add("Remote-support entries indicate installed software only; they do not prove active remote access.")

Section $lines "WINDOWS UPDATE / RECENT STABILITY"
Add-KV $lines "Latest installed hotfix" $(if($latestHotfix){$latestHotfix.HotFixID + " | " + $latestHotfix.InstalledOn}else{"Unavailable"})
Add-KV $lines "Hotfixes returned" $hotfixes.Count
Add-KV $lines "Unexpected shutdown events (7d)" $unexpectedShutdownCount
Add-KV $lines "Hardware/storage/display errors (7d)" $hardwareEventCount
Add-KV $lines "Application crash/hang events (7d)" $appCrashCount
Add-KV $lines "Windows Update error events (7d)" $wuFailures
Add-KV $lines "Startup entries" $startup.Count
Add-KV $lines "Automatic services" $autoServices.Count
Add-KV $lines "Automatic services stopped" $stoppedAutoServices.Count
$lines.Add("Event counts are intake clues from a limited recent sample, not a forensic or complete event-log analysis.")

Section $lines "PROBLEM DEVICES"
Add-KV $lines "Problem PnP devices" $problemDevices.Count
foreach ($d in $problemDevices | Select-Object -First 25) {
    $lines.Add(("  " + (Text-Or $d.Status) + " | " + (Text-Or $d.Class) + " | " + (Text-Or $d.FriendlyName) + " | " + (Text-Or $d.InstanceId)))
}
if ($problemDevices.Count -gt 25) { $lines.Add("  ... additional problem devices omitted from intake; use Advanced -> Problem Devices.") }

Section $lines "COLLECTION QUALITY"
$okCollectors = @($collector | Where-Object Status -eq "OK").Count
$unavailableCollectors = @($collector | Where-Object Status -ne "OK").Count
Add-KV $lines "Collectors OK" $okCollectors
Add-KV $lines "Collectors unavailable" $unavailableCollectors
foreach ($c in $collector) {
    $lines.Add(("  [" + $c.Status + "] " + $c.Name + " - " + (Text-Or $c.Details)))
}
$lines.Add("")
$lines.Add("A collector marked UNAVAILABLE means that source could not be read in this context.")
$lines.Add("It does not mean the corresponding feature/device is absent or healthy.")
$lines.Add("Use the deeper Advanced investigators or Full Machine Report when intake flags require follow-up.")

$body = $lines -join [Environment]::NewLine

try {
    & $writer -BasePath $reportBase -Title "Machine Intake Summary" -Body $body
    if ($LASTEXITCODE -and $LASTEXITCODE -ne 0) {
        throw ("Write-TriReport returned code " + $LASTEXITCODE)
    }
}
catch {
    Write-Host ""
    Write-Host "Machine Intake data collection completed, but report rendering failed."
    Write-Host $_.Exception.Message
    try {
        $body | Set-Content -LiteralPath $txtPath -Encoding UTF8
        Write-Host ("Fallback text report: " + $txtPath)
    }
    catch {}
    exit 2
}

Write-Host ""
Write-Host ("Overall intake verdict: " + $overall)
Write-Host ("Attention items: " + $flags.Count)
Write-Host ("Collectors unavailable: " + $unavailableCollectors)
Write-Host ""
Write-Host ("HTML: " + $htmlPath)
Write-Host ("Text: " + $txtPath)
Write-Host ("Markdown: " + $mdPath)

try { Start-Process -FilePath $htmlPath } catch {}

exit 0

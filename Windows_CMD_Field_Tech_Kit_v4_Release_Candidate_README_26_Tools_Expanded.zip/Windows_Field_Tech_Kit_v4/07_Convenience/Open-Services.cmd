@echo off
start services.msc
exit /b 0

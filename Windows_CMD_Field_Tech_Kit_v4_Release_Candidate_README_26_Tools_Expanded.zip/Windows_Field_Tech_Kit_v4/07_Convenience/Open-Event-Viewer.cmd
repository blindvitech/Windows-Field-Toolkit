@echo off
start eventvwr.msc
exit /b 0

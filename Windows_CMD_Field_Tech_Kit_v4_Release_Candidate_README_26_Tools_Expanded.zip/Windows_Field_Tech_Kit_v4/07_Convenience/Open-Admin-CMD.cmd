@echo off
setlocal EnableExtensions
title Elevated CMD
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Open-Admin-CMD.ps1"
exit /b %errorlevel%

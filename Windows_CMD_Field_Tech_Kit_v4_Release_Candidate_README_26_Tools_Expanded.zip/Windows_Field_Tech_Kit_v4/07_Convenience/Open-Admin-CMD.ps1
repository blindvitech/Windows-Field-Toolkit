$ErrorActionPreference = "Stop"
try {
    Start-Process -FilePath "cmd.exe" -Verb RunAs -ErrorAction Stop
    exit 0
}
catch {
    Write-Host "Could not open an elevated Command Prompt."
    Write-Host $_.Exception.Message
    exit 1
}

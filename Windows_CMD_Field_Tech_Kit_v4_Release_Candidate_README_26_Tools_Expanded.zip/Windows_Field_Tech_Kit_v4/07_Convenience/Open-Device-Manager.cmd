@echo off
start devmgmt.msc
exit /b 0

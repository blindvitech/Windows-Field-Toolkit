@echo off
start diskmgmt.msc
exit /b 0

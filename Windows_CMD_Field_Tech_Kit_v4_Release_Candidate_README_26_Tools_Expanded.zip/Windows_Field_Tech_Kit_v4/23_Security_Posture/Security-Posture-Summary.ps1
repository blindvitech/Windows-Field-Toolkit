$ErrorActionPreference = "SilentlyContinue"
$ProgressPreference = "SilentlyContinue"

$toolkitRoot = Split-Path $PSScriptRoot -Parent
$logs = Join-Path $toolkitRoot "Logs"
if (-not (Test-Path -LiteralPath $logs)) {
    New-Item -ItemType Directory -Path $logs -Force | Out-Null
}

$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$basePath = Join-Path $logs ($env:COMPUTERNAME + "_Security_Posture_Summary_" + $stamp)
$writer = Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"

Write-Host "Collecting Security Posture Summary..."

$isAdmin = $false
try {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    $isAdmin = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}
catch {
    $isAdmin = $false
}

$body = & {
Write-Output "===== COLLECTION CONTEXT ====="
[pscustomobject]@{
    RunningAsAdministrator = $isAdmin
    User = $env:USERDOMAIN + "\" + $env:USERNAME
}

Write-Output "`n===== SECURE BOOT ====="
if (-not $isAdmin) {
    [pscustomobject]@{
        Status = "Not collected"
        Reason = "Administrator privileges are required for a reliable Secure Boot check."
    }
}
else {
    try {
        [pscustomobject]@{
            SecureBootEnabled = Confirm-SecureBootUEFI -ErrorAction Stop
            Status = "Collected"
            Reason = ""
        }
    }
    catch {
        [pscustomobject]@{
            SecureBootEnabled = $null
            Status = "Unavailable"
            Reason = $_.Exception.Message
        }
    }
}

Write-Output "`n===== TPM ====="
if (-not $isAdmin) {
    [pscustomobject]@{
        Status = "Not collected"
        Reason = "Administrator privileges are required for this toolkit TPM check."
    }
}
else {
    try {
        $tpm = Get-Tpm -ErrorAction Stop
        if ($null -eq $tpm) {
            [pscustomobject]@{
                Status = "Unavailable"
                Reason = "Get-Tpm returned no data."
            }
        }
        else {
            $tpm | Select-Object TpmPresent,TpmReady,TpmEnabled,TpmActivated,ManufacturerIdTxt,ManufacturerVersion
        }
    }
    catch {
        [pscustomobject]@{
            Status = "Unavailable"
            Reason = $_.Exception.Message
        }
    }
}

Write-Output "`n===== BITLOCKER ====="
if (-not $isAdmin) {
    [pscustomobject]@{
        Status = "Not collected"
        Reason = "Administrator privileges are required for this toolkit BitLocker check."
    }
}
else {
    try {
        $bitlocker = @(Get-BitLockerVolume -ErrorAction Stop |
            Select-Object MountPoint,ProtectionStatus,VolumeStatus,EncryptionMethod)
        if ($bitlocker.Count -eq 0) {
            [pscustomobject]@{
                Status = "Unavailable"
                Reason = "No BitLocker volume data was returned."
            }
        }
        else {
            $bitlocker
        }
    }
    catch {
        [pscustomobject]@{
            Status = "Unavailable"
            Reason = $_.Exception.Message
        }
    }
}

Write-Output "`n===== DEFENDER ====="
Get-MpComputerStatus -ErrorAction SilentlyContinue |
    Select-Object AntivirusEnabled,RealTimeProtectionEnabled,BehaviorMonitorEnabled,NISEnabled,AntivirusSignatureLastUpdated
Write-Output "`n===== FIREWALL ====="
Get-NetFirewallProfile -ErrorAction SilentlyContinue |
    Select-Object Name,Enabled,DefaultInboundAction,DefaultOutboundAction
Write-Output "`n===== UAC ====="
Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -ErrorAction SilentlyContinue |
    Select-Object EnableLUA,ConsentPromptBehaviorAdmin,PromptOnSecureDesktop
Write-Output "`n===== LOCAL ADMINS ====="
Get-LocalGroupMember Administrators -ErrorAction SilentlyContinue |
    Select-Object Name,ObjectClass,PrincipalSource
Write-Output "`n===== GUEST ACCOUNT ====="
Get-LocalUser Guest -ErrorAction SilentlyContinue |
    Select-Object Name,Enabled,LastLogon

Write-Output "`n===== SMB1 ====="
if (-not $isAdmin) {
    [pscustomobject]@{
        Status = "Not collected"
        Reason = "Administrator privileges are required to query Windows optional-feature state."
    }
}
else {
    try {
        $smb1 = Get-WindowsOptionalFeature -Online -FeatureName SMB1Protocol -ErrorAction Stop |
            Select-Object FeatureName,State
        if ($null -eq $smb1) {
            [pscustomobject]@{
                Status = "Unavailable"
                Reason = "Windows returned no SMB1 optional-feature data."
            }
        }
        else {
            $smb1
        }
    }
    catch {
        [pscustomobject]@{
            Status = "Unavailable"
            Reason = $_.Exception.Message
        }
    }
}

Write-Output "`n===== POWERSHELL ====="
$PSVersionTable
Write-Output "`n===== LSA PROTECTION ====="
Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -ErrorAction SilentlyContinue |
    Select-Object RunAsPPL,RunAsPPLBoot
} | Out-String -Width 240

if (-not (Test-Path -LiteralPath $writer)) {
    Write-Host "Report writer not found:"
    Write-Host $writer
    exit 3
}

& $writer -BasePath $basePath -Title "Security Posture Summary" -Body $body

$html = $basePath + ".html"
$txt = $basePath + ".txt"
$md = $basePath + ".md"

if (-not (Test-Path -LiteralPath $html) -or -not (Test-Path -LiteralPath $txt) -or -not (Test-Path -LiteralPath $md)) {
    Write-Host ""
    Write-Host "Collection finished, but one or more report files were not created."
    exit 4
}

Write-Host ""
Write-Host "Security Posture Summary complete."
Write-Host ("HTML: " + $html)
Write-Host ("Text: " + $txt)
Write-Host ("Markdown: " + $md)
exit 0

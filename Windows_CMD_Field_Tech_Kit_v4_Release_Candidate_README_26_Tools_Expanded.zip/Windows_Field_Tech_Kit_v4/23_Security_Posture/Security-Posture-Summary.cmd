@echo off
setlocal EnableExtensions
title Security Posture Summary

echo Security Posture Summary
echo.
echo Collecting report data. This may take a moment.
echo Run the toolkit as Administrator for Secure Boot, TPM, BitLocker, and SMB1 feature details.
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Security-Posture-Summary.ps1"
set "RC=%errorlevel%"

if "%SRMODE%"=="1" (
    echo.
    if "%RC%"=="0" (
        echo Security Posture Summary completed successfully.
    ) else (
        echo Security Posture Summary returned error code %RC%.
    )
    echo Press any key to continue.
    pause >nul
) else (
    echo.
    pause
)

exit /b %RC%

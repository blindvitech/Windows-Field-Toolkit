$ErrorActionPreference = "SilentlyContinue"
$ProgressPreference = "SilentlyContinue"

$toolkitRoot = Split-Path $PSScriptRoot -Parent
$logs = Join-Path $toolkitRoot "Logs"
if (-not (Test-Path -LiteralPath $logs)) {
    New-Item -ItemType Directory -Path $logs -Force | Out-Null
}

$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$basePath = Join-Path $logs ($env:COMPUTERNAME + "_Performance_Snapshot_" + $stamp)
$writer = Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"

Write-Host "Collecting Performance Snapshot..."

$body = & {
Write-Output "===== UPTIME ====="
$os = Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
if ($os) {
    [pscustomobject]@{
        LastBoot = $os.LastBootUpTime
        Uptime = (Get-Date) - $os.LastBootUpTime
    }
}
Write-Output "`n===== CPU / MEMORY ====="
Get-CimInstance Win32_Processor -ErrorAction SilentlyContinue |
    Select-Object Name,LoadPercentage,NumberOfCores,NumberOfLogicalProcessors
Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue |
    Select-Object @{N='TotalRAMGB';E={[math]::Round($_.TotalVisibleMemorySize/1MB,2)}},
                  @{N='FreeRAMGB';E={[math]::Round($_.FreePhysicalMemory/1MB,2)}}
Write-Output "`n===== TOP CPU PROCESSES ====="
Get-Process -ErrorAction SilentlyContinue |
    Sort-Object CPU -Descending |
    Select-Object -First 15 ProcessName,Id,CPU,WorkingSet64
Write-Output "`n===== TOP MEMORY PROCESSES ====="
Get-Process -ErrorAction SilentlyContinue |
    Sort-Object WorkingSet64 -Descending |
    Select-Object -First 15 ProcessName,Id,@{N='RAMMB';E={[math]::Round($_.WorkingSet64/1MB,1)}},CPU
Write-Output "`n===== QUICK COUNTERS ====="
Get-Counter '\Processor(_Total)\% Processor Time','\Memory\Available MBytes','\PhysicalDisk(_Total)\Avg. Disk Queue Length' -SampleInterval 1 -MaxSamples 3 -ErrorAction SilentlyContinue
} | Out-String -Width 240

if (-not (Test-Path -LiteralPath $writer)) {
    Write-Host "Report writer not found:"
    Write-Host $writer
    exit 3
}

& $writer -BasePath $basePath -Title "Performance Snapshot" -Body $body

$html = $basePath + ".html"
$txt = $basePath + ".txt"
$md = $basePath + ".md"

if (-not (Test-Path -LiteralPath $html) -or -not (Test-Path -LiteralPath $txt) -or -not (Test-Path -LiteralPath $md)) {
    Write-Host ""
    Write-Host "Collection finished, but one or more report files were not created."
    exit 4
}

Write-Host ""
Write-Host "Performance Snapshot complete."
Write-Host ("HTML: " + $html)
Write-Host ("Text: " + $txt)
Write-Host ("Markdown: " + $md)
exit 0

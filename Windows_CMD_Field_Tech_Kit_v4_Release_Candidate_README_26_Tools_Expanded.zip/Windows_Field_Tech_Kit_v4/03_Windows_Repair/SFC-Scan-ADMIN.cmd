@echo off
setlocal EnableExtensions
title System File Checker - ADMIN

net session >nul 2>&1
if not "%errorlevel%"=="0" (
    echo Requesting Administrator privileges...
    powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\00_Common\Invoke-Elevated-Self.ps1" -ScriptPath "%~f0"
    exit /b
)

echo SYSTEM FILE CHECKER
echo.
echo This will run SFC /SCANNOW against protected Windows system files.
echo SFC is not scan-only: if corruption is found, Windows may automatically repair or
echo replace protected system files using known-good component-store copies.
echo Personal documents are not targeted. The scan may take several minutes.
echo.
if "%SRMODE%"=="1" echo Confirmation prompt follows. Press Y for yes or N for no.
choice /C YN /N /M "Continue? [Y/N]: "
if errorlevel 2 goto CANCELED

echo.
echo Running System File Checker...
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\00_Common\Invoke-Native-Bridge.ps1" -FilePath "sfc.exe" -Label "SFC Scannow" -Action "SFC Scan Repair Basic" -Mutation /scannow
set "RC=%errorlevel%"

echo.
echo SFC finished with return code %RC%.
goto FINISH

:CANCELED
echo.
echo Canceled. No changes were made.
set "RC=0"

:FINISH
echo.
if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)
exit /b %RC%

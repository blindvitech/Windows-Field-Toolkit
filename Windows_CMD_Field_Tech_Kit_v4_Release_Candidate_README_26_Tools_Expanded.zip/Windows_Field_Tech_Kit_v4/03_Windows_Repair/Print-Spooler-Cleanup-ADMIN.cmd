@echo off
setlocal EnableExtensions
title Print Spooler Cleanup - ADMIN

net session >nul 2>&1
if not "%errorlevel%"=="0" (
    echo Administrator privileges required.
    echo Relaunch the toolkit as Administrator and try again.
    echo.
    if "%SRMODE%"=="1" (
        echo Press any key to continue.
        pause >nul
    ) else (
        pause
    )
    exit /b 1
)

echo PRINT SPOOLER CLEANUP
echo.
echo This will:
echo - Stop the Print Spooler service.
echo - Delete all currently queued spool files from:
echo   %SystemRoot%\System32\spool\PRINTERS
echo - Restart the Print Spooler service.
echo.
echo Existing queued print jobs WILL be removed.
echo Installed printers, printer ports, and printer drivers are NOT removed.
echo.
if "%SRMODE%"=="1" echo Confirmation prompt follows. Press Y for yes or N for no.
choice /C YN /N /M "Continue? [Y/N]: "
if errorlevel 2 goto CANCELED

echo.
echo Stopping Print Spooler...
net stop spooler
set "STOP_RC=%errorlevel%"

echo.
echo Clearing queued print jobs...
del /F /Q "%SystemRoot%\System32\spool\PRINTERS\*" >nul 2>&1
set "DELETE_RC=%errorlevel%"

echo.
echo Starting Print Spooler...
net start spooler
set "START_RC=%errorlevel%"

echo.
echo Verification:
sc query spooler | findstr /I "STATE"

if "%START_RC%"=="0" (
    echo Print Spooler cleanup completed.
    set "RC=0"
) else (
    echo Cleanup completed, but the Print Spooler did not restart successfully.
    echo Spooler start return code: %START_RC%
    set "RC=1"
)
goto FINISH

:CANCELED
echo.
echo Canceled. No changes were made.
set "RC=0"

:FINISH
echo.
if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)
exit /b %RC%

@echo off
title DISM Component Store Analysis - ADMIN
net session >nul 2>&1
if not "%errorlevel%"=="0" (
    echo This script requires Administrator privileges.
    echo Right-click it and choose "Run as administrator".
    if "%SRMODE%"=="1" (
        echo Press any key to continue.
        pause >nul
    ) else (
        pause
    )
    exit /b 1
)
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\00_Common\Invoke-Native-Bridge.ps1" -FilePath "dism.exe" -Label "DISM Analyze Component Store" /Online /Cleanup-Image /AnalyzeComponentStore
if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

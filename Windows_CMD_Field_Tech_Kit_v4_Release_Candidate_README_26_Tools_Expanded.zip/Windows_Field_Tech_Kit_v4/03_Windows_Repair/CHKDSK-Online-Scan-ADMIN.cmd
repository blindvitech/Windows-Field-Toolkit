@echo off

setlocal

title CHKDSK Online Scan - ADMIN

net session >nul 2>&1

if not "%errorlevel%"=="0" (

 echo Requesting Administrator privileges...
    powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\00_Common\Invoke-Elevated-Self.ps1" -ScriptPath "%~f0"
 exit /b

)

echo Running a read-only online scan of C: ...
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\00_Common\Invoke-Native-Bridge.ps1" -FilePath "chkdsk.exe" -Label "CHKDSK Online Scan C" C: /scan
if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

endlocal


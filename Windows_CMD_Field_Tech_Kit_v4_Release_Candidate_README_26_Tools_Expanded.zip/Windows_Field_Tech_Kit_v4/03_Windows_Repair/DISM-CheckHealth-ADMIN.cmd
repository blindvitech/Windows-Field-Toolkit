@echo off

setlocal

title DISM CheckHealth - ADMIN

net session >nul 2>&1

if not "%errorlevel%"=="0" (

 echo Requesting Administrator privileges...
    powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\00_Common\Invoke-Elevated-Self.ps1" -ScriptPath "%~f0"
 exit /b

)

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\00_Common\Invoke-Native-Bridge.ps1" -FilePath "dism.exe" -Label "DISM CheckHealth" /Online /Cleanup-Image /CheckHealth
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\00_Common\Invoke-Native-Bridge.ps1" -FilePath "dism.exe" -Label "DISM ScanHealth" /Online /Cleanup-Image /ScanHealth
if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

endlocal


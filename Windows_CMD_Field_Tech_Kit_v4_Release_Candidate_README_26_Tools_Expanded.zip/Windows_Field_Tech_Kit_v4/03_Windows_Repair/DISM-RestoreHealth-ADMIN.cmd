@echo off
setlocal EnableExtensions
title DISM RestoreHealth - ADMIN

net session >nul 2>&1
if not "%errorlevel%"=="0" (
    echo Requesting Administrator privileges...
    powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\00_Common\Invoke-Elevated-Self.ps1" -ScriptPath "%~f0"
    exit /b
)

echo DISM RESTOREHEALTH
echo.
echo This will run powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\00_Common\Invoke-Native-Bridge.ps1" -FilePath "dism.exe" -Label "DISM RestoreHealth" -Action "DISM RestoreHealth Basic" -Mutation /Online /Cleanup-Image /RestoreHealth.
echo DISM may repair the Windows component store and may use Windows Update as a
echo repair source when local repair content is unavailable.
echo The operation can take time and may use network bandwidth.
echo.
if "%SRMODE%"=="1" echo Confirmation prompt follows. Press Y for yes or N for no.
choice /C YN /N /M "Continue? [Y/N]: "
if errorlevel 2 goto CANCELED

echo.
echo Running DISM RestoreHealth...
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\00_Common\Invoke-Native-Bridge.ps1" -FilePath "dism.exe" -Label "DISM RestoreHealth" -Action "DISM RestoreHealth Basic" -Mutation /Online /Cleanup-Image /RestoreHealth
set "RC=%errorlevel%"

echo.
if "%RC%"=="0" (
    echo DISM RestoreHealth completed successfully.
) else (
    echo DISM RestoreHealth returned error code %RC%.
)
echo Running SFC afterward is often useful when component-store corruption was repaired.
goto FINISH

:CANCELED
echo.
echo Canceled. No changes were made.
set "RC=0"

:FINISH
echo.
if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)
exit /b %RC%

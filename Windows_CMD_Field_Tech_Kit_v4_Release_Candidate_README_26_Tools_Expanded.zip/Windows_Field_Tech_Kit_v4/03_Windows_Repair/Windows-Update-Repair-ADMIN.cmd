@echo off
setlocal EnableExtensions
title Windows Update Repair - ADMIN

net session >nul 2>&1
if not "%errorlevel%"=="0" (
    echo This action requires Administrator privileges.
    echo Relaunch the toolkit as Administrator and try again.
    echo.
    if "%SRMODE%"=="1" (
        echo Press any key to continue.
        pause >nul
    ) else (
        pause
    )
    exit /b 1
)

echo WINDOWS UPDATE REPAIR
echo.
echo This performs a conservative Windows Update reset:
echo - Stop the Windows Update service.
echo - Stop Background Intelligent Transfer Service ^(BITS^).
echo - Rename SoftwareDistribution to SoftwareDistribution.old when no .old folder exists.
echo - Restart BITS and Windows Update.
echo.
echo Windows will rebuild its active update cache afterward.
echo Locally displayed update-history/cache information may be rebuilt as part of this reset.
echo Installed Windows updates are NOT uninstalled by this tool.
echo A reboot is recommended before retrying Windows Update.
echo.
if "%SRMODE%"=="1" echo Confirmation prompt follows. Press Y for yes or N for no.
choice /C YN /N /M "Continue with Windows Update reset? [Y/N]: "
if errorlevel 2 goto CANCELED

echo.
echo Stopping Windows Update...
net stop wuauserv
set "WU_STOP_RC=%errorlevel%"

echo.
echo Stopping BITS...
net stop bits
set "BITS_STOP_RC=%errorlevel%"

echo.
if exist "%windir%\SoftwareDistribution.old" (
    echo Existing SoftwareDistribution.old found.
    echo The active SoftwareDistribution folder will NOT be renamed to avoid overwriting it.
    set "RENAME_RC=2"
) else (
    echo Renaming SoftwareDistribution...
    ren "%windir%\SoftwareDistribution" SoftwareDistribution.old
    set "RENAME_RC=%errorlevel%"
)

echo.
echo Starting BITS...
net start bits
set "BITS_START_RC=%errorlevel%"

echo.
echo Starting Windows Update...
net start wuauserv
set "WU_START_RC=%errorlevel%"

echo.
echo Verification:
sc query bits | findstr /I "STATE"
sc query wuauserv | findstr /I "STATE"

echo.
if not "%WU_START_RC%"=="0" goto UPDATE_ERROR
if not "%BITS_START_RC%"=="0" goto UPDATE_ERROR
echo Windows Update reset sequence completed.
if "%RENAME_RC%"=="2" echo Note: SoftwareDistribution was not renamed because SoftwareDistribution.old already exists.
set "RC=0"
goto FINISH

:UPDATE_ERROR
echo The reset sequence completed with one or more service-start errors.
echo BITS start return code: %BITS_START_RC%
echo Windows Update start return code: %WU_START_RC%
set "RC=1"
goto FINISH

:CANCELED
echo.
echo Canceled. No changes were made.
set "RC=0"

:FINISH
echo.
if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)
exit /b %RC%

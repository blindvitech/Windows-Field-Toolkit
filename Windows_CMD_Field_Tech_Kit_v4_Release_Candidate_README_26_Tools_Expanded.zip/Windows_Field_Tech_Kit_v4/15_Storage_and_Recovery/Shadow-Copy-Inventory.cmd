@echo off
setlocal
title VSS Shadow Copy Inventory
set "LOGDIR=%~dp0..\Logs"
if not exist "%LOGDIR%" mkdir "%LOGDIR%"
set "LOG=%LOGDIR%\%COMPUTERNAME%_ShadowCopies_%RANDOM%.txt"

(
echo VSS SHADOW COPY INVENTORY
echo Computer: %COMPUTERNAME%
echo Date: %DATE% %TIME%
echo.
vssadmin list shadows
echo.
vssadmin list shadowstorage
) > "%LOG%" 2>&1


powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\00_Common\Convert-TextReport.ps1" -TextPath "%LOG%" -Title "%~n0"


echo Saved to:
echo %LOG%
if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)
endlocal


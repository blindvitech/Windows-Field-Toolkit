@echo off
setlocal
title Robocopy Recovery Helper

echo ============================================================
echo               ROBOCOPY RECOVERY HELPER
echo ============================================================
echo.
echo This performs a COPY only. It does not delete the source.
echo It uses restartable mode, preserves timestamps, and writes a log.
echo.
set /p SRC=Source folder: 
if "%SRC%"=="" exit /b
set /p DST=Destination folder: 
if "%DST%"=="" exit /b

set "LOGDIR=%~dp0..\Logs"
if not exist "%LOGDIR%" mkdir "%LOGDIR%"
set "LOG=%LOGDIR%\%COMPUTERNAME%_Robocopy_%RANDOM%.log"

echo.
echo Source:      %SRC%
echo Destination: %DST%
echo Log:         %LOG%
echo.
if "%SRMODE%"=="1" echo Confirmation prompt follows. Press Y for yes or N for no.
choice /C YN /M "Begin copy"
if errorlevel 2 exit /b

robocopy "%SRC%" "%DST%" /E /Z /COPY:DAT /DCOPY:T /R:2 /W:2 /XJ /TEE /LOG+:"%LOG%"

echo.
echo Robocopy finished. Review the exit code and log above.
echo Codes below 8 normally indicate no fatal copy failure.
if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)
endlocal


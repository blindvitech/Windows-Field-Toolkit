@echo off
setlocal EnableExtensions
title BitLocker Protector Summary

echo BitLocker Protector Summary
echo.
echo Running dedicated PowerShell collector...
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0BitLocker-Protector-Summary.ps1"
set "RC=%errorlevel%"

echo.
if "%RC%"=="0" (
    echo BitLocker Protector Summary completed.
) else (
    echo BitLocker Protector Summary returned error code %RC%.
)

if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

exit /b %RC%

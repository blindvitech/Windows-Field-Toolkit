@echo off
setlocal EnableExtensions
title Disk and Partition Layout

echo Disk and Partition Layout
echo.
echo Running dedicated PowerShell collector...
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Disk-Partition-Layout.ps1"
set "RC=%errorlevel%"

echo.
if "%RC%"=="0" (
    echo Disk and Partition Layout completed.
) else (
    echo Disk and Partition Layout returned error code %RC%.
)

if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

exit /b %RC%

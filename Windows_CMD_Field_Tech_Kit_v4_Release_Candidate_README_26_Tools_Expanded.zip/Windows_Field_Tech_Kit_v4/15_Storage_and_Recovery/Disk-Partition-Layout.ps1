$ErrorActionPreference = "SilentlyContinue"
$ProgressPreference = "SilentlyContinue"
$toolkitRoot = Split-Path $PSScriptRoot -Parent
$logs = Join-Path $toolkitRoot "Logs"
if (-not (Test-Path -LiteralPath $logs)) { New-Item -ItemType Directory -Path $logs -Force | Out-Null }
$writer = Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"
$stamp = Get-Date -Format "yyyyMMdd_HHmmss"

$reportBase=Join-Path $logs ($env:COMPUTERNAME+"_DiskLayout_"+$stamp)
$lines=New-Object System.Collections.Generic.List[string]
$lines.Add("DISKS")
$lines.Add((Get-Disk -ErrorAction SilentlyContinue |
 Format-Table Number,FriendlyName,SerialNumber,PartitionStyle,OperationalStatus,HealthStatus,@{N="SizeGB";E={[math]::Round($_.Size/1GB,2)}} -AutoSize |
 Out-String -Width 260).TrimEnd())
$lines.Add("")
$lines.Add("PARTITIONS")
$lines.Add((Get-Partition -ErrorAction SilentlyContinue |
 Format-Table DiskNumber,PartitionNumber,DriveLetter,Type,@{N="SizeGB";E={[math]::Round($_.Size/1GB,2)}} -AutoSize |
 Out-String -Width 260).TrimEnd())
$lines.Add("")
$lines.Add("VOLUMES")
$lines.Add((Get-Volume -ErrorAction SilentlyContinue |
 Format-Table DriveLetter,FileSystemLabel,FileSystem,HealthStatus,@{N="SizeGB";E={[math]::Round($_.Size/1GB,2)}},@{N="FreeGB";E={[math]::Round($_.SizeRemaining/1GB,2)}} -AutoSize |
 Out-String -Width 260).TrimEnd())
$body=$lines -join [Environment]::NewLine
& $writer -BasePath $reportBase -Title "Disk and Partition Layout" -Body $body
Write-Host("Report: "+$reportBase+".html")
try{Start-Process -FilePath ($reportBase+".html")}catch{}
exit 0

$ErrorActionPreference="SilentlyContinue"
$data=Get-BitLockerVolume -ErrorAction SilentlyContinue |
    ForEach-Object {
        [pscustomobject]@{
            MountPoint=$_.MountPoint
            ProtectionStatus=$_.ProtectionStatus
            VolumeStatus=$_.VolumeStatus
            EncryptionMethod=$_.EncryptionMethod
            ProtectorTypes=($_.KeyProtector.KeyProtectorType -join ", ")
        }
    }
$data|Format-Table -AutoSize
Write-Host ""
Write-Host "Recovery passwords/keys are intentionally NOT displayed."
exit 0

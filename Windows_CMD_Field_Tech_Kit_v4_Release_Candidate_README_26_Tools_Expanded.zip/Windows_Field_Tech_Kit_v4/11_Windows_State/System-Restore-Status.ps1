$ErrorActionPreference = "SilentlyContinue"
$ProgressPreference = "SilentlyContinue"
$toolkitRoot = Split-Path $PSScriptRoot -Parent
$logs = Join-Path $toolkitRoot "Logs"
if (-not (Test-Path -LiteralPath $logs)) { New-Item -ItemType Directory -Path $logs -Force | Out-Null }
$writer = Join-Path $toolkitRoot "00_Common\Write-TriReport.ps1"
$stamp = Get-Date -Format "yyyyMMdd_HHmmss"

$reportBase = Join-Path $logs ($env:COMPUTERNAME + "_RestorePoints_" + $stamp)
$data = Get-ComputerRestorePoint -ErrorAction SilentlyContinue |
    Select-Object SequenceNumber,CreationTime,Description,RestorePointType
$body = if ($data) { ($data | Format-Table -AutoSize | Out-String -Width 260).TrimEnd() } else { "(No restore points returned, or collection unavailable.)" }
& $writer -BasePath $reportBase -Title "System Restore Status" -Body $body
Write-Host ("Report: " + $reportBase + ".html")
try { Start-Process -FilePath ($reportBase + ".html") } catch {}
exit 0

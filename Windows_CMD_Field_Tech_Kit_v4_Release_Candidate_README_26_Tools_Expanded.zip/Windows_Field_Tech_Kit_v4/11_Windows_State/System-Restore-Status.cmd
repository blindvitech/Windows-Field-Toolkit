@echo off
setlocal EnableExtensions
title System Restore Status

echo System Restore Status
echo.
echo Running dedicated PowerShell collector...
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0System-Restore-Status.ps1"
set "RC=%errorlevel%"

echo.
if "%RC%"=="0" (
    echo System Restore Status completed.
) else (
    echo System Restore Status returned error code %RC%.
)

if "%SRMODE%"=="1" (
    echo Press any key to continue.
    pause >nul
) else (
    pause
)

exit /b %RC%

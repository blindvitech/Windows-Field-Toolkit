@echo off
setlocal EnableExtensions
set "COMMON=%~dp0..\00_Common\WinPE-Common.cmd"
call "%COMMON%" INIT
set "LOG=%WINPE_LOGROOT%\Disk-Volume-Layout_%WINPE_STAMP%.txt"
set "DPS=%TEMP%\FieldTech_DiskPart_%RANDOM%.txt"

> "%DPS%" echo list disk
>>"%DPS%" echo list volume

echo WINDOWS FIELD TECH TOOLKIT v4 - DISK / VOLUME LAYOUT INVENTORY
echo This workflow is read-only.
echo Report: %LOG%
echo.

> "%LOG%" echo DISK / VOLUME LAYOUT INVENTORY
>>"%LOG%" echo.
diskpart /s "%DPS%" >>"%LOG%" 2>&1
>>"%LOG%" echo.
>>"%LOG%" echo MOUNTVOL
mountvol >>"%LOG%" 2>&1
>>"%LOG%" echo.
>>"%LOG%" echo BCDEDIT CURRENT ENVIRONMENT
bcdedit /enum all >>"%LOG%" 2>&1

del "%DPS%" >nul 2>&1
type "%LOG%"
exit /b 0

@echo off
setlocal EnableExtensions
set "COMMON=%~dp0..\00_Common\WinPE-Common.cmd"
call "%COMMON%" INIT
call "%COMMON%" TARGET
if errorlevel 1 exit /b 2

echo.
echo WINDOWS FIELD TECH TOOLKIT v4 - OFFLINE SFC
echo Target: %OFFLINE_WIN%\Windows
echo.
echo 1. Verify only - no repair
echo 2. Scan and repair offline system files
echo Q. Cancel
set "mode="
set /p "mode=Select: "
if /I "%mode%"=="Q" exit /b 0
if not "%mode%"=="1" if not "%mode%"=="2" (
  echo Invalid selection.
  exit /b 2
)

set "BOOTVOL="
set /p "BOOTVOL=Offline boot volume [default %OFFLINE_WIN%]: "
if "%BOOTVOL%"=="" set "BOOTVOL=%OFFLINE_WIN%"
call "%COMMON%" DRIVE "%BOOTVOL%"
if errorlevel 1 (
  echo Invalid boot volume.
  exit /b 2
)
set "BOOTVOL=%WINPE_DRIVE%"

set "LOG=%WINPE_LOGROOT%\Offline-SFC_%WINPE_STAMP%.txt"

if "%mode%"=="1" goto :VERIFY

echo.
echo STATE CHANGE: SFC /SCANNOW may replace damaged protected Windows files
echo in the selected offline installation.
echo Target: %OFFLINE_WIN%\Windows
echo Boot volume: %BOOTVOL%\
echo.
set "ACK="
set /p "ACK=Type SFC OFFLINE exactly to continue: "
if not "%ACK%"=="SFC OFFLINE" (
  echo Canceled. No repair was started.
  exit /b 0
)

sfc /scannow /offbootdir=%BOOTVOL%\ /offwindir=%OFFLINE_WIN%\Windows >"%LOG%" 2>&1
set "RC=%errorlevel%"
type "%LOG%"
exit /b %RC%

:VERIFY
echo.
echo Running offline SFC verification. No repair will be requested.
sfc /verifyonly /offbootdir=%BOOTVOL%\ /offwindir=%OFFLINE_WIN%\Windows >"%LOG%" 2>&1
set "RC=%errorlevel%"
type "%LOG%"
exit /b %RC%

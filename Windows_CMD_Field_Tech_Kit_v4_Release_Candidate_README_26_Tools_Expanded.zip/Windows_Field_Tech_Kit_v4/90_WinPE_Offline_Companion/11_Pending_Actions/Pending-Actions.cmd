@echo off
setlocal EnableExtensions
set "COMMON=%~dp0..\00_Common\WinPE-Common.cmd"
call "%COMMON%" INIT
call "%COMMON%" TARGET
if errorlevel 1 exit /b 2

:MENU
echo.
echo WINDOWS FIELD TECH TOOLKIT v4 - PENDING UPDATE / ACTIONS
echo Target: %OFFLINE_WIN%\Windows
echo.
echo 1. Inspect pending-action evidence
echo 2. Revert pending servicing actions - boot recovery mutation
echo Q. Cancel
set "mode="
set /p "mode=Select: "
if /I "%mode%"=="Q" exit /b 0
if "%mode%"=="1" goto :INSPECT
if "%mode%"=="2" goto :REVERT
echo Invalid selection.
goto :MENU

:INSPECT
set "LOG=%WINPE_LOGROOT%\Pending-Actions-Inspection_%WINPE_STAMP%.txt"
> "%LOG%" echo PENDING ACTIONS INSPECTION
>>"%LOG%" echo Target: %OFFLINE_WIN%\Windows
>>"%LOG%" echo.
if exist "%OFFLINE_WIN%\Windows\WinSxS\pending.xml" (
  >>"%LOG%" echo pending.xml: PRESENT
) else (
  >>"%LOG%" echo pending.xml: not present
)
>>"%LOG%" echo.
dism /Image:%OFFLINE_WIN%\ /Get-Packages >>"%LOG%" 2>&1
type "%LOG%"
exit /b 0

:REVERT
echo.
echo HIGH-IMPACT RECOVERY ACTION
echo DISM /RevertPendingActions is intended for recovery of an offline Windows
echo image that cannot boot because servicing operations are stuck or incomplete.
echo It changes the offline component-store servicing state.
echo.
if exist "%OFFLINE_WIN%\Windows\WinSxS\pending.xml" (
  echo pending.xml is present.
) else (
  echo NOTE: pending.xml was not found. Do not use this action casually.
)
echo.
set "ACK="
set /p "ACK=Type REVERT PENDING ACTIONS exactly to continue: "
if not "%ACK%"=="REVERT PENDING ACTIONS" (
  echo Canceled. No servicing state was changed.
  exit /b 0
)

set "BACKUP=%WINPE_LOGROOT%\Pending-Actions-Backup_%WINPE_STAMP%"
md "%BACKUP%" >nul 2>&1
if exist "%OFFLINE_WIN%\Windows\WinSxS\pending.xml" (
  copy /y "%OFFLINE_WIN%\Windows\WinSxS\pending.xml" "%BACKUP%\pending.xml" >nul 2>&1
)

set "LOG=%WINPE_LOGROOT%\Revert-Pending-Actions_%WINPE_STAMP%.txt"
dism /Image:%OFFLINE_WIN%\ /Cleanup-Image /RevertPendingActions >"%LOG%" 2>&1
set "RC=%errorlevel%"
type "%LOG%"
exit /b %RC%

@echo off
setlocal EnableExtensions
set "COMMON=%~dp0..\00_Common\WinPE-Common.cmd"
call "%COMMON%" INIT
call "%COMMON%" TARGET
if errorlevel 1 exit /b 2
set "LOG=%WINPE_LOGROOT%\Offline-Registry-Audit_%WINPE_STAMP%.txt"

echo WINDOWS FIELD TECH TOOLKIT v4 - OFFLINE REGISTRY AUDIT
echo Target: %OFFLINE_WIN%\Windows
echo This workflow loads hives temporarily for read-only queries, then unloads them.
echo Report: %LOG%
echo.

reg unload HKLM\FT_OFFLINE_SOFTWARE >nul 2>&1
reg unload HKLM\FT_OFFLINE_SYSTEM >nul 2>&1

reg load HKLM\FT_OFFLINE_SOFTWARE "%OFFLINE_WIN%\Windows\System32\Config\SOFTWARE" >nul 2>&1
if errorlevel 1 (
  echo Could not load the offline SOFTWARE hive.
  exit /b 3
)
reg load HKLM\FT_OFFLINE_SYSTEM "%OFFLINE_WIN%\Windows\System32\Config\SYSTEM" >nul 2>&1
if errorlevel 1 (
  reg unload HKLM\FT_OFFLINE_SOFTWARE >nul 2>&1
  echo Could not load the offline SYSTEM hive.
  exit /b 3
)

> "%LOG%" echo OFFLINE REGISTRY AUDIT
>>"%LOG%" echo Target: %OFFLINE_WIN%\Windows
>>"%LOG%" echo.
>>"%LOG%" echo WINDOWS VERSION
reg query "HKLM\FT_OFFLINE_SOFTWARE\Microsoft\Windows NT\CurrentVersion" /v ProductName >>"%LOG%" 2>&1
reg query "HKLM\FT_OFFLINE_SOFTWARE\Microsoft\Windows NT\CurrentVersion" /v DisplayVersion >>"%LOG%" 2>&1
reg query "HKLM\FT_OFFLINE_SOFTWARE\Microsoft\Windows NT\CurrentVersion" /v CurrentBuildNumber >>"%LOG%" 2>&1
reg query "HKLM\FT_OFFLINE_SOFTWARE\Microsoft\Windows NT\CurrentVersion" /v UBR >>"%LOG%" 2>&1
>>"%LOG%" echo.
>>"%LOG%" echo WINDOWS SETUP STATE
reg query "HKLM\FT_OFFLINE_SYSTEM\Setup" >>"%LOG%" 2>&1
>>"%LOG%" echo.
>>"%LOG%" echo CONTROL SET SELECTION
reg query "HKLM\FT_OFFLINE_SYSTEM\Select" >>"%LOG%" 2>&1
>>"%LOG%" echo.
>>"%LOG%" echo SESSION MANAGER
reg query "HKLM\FT_OFFLINE_SYSTEM\ControlSet001\Control\Session Manager" /v PendingFileRenameOperations >>"%LOG%" 2>&1

reg unload HKLM\FT_OFFLINE_SYSTEM >nul 2>&1
reg unload HKLM\FT_OFFLINE_SOFTWARE >nul 2>&1

type "%LOG%"
exit /b 0

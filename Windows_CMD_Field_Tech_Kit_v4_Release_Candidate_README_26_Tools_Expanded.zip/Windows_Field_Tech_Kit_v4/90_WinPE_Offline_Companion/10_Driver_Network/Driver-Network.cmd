@echo off
setlocal EnableExtensions
set "COMMON=%~dp0..\00_Common\WinPE-Common.cmd"
call "%COMMON%" INIT

:MENU
echo.
echo WINDOWS FIELD TECH TOOLKIT v4 - WINPE DRIVER / NETWORK BRING-UP
echo.
echo 1. Initialize WinPE networking
echo 2. Show network state
echo 3. Load one WinPE driver INF
echo 4. Map an SMB share with Windows password prompt
echo 5. Disconnect a mapped SMB drive
echo Q. Cancel
set "mode="
set /p "mode=Select: "
if /I "%mode%"=="Q" exit /b 0
if "%mode%"=="1" goto :INITNET
if "%mode%"=="2" goto :STATE
if "%mode%"=="3" goto :DRIVER
if "%mode%"=="4" goto :MAP
if "%mode%"=="5" goto :UNMAP
echo Invalid selection.
goto :MENU

:INITNET
echo Initializing WinPE Plug and Play and network stack...
wpeinit
ipconfig /all
exit /b %errorlevel%

:STATE
set "LOG=%WINPE_LOGROOT%\WinPE-Network-State_%WINPE_STAMP%.txt"
> "%LOG%" echo WINPE NETWORK STATE
>>"%LOG%" echo.
ipconfig /all >>"%LOG%" 2>&1
>>"%LOG%" echo.
route print >>"%LOG%" 2>&1
>>"%LOG%" echo.
arp -a >>"%LOG%" 2>&1
type "%LOG%"
exit /b 0

:DRIVER
set "INF="
set /p "INF=Full path to driver INF: "
if not exist "%INF%" (
  echo INF file not found.
  exit /b 2
)
echo.
echo STATE CHANGE: DRVLOAD loads this driver into the current WinPE session.
echo It does not inject the driver into the offline Windows installation.
set "ACK="
set /p "ACK=Type LOAD DRIVER exactly to continue: "
if not "%ACK%"=="LOAD DRIVER" (
  echo Canceled.
  exit /b 0
)
drvload "%INF%"
exit /b %errorlevel%

:MAP
set "UNC="
set /p "UNC=UNC share, for example \\server\share: "
set "MAPDRIVE="
set /p "MAPDRIVE=Drive letter to map, for example Z: "
call "%COMMON%" DRIVE "%MAPDRIVE%"
if not errorlevel 1 (
  echo The selected drive letter is already accessible. Choose an unused letter.
  exit /b 2
)
set "MAPDRIVE=%MAPDRIVE:"=%"
if "%MAPDRIVE:~1,1%"==":" set "MAPDRIVE=%MAPDRIVE:~0,2%"
if not "%MAPDRIVE:~1,1%"==":" set "MAPDRIVE=%MAPDRIVE:~0,1%:"
set "MAPUSER="
set /p "MAPUSER=Username, for example DOMAIN\User: "
echo Windows NET USE will prompt for the password. The toolkit does not capture it.
net use %MAPDRIVE% "%UNC%" /user:"%MAPUSER%" * /persistent:no
exit /b %errorlevel%

:UNMAP
set "MAPDRIVE="
set /p "MAPDRIVE=Mapped drive to disconnect, for example Z: "
set "MAPDRIVE=%MAPDRIVE:"=%"
if "%MAPDRIVE:~1,1%"==":" set "MAPDRIVE=%MAPDRIVE:~0,2%"
if not "%MAPDRIVE:~1,1%"==":" set "MAPDRIVE=%MAPDRIVE:~0,1%:"
net use %MAPDRIVE% /delete
exit /b %errorlevel%

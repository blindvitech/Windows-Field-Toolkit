@echo off
rem Windows Field Tech Toolkit v4 - WinPE Offline Companion common helper.
rem Native CMD only: no PowerShell dependency.

if /I "%~1"=="INIT" goto :INIT
if /I "%~1"=="STAMP" goto :STAMP
if /I "%~1"=="TARGET" goto :TARGET
if /I "%~1"=="DRIVE" goto :DRIVE
exit /b 64

:INIT
for %%I in ("%~dp0..") do set "WINPE_COMPANION_ROOT=%%~fI"
for %%I in ("%WINPE_COMPANION_ROOT%\..") do set "WINPE_TOOLKIT_ROOT=%%~fI"
set "WINPE_LOGROOT=%WINPE_TOOLKIT_ROOT%\Logs\WinPE_Offline"
if not exist "%WINPE_LOGROOT%" (
  md "%WINPE_LOGROOT%" >nul 2>&1
)
if not exist "%WINPE_LOGROOT%" (
  set "WINPE_LOGROOT=%TEMP%\FieldTechWinPELogs"
  if not exist "%WINPE_LOGROOT%" (
    md "%WINPE_LOGROOT%" >nul 2>&1
  )
)
call "%~f0" STAMP
exit /b 0

:STAMP
set "WINPE_STAMP=%DATE%_%TIME%_%RANDOM%"
set "WINPE_STAMP=%WINPE_STAMP:/=-%"
set "WINPE_STAMP=%WINPE_STAMP:\=-%"
set "WINPE_STAMP=%WINPE_STAMP::=-%"
set "WINPE_STAMP=%WINPE_STAMP:.=-%"
set "WINPE_STAMP=%WINPE_STAMP:,=-%"
set "WINPE_STAMP=%WINPE_STAMP: =_%"
exit /b 0

:DRIVE
setlocal
set "FT_DRIVE=%~2"
set "FT_DRIVE=%FT_DRIVE:"=%"
if "%FT_DRIVE%"=="" (
  endlocal
  exit /b 1
)
if "%FT_DRIVE:~1,1%"==":" set "FT_DRIVE=%FT_DRIVE:~0,2%"
if not "%FT_DRIVE:~1,1%"==":" set "FT_DRIVE=%FT_DRIVE:~0,1%:"
if not exist "%FT_DRIVE%\" (
  endlocal
  exit /b 2
)
endlocal & set "WINPE_DRIVE=%FT_DRIVE%"
exit /b 0

:TARGET
setlocal EnableDelayedExpansion

if defined OFFLINE_WIN (
  if exist "!OFFLINE_WIN!\Windows\System32\Config\SYSTEM" (
    endlocal & set "OFFLINE_WIN=%OFFLINE_WIN%"
    exit /b 0
  )
)

set /a FT_COUNT=0
for %%D in (C D E F G H I J K L M N O P Q R S T U V W X Y Z) do (
  if exist "%%D:\Windows\System32\Config\SYSTEM" (
    set /a FT_COUNT+=1
    set "FT_CAND_!FT_COUNT!=%%D:"
  )
)

if !FT_COUNT! EQU 1 (
  for %%N in (1) do set "FT_SELECTED=!FT_CAND_%%N!"
  echo Offline Windows installation detected at !FT_SELECTED!
  endlocal & set "OFFLINE_WIN=%FT_SELECTED%"
  exit /b 0
)

if !FT_COUNT! GTR 1 (
  echo.
  echo Multiple offline Windows installations were detected:
  for /L %%N in (1,1,!FT_COUNT!) do echo   !FT_CAND_%%N!\Windows
  echo.
)

if !FT_COUNT! EQU 0 (
  echo.
  echo No unlocked offline Windows installation was detected automatically.
  echo If the OS volume is BitLocker-locked, use the BitLocker tool first.
  echo.
)

set "FT_SELECTED="
set /p "FT_SELECTED=Offline Windows drive letter, for example D: "
set "FT_SELECTED=!FT_SELECTED:"=!"
if "!FT_SELECTED!"=="" (
  endlocal
  exit /b 1
)
if "!FT_SELECTED:~1,1!"==":" set "FT_SELECTED=!FT_SELECTED:~0,2!"
if not "!FT_SELECTED:~1,1!"==":" set "FT_SELECTED=!FT_SELECTED:~0,1!:"

if not exist "!FT_SELECTED!\Windows\System32\Config\SYSTEM" (
  echo The selected drive does not contain an accessible Windows SYSTEM hive.
  endlocal
  exit /b 2
)

endlocal & set "OFFLINE_WIN=%FT_SELECTED%"
exit /b 0

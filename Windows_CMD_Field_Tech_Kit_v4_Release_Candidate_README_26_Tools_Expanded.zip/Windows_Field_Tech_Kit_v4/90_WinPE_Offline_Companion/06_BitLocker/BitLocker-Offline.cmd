@echo off
setlocal EnableExtensions
set "COMMON=%~dp0..\00_Common\WinPE-Common.cmd"
call "%COMMON%" INIT

:MENU
echo.
echo WINDOWS FIELD TECH TOOLKIT v4 - BITLOCKER OFFLINE
echo.
echo 1. Show BitLocker status for all detected volumes
echo 2. Unlock a volume with an interactive password prompt
echo 3. Unlock a volume with a .BEK recovery key file
echo 4. Recovery-password privacy note
echo Q. Cancel
set "mode="
set /p "mode=Select: "
if /I "%mode%"=="Q" exit /b 0
if "%mode%"=="1" goto :STATUS
if "%mode%"=="2" goto :PASSWORD
if "%mode%"=="3" goto :BEK
if "%mode%"=="4" goto :RECOVERY_NOTE
echo Invalid selection.
goto :MENU

:STATUS
set "LOG=%WINPE_LOGROOT%\BitLocker-Status_%WINPE_STAMP%.txt"
manage-bde -status >"%LOG%" 2>&1
set "RC=%errorlevel%"
type "%LOG%"
exit /b %RC%

:PASSWORD
set "DRV="
set /p "DRV=Volume to unlock, for example D: "
call "%COMMON%" DRIVE "%DRV%"
if errorlevel 1 (
  echo Invalid drive.
  exit /b 2
)
set "DRV=%WINPE_DRIVE%"
echo.
echo Windows manage-bde will prompt for the password itself.
echo The toolkit does not receive, echo, store, or log that password.
manage-bde -unlock %DRV% -password
set "RC=%errorlevel%"
echo.
manage-bde -status %DRV%
exit /b %RC%

:BEK
set "DRV="
set /p "DRV=Volume to unlock, for example D: "
call "%COMMON%" DRIVE "%DRV%"
if errorlevel 1 (
  echo Invalid drive.
  exit /b 2
)
set "DRV=%WINPE_DRIVE%"
set "KEYFILE="
set /p "KEYFILE=Full path to the .BEK recovery key file: "
if not exist "%KEYFILE%" (
  echo Recovery key file not found.
  exit /b 2
)
echo.
echo The toolkit will pass the selected key-file path to manage-bde.
echo The key file itself is not copied or logged.
manage-bde -unlock %DRV% -recoverykey "%KEYFILE%"
set "RC=%errorlevel%"
echo.
manage-bde -status %DRV%
exit /b %RC%

:RECOVERY_NOTE
echo.
echo The 48-digit BitLocker recovery password form requires the recovery
echo password as a manage-bde command argument. This companion intentionally
echo does not wrap that form because doing so would place the recovery secret
echo in a process command line.
echo.
echo Use an interactive password protector, a .BEK recovery key file, or the
echo platform recovery UI when available. The toolkit never collects or logs
echo BitLocker recovery passwords.
exit /b 0

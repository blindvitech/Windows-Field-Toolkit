@echo off
setlocal EnableExtensions
title Windows Field Tech Toolkit v4 - WinPE Offline Companion

set "COMMON=%~dp000_Common\WinPE-Common.cmd"
call "%COMMON%" INIT

reg query HKLM\SYSTEM\CurrentControlSet\Control\MiniNT >nul 2>&1
if errorlevel 1 (
  echo.
  echo WARNING: Windows PE / Windows RE was not detected.
  echo This companion is designed for an offline recovery environment.
  echo Read-only inventory can still be reviewed, but repair actions should
  echo not be used against the currently running Windows installation.
  echo.
)

:MENU
echo.
echo WINDOWS FIELD TECH TOOLKIT v4 - WINPE OFFLINE COMPANION
echo Native-CMD recovery path. PowerShell is not required.
echo Main toolkit catalog remains 158 tools; these are separate offline workflows.
echo.
echo  1. Detect Offline Windows Installations
echo  2. Disk / Volume Layout Inventory
echo  3. Offline SFC Verify / Repair
echo  4. Offline DISM Health / Repair
echo  5. Boot / EFI Repair Assistant
echo  6. BitLocker Status / Safe Unlock
echo  7. Offline Registry Audit
echo  8. Data Rescue Copy
echo  9. Offline Log Harvester
echo 10. WinPE Driver / Network Bring-Up
echo 11. Pending Update / Revert Actions
echo  S. Companion Self-Test
echo  Q. Quit
echo.
set "choice="
set /p "choice=Select: "

if /I "%choice%"=="1" call "%~dp001_Detect_Offline_Windows\Detect-Offline-Windows.cmd"
if /I "%choice%"=="2" call "%~dp002_Disk_Layout\Disk-Layout.cmd"
if /I "%choice%"=="3" call "%~dp003_Offline_SFC\Offline-SFC.cmd"
if /I "%choice%"=="4" call "%~dp004_Offline_DISM\Offline-DISM.cmd"
if /I "%choice%"=="5" call "%~dp005_Boot_EFI\Boot-EFI-Repair.cmd"
if /I "%choice%"=="6" call "%~dp006_BitLocker\BitLocker-Offline.cmd"
if /I "%choice%"=="7" call "%~dp007_Offline_Registry\Offline-Registry-Audit.cmd"
if /I "%choice%"=="8" call "%~dp008_Data_Rescue\Data-Rescue.cmd"
if /I "%choice%"=="9" call "%~dp009_Log_Harvester\Log-Harvester.cmd"
if /I "%choice%"=="10" call "%~dp010_Driver_Network\Driver-Network.cmd"
if /I "%choice%"=="11" call "%~dp011_Pending_Actions\Pending-Actions.cmd"
if /I "%choice%"=="S" call :SELFTEST
if /I "%choice%"=="Q" exit /b 0

if /I "%choice%"=="1" goto :AFTER_TOOL
if /I "%choice%"=="2" goto :AFTER_TOOL
if /I "%choice%"=="3" goto :AFTER_TOOL
if /I "%choice%"=="4" goto :AFTER_TOOL
if /I "%choice%"=="5" goto :AFTER_TOOL
if /I "%choice%"=="6" goto :AFTER_TOOL
if /I "%choice%"=="7" goto :AFTER_TOOL
if /I "%choice%"=="8" goto :AFTER_TOOL
if /I "%choice%"=="9" goto :AFTER_TOOL
if /I "%choice%"=="10" goto :AFTER_TOOL
if /I "%choice%"=="11" goto :AFTER_TOOL
if /I "%choice%"=="S" goto :AFTER_TOOL

echo Invalid selection.
goto :MENU

:AFTER_TOOL
echo.
echo Press any key to return to the WinPE Offline Companion menu.
pause >nul
goto :MENU

:SELFTEST
echo.
echo WINPE OFFLINE COMPANION SELF-TEST
set "FT_FAIL=0"
for %%C in (cmd.exe dism.exe sfc.exe bcdboot.exe bcdedit.exe manage-bde.exe reg.exe robocopy.exe diskpart.exe drvload.exe wpeinit.exe mountvol.exe ipconfig.exe route.exe arp.exe net.exe) do (
  if not exist "%SystemRoot%\System32\%%C" (
    echo MISSING: %%C
    set "FT_FAIL=1"
  ) else (
    echo FOUND:   %%C
  )
)
for %%F in (
  "00_Common\WinPE-Common.cmd"
  "01_Detect_Offline_Windows\Detect-Offline-Windows.cmd"
  "02_Disk_Layout\Disk-Layout.cmd"
  "03_Offline_SFC\Offline-SFC.cmd"
  "04_Offline_DISM\Offline-DISM.cmd"
  "05_Boot_EFI\Boot-EFI-Repair.cmd"
  "06_BitLocker\BitLocker-Offline.cmd"
  "07_Offline_Registry\Offline-Registry-Audit.cmd"
  "08_Data_Rescue\Data-Rescue.cmd"
  "09_Log_Harvester\Log-Harvester.cmd"
  "10_Driver_Network\Driver-Network.cmd"
  "11_Pending_Actions\Pending-Actions.cmd"
) do (
  if not exist "%~dp0%%~F" (
    echo MISSING FILE: %%~F
    set "FT_FAIL=1"
  )
)
if "%FT_FAIL%"=="0" (
  echo RESULT: PASS
) else (
  echo RESULT: ATTENTION
)
exit /b %FT_FAIL%

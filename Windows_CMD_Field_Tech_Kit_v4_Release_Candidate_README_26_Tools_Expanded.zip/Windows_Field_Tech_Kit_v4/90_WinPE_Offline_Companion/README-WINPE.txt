WINDOWS FIELD TECH TOOLKIT v4 - WINPE OFFLINE COMPANION
========================================================

PURPOSE
-------
This is a separate offline-recovery companion to the normal 158-tool Windows
Field Tech Toolkit. It does not add a Tool 159 and does not change the normal
Basic / Advanced / Tools / Repair catalog.

When RUN-WINDOWS-FIELD-TECH.cmd detects Windows PE / Windows RE, the root
launcher automatically hands off to:
  90_WinPE_Offline_Companion\RUN-WINPE-OFFLINE-TECH.cmd

The companion can also be launched directly.

DESIGN
------
The offline path is intentionally native-CMD first. It does not require
PowerShell, .NET, or optional WinPE PowerShell components.

It follows the same operating philosophy as the main toolkit:
  Identify -> Inventory -> Diagnose -> Repair -> Verify -> Document

Read-only workflows run directly. State-changing workflows explain the change,
identify the target, require an exact confirmation phrase, run the native
Windows recovery tool, and save non-secret output under the main toolkit Logs\WinPE_Offline folder
(or TEMP if the toolkit media is not writable).

OFFLINE WORKFLOWS
-----------------
1. Detect Offline Windows Installations
   Scans unlocked drive letters for Windows installations and queries basic
   version/build evidence from the offline SOFTWARE hive.

2. Disk / Volume Layout Inventory
   Uses read-only DiskPart list commands, MountVol, and BCDEdit evidence.

3. Offline SFC
   Offers /VERIFYONLY or confirmed /SCANNOW with explicit offline boot and
   Windows paths.

4. Offline DISM
   CheckHealth, ScanHealth, package inventory, and confirmed RestoreHealth.

5. Boot / EFI Repair Assistant
   Uses BCDBOOT only. It never automatically formats, cleans, repartitions, or
   runs bootrec /fixmbr or /fixboot. The technician must deliberately mount and
   identify the EFI/System partition.

6. BitLocker Status / Safe Unlock
   Status is read-only. Password unlock delegates the secret prompt directly to
   manage-bde. .BEK recovery-key files are supported. The companion does not
   wrap 48-digit recovery-password entry because manage-bde requires that secret
   as a command-line argument; the toolkit will not place a recovery password in
   its own process command line, logs, or reports.

7. Offline Registry Audit
   Temporarily loads SYSTEM/SOFTWARE hives for read-only version, setup-state,
   control-set, and pending-rename evidence, then unloads them.

8. Data Rescue
   Robocopy-based recursive copy. No /MIR, /PURGE, /MOVE, or source deletion.

9. Offline Log Harvester
   Collects CBS, DISM, Panther, MoSetup, Startup Repair, event logs, SetupAPI,
   and Windows Update reporting evidence. It intentionally excludes registry
   hives, credential stores, browser data, and user-profile contents.

10. Driver / Network Bring-Up
    Initializes WinPE networking, records network state, loads one driver INF
    into the current WinPE session, or maps an SMB share using the Windows
    password prompt.

11. Pending Update / Revert Actions
    Inspects pending servicing evidence. RevertPendingActions is isolated behind
    a high-impact typed confirmation and is intended only for boot-recovery use.

SCOPE / SAFETY
--------------
- No password, Wi-Fi key, or BitLocker recovery password is collected or logged.
- No automatic disk formatting, partition creation/deletion, or BCD partition
  selection occurs.
- No automatic BitLocker recovery-password handling.
- No offline registry editing workflow is included in this first release.
- No automatic Windows installation selection when multiple candidates exist.
- Data rescue never mirrors/purges the source.
- Repair outputs are evidence, not proof that the machine is fixed; reboot and
  verify on the installed Windows system afterward.

WINPE / WINRE NOTES
-------------------
The companion itself requires only native Windows recovery commands. PowerShell
support is optional. If you build a custom WinPE image with PowerShell, current
Microsoft documentation requires the WinPE optional-component dependency chain:
WinPE-WMI -> WinPE-NetFX -> WinPE-Scripting -> WinPE-PowerShell.

Windows PE and Windows RE do not provide general Wi-Fi networking support in
the same way as a normal Windows installation. Plan on Ethernet or another
supported network path when network access is required.

BitLocker password unlock is delegated to:
  manage-bde -unlock <drive> -password
which lets manage-bde present its own password prompt.

FIELD USE
---------
Boot WinPE/WinRE, attach or mount the toolkit media, and run:
  RUN-WINDOWS-FIELD-TECH.cmd

The normal launcher will detect MiniNT and route to the offline companion.

@echo off
setlocal EnableExtensions
set "COMMON=%~dp0..\00_Common\WinPE-Common.cmd"
call "%COMMON%" INIT

echo WINDOWS FIELD TECH TOOLKIT v4 - DATA RESCUE COPY
echo This workflow reads from the source and copies to the destination.
echo It does NOT use /MIR, /PURGE, /MOVE, or delete source data.
echo.

set "SRC="
set /p "SRC=Source folder: "
if not exist "%SRC%" (
  echo Source folder not found.
  exit /b 2
)
set "DST="
set /p "DST=Destination folder: "
if "%DST%"=="" (
  echo Destination is required.
  exit /b 2
)

echo.
echo Source:      %SRC%
echo Destination: %DST%
echo Copy policy: recursive, preserve data/attributes/timestamps, skip junctions,
echo              one retry, no source deletion.
echo.
set "ACK="
set /p "ACK=Type COPY DATA exactly to continue: "
if not "%ACK%"=="COPY DATA" (
  echo Canceled. No files were copied.
  exit /b 0
)

set "LOG=%WINPE_LOGROOT%\Data-Rescue_%WINPE_STAMP%.txt"
robocopy "%SRC%" "%DST%" /E /COPY:DAT /DCOPY:T /R:1 /W:1 /XJ /ZB /TEE /LOG:"%LOG%"
set "RC=%errorlevel%"

echo.
if %RC% LSS 8 (
  echo Robocopy result %RC%: completed without a Robocopy failure code.
  exit /b 0
)
echo Robocopy result %RC%: one or more copy failures occurred. Review %LOG%.
exit /b %RC%

@echo off
setlocal EnableExtensions
set "COMMON=%~dp0..\00_Common\WinPE-Common.cmd"
call "%COMMON%" INIT
call "%COMMON%" TARGET
if errorlevel 1 exit /b 2

set "DEST=%WINPE_LOGROOT%\Offline-Harvest_%WINPE_STAMP%"
md "%DEST%" >nul 2>&1
if not exist "%DEST%" (
  echo Could not create harvest destination: %DEST%
  exit /b 3
)

echo WINDOWS FIELD TECH TOOLKIT v4 - OFFLINE LOG HARVESTER
echo Target: %OFFLINE_WIN%\Windows
echo Destination: %DEST%
echo.
echo Collecting recovery-relevant logs. Registry hives, credential stores,
echo browser data, and user profile contents are intentionally excluded.

if exist "%OFFLINE_WIN%\Windows\Logs\CBS" robocopy "%OFFLINE_WIN%\Windows\Logs\CBS" "%DEST%\CBS" /E /R:0 /W:0 /XJ >nul
if exist "%OFFLINE_WIN%\Windows\Logs\DISM" robocopy "%OFFLINE_WIN%\Windows\Logs\DISM" "%DEST%\DISM" /E /R:0 /W:0 /XJ >nul
if exist "%OFFLINE_WIN%\Windows\Panther" robocopy "%OFFLINE_WIN%\Windows\Panther" "%DEST%\Panther" /E /R:0 /W:0 /XJ >nul
if exist "%OFFLINE_WIN%\Windows\Logs\MoSetup" robocopy "%OFFLINE_WIN%\Windows\Logs\MoSetup" "%DEST%\MoSetup" /E /R:0 /W:0 /XJ >nul
if exist "%OFFLINE_WIN%\Windows\System32\LogFiles\Srt" robocopy "%OFFLINE_WIN%\Windows\System32\LogFiles\Srt" "%DEST%\Srt" /E /R:0 /W:0 /XJ >nul
if exist "%OFFLINE_WIN%\Windows\System32\winevt\Logs" robocopy "%OFFLINE_WIN%\Windows\System32\winevt\Logs" "%DEST%\EventLogs" *.evtx /R:0 /W:0 >nul
if exist "%OFFLINE_WIN%\Windows\INF\setupapi.dev.log" copy /y "%OFFLINE_WIN%\Windows\INF\setupapi.dev.log" "%DEST%\" >nul
if exist "%OFFLINE_WIN%\Windows\INF\setupapi.app.log" copy /y "%OFFLINE_WIN%\Windows\INF\setupapi.app.log" "%DEST%\" >nul
if exist "%OFFLINE_WIN%\Windows\SoftwareDistribution\ReportingEvents.log" copy /y "%OFFLINE_WIN%\Windows\SoftwareDistribution\ReportingEvents.log" "%DEST%\" >nul

> "%DEST%\HARVEST-NOTE.txt" echo Windows Field Tech Toolkit v4 Offline Log Harvest
>>"%DEST%\HARVEST-NOTE.txt" echo Source Windows: %OFFLINE_WIN%\Windows
>>"%DEST%\HARVEST-NOTE.txt" echo Privacy scope: recovery logs only; no registry hives or user-profile data collected.

echo Harvest complete.
echo %DEST%
exit /b 0

@echo off
setlocal EnableExtensions
set "COMMON=%~dp0..\00_Common\WinPE-Common.cmd"
call "%COMMON%" INIT
call "%COMMON%" TARGET
if errorlevel 1 exit /b 2

:MENU
echo.
echo WINDOWS FIELD TECH TOOLKIT v4 - OFFLINE DISM
echo Target image: %OFFLINE_WIN%\
echo.
echo 1. CheckHealth
echo 2. ScanHealth
echo 3. Get Packages
echo 4. RestoreHealth - state changing
echo Q. Cancel
set "mode="
set /p "mode=Select: "
if /I "%mode%"=="Q" exit /b 0
if "%mode%"=="1" goto :CHECK
if "%mode%"=="2" goto :SCAN
if "%mode%"=="3" goto :PACKAGES
if "%mode%"=="4" goto :RESTORE
echo Invalid selection.
goto :MENU

:CHECK
set "LOG=%WINPE_LOGROOT%\Offline-DISM-CheckHealth_%WINPE_STAMP%.txt"
dism /Image:%OFFLINE_WIN%\ /Cleanup-Image /CheckHealth >"%LOG%" 2>&1
set "RC=%errorlevel%"
type "%LOG%"
exit /b %RC%

:SCAN
set "LOG=%WINPE_LOGROOT%\Offline-DISM-ScanHealth_%WINPE_STAMP%.txt"
dism /Image:%OFFLINE_WIN%\ /Cleanup-Image /ScanHealth >"%LOG%" 2>&1
set "RC=%errorlevel%"
type "%LOG%"
exit /b %RC%

:PACKAGES
set "LOG=%WINPE_LOGROOT%\Offline-DISM-Packages_%WINPE_STAMP%.txt"
dism /Image:%OFFLINE_WIN%\ /Get-Packages >"%LOG%" 2>&1
set "RC=%errorlevel%"
type "%LOG%"
exit /b %RC%

:RESTORE
echo.
echo STATE CHANGE: DISM RestoreHealth may modify the offline Windows component store.
echo Use a matching repair source when Windows cannot repair from the local store.
echo.
set "ACK="
set /p "ACK=Type DISM RESTORE exactly to continue: "
if not "%ACK%"=="DISM RESTORE" (
  echo Canceled. No repair was started.
  exit /b 0
)
set "SOURCE="
set /p "SOURCE=Optional DISM source, e.g. WIM:D:\sources\install.wim:1 [blank for none]: "
set "LOG=%WINPE_LOGROOT%\Offline-DISM-RestoreHealth_%WINPE_STAMP%.txt"
if "%SOURCE%"=="" (
  dism /Image:%OFFLINE_WIN%\ /Cleanup-Image /RestoreHealth >"%LOG%" 2>&1
) else (
  dism /Image:%OFFLINE_WIN%\ /Cleanup-Image /RestoreHealth /Source:"%SOURCE%" /LimitAccess >"%LOG%" 2>&1
)
set "RC=%errorlevel%"
type "%LOG%"
exit /b %RC%

@echo off
setlocal EnableExtensions EnableDelayedExpansion
set "COMMON=%~dp0..\00_Common\WinPE-Common.cmd"
call "%COMMON%" INIT
set "LOG=%WINPE_LOGROOT%\Offline-Windows-Detection_%WINPE_STAMP%.txt"

echo WINDOWS FIELD TECH TOOLKIT v4 - OFFLINE WINDOWS DETECTION
echo Report: %LOG%
echo.
> "%LOG%" echo OFFLINE WINDOWS DETECTION
>>"%LOG%" echo Generated in WinPE/WinRE recovery environment.
>>"%LOG%" echo.

set /a COUNT=0
for %%D in (C D E F G H I J K L M N O P Q R S T U V W X Y Z) do (
  if exist "%%D:\Windows\System32\Config\SYSTEM" (
    set /a COUNT+=1
    echo Candidate !COUNT!: %%D:\Windows
    >>"%LOG%" echo Candidate !COUNT!: %%D:\Windows

    reg unload HKLM\FT_OFFLINE_SOFTWARE >nul 2>&1
    reg load HKLM\FT_OFFLINE_SOFTWARE "%%D:\Windows\System32\Config\SOFTWARE" >nul 2>&1
    if not errorlevel 1 (
      >>"%LOG%" echo.
      >>"%LOG%" echo Windows version evidence:
      reg query "HKLM\FT_OFFLINE_SOFTWARE\Microsoft\Windows NT\CurrentVersion" /v ProductName >>"%LOG%" 2>&1
      reg query "HKLM\FT_OFFLINE_SOFTWARE\Microsoft\Windows NT\CurrentVersion" /v DisplayVersion >>"%LOG%" 2>&1
      reg query "HKLM\FT_OFFLINE_SOFTWARE\Microsoft\Windows NT\CurrentVersion" /v CurrentBuildNumber >>"%LOG%" 2>&1
      reg query "HKLM\FT_OFFLINE_SOFTWARE\Microsoft\Windows NT\CurrentVersion" /v UBR >>"%LOG%" 2>&1
      reg unload HKLM\FT_OFFLINE_SOFTWARE >nul 2>&1
    )
    >>"%LOG%" echo.
  )
)

if !COUNT! EQU 0 (
  echo No accessible Windows installation was detected.
  echo A BitLocker-locked OS volume may need to be unlocked first.
  >>"%LOG%" echo No accessible Windows installation was detected.
)

echo.
echo Detailed evidence:
type "%LOG%"
exit /b 0

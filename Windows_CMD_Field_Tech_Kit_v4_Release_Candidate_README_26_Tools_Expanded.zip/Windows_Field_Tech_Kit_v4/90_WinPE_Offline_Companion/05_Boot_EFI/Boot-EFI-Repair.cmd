@echo off
setlocal EnableExtensions
set "COMMON=%~dp0..\00_Common\WinPE-Common.cmd"
call "%COMMON%" INIT
call "%COMMON%" TARGET
if errorlevel 1 exit /b 2

echo.
echo WINDOWS FIELD TECH TOOLKIT v4 - BOOT / EFI REPAIR ASSISTANT
echo This workflow uses BCDBOOT only. It does not run bootrec /fixmbr,
echo bootrec /fixboot, format, clean, or automatic partition reassignment.
echo.
echo Current WinPE firmware evidence:
wpeutil UpdateBootInfo >nul 2>&1
reg query HKLM\SYSTEM\CurrentControlSet\Control /v PEFirmwareType 2>nul
echo.
echo Disk and volume layout should be reviewed before continuing.
echo If the EFI/System partition has no drive letter, use DiskPart manually
echo and deliberately assign one before running this workflow.
echo.

set "SYSVOL="
set /p "SYSVOL=Mounted EFI/System partition drive letter, for example S: "
call "%COMMON%" DRIVE "%SYSVOL%"
if errorlevel 1 (
  echo Invalid or inaccessible system partition drive.
  exit /b 2
)
set "SYSVOL=%WINPE_DRIVE%"

set "FWMODE="
set /p "FWMODE=Firmware target UEFI, BIOS, or ALL: "
if /I "%FWMODE%"=="UEFI" set "FWMODE=UEFI"
if /I "%FWMODE%"=="BIOS" set "FWMODE=BIOS"
if /I "%FWMODE%"=="ALL" set "FWMODE=ALL"
if not "%FWMODE%"=="UEFI" if not "%FWMODE%"=="BIOS" if not "%FWMODE%"=="ALL" (
  echo Invalid firmware target.
  exit /b 2
)

echo.
echo STATE CHANGE: BCDBOOT will create or replace boot files on %SYSVOL%.
echo Offline Windows source: %OFFLINE_WIN%\Windows
echo Firmware target: %FWMODE%
echo No partition formatting will be performed.
echo.
set "ACK="
set /p "ACK=Type BCDBOOT exactly to continue: "
if not "%ACK%"=="BCDBOOT" (
  echo Canceled. No boot files were changed.
  exit /b 0
)

set "LOG=%WINPE_LOGROOT%\BCDBoot_%WINPE_STAMP%.txt"
bcdboot "%OFFLINE_WIN%\Windows" /s %SYSVOL% /f %FWMODE% >"%LOG%" 2>&1
set "RC=%errorlevel%"
type "%LOG%"
exit /b %RC%
